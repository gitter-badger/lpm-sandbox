/* -----------------------------------------------------------------------------
** Copyright (c) 2012 Advanced Resources and Risk Technology, LLC
** All rights reserved.
**
** This file is part of Advanced Resources and Risk Technology, LLC (AR2TECH) 
** version of the open source software sgems.  It is a derivative work by 
** AR2TECH (THE LICENSOR) based on the x-free license granted in the original 
** version of the software (see notice below) and now sublicensed such that it 
** cannot be distributed or modified without the explicit and written permission 
** of AR2TECH.
**
** Only AR2TECH can modify, alter or revoke the licensing terms for this 
** file/software.
**
** This file cannot be modified or distributed without the explicit and written 
** consent of AR2TECH.
**
** Contact Dr. Alex Boucher (aboucher@ar2tech.com) for any questions regarding
** the licensing of this file/software
**
** The open-source version of sgems can be downloaded at 
** sourceforge.net/projects/sgems.
** ----------------------------------------------------------------------------*/



/**********************************************************************
** Author: Nicolas Remy
** Copyright (C) 2002-2004 The Board of Trustees of the Leland Stanford Junior
**   University
** All rights reserved.
**
** This file is part of the "geostat" module of the Geostatistical Earth
** Modeling Software (GEMS)
**
** This file may be distributed and/or modified under the terms of the 
** license defined by the Stanford Center for Reservoir Forecasting and 
** appearing in the file LICENSE.XFREE included in the packaging of this file.
**
** This file may be distributed and/or modified under the terms of the
** GNU General Public License version 2 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** See http://www.gnu.org/copyleft/gpl.html for GPL licensing information.
**
** Contact the Stanford Center for Reservoir Forecasting, Stanford University
** if any conditions of this licensing are not clear to you.
**
**********************************************************************/
#include <cstdio>
#include "convex_kriging_algo.h"
#include <geostat/kriging.h>
#include <geostat/parameters_handler.h>
#include <utils/gstl_messages.h>
#include <utils/string_manipulation.h>
#include <utils/error_messages_handler.h>
#include <grid/geostat_grid.h>
#include <grid/point_set.h>
#include <grid/combined_neighborhood.h>
#include <grid/gval_iterator.h>
#include <utils/manager_repository.h>
#include <grid/cartesian_grid.h>
#include <grid/point_set.h>
#include <grid/grid_region.h>
#include <grid/grid_path.h>
#include <appli/utilities.h>
#include <vector>
#include <math.h>
#include <qmath.h>
#include <string>
#include <GsTL/kriging/kriging_weights.h>
#include <GsTL/geometry/Block_covariance.h>


Named_interface* Convex_kriging::create_new_interface( std::string& ) {
  return new Convex_kriging;
}


Convex_kriging::Convex_kriging()
  : Kconstraints_(0), combiner_(0),simul_grid_(0),harddata_grid_(0),
    neighborhood_(0), min_neigh_(0) {
}
 

Convex_kriging::~Convex_kriging() {
  if( Kconstraints_ )
    delete Kconstraints_;

  if( combiner_ )
    delete combiner_;

  if( harddata_grid_!=0 && dynamic_cast<Point_set*>(harddata_grid_) ) {
      harddata_grid_->set_coordinate_mapper(0);
  }

 // if(blk_covar_)
 //   delete blk_covar_;
}


#include <cstdio>
int Convex_kriging::execute( GsTL_project* proj, Progress_notifier* notifier   ) {
  // those flags will be used to signal if some of the nodes could not be
  // informed
//	FILE* f = fopen("out_weight","w+");
//	FILE* g = fopen("out_avneg","w+");
	//std::vector<std::vector<double> > w(neighborhood_);
  bool issue_singular_system_warning = false;
  bool issue_no_conditioning_data_warning = false;

  // Set up a progress notifier	
  int total_steps = simul_grid_->size();
  int frequency = std::max( total_steps / 20, 1 );
  SmartPtr<Progress_notifier> progress_notifier = 
    utils::create_notifier( "Running Kriging", 
			    total_steps, frequency );

  // create the property
  appli_message("creating new property: " << property_name_ << "..." );
  Grid_continuous_property* prop = 
    geostat_utils::add_property_to_grid( simul_grid_, property_name_ );
  prop->set_parameters(parameters_);
  simul_grid_->select_property( prop->name() );
  
  // create property for kriging variance
  Grid_continuous_property* var_prop=0;
   Grid_continuous_property* nsamples_prop=0;
  Grid_continuous_property* aver_dist_prop=0;
  Grid_continuous_property* interpolation_prop=0;
  Grid_continuous_property* combined_prop=0;
  Grid_continuous_property* p_prop=0;
  Grid_continuous_property* c80_prop=0;
  Grid_continuous_property* c90_prop=0;
  Grid_continuous_property* c95_prop=0;
  Grid_continuous_property* c99_prop=0;
  Grid_continuous_property* c80_prop_scv_=0;
  Grid_continuous_property* c90_prop_scv_=0;
  Grid_continuous_property* c95_prop_scv_=0;
  Grid_continuous_property* c99_prop_scv_=0;
  Grid_continuous_property* c80_prop_svi_=0;
  Grid_continuous_property* c90_prop_svi_=0;
  Grid_continuous_property* c95_prop_svi_=0;
  Grid_continuous_property* c99_prop_svi_=0;
  Grid_continuous_property* ir_prop=0;
  Grid_continuous_property* sum_pos_prop=0;
  Grid_continuous_property* sum_weights_prop=0;
  Grid_continuous_property* lagrangian_prop=0;
  

  this->init_option_properties(prop->name(),var_prop,nsamples_prop,aver_dist_prop,interpolation_prop,combined_prop,p_prop,ir_prop,
	  c80_prop,c90_prop,c95_prop,c99_prop,
	  c80_prop_scv_,c90_prop_scv_,c95_prop_scv_,c99_prop_scv_,
	  c80_prop_svi_,c90_prop_svi_,c95_prop_svi_,c99_prop_svi_,
	  sum_pos_prop,sum_weights_prop, lagrangian_prop);



  //typedef Geostat_grid::iterator iterator;
 //iterator begin = simul_grid_->begin();
 // iterator end = simul_grid_->end();
  Grid_path path(simul_grid_, prop, target_grid_region_);
  Grid_path::iterator begin =path.begin();
  Grid_path::iterator end = path.end();
  
  for( ; begin != end; ++begin ) {
    if( !progress_notifier->notify() ) {
      clean( property_name_ );
      return 1;
    }

    if( begin->is_informed() ) continue;
      
    neighborhood_->find_neighbors( *begin );
    
    if( neighborhood_->size() < min_neigh_ )  continue;
    if(!neighborhood_->is_valid()) continue;


	const std::vector<Geovalue>& neigh_ = neighborhood_->get_neighbors();
/*
 //   if( neighborhood_->is_empty() ) {
    if( neighborhood_->size() < min_neigh_ ) {
      //if we don't have any conditioning data, skip the node
      issue_no_conditioning_data_warning = true;
      continue;
    }
*/
    double variance;

	

    int status;
    
    if(rhs_covar_blk_) {
      status  = kriging_weights_2( kriging_weights_, variance,
                                   *begin, *(neighborhood_.raw_ptr()),
                                   covar_,*rhs_covar_blk_, *Kconstraints_,rhs_covar_blk_->block_covariance()  );
    } 
    else {
      status = kriging_weights_2( kriging_weights_, variance,
                                  *begin, *(neighborhood_.raw_ptr()),
                                  covar_,*rhs_covar_, *Kconstraints_, rhs_covar_->c0() );
    }

    if(status == 0) {

	   	// the kriging system could be solved
    	double estimate = (*combiner_)( kriging_weights_.begin(), 
		                            			kriging_weights_.end(),
					                            *(neighborhood_.raw_ptr()) );

//----------------------------------------------------------------------------------------------------
//calculando o indice de risco para krigagem dos indicadores

	  //double termo1 = 0.0, termo2 =0.0, termo3=0.0, termo4 = 0.0, ir = 0.0;
	  //termo1 = pow(1-estimate,2);
	  //termo2 = pow(variance,2);
	  //termo3 = termo1 + termo2;
	  //termo4 = sqrt(termo3);
	  //ir = termo4;
//----------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------
//calculo erro variancia
		
		double t_99_[] = {63.66,9.92,5.84,4.60,4.03,3.71,3.50,3.36,3.25,3.17,3.11,3.06,3.01,2.98,2.95,2.92,2.90,2.88,2.86,2.84,2.83,2.82,2.81,2.80,2.79,2.78,2.77,2.76,2.76,2.75,2.58};
		double t_95_[] = {12.71,4.30,3.18,2.78,2.57,2.45,2.36,2.31,2.26,2.23,2.20,2.18,2.16,2.14,2.13,2.12,2.11,2.10,2.09,2.09,2.08,2.07,2.07,2.06,2.06,2.06,2.05,2.05,2.04,2.04,1.96};
		double t_90_[] = {6.31,2.92,2.35,2.13,2.02,1.94,1.90,1.86,1.83,1.81,1.80,1.78,1.77,1.76,1.75,1.75,1.74,1.73,1.73,1.72,1.72,1.72,1.71,1.71,1.71,1.71,1.70,1.70,1.70,1.70,1.64};
		double t_80_[] = {3.08,1.89,1.64,1.53,1.48,1.44,1.41,1.40,1.38,1.37,1.36,1.36,1.35,1.34,1.34,1.34,1.33,1.33,1.33,1.32,1.32,1.32,1.32,1.32,1.32,1.31,1.31,1.31,1.31,1.31,1.28};
		

		/*
		double t_99_[] = {63.7,9.9,5.8,4.6,4.0,3.7,3.5,3.4,3.2,3.2,3.1,3.1,3.0,3.0,2.9,2.9,2.9,2.9,2.9,2.8,2.8,2.8,2.8,2.8,2.8,2.8,2.8,2.8,2.8,2.7,2.6};
		double t_95_[] = {12.7,4.3,3.2,2.8,2.6,2.4,2.4,2.3,2.3,2.2,2.2,2.2,2.2,2.1,2.1,2.1,2.1,2.1,2.1,2.1,2.1,2.1,2.1,2.1,2.1,2.1,2.0,2.0,2.0,2.0,2.0};
		double t_90_[] = {6.3,2.9,2.3,2.1,2.0,1.9,1.9,1.9,1.8,1.8,1.8,1.8,1.8,1.8,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.7,1.6};
		double t_80_[] = {3.1,1.9,1.6,1.5,1.5,1.4,1.4,1.4,1.4,1.4,1.4,1.4,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3};
		*/
		double n = neighborhood_->size(),vlr_t80=0.0,vlr_t90=0.0,vlr_t95=0.0,vlr_t99=0.0,erro_num_80_=0.0,erro_num_90_=0.0,
			erro_num_95_=0.0,erro_num_99_=0.0,erro_var_c80_=0.0,erro_var_c90_=0.0,
			erro_var_c95_=0.0,erro_var_c99_=0.0;
		double erro_deno=0.0;
		int t=0;
		int v=0;
		 
		v = n-2;

		if(v<1){
		 t = 1;
		}
		
		t = v;

		int nd = 0;

		nd = nblock_pts_[0] * nblock_pts_[1] * nblock_pts_[2];

		if(nd<1){ 

		 vlr_t80 = t_80_[t];
		 vlr_t90 = t_90_[t];
		 vlr_t95 = t_95_[t];
		 vlr_t99 = t_99_[t];

		 erro_num_80_ = sqrt(variance)*t_80_[t];
		 erro_num_90_ = sqrt(variance)*t_90_[t];
		 erro_num_95_ = sqrt(variance)*t_95_[t];
		 erro_num_99_ = sqrt(variance)*t_99_[t];

		 erro_deno = estimate*sqrt(n);

		 erro_var_c80_ = 100*(erro_num_80_/erro_deno);
		 erro_var_c90_ = 100*(erro_num_90_/erro_deno);
		 erro_var_c95_ = 100*(erro_num_95_/erro_deno);
		 erro_var_c99_ = 100*(erro_num_99_/erro_deno);

		}

		else{

		 vlr_t80 = t_80_[t];
		 vlr_t90 = t_90_[t];
		 vlr_t95 = t_95_[t];
		 vlr_t99 = t_99_[t];

		 erro_num_80_ = sqrt(variance)*t_80_[t];
		 erro_num_90_ = sqrt(variance)*t_90_[t];
		 erro_num_95_ = sqrt(variance)*t_95_[t];
		 erro_num_99_ = sqrt(variance)*t_99_[t];

		 erro_deno = estimate*sqrt(n);
		 //erro_deno = estimate*pow(nd,0.5);

		 erro_var_c80_ = 100*(erro_num_80_/erro_deno);
		 erro_var_c90_ = 100*(erro_num_90_/erro_deno);
		 erro_var_c95_ = 100*(erro_num_95_/erro_deno);
		 erro_var_c99_ = 100*(erro_num_99_/erro_deno);


		 }
		
		//int erro_var_80_= ceil(erro_var_c80_);
		//int erro_var_90_= ceil(erro_var_c90_);
		//int erro_var_95_= ceil(erro_var_c95_);
		//int erro_var_99_= ceil(erro_var_c99_);

		//int erro_var_c80_ = erro_var_c80;
		//int erro_var_c90_ = erro_var_c90;
		//int erro_var_c95_ = erro_var_c95;
		//int erro_var_c99_ = erro_var_c99;
//--------------------------------------------------------------------------------------------
//inserir codigo da correcao dos pesos AQUI!!!!
		
		double c_0 = 0.0;
		
		if(rhs_covar_blk_){
		c_0 = rhs_covar_blk_->c0();
		}
		else
		 c_0 = rhs_covar_->c0();
		

		int nw = 0, grid=0, nwav =0;
		double avnegw = 0.0, avgcov =0.0 , cov=0.0, sumwt = 0.0 , est=0.0, sumwtb = 0.0, p1=0.0, p =0.0;
		est = estimate;		
		double pesoneg =0.0;
		float val=0.0, teste=0.0;
		double c = -666, vr =0.0, sw1 =0.0, sw2=0.0, sw3 =0.0, sw =0.0, svi1 = 0.0, svi =0.0, ne = 0.0, s = 0.0, nume=0.0, nume1=0.0,deno=0.0 , deno1=0.0;
		double data=0.0;
		double peso=0.0;
		
		

		//calculo do angulo de regressao linear
		for(size_t i = 0; i<neighborhood_->size();++i){
			
			peso = kriging_weights_[i];
			data = neigh_[i].property_value();

			//c = covar_(neighborhood_->center(),  neigh_[i]);
			nume1 = kriging_weights_[i] * covar_(neighborhood_->center(),  neigh_[i]) ;
			nume = nume + nume1;
			deno1 = deno1 + nume1; 

					
		}

		deno = deno1 -kriging_weights_[neighborhood_->size()];

		p = nume/ deno;
		
		
		
		//calculo da variancia combinada
		for(size_t i = 0; i<neighborhood_->size();++i){
		 vr = neigh_[i].property_value(); // pega valores da vizinhanca
		 sw1 = pow(kriging_weights_[i],2);
		 sw2 = pow(estimate - vr,2);
		 sw3 = sw1 * sw2;
		 sw = sw3 + sw;

		
	}
		float scv1 = variance * sw;
		float scv = sqrt(scv1);//combined variance

//-------------------------------------------------------------------------------------------
//calculo erro variancia combinada

		double erro_scv_c80_ =0.0, erro_scv_c90_ =0.0, erro_scv_c95_ =0.0, erro_scv_c99_ =0.0;
		

		if(nd<1){ 

		 erro_num_80_ = sqrt(scv)*t_80_[t];
		 erro_num_90_ = sqrt(scv)*t_90_[t];
		 erro_num_95_ = sqrt(scv)*t_95_[t];
		 erro_num_99_ = sqrt(scv)*t_99_[t];

		 erro_deno = estimate*sqrt(n);

		 erro_scv_c80_ = 100*(erro_num_80_/erro_deno);
		 erro_scv_c90_ = 100*(erro_num_90_/erro_deno);
		 erro_scv_c95_ = 100*(erro_num_95_/erro_deno);
		 erro_scv_c99_ = 100*(erro_num_99_/erro_deno);

		}

		else{

		
		 erro_num_80_ = sqrt(scv)*t_80_[t];
		 erro_num_90_ = sqrt(scv)*t_90_[t];
		 erro_num_95_ = sqrt(scv)*t_95_[t];
		 erro_num_99_ = sqrt(scv)*t_99_[t];

		 erro_deno = estimate*pow(nd,0.5);

		 erro_scv_c80_ = 100*(erro_num_80_/erro_deno);
		 erro_scv_c90_ = 100*(erro_num_90_/erro_deno);
		 erro_scv_c95_ = 100*(erro_num_95_/erro_deno);
		 erro_scv_c99_ = 100*(erro_num_99_/erro_deno);


		 }

//--------------------------------------------------------------------------------------------
		//corrigindo os pesos negativos
		
				
		for(size_t i = 0; i<neighborhood_->size();++i){
			
			//verificando o numero de pesos negativos
			if(kriging_weights_[i]<0) {
				++nw;
				pesoneg = kriging_weights_[i];// se peso negativo, recebe zero
				avnegw -= pesoneg;
				avgcov += covar_(neighborhood_->center(),  neigh_[i]);//calculando a covariancia
				
			}
			
		}

		if (nw > 0) {
			avnegw /= nw;//media dos pesos negativos
			avgcov /= nw;//media das covariancias que receberam pesos negativos
		}

		if (nw > 0) {
			nw = 0;
			int countavcov_neg = 0, nw2=0;
			for(size_t i = 0; i<neighborhood_->size();++i){
				
				c = covar_(neighborhood_->center(),  neigh_[i]);
				
				double x = neighborhood_->center().xyz_location().x();
				double y = neighborhood_->center().xyz_location().y();
				double z = neighborhood_->center().xyz_location().z();

				

				if ( (kriging_weights_[i] > 0 && c < avgcov && kriging_weights_[i] < avnegw)) {
					++countavcov_neg;
					kriging_weights_[i] = 0;//peso negativo recebe zero, caso atenda a essa condicao
					
					}
		
				if(kriging_weights_[i] < 0){
					++nw2;
					kriging_weights_[i] = 0;//peso negativo recebe zero, caso atenda a essa condicao
				
					}

				sumwt += kriging_weights_[i];  //soma dos pesos
			}

			for(size_t i = 0; i<neighborhood_->size();++i){
				double weith = 0.0;
				weith = kriging_weights_[i] / sumwt; //re-escalonacao dos pesos
				kriging_weights_[i] = weith;
				sumwtb += kriging_weights_[i]; //somatoria dos pesos
				
			}

		}
		
//-------------------------------------------------------------------------------------------------------

	// recalculando a estimativa com os novos pesos
	double estm = (*combiner_)( kriging_weights_.begin(), 
		                            			kriging_weights_.end(),
					                            *(neighborhood_.raw_ptr()) );
	
	// recalculando a variancia
	double var_c = 0.0, var_c1=0.0, var = 0.0;
	for(size_t i = 0; i<neighborhood_->size();++i){
		c = covar_(neighborhood_->center(),  neigh_[i]);
		var_c1 = c * kriging_weights_[i];
		var_c = var_c + var_c1;

	}
	
	variance;

	
	var = c_0 - var_c - kriging_weights_[neighborhood_->size()] ;
	


	//calculo da variancia de interpolacao
	for(size_t i = 0; i<neighborhood_->size();++i){
		//calculo da variancia de interpolacao
		 vr = neigh_[i].property_value(); // pega valores da vizinhanca
		 sw1 = pow(kriging_weights_[i],2);
		 sw2 = pow(estm - vr,2);
		 sw3 = sw1 * sw2;
		 sw = sw3 + sw;

		 //calculo da variancia de interpolacao
		 svi1 = kriging_weights_[i] * sw2;
		 svi = svi1 + svi;
	}
//-------------------------------------------------------------------------------------------
//calculo erro variancia de interpolacao

	double erro_svi_c80_ =0.0, erro_svi_c90_ =0.0, erro_svi_c95_ =0.0, erro_svi_c99_ =0.0;

		if(nd<1){ 

		 
		 erro_num_80_ = sqrt(svi)*t_80_[t];
		 erro_num_90_ = sqrt(svi)*t_90_[t];
		 erro_num_95_ = sqrt(svi)*t_95_[t];
		 erro_num_99_ = sqrt(svi)*t_99_[t];

		 erro_deno = estimate*sqrt(n);

		 erro_svi_c80_ = 100*(erro_num_80_/erro_deno);
		 erro_svi_c90_ = 100*(erro_num_90_/erro_deno);
		 erro_svi_c95_ = 100*(erro_num_95_/erro_deno);
		 erro_svi_c99_ = 100*(erro_num_99_/erro_deno);

		}

		else{

		 vlr_t80 = t_80_[t];
		 vlr_t90 = t_90_[t];
		 vlr_t95 = t_95_[t];
		 vlr_t99 = t_99_[t];

		 erro_num_80_ = sqrt(svi)*t_80_[t];
		 erro_num_90_ = sqrt(svi)*t_90_[t];
		 erro_num_95_ = sqrt(svi)*t_95_[t];
		 erro_num_99_ = sqrt(svi)*t_99_[t];

		 erro_deno = estimate*pow(nd,0.5);

		 erro_svi_c80_ = 100*(erro_num_80_/erro_deno);
		 erro_svi_c90_ = 100*(erro_num_90_/erro_deno);
		 erro_svi_c95_ = 100*(erro_num_95_/erro_deno);
		 erro_svi_c99_ = 100*(erro_num_99_/erro_deno);


		 }


//----------------------------------------------------------------------------------------------------	
     
	  begin->set_property_value( estm ); // nova estimativa com os pesos corrigidos
	  
	  //calculo do indice de risco
	  double termo1 = 0.0, termo2 =0.0, termo3=0.0, termo4 = 0.0, ir = 0.0;
	  termo1 = pow(1-estm,2);
	  termo2 = pow(var,2);
	  termo3 = termo1 + termo2;
	  termo4 = sqrt(termo3);
	  ir = termo4;


      if (output_krig_var_){
		  var_prop->set_value( var, begin->node_id() );
		 
		  if(output_c80_){
			c80_prop->set_value(erro_var_c80_, begin->node_id());
			
		  }

		  if(output_c90_){
			c90_prop->set_value(erro_var_c90_, begin->node_id());
			
		  }
		  
		  if(output_c95_){
			c95_prop->set_value(erro_var_c95_, begin->node_id());
			
		  }

		   if(output_c99_){
			c99_prop->set_value(erro_var_c99_, begin->node_id());
			
		  }

	  }
	 

      if(output_average_distance_ && !neighborhood_->is_empty()) {
        float average_dist = 0.0;
        Neighborhood::const_iterator it = neighborhood_->begin();
        for(; it!=neighborhood_->end(); ++it) {
          average_dist += (begin->location()-it->location()).length();
        }
        aver_dist_prop->set_value( average_dist/neighborhood_->size(), begin->node_id() );
      }
	  
	  //setando valores no grid interpolation variance
	  if(output_krig_interp_var_){ 
		  interpolation_prop->set_value( svi, begin->node_id() );

		  if(output_c80_){
			c80_prop_svi_->set_value(erro_svi_c80_, begin->node_id());
		  }

		  if(output_c90_){
			c90_prop_svi_->set_value(erro_svi_c90_, begin->node_id());
		  }
		  
		  if(output_c95_){
			c95_prop_svi_->set_value(erro_svi_c95_, begin->node_id());
		  }

		   if(output_c99_){
			c99_prop_svi_->set_value(erro_svi_c99_, begin->node_id());
		  }
	  }
	 
	  //setando valores no grid combined variance
	  if(output_krig_combined_var_) {
		  
		  combined_prop->set_value( scv, begin->node_id() );
		  
		  if(output_c80_){
			c80_prop_scv_->set_value(erro_scv_c80_, begin->node_id());
		  }

		  if(output_c90_){
			c90_prop_scv_->set_value(erro_scv_c90_, begin->node_id());
		  }
		  
		  if(output_c95_){
			c95_prop_scv_->set_value(erro_scv_c95_, begin->node_id());
		  }

		  if(output_c99_){
			c99_prop_scv_->set_value(erro_scv_c99_, begin->node_id());
		  }
	  
	  }
	  //setando valores do angulo de regressao no grid
	  if(output_p_) p_prop->set_value( p, begin->node_id() );

	  //setando valores do indice de risco no grid
	  if(output_ir_) ir_prop->set_value( ir, begin->node_id() );


      if(output_n_samples_) nsamples_prop->set_value( neighborhood_->size(), begin->node_id() );
      
      if(output_sum_positive_weights_) {
        float sum_pos_weight =0.0;
        for(int i=0; i<neighborhood_->size();++i) {
          if(kriging_weights_[i] > 0) sum_pos_weight+=kriging_weights_[i];
			
		  
		}
		
        sum_pos_prop->set_value( sum_pos_weight, begin->node_id() );
		
      }
	 
      if(output_sum_weights_) {
        float sum_weight =0.0;
		for(int i=0; i<neighborhood_->size();++i) {
          sum_weight+=kriging_weights_[i];
		  
        }
		
        sum_weights_prop->set_value( sum_weight, begin->node_id() );
		
      }
	   
      //Here we assumed that the check was already done that there is lagrangian computed in the system
      if(output_lagrangian_) {  
        lagrangian_prop->set_value( kriging_weights_[neighborhood_->size()], begin->node_id() );
      }
	
    }
    else {
    	// the kriging system could not be solved, issue a warning and skip the
    	// node
      issue_singular_system_warning = true;
        
    }
	
  }



/* This pop-up windows breaks script

  if( issue_singular_system_warning )
    GsTLcerr << "Kriging could not be performed at some locations because\n"
             << "the kriging system was singular\n" 
             << gstlIO::end; 
  if( issue_no_conditioning_data_warning )
    GsTLcerr << "Kriging could not be performed at some locations because\n"
             << "the neighborhood of those locations was empty.\n"
             << "Try increasing the size of the search ellipsoid.\n"
             << gstlIO::end; 
*/
  
  return 0;
}


void Convex_kriging::clean( const std::string& prop ) {
  simul_grid_->remove_property( prop );
}




bool Convex_kriging::initialize( const Parameters_handler* parameters,
                                 Error_messages_handler* errors,
                             Progress_notifier* notifier ) {
  
  //-----------------
  // Extract the parameters input by the user from the parameter handler
  // Extract the parameters input by the user from the parameter handler

  std::string simul_grid_name = parameters->value( "Grid_Name.value" );
  errors->report( simul_grid_name.empty(), 
		  "Grid_Name", "No grid selected" );
  property_name_ = parameters->value( "Property_Name.value" );
  errors->report( property_name_.empty(), 
		  "Property_Name", "No property name specified" );


  // Get the simulation grid from the grid manager

  if( !simul_grid_name.empty() ) {
    bool ok = geostat_utils::create( simul_grid_, simul_grid_name,
				 "Grid_Name", errors );
    if( !ok ) return false;
  }
  else 
    return false;

  target_grid_region_ = simul_grid_->region(parameters->value( "Grid_Name.region" ));

  //gridTempRegionSelector_.set_temporary_region(
   //             parameters->value( "Grid_Name.region" ), simul_grid_);


  std::string harddata_grid_name = parameters->value( "Hard_Data.grid" );
  errors->report( harddata_grid_name.empty(), 
		  "Hard_Data", "No hard data specified" );
  harddata_property_name_ = parameters->value( "Hard_Data.property" );
  errors->report( harddata_property_name_.empty(), 
		  "Hard_Data", "No property name specified" );

  // Get the harddata grid from the grid manager
  if( !harddata_grid_name.empty() ) {
    bool ok = geostat_utils::create( harddata_grid_, harddata_grid_name,
				 "Hard_Data", errors );
    if( !ok ) return false;
  }
  else 
    return false;

  std::string harddata_region_name = parameters->value( "Hard_Data.region" );
  Grid_region* hd_region = harddata_grid_->region(harddata_region_name);

  // If the hard data is on the same grid than the
  // estimation grid, than it cannot be set to a region others than the one
  // already set on that grid
  // The is only used if the neighborhood is to consider only data within a region
 // if(harddata_grid_ !=  simul_grid_)
   //   hdgridTempRegionSelector_.set_temporary_region(
           //   parameters->value( "Hard_Data.region" ),harddata_grid_ );

  int max_neigh = 
    String_Op::to_number<int>( parameters->value( "Max_Conditioning_Data.value" ) );

  min_neigh_ = 
    String_Op::to_number<int>( parameters->value( "Min_Conditioning_Data.value" ) );
  errors->report( min_neigh_ >= max_neigh, 
		  "Min_Conditioning_Data", "Min must be less than Max" );

  // set-up the covariance
  //bool init_cov_ok =
    //geostat_utils::initialize_covariance( &covar_, "Variogram",
      //                      		            parameters, errors );

  bool init_cov_ok =
          geostat_utils::initialize_two_point_nested_structure(&two_point_stat_, "Variogram", parameters, errors, simul_grid_);
   if( !init_cov_ok ) return false;

  if( !init_cov_ok ) return false;
  do_block_kriging_ = parameters->value("do_block_kriging.value") == "1";
  if( do_block_kriging_ ) {

    RGrid* block_grid = dynamic_cast<RGrid*>(simul_grid_);
    if(!block_grid) {
      errors->report("Grid_Name","Must be a Cartesian grid to use the Block Kriging Option");
      return false;
    }

    nblock_pts_[0] = String_Op::to_number<int>(parameters->value( "npoints_x.value" ) );
    nblock_pts_[1] = String_Op::to_number<int>(parameters->value( "npoints_y.value" ) );
    nblock_pts_[2] = String_Op::to_number<int>(parameters->value( "npoints_z.value" ) );

    errors->report(nblock_pts_[0] <= 0,"npoints_x","At least one point is necessary");
    errors->report(nblock_pts_[1] <= 0,"npoints_y","At least one point is necessary");
    errors->report(nblock_pts_[2] <= 0,"npoints_z","At least one point is necessary");
    if(!errors->empty()) return false;


    block_covar_ = new Regular_block_covariance( &two_point_stat_ );
    block_covar_->set_block_geometry(block_grid->geometry()->cell_dims().x(),
                                     block_grid->geometry()->cell_dims().y(),
                                     block_grid->geometry()->cell_dims().z(),
                                     n_pts_x, n_pts_y, n_pts_z);
  }

/*  bool init_blk_cok_ok =  initialize_blk_covariance( &blk_covar_, 
            nblock_pts_,covar_, simul_grid_->geometry->cell_dims());
  if( !init_blk_cok_ok ) {
    errors->errors("Variogram",
      "Bad intialization of the block variogram, check the discretization and/or variogram");
    return false;
  }
  */ 

  Grid_continuous_property* prop =
    harddata_grid_->select_property( harddata_property_name_ );
  if( !prop ) {
    std::ostringstream error_stream;
    error_stream << harddata_grid_name <<  " does not have a property called " 
	            	 << harddata_property_name_;
    errors->report( "Hard_Data", error_stream.str() );
  }


  //-------------
  // Set up the search neighborhood

  GsTLTriplet ellips_ranges;
  GsTLTriplet ellips_angles;
  bool extract_ok = 
    geostat_utils::extract_ellipsoid_definition( ellips_ranges, ellips_angles,
	                                    				   "Search_Ellipsoid.value",
					                                       parameters, errors );
  if( !extract_ok ) return false;

  extract_ok = geostat_utils::is_valid_range_triplet( ellips_ranges );
  errors->report( !extract_ok,
                  "Search_Ellipsoid",
                  "Ranges must verify: major range >= " 
                  "medium range >= minor range >= 0" );
  if( !extract_ok ) return false;


  harddata_grid_->select_property(harddata_property_name_);
  if( dynamic_cast<Point_set*>(harddata_grid_) ) {
    harddata_grid_->set_coordinate_mapper(simul_grid_->coordinate_mapper());
    neighborhood_ = SmartPtr<Neighborhood>(
      harddata_grid_->neighborhood( ellips_ranges, ellips_angles, &covar_, true, hd_region ) );

    //harddata_grid_->neighborhood( ellips_ranges, ellips_angles, &covar_, true, hd_region, simul_grid_->coordinate_mapper() ) );
  } 
  else {
    neighborhood_ =  SmartPtr<Neighborhood>(
      harddata_grid_->neighborhood( ellips_ranges, ellips_angles, &covar_, false, hd_region ));
  }
  neighborhood_->select_property( harddata_property_name_ );
  neighborhood_->max_size( max_neigh );

  geostat_utils::set_advanced_search(neighborhood_.raw_ptr(), 
                      "AdvancedSearch", parameters, errors);

  kriging_weights_.reserve( 2 * max_neigh );


  
  //-----------------
  // The kriging constraints and combiner

  //  std::string kriging_type = parameters->value( "Kriging_Type.type" );
  //  set_kriging_parameters( kriging_type, parameters, errors );

  geostat_utils::KrigTagMap tags_map;
  tags_map[ geostat_utils::SK  ] = "Kriging_Type/parameters.mean";
  tags_map[ geostat_utils::KT  ] = "Kriging_Type/parameters.trend";
  tags_map[ geostat_utils::LVM ] = "Kriging_Type/parameters.property";
//  tags_map[ geostat_utils::LVM ] = "Kriging_Type/prop_mean_grid;harddata_grid_name;Kriging_Type/prop_mean_hdata";

  geostat_utils::initialize_kriging_system( "Kriging_Type",combiner_,Kconstraints_,
                                 parameters, errors,
                                 simul_grid_,harddata_grid_);

  /*
  geostat_utils::Kriging_type ktype = 
    geostat_utils::kriging_type( "Kriging_Type.type", parameters, errors );
  geostat_utils::initialize( ktype, combiner_, Kconstraints_,
                             tags_map,
                             parameters, errors,
                             simul_grid_ );
*/
  //foi inserido codigo aqui
  output_krig_var_ = parameters->value( "ouput_kriging_variance.value" )=="1";
   output_n_samples_ = parameters->value( "output_n_samples_.value" )=="1";
  output_average_distance_ = parameters->value( "output_average_distance.value" )=="1";
  output_krig_interp_var_ = parameters->value( "output_krig_interp_var_.value" )=="1";
  output_p_ = parameters->value( "output_p_.value" )=="1";
  output_ir_ = parameters->value( "output_ir_.value" )=="1";
  output_krig_combined_var_ = parameters->value( "output_krig_combined_var_.value" )=="1";
  output_sum_positive_weights_ = parameters->value( "output_sum_positive_weights.value" )=="1";
  output_sum_weights_ = parameters->value( "output_sum_weights.value" )=="1";
  output_c80_ = parameters->value( "output_c80_.value" )=="1";
  output_c90_ = parameters->value( "output_c90_.value" )=="1";
  output_c95_ = parameters->value( "output_c95_.value" )=="1";
  output_c99_ = parameters->value( "output_c99_.value" )=="1";
  
  std:string kriging_type = parameters->value( "Kriging_Type.type" );
  if(String_Op::contains( kriging_type, "OK", false ) ||  String_Op::contains( kriging_type, "KT", false )) {
    output_lagrangian_ = parameters->value( "output_lagrangian.value" )=="1";
  }
  else output_lagrangian_= false;

  if( !errors->empty() )
    return false;
 
  this->extract_parameters(parameters);
  return true;
}

//foi inserido codigo aqui
void  Convex_kriging::init_option_properties(std::string base_name, 
                              Grid_continuous_property*& var_prop,Grid_continuous_property*& nsamples_prop,							  
                              Grid_continuous_property*& aver_dist_prop,
							  Grid_continuous_property*& interpolation_prop, Grid_continuous_property*& combined_prop,
							  Grid_continuous_property*& p_prop,
							  Grid_continuous_property*& ir_prop,
							  Grid_continuous_property*& c80_prop,
							  Grid_continuous_property*& c90_prop,
							  Grid_continuous_property*& c95_prop,
							  Grid_continuous_property*& c99_prop,
							  Grid_continuous_property*& c80_prop_scv_,
							  Grid_continuous_property*& c90_prop_scv_,
							  Grid_continuous_property*& c95_prop_scv_,
							  Grid_continuous_property*& c99_prop_scv_,
							  Grid_continuous_property*& c80_prop_svi_,
							  Grid_continuous_property*& c90_prop_svi_,
							  Grid_continuous_property*& c95_prop_svi_,
							  Grid_continuous_property*& c99_prop_svi_,
							  Grid_continuous_property*& sum_pos_prop,
                              Grid_continuous_property*& sum_weights_prop,Grid_continuous_property*& lagrangian_prop)
{
  if(output_krig_var_) {
    std::string prop_name = base_name + " krig_var";
    var_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    var_prop->set_parameters(parameters_);
	if(output_c80_){
		std::string prop_name = base_name + " krig_var_c80_";
		c80_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c80_prop->set_parameters(parameters_);
		}
	
	if(output_c90_){
		std::string prop_name = base_name + " krig_var_c90_";
		c90_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c90_prop->set_parameters(parameters_);
	}
	if(output_c95_){
		std::string prop_name = base_name + " krig_var_c95_";
		c95_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c95_prop->set_parameters(parameters_);
	}
	if(output_c99_){
		std::string prop_name = base_name + " krig_var_c99_";
		c99_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c99_prop->set_parameters(parameters_);
	}
	
  }
  //interpolation output
  if(output_krig_interp_var_) {
    std::string prop_name = base_name + " krig_interp_var";
    interpolation_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    interpolation_prop->set_parameters(parameters_);
	if(output_c80_){
		std::string prop_name = base_name + " krig_interp_var_c80_";
		c80_prop_svi_ = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c80_prop_svi_->set_parameters(parameters_);
		}
	
	if(output_c90_){
		std::string prop_name = base_name + " krig_interp_var_c90_";
		c90_prop_svi_ = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c90_prop_svi_->set_parameters(parameters_);
	}
	if(output_c95_){
		std::string prop_name = base_name + " krig_interp_var_c95_";
		c95_prop_svi_= geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c95_prop_svi_->set_parameters(parameters_);
	}
	if(output_c99_){
		std::string prop_name = base_name + " krig_interp_var_c99_";
		c99_prop_svi_ = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c99_prop_svi_->set_parameters(parameters_);
	}
  }
  //combined output
  if(output_krig_combined_var_) {
    std::string prop_name = base_name + " krig_combined_var";
    combined_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    combined_prop->set_parameters(parameters_);
	if(output_c80_){
		std::string prop_name = base_name + " krig_combined_var_c80_";
		c80_prop_scv_ = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c80_prop_scv_->set_parameters(parameters_);
		}
	
	if(output_c90_){
		std::string prop_name = base_name + " krig_combined_var_c90_";
		c90_prop_scv_ = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c90_prop_scv_->set_parameters(parameters_);
	}
	if(output_c95_){
		std::string prop_name = base_name + " krig_combined_var_c95_";
		c95_prop_scv_ = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c95_prop_scv_->set_parameters(parameters_);
	}
	if(output_c99_){
		std::string prop_name = base_name + " krig_combined_var_c99_";
		c99_prop_scv_ = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
		c99_prop_scv_->set_parameters(parameters_);
	}
  }
  // slope regression
  if(output_p_) {
    std::string prop_name = base_name + " p";
    p_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    p_prop->set_parameters(parameters_);
  }
  
   // index risk
  if(output_ir_) {
    std::string prop_name = base_name + " ri";
    ir_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    ir_prop->set_parameters(parameters_);
  }

  if(output_n_samples_) {
    std::string prop_name = base_name + " n samples";
    nsamples_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    nsamples_prop->set_parameters(parameters_);
  }
  if(output_average_distance_) {
    std::string prop_name = base_name + " average sample distance";
    aver_dist_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    aver_dist_prop->set_parameters(parameters_);
  }
  if(output_sum_positive_weights_) {
    std::string prop_name = base_name + " sum positive weights";
    sum_pos_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    sum_pos_prop->set_parameters(parameters_);
  }
  if(output_sum_weights_) {
    std::string prop_name = base_name + " sum weigts";
    sum_weights_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    sum_weights_prop->set_parameters(parameters_);
  }

  if(output_lagrangian_) {
    std::string prop_name = base_name + " Lagrangian";
    lagrangian_prop = geostat_utils::add_property_to_grid( simul_grid_, prop_name );
    lagrangian_prop->set_parameters(parameters_);
  }
  
}


