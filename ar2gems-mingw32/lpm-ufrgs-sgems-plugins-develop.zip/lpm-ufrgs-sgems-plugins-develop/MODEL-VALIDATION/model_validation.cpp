/*
Implementa��o do plugin que realiza o Model validation.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "model_validation.h"

ModelValidation::ModelValidation(QWidget *parent)
    : QFrame(parent) {
    ui.setupUi(this);
}

int ModelValidation::getNumberBins() {
    return ui.nBins->value();
}

int ModelValidation::getNumberThreads() {
    return ui.nThreads->value();
}

QStringList ModelValidation::getProperties() {
    return ui.props->selected_properties();
}

QString ModelValidation::getRefProp() {
    return ui.refProp->currentText();
}

Geostat_grid* ModelValidation::getGrid() {
    return ui.grid->selected_grid_object();
}

Geostat_grid* ModelValidation::getRefGrid() {
    return ui.reference->selected_grid_object();
}

ModelValidationDirection ModelValidation::getDirection() {
    QString dir = ui.direction->currentText();
    if (dir == "X") {
        return ModelValidationDirection::MV_DIR_X;
    } else if (dir == "Y") {
        return ModelValidationDirection::MV_DIR_Y;
    }
    return ModelValidationDirection::MV_DIR_Z;
}

ModelValidation::~ModelValidation() {
}

QPushButton* ModelValidation::getDisplayButton() {
    return ui.displayButton;
}

