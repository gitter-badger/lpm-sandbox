# ifndef CREATE_BLOCK_CENTROID_POINT_SET_FROM_BLOCK_MAP_H
# define CREATE_BLOCK_CENTROID_POINT_SET_FROM_BLOCK_MAP_H
# include <grid/point_set.h>
# include <map>
# include "Struct_Block.h"

bool Create_Block_Centroid_Point_Set_From_Block_Map(Point_set * &Block_Centroids_Point_Set, const std::string &Point_Set_Name, const std::map<int, Struct_Block> &Map_ID_Blocks);

#endif