/*
Implementa��o do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "model_validation_chart_creator.h"
#include "model_validation_chart.h"
#include "model_validation_graphout.h"
#include "model_validation_report.h"

#include <qfiledialog.h>

#include <cmath>

#include <utils/string_manipulation.h>

#include <vtkAxis.h>
#include <vtkPlotLine.h>
#include <vtkPlotPoints.h>
#include <vtkPlotPie.h>
#include <vtkPlotBar.h>
#include <vtkIntArray.h>
#include <vtkFloatArray.h>
#include <vtkDoubleArray.h>
#include <vtkColorSeries.h>
#include <vtkTextProperty.h>

#define INF 1e9

ModelValidation_chart::ModelValidation_chart(
    ModelValidation* my_model_validation,
	QWidget *parent)
	: 
    ModelValidationAction(),
	Chart_base(parent), 
    my_model_validation_(my_model_validation)
{
    ModelValidationGraphOutput* gout = new ModelValidationGraphOutput(this);
	gout_ = gout;
	my_process_handler_ = 0;
	dv_ = INF;
    table_model_validation_ = 0;
	is_ok = false;
	
    n_bins_ = my_model_validation_->getNumberBins();

    grid_ = my_model_validation_->getGrid();
	grid_reference_ = my_model_validation_->getRefGrid();
    props_names_ = my_model_validation_->getProperties();
	prop_ref_name_ = my_model_validation_->getRefProp();
    model_validations_.resize(props_names_.size());
	dir_ = my_model_validation_->getDirection();


	this->hide();
}

void ModelValidation_chart::run_master_process(ModelValidationProcess* process_handler, int number_threads, std::vector<ModelValidationProcess*>& slaves)
{
	if (process_handler->isOk()) {
        process_handler->getNotifier()->appendText("Creating model validations...\n");
		this->my_process_handler_ = process_handler;
	}
}

void ModelValidation_chart::run_slave_process(ModelValidationProcess* process_handler, int id_thread, int number_threads)
{
	if (process_handler->isOk()) {
        build_model_validations(id_thread, number_threads);
	}
}


void ModelValidation_chart::repaint_chart(const QString& in)
{
	if (is_ok) {
		this->build_value_table();
		this->build_plot();
	}
}


void ModelValidation_chart::build_value_table()
{	
    table_model_validation_ = vtkSmartPointer<vtkTable>::New();
	table_ref_model_validation_ = vtkSmartPointer<vtkTable>::New();

	QStringList& props = props_names_;
	
    vtkSmartPointer<vtkFloatArray> index_model_validation = vtkSmartPointer<vtkFloatArray>::New();
	std::vector<vtkSmartPointer<vtkFloatArray> > values(props.size());
	
    std::vector<ModelValidationPoints> vars(props.size());
    std::map<int, std::vector<double> > model_validations;

	vtkSmartPointer<vtkFloatArray> index_ref_model_validation = vtkSmartPointer<vtkFloatArray>::New();
	vtkSmartPointer<vtkFloatArray> ref_values;

	std::vector<ModelValidationPoints> ref_vars(props.size());
	std::map<int, double> ref_model_validation;

	for (int i = 0; i < props.size(); ++i) {
		values[i] = vtkSmartPointer<vtkFloatArray>::New();

        ModelValidationPoints& pts = model_validations_[i];

		for (int k = 0; k < pts.size(); ++k) {
            if (model_validations[static_cast<int>(pts[k].x / dv_)].size() < props.size())
                model_validations[static_cast<int>(pts[k].x / dv_)] = std::vector<double>(props.size(), 0);
            model_validations[static_cast<int>(pts[k].x / dv_)][i] = pts[k].y;
		}
	}

	ref_values = vtkSmartPointer<vtkFloatArray>::New();
	ModelValidationPoints ref_pts;
	build_model_validation(ref_pts, 0, true);

	for (int k = 0; k < ref_pts.size(); ++k) {
		ref_model_validation[static_cast<int>(ref_pts[k].x / dv_)] = ref_pts[k].y;
	}

	if (dir_ == ModelValidationDirection::MV_DIR_X) {
		index_model_validation->SetName("X");
		index_ref_model_validation->SetName("X");
	}
	else if (dir_ == ModelValidationDirection::MV_DIR_Y) {
		index_model_validation->SetName("Y");
		index_ref_model_validation->SetName("Y");
	}
	else if (dir_ == ModelValidationDirection::MV_DIR_Z) {
		index_model_validation->SetName("Z");
		index_ref_model_validation->SetName("Z");
	}

    index_model_validation->SetNumberOfValues(model_validations.size());
	index_ref_model_validation->SetNumberOfValues(ref_model_validation.size());

	for (int i = 0; i < values.size(); ++i) {
		QString name;
		QTextStream in(&name);

        in << "Model Validation  [ " << props[i] << " ]";

		values[i]->SetName(name.toStdString().c_str());
        values[i]->SetNumberOfValues(model_validations.size());
	}

	QString ref_name;
	QTextStream ref_in(&ref_name);
	ref_in << "Reference";

	ref_values->SetName(ref_name.toStdString().c_str());
	ref_values->SetNumberOfValues(ref_model_validation.size());

    std::map<int, std::vector<double> >::iterator it = model_validations.begin(), 
		ed = model_validations.end();

	int idx = 0;
    while (it != ed) {
        index_model_validation->SetValue(idx, it->first * dv_);
		std::vector<double>& v = it->second;

		for (int i = 0; i < v.size(); ++i) {
            values[i]->SetValue(idx, v[i]);
		}

		++it;
		++idx;
	}

	std::map<int, double>::iterator ref_it = ref_model_validation.begin(), 
		ref_ed = ref_model_validation.end();

	idx = 0;
	while (ref_it != ref_ed) {
		index_ref_model_validation->SetValue(idx, ref_it->first * dv_);
		double v = ref_it->second;

		ref_values->SetValue(idx, v);

		++ref_it;
		++idx;
	}
	
    table_model_validation_->AddColumn(index_model_validation);
	for (int i = 0; i < values.size(); ++i) {
        table_model_validation_->AddColumn(values[i]);
	}

	table_ref_model_validation_->AddColumn(index_ref_model_validation);
	table_ref_model_validation_->AddColumn(ref_values);

    this->table_model_validation_view_->SetRepresentationFromInput(table_model_validation_);
    this->table_model_validation_view_->Update();
}


void ModelValidation_chart::build_model_validation(ModelValidationPoints& pts, int i, bool is_reference)
{
	Grid_continuous_property* prop = 0;

	if (is_reference) {
		prop = grid_reference_->property(prop_ref_name_.toStdString());
	} else {
		prop = grid_->property(props_names_[i].toStdString());
	}

    std::map<int, double> model_validation;
	std::map<int, int> count;
	double acc = 0;
	bool is_first = true;
	double vmin = 0, vmax = 0;
	
	for (int p = 0; p < prop->size(); ++p) {
		if (prop->is_informed(p)) {
			double v = 0;
			
			if (dir_ == ModelValidationDirection::MV_DIR_X) {
				if (is_reference) {
					v = grid_reference_->xyz_location(grid_reference_->node_id(p)).x();
				} else {
					v = grid_->xyz_location(grid_->node_id(p)).x();
				}
			} else if (dir_ == ModelValidationDirection::MV_DIR_Y) {
				if (is_reference) {
					v = grid_reference_->xyz_location(grid_reference_->node_id(p)).y();
				} else {
					v = grid_->xyz_location(grid_->node_id(p)).y();
				}
			} else {
				if (is_reference) {
					v = grid_reference_->xyz_location(grid_reference_->node_id(p)).z();
				} else {
					v = grid_->xyz_location(grid_->node_id(p)).z();
				}
			}

			if (fabs(v) < INF) {
				if (is_first) {
					is_first = false;
					vmin = vmax = v;
				}
				else if (v > vmax) {
					vmax = v;
				}
				else if (v < vmin) {
					vmin = v;
				}
			}
		}
	}
	
	double dv =  (vmax - vmin) / n_bins_;
	
	for (int p = 0; p < prop->size(); ++p) {
		if (prop->is_informed(p)) {
			double c = 0;

			if (dir_ == ModelValidationDirection::MV_DIR_X) {
				if (is_reference) {
					c = grid_reference_->xyz_location(grid_reference_->node_id(p)).x();
				} else {
					c = grid_->xyz_location(grid_->node_id(p)).x();
				}
			} else if (dir_ == ModelValidationDirection::MV_DIR_Y) {
				if (is_reference) {
					c = grid_reference_->xyz_location(grid_reference_->node_id(p)).y();
				} else {
					c = grid_->xyz_location(grid_->node_id(p)).y();
				}
			} else {
				if (is_reference) {
					c = grid_reference_->xyz_location(grid_reference_->node_id(p)).z();
				} else {
					c = grid_->xyz_location(grid_->node_id(p)).z();
				}
			}

			double v = prop->get_value(p);
			if (fabs(v) < INF) {
                model_validation[static_cast<int>(c / dv)] += v;
				++count[static_cast<int>(c / dv)];
			}
		}
	}
	
    std::map<int, double>::iterator it = model_validation.begin(), ed = model_validation.end();
	std::map<int, int>::iterator it2 = count.begin(), ed2 = count.end();

	while (it != ed) {
		double v = it->second;
		double c = it2->second;
		it->second /= c;
	
		++it;
		++it2;
	}

    it = model_validation.begin();
    ed = model_validation.end();
	while (it != ed) {
        pts.push_back(ModelValidationPoint(it->first * dv, it->second));
		++it;
	}

	mutex.lock();
	if (dv < dv_ && !is_reference) dv_ = dv;
	mutex.unlock();
}

void ModelValidation_chart::build_model_validations(int id, int n_threads)
{
	for (int i = id; i < props_names_.size(); i += n_threads) {
		if (this->my_process_handler_) {
			if (!this->my_process_handler_->isOk()){
				return;
			}

			if (this->my_process_handler_->getNotifier()->isPaused()) {
				my_process_handler_->getNotifier()->appendText("Paused...");
				while (this->my_process_handler_->getNotifier()->isPaused()) {
				}
			}
		}

		Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());

		if (my_process_handler_) my_process_handler_
			->getNotifier()
            ->appendText("Creating model validation to property <" +
			props_names_[i] +  ">");

        ModelValidationPoints pts;
        build_model_validation(pts,  i);
        model_validations_[i] = pts;
		
		if (my_process_handler_) my_process_handler_->getNotifier()->nextStep();
	}
}


void ModelValidation_chart::clear_chart()
{
    chart_model_validation_widget_->chart()->ClearPlots();
}

void ModelValidation_chart::build_plot()
{
    for (int i = 1; i < table_model_validation_->GetNumberOfColumns(); ++i) {

		if (gout_->getUI().line->isChecked()) {
            vtkPlotLine* plot_hist = vtkPlotLine::SafeDownCast(chart_model_validation_widget_->chart()->AddPlot(vtkChart::LINE));

            plot_hist->SetInputData(table_model_validation_, 0, i);
			plot_hist->SetColor(1.0, 0.0, 0.0);
		}

		if (gout_->getUI().point->isChecked()) {
            vtkPlotPoints* plot_hist = vtkPlotPoints::SafeDownCast(chart_model_validation_widget_->chart()->AddPlot(vtkChart::POINTS));

            plot_hist->SetInputData(table_model_validation_, 0, i);
			plot_hist->SetColor(1.0, 0.0, 0.0);
		}	
	}

	if (gout_->getUI().line->isChecked()) {
		vtkPlotLine* plot_hist = vtkPlotLine::SafeDownCast(chart_model_validation_widget_->chart()->AddPlot(vtkChart::LINE));

		plot_hist->SetInputData(table_ref_model_validation_, 0, 1);
		plot_hist->SetColor(0.0, 0.0, 1.0);
	}

	if (gout_->getUI().point->isChecked()) {
		vtkPlotPoints* plot_hist = vtkPlotPoints::SafeDownCast(chart_model_validation_widget_->chart()->AddPlot(vtkChart::POINTS));

		plot_hist->SetInputData(table_ref_model_validation_, 0, 1);
		plot_hist->SetColor(0.0, 0.0, 1.0);
	}

    chart_model_validation_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Model Validation");
    

	if (dir_ == ModelValidationDirection::MV_DIR_X) {
		chart_model_validation_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle("X");
	}
	else if (dir_ == ModelValidationDirection::MV_DIR_Y) {
		chart_model_validation_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle("Y");
	}
	else if (dir_ == ModelValidationDirection::MV_DIR_Z) {
		chart_model_validation_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle("Z");
	}


	//chart_histogram_widget_->chart()->SetAutoAxes(true);
    chart_model_validation_widget_->chart()->SetVisible(true);
    chart_model_validation_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));
    chart_model_validation_widget_->chart()->Update();

    chart_model_validation_widget_->update();
}

void ModelValidation_chart::build_model_validation_chart()
{
	if (grid_ == 0) return;
	if (props_names_.size() == 0) return;
	if (grid_reference_ == 0) return;
	if (prop_ref_name_.size() == 0) return;

    QString title = QString(model_validation_charts_name).arg(grid_->name().c_str());

	this->setWindowTitle(title);
	this->setWindowIcon(QPixmap(":/icons/appli/Pixmaps/ar2gems-icon-256x256.png"));

    chart_model_validation_widget_ = new Chart_widget(this);
    chart_model_validation_control_ = new Chart_display_control( chart_model_validation_widget_ );
    chart_model_validation_widget_->set_controler(chart_model_validation_control_);

    table_model_validation_view_ = vtkSmartPointer<vtkQtTableView>::New();

    QVBoxLayout* model_validation_layout = new QVBoxLayout(this);

    model_validation_layout->addWidget(gout_);
    this->setLayout(model_validation_layout);
	
	ok = connect(gout_->getUI().line, SIGNAL(clicked()), this, SLOT(build_plot()));
	ok = connect(gout_->getUI().point, SIGNAL(clicked()), this, SLOT(build_plot()));

	this->build_value_table();
	this->build_plot();

    QTableView* table_model_validation = dynamic_cast<QTableView*>(table_model_validation_view_->GetWidget());
    qtable_model_validation_ = table_model_validation;

	ok = connect(
        table_model_validation, SIGNAL(clicked(const QModelIndex &)),
		this, SLOT(cutoff_selected(const QModelIndex &)));

    gout_->getUI().graphViewer->addWidget(chart_model_validation_widget_);
    gout_->getUI().graphControl->addWidget(chart_model_validation_control_);
    gout_->getUI().tabWidget->addTab(table_model_validation, "Data");

    ok = connect(gout_->getUI().saveFigureButton, SIGNAL(clicked()), chart_model_validation_widget_, SLOT(save_figure()));
	ok = connect(gout_->getUI().saveReportButton, SIGNAL(clicked()), this, SLOT(save_report()));
	ok = connect(gout_->getUI().viewReportButton, SIGNAL(clicked()), this, SLOT(view_report()));
	ok = connect(gout_->getUI().clear, SIGNAL(clicked()), this, SLOT(clear_chart()));
	ok = connect(gout_->getUI().importGraphsButton, SIGNAL(clicked()), this, SLOT(import_graphs()));

	is_ok = true;
	this->show();
	
}

void ModelValidation_chart::save_report()
{
	QString fileName = QFileDialog::getSaveFileName(this, tr("Save File"),
		"report.csv",
		tr("CSV Files (*.csv)"));

	if (fileName.size() > 0) {
		QString msg;
		QTextStream output(&msg);

        write_table_model_validation(output);

		FILE* fout = fopen(fileName.toStdString().c_str(), "w+");
		fprintf(fout, "%s\n", msg.toStdString().c_str());
		fclose(fout);
	}
}

void ModelValidation_chart::view_report()
{
    ModelValidationReport* report = new ModelValidationReport(0);
	QString msg;
	QTextStream output(&msg, QIODevice::WriteOnly);

    write_table_model_validation(output);

	report->setText(msg);
	report->show();
}

void ModelValidation_chart::write_table_model_validation(QTextStream& out)
{
    int nr = this->table_model_validation_->GetNumberOfRows();
    int nc = this->table_model_validation_->GetNumberOfColumns();

	for (int i = 0; i < nc; ++i) {
		if (i > 0) out << ", ";

        out << "\"" << QString(this->table_model_validation_->GetColumnName(i)) << "\"";
	}
	out << "\n";

	for (int j = 0; j < nr; ++j) {
		for (int k = 0; k < nc; ++k) {
			if (k > 0) out << ", ";

            out << this->table_model_validation_->GetValue(j, k).ToDouble();
		}
		out << "\n";
	}
}


void ModelValidation_chart::import_graphs()
{
	QString file_name = QFileDialog::getOpenFileName(this, "Import graphs", "", tr("CSV Files (*.csv)"));

	if (file_name == "") return;

	std::ifstream fin(file_name.toStdString().c_str());

	if (fin.fail()) return;

	bool is_first = true;

	std::vector<std::string> titles;
	std::vector<std::vector<double> > data;

	size_t min_size = 0;
	while (!fin.eof()) {

		std::string line;
		std::getline(fin, line);

		std::vector<std::string> values = String_Op::decompose_string(line, ",");

		if (is_first) {
			is_first = false;
			titles = values;
			data.resize(values.size());
		}
		else {
			for (int i = 0; i < std::min(values.size(), data.size()); ++i) {
				double v = String_Op::to_number<double>(values[i]);
				data[i].push_back(v);
			}
		}
	}

	for (int i = 0; i < data.size(); ++i) {
		if (i == 0) {
			min_size = data[i].size();
		}
		else {
			min_size = std::min(min_size, data[i].size());
		}
	}

	std::vector<vtkSmartPointer<vtkFloatArray> > values(titles.size());
	vtkSmartPointer<vtkTable> table_values = vtkSmartPointer<vtkTable>::New();

	for (int i = 0; i < titles.size(); ++i) {
		values[i] = vtkSmartPointer<vtkFloatArray>::New();
		values[i]->SetName(titles[i].c_str());
		values[i]->SetNumberOfValues(min_size);
		for (int j = 0; j < min_size; ++j) {
			values[i]->SetValue(j, data[i][j]);
		}
		table_values->AddColumn(values[i]);
	}


	for (int i = 1; i < table_values->GetNumberOfColumns(); ++i) {

		if (gout_->getUI().line->isChecked()) {
            vtkPlotLine* plot_variog = vtkPlotLine::SafeDownCast(chart_model_validation_widget_->chart()->AddPlot(vtkChart::LINE));

			plot_variog->SetInputData(table_values, 0, i);
			plot_variog->SetColor(0.0, 0.0, 1.0);
		}

		if (gout_->getUI().point->isChecked()) {
            vtkPlotPoints* plot_variog = vtkPlotPoints::SafeDownCast(chart_model_validation_widget_->chart()->AddPlot(vtkChart::POINTS));

			plot_variog->SetInputData(table_values, 0, i);
			plot_variog->SetColor(0.0, 0.0, 1.0);
		}
	}

	fin.close();
    chart_model_validation_widget_->update();
}
