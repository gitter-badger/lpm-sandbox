/*
Implementa��o do plugin BLENDSIM.

(c) 2013, LPM/UFRGS, Roberto Menin, P�ricles Lopes Machado
*/

#include "blendsim_chart.h"
#include "blendsim_chart_creator.h"
#include "blendsim_calc.h"

#include <utils/manager.h>
#include <utils/manager_repository.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>

#include <QPixmap>
#include <QIcon>
#include <QTime>
#include <qtextstream.h>

#include <QSplitter>
#include <QVBoxLayout>
#include <QTabWidget>
#include <QTableView>
#include <QSortFilterProxyModel>

#include <vtkAxis.h>
#include <vtkPlotLine.h>
#include <vtkPlotPie.h>
#include <vtkPlotBar.h>
#include <vtkIntArray.h>
#include <vtkFloatArray.h>
#include <vtkDoubleArray.h>
#include <vtkColorSeries.h>
#include <vtkTextProperty.h>

#include <iostream>
#include <cstdio>
#include <vector>
#include <cmath>
#include <string>
#include <map>

using namespace std;

inline int min(double a, double b) {
    return a < b ? int(a) : int(b);
}

Blendsim_chart::Blendsim_chart(Geostat_grid* grid,
                               std::vector<Grid_continuous_property*> grade_props,
                               Grid_continuous_property* sequence_prop,
                               Grid_continuous_property* mass_prop_,
                               Grid_region* region,
                               Blending_types bt,
                               double IniMass,
                               double FinalMass,
                               double IncMass,
                               QWidget *parent ) :
    Chart_base(parent), grid_(grid),
    grade_props_(grade_props),
    sequence_prop_(sequence_prop), mass_prop_(mass_prop_),
    region_(region),
    blending_type(bt),
    IniMass(IniMass), FinalMass(FinalMass), IncMass(IncMass) {
    this->my_parent_ = parent;
    switch (bt) {
    case Blending_types::BLENDING_INTERPILES:
        this->build_interpiles_chart();
        break;
    case Blending_types::BLENDING_PILESERIES:
        this->build_pileseries_chart();
        break;
    case Blending_types::BLENDING_PILELOCATE:
        this->build_pileseries_chart();
        break;
    case Blending_types::BLENDING_INTRAPILES:
        this->build_intrapiles_chart();
        break;
    }
}

void Blendsim_chart::build_value_table() {
    switch (this->blending_type) {
    case Blending_types::BLENDING_INTERPILES:
        build_value_table_interpile();
        break;
    case Blending_types::BLENDING_PILESERIES:
        build_value_table_pileseries();
        break;
    case Blending_types::BLENDING_PILELOCATE:
        build_value_table_pilelocate();
        break;
    case Blending_types::BLENDING_INTRAPILES:
        this->build_value_table_intrapiles();
        break;
    }
}

void Blendsim_chart::build_plot() {
    switch (this->blending_type) {
    case Blending_types::BLENDING_INTERPILES:
        build_plot_interpile();
        break;
    case Blending_types::BLENDING_PILESERIES:
        build_plot_pileseries();
        break;
    case Blending_types::BLENDING_INTRAPILES:
        this->build_plot_intrapile();
        break;
    }
}

//INTRAPILE
void Blendsim_chart::build_intrapiles_chart() {
    min_X = max_X = min_Y = max_Y = 0;
    QString title = QString("Blendsim").arg(sequence_prop_->name().c_str());
    this->setWindowTitle(title);
    this->setWindowIcon(QPixmap(":/icons/appli/Pixmaps/ar2gems-icon-256x256.png"));
    QSplitter* main_splitter = new QSplitter(Qt::Horizontal, this);
    QTabWidget* chart_tab = new QTabWidget(main_splitter);
    QTabWidget* table_tab = new QTabWidget(main_splitter);
    QSplitter* chart_permissive_splitter = new QSplitter(Qt::Vertical, main_splitter);
    chart_permissive_widget_ = new Chart_widget(chart_permissive_splitter);
    chart_permissive_splitter->addWidget( chart_permissive_widget_ );
    chart_permissive_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    data_permissive_view_ = vtkSmartPointer<vtkQtTableView>::New();
    QSplitter* chart_CV_permissive_splitter = new QSplitter(Qt::Vertical, main_splitter);
    chart_CV_permissive_widget_ = new Chart_widget(chart_CV_permissive_splitter);
    chart_CV_permissive_splitter->addWidget( chart_CV_permissive_widget_ );
    chart_CV_permissive_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    data_CV_permissive_view_ = vtkSmartPointer<vtkQtTableView>::New();
    data_mean_mass_view_ = vtkSmartPointer<vtkQtTableView>::New();
    chart_tab->addTab(chart_permissive_splitter, "IntraPiles Variance" );
    QFrame* report_permissive_frame = new QFrame(chart_permissive_splitter);
    QPushButton* view_permissive_report_button = new QPushButton("View IntraPiles Report",report_permissive_frame);
    QPushButton* save_permissive_report_button = new QPushButton("Save IntraPiles Report",report_permissive_frame);
    QPushButton* save_permissive_figure_button = new QPushButton("Save IntraPiles Figure",report_permissive_frame);
    QHBoxLayout* report_permissive_layout = new QHBoxLayout(report_permissive_frame);
    report_permissive_layout->addWidget(save_permissive_figure_button);
    report_permissive_layout->addWidget(save_permissive_report_button);
    report_permissive_layout->addWidget(view_permissive_report_button);
    report_permissive_frame->setLayout(report_permissive_layout);
    report_permissive_frame->setFixedHeight(40);
    chart_permissive_splitter->addWidget( report_permissive_frame );
    report_permissive_frame->setSizePolicy(QSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum));
    chart_tab->addTab(chart_CV_permissive_splitter, "IntraPiles CV" );
    QFrame* report_CV_permissive_frame = new QFrame(chart_CV_permissive_splitter);
    QPushButton* view_CV_permissive_report_button = new QPushButton("View IntraPiles Report",report_CV_permissive_frame);
    QPushButton* save_CV_permissive_report_button = new QPushButton("Save IntraPiles Report",report_CV_permissive_frame);
    QPushButton* save_CV_permissive_figure_button = new QPushButton("Save IntraPiles Figure",report_CV_permissive_frame);
    QHBoxLayout* report_CV_permissive_layout = new QHBoxLayout(report_permissive_frame);
    report_CV_permissive_layout->addWidget(save_CV_permissive_figure_button);
    report_CV_permissive_layout->addWidget(save_CV_permissive_report_button);
    report_CV_permissive_layout->addWidget(view_CV_permissive_report_button);
    report_CV_permissive_frame->setLayout(report_CV_permissive_layout);
    report_CV_permissive_frame->setFixedHeight(40);
    //report_CV_permissive_layout->addStretch();
    chart_permissive_splitter->addWidget( report_permissive_frame );
    report_permissive_frame->setSizePolicy(QSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum));
    main_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    ///////////////
    QVBoxLayout* interpiles_permissive_layout = new QVBoxLayout(this);
    interpiles_permissive_layout->addWidget(main_splitter); //AQUI FOI FEITA A ALTERA��O DE "chart_splitter" PARA "main_splitter"!!
    //interpiles_variance_layout->addWidget(report_var_frame);
    this->setLayout(interpiles_permissive_layout);
    this->build_value_table();
    this->build_plot();
    ///////////////////////
    data_permissive_view_->SetRepresentationFromInput(table_permissive_);
    data_permissive_view_->Update();
    QTableView* table_permissive = dynamic_cast<QTableView*>(data_permissive_view_->GetWidget());
    bool ok = connect(table_permissive, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
    ///////////////////////
    data_CV_permissive_view_->SetRepresentationFromInput(table_CV_permissive_);
    data_CV_permissive_view_->Update();
    QTableView* table_CV_permissive = dynamic_cast<QTableView*>(data_CV_permissive_view_->GetWidget());
    ok = connect(table_CV_permissive, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
    //////////////////////
    ok = connect( save_permissive_figure_button, SIGNAL(clicked()), chart_permissive_widget_, SLOT(save_figure()) ); ///////
    ok = connect( save_permissive_report_button, SIGNAL(clicked()), data_permissive_view_, SLOT(save_report()) );
    ok = connect( save_CV_permissive_figure_button, SIGNAL(clicked()), chart_CV_permissive_widget_, SLOT(save_figure()) ); ///////
    ok = connect( save_CV_permissive_report_button, SIGNAL(clicked()), data_CV_permissive_view_, SLOT(save_report()) );
    table_tab->addTab(table_permissive, "Intrapile Variance");
    table_tab->addTab(table_CV_permissive, "Intrapile CV");
}

void Blendsim_chart::build_plot_intrapile() {
    for(int i= 0; i< grade_props_.size(); ++i) {
        vtkPlotLine* plot_variance = vtkPlotLine::SafeDownCast(chart_permissive_widget_->chart()->AddPlot(vtkChart::LINE ));
        plot_variance->SetInputData(table_permissive_,0,i+2);
    }
    chart_permissive_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Variance");
    chart_permissive_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle(" # Layers");
    /*
    	chart_permissive_widget_->set_xaxis_min(min_X);
    	chart_permissive_widget_->set_yaxis_min(min_Y);

    	chart_permissive_widget_->set_xaxis_max(max_X);
    	chart_permissive_widget_->set_yaxis_max(max_Y);
    */
    //chart_permissive_widget_->chart()->SetAutoAxes(true);
    chart_permissive_widget_->chart()->SetVisible(true);
    chart_permissive_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    chart_permissive_widget_->chart()->Update();
    chart_permissive_widget_->update();
}

void Blendsim_chart::build_value_table_intrapiles() {
    Blendsim_chart_creator* mp = static_cast<Blendsim_chart_creator*>(this->my_parent_);
    MapPileSeries& pileseries = mp->getMapPileSeries();
    double bulk_factor = mp->getBulkFactor();
    double staker_material = mp->getMaterialStaker();
    double repose_angle = mp->getReposeAngle() * 0.0174532925;
    double base_length = mp->getBaseLength();
    int initial_layers = mp->getInitialLayers();
    int final_layers = min(mp->getFinalLayers(), base_length * base_length * tan(repose_angle) / (4 * staker_material));
    if (initial_layers > final_layers) initial_layers = final_layers;
    int interval_layers = mp->getIntervalLayers();
    std::vector<double> volume;
    std::vector<int> seqmin;
    QTime clock_;
    QString out_buf;
    QTextStream out(&out_buf);
    clock_.start();
    for(int i = 0; i < sequence_prop_->size(); ++i) {
        if(region_ && !region_->is_inside_region(i)) continue;
        seqmin.push_back(sequence_prop_->get_value(i));
    }
    Grid_continuous_property* volume_prop = mp->getVolumeProp();
    if (volume_prop == 0) return;
    for (int i = 0; i < volume_prop->size(); ++i) {
        if(region_ && !region_->is_inside_region(i)) continue;
        volume.push_back(volume_prop->get_value(i));
    }
    sort_info(volume, seqmin, volume);
    std::map<int, PairMinMax>& piles = pileseries[mp->getMassIntrapile()];
    std::map<int, PairMinMax>::iterator it = piles.begin(), ed = piles.end();
    std::map<int, double> length_map;
    std::map<int, std::map<int, double> > std_dev_map;
    std::map<int, std::map<int, double> > var_map;
    while (it != ed) {
        PairMinMax& pminmax = it->second;
        int io = pminmax.addr0_min;
        int n_b = pminmax.n_seq_min;
        double v_b = 0;
        for (int i = io; i < io + n_b && i < volume.size(); ++i) {
            v_b += volume[i];
        }
        v_b *= bulk_factor;
        for(int p=0; p< grade_props_.size(); ++p) {
            Grid_continuous_property* grade_prop = grade_props_[p];
            vector<double> sim;
            for (int i = 0; i < grade_prop->size(); ++i) {
                if (region_ && !region_->is_inside_region(i)) continue;
                if (grade_prop->get_value(i) < 0 || !grade_prop->is_informed(i)) {
                    sim.push_back(0);
                } else {
                    sim.push_back(grade_prop->get_value(i));
                }
            }
            sort_info(sim, seqmin, sim);
            for (int l = initial_layers; l <= final_layers; l += interval_layers) {
                double volume_layer = v_b / l ;
                double pile_length = v_b / (l * staker_material);
                double area_face = v_b / pile_length;
                length_map[l] += pile_length / (grade_props_.size() * piles.size());
                vector<vector<double> > m;
                build_layers(m, volume, sim, bulk_factor, l, pile_length, staker_material, io, n_b);
                vector<double> average;
                if (m.size() > 0)
                    for (int i = 0; i < m[0].size(); ++i) {
                        double s = 0;
                        int c = 0;
                        for (int j = 0; j < m.size(); ++j) {
                            if (i < m[j].size()) {
                                s += m[j][i];
                                ++c;
                            }
                        }
                        double  av = s / c;
                        average.push_back(av);
                    }
                double grade_pile = pminmax.grades[p];
                double var_acc = 0;
                double std_dev;
                for (int i = 0; i < average.size(); ++i) {
                    var_acc += (average[i] - grade_pile) * (average[i] - grade_pile)  / average.size();
                }
                std_dev = sqrt(var_acc);
                var_map[p][l] += var_acc / piles.size();
                std_dev_map[p][l] += std_dev / piles.size();
            }
        }
        ++it;
    }
    //////////////////////////////////////////////////////////////////////////////////
    table_permissive_ = vtkSmartPointer<vtkTable>::New();
    vtkSmartPointer<vtkFloatArray> index_array_layers = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_length = vtkSmartPointer<vtkFloatArray>::New();
    index_array_layers->SetName("# Layers");
    index_array_layers->SetNumberOfValues(var_map[0].size());
    index_array_length->SetName("Average Length");
    index_array_length->SetNumberOfValues(var_map[0].size());
    for (int l = initial_layers, idx = 0; l <= final_layers; l += interval_layers, ++idx) {
        index_array_layers->SetValue(idx, l);
        index_array_length->SetValue(idx, length_map[l]);
    }
    table_permissive_->AddColumn(index_array_layers);
    table_permissive_->AddColumn(index_array_length);
    min_X = max_X = min_Y = max_Y = 0;
    min_X = initial_layers;
    max_X = final_layers;
    for(int p=0; p < grade_props_.size(); ++p) {
        Grid_continuous_property* grade_prop = grade_props_[p];
        vtkSmartPointer<vtkFloatArray> grade_var_array = vtkSmartPointer<vtkFloatArray>::New();
        grade_var_array->SetName(grade_prop->name().c_str());
        grade_var_array->SetNumberOfValues(var_map[p].size());
        for (int l = initial_layers, idx = 0; l <= final_layers; l += interval_layers, ++idx) {
            grade_var_array->SetValue(idx, var_map[p][l]);
            if (var_map[p][l] > max_Y) max_Y = var_map[p][l];
            if (var_map[p][l] < min_Y) min_Y = var_map[p][l];
        }
        table_permissive_->AddColumn(grade_var_array);
    }
    int t = clock_.elapsed();
    out << "Process took " << t << "ms to run\n";
    mp->setTime(out_buf);
}



//INTERPILES
void Blendsim_chart::build_interpiles_chart() {
    min_X = max_X = min_Y = max_Y = 0;
    QString title = QString("Blend Pile").arg(sequence_prop_->name().c_str());
    this->setWindowTitle(title);
    this->setWindowIcon(QPixmap(":/icons/appli/Pixmaps/ar2gems-icon-256x256.png"));
    QSplitter* main_splitter = new QSplitter(Qt::Horizontal, this);
    QTabWidget* chart_tab = new QTabWidget(main_splitter);
    QTabWidget* table_tab = new QTabWidget(main_splitter);
    // Constroi widget para o chart da variancia
    QSplitter* chart_variance_splitter = new QSplitter(Qt::Vertical, main_splitter);
    chart_variance_widget_ = new Chart_widget(chart_variance_splitter);
    //chart_variance_control_ = new Chart_display_control( chart_variance_widget_ );
    //chart_variance_widget_->set_controler(chart_variance_control_);
    chart_variance_splitter->addWidget( chart_variance_widget_ );
    //chart_variance_splitter->addWidget( chart_variance_control_ );
    chart_variance_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    data_variance_view_ = vtkSmartPointer<vtkQtTableView>::New();
    /* QWidget *widget = chart_variance_splitter->widget(0);
    	QSizePolicy policy = widget->sizePolicy();
    	policy.setHorizontalStretch(QSizePolicy::Maximum);
    	policy.setVerticalStretch(QSizePolicy::Maximum);
    	widget->setSizePolicy(policy);*/
    // Constroi widget para o chart da desvio padr�o
    QSplitter* chart_desvpad_splitter = new QSplitter(Qt::Vertical, main_splitter);
    chart_desvpad_widget_ = new Chart_widget(chart_desvpad_splitter);
//	chart_desvpad_control_ = new Chart_display_control( chart_desvpad_widget_ );
//	chart_desvpad_widget_->set_controler(chart_desvpad_control_);
    chart_desvpad_splitter->addWidget( chart_desvpad_widget_ );
//	chart_desvpad_splitter->addWidget( chart_desvpad_control_ );
    chart_desvpad_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    data_desvpad_view_ = vtkSmartPointer<vtkQtTableView>::New();
    // Constroi widget para o chart da CV
    QSplitter* chart_CV_splitter = new QSplitter(Qt::Vertical, main_splitter);
    chart_CV_widget_ = new Chart_widget(chart_CV_splitter);
//	chart_CV_control_ = new Chart_display_control( chart_CV_splitter );
//	chart_CV_widget_->set_controler(chart_CV_control_);
    chart_CV_splitter->addWidget( chart_CV_widget_ );
//	chart_CV_splitter->addWidget( chart_CV_control_ );
    chart_CV_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    data_CV_view_ = vtkSmartPointer<vtkQtTableView>::New();
    ///////////inicial
    data_mean_mass_view_ = vtkSmartPointer<vtkQtTableView>::New(); ///////////inicial
    ///////////inicial
    chart_tab->addTab(chart_variance_splitter, "Variance InterPiles" );
    QFrame* report_var_frame = new QFrame(chart_variance_splitter);
    QPushButton* view_var_report_button = new QPushButton("View Variance Report",report_var_frame);
    QPushButton* save_var_report_button = new QPushButton("Save Variance Report",report_var_frame);
    QPushButton* save_var_figure_button = new QPushButton("Save Variance Figure",report_var_frame);
    QHBoxLayout* report_var_layout = new QHBoxLayout(report_var_frame);
    report_var_layout->addWidget(save_var_figure_button);
    report_var_layout->addWidget(save_var_report_button);
    report_var_layout->addWidget(view_var_report_button);
    report_var_frame->setLayout(report_var_layout);
    report_var_frame->setFixedHeight(40);
    //report_var_layout->addStretch();
    chart_variance_splitter->addWidget( report_var_frame );
    report_var_frame->setSizePolicy(QSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum));
    chart_tab->addTab(chart_desvpad_splitter, "Std. Dev. InterPiles");
    QFrame* report_desvpad_frame = new QFrame(chart_desvpad_splitter);
    QPushButton* view_desvpad_report_button = new QPushButton("View Std. Dev Report",report_desvpad_frame);
    QPushButton* save_desvpad_report_button = new QPushButton("Save Std. Dev Report",report_desvpad_frame);
    QPushButton* save_desvpad_figure_button = new QPushButton("Save Std. Dev Figure",report_desvpad_frame);
    QHBoxLayout* report_desvpad_layout = new QHBoxLayout(report_desvpad_frame);
    //report_desvpad_layout->addStretch();
    report_desvpad_layout->addWidget(save_desvpad_figure_button);
    report_desvpad_layout->addWidget(save_desvpad_report_button);
    report_desvpad_layout->addWidget(view_desvpad_report_button);
    report_desvpad_frame->setLayout(report_desvpad_layout);
    report_desvpad_frame->setFixedHeight(40);
    chart_desvpad_splitter->addWidget( report_desvpad_frame );
    report_desvpad_frame->setSizePolicy(QSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum));
    chart_tab->addTab(chart_CV_splitter, "CV Interpiles" );
    QFrame* report_CV_frame = new QFrame(chart_CV_splitter);
    QPushButton* view_CV_report_button = new QPushButton("View CV  Report",report_CV_frame);
    QPushButton* save_CV_report_button = new QPushButton("Save CV  Report",report_CV_frame);
    QPushButton* save_CV_figure_button = new QPushButton("Save CV  Figure",report_CV_frame);
    QHBoxLayout* report_CV_layout = new QHBoxLayout(report_CV_frame);
    report_CV_layout->addWidget(save_CV_figure_button);
    report_CV_layout->addWidget(save_CV_report_button);
    report_CV_layout->addWidget(view_CV_report_button);
    report_CV_frame->setLayout(report_CV_layout);
    report_CV_frame->setFixedHeight(40);
    //report_CV_layout->addStretch();
    chart_CV_splitter->addWidget ( report_CV_frame );
    report_CV_frame->setSizePolicy(QSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum));
    main_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    ///////////////
    QVBoxLayout* interpiles_variance_layout = new QVBoxLayout(this);
    interpiles_variance_layout->addWidget(main_splitter); //AQUI FOI FEITA A ALTERA��O DE "chart_splitter" PARA "main_splitter"!!
    //interpiles_variance_layout->addWidget(report_var_frame);
    this->setLayout(interpiles_variance_layout);
    this->build_value_table();
    this->build_plot();
    ///////////////////////
    data_variance_view_->SetRepresentationFromInput(table_variance_);
    data_variance_view_->Update();
    QTableView* table_variance = dynamic_cast<QTableView*>(data_variance_view_->GetWidget());
    bool ok = connect(table_variance, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
    ///////////////////////
    data_desvpad_view_->SetRepresentationFromInput(table_desvpad_);
    data_desvpad_view_->Update();
    QTableView* table_desvpad = dynamic_cast<QTableView*>(data_desvpad_view_->GetWidget());
    ok = connect(table_desvpad, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
    //////////////////////
    data_CV_view_->SetRepresentationFromInput(table_CV_);
    data_CV_view_->Update();
    QTableView* table_CV = dynamic_cast<QTableView*>(data_CV_view_->GetWidget());
    ok = connect(table_CV, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
    //////////////////////////
    data_mean_mass_view_->SetRepresentationFromInput(table_mean_mass_);
    data_mean_mass_view_->Update();
    QTableView* table_mean_mass = dynamic_cast<QTableView*>(data_mean_mass_view_->GetWidget());
    ok = connect(table_mean_mass, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
    ///////////////////
    ok = connect( save_var_figure_button, SIGNAL(clicked()), chart_variance_widget_, SLOT(save_figure()) ); ///////
    ok = connect( save_var_report_button, SIGNAL(clicked()), data_variance_view_, SLOT(save_report()) );
    ok = connect( save_desvpad_figure_button, SIGNAL(clicked()), chart_desvpad_widget_, SLOT(save_figure()) ); ///////
    ok = connect( save_desvpad_report_button, SIGNAL(clicked()), data_desvpad_view_, SLOT(save_report()) );
    ok = connect( save_CV_figure_button, SIGNAL(clicked()), chart_CV_widget_, SLOT(save_figure()) ); ///////
    ok = connect( save_CV_report_button, SIGNAL(clicked()), data_CV_view_, SLOT(save_report()) );
    table_tab->addTab(table_variance, "Variance InterPiles");
    table_tab->addTab(table_desvpad, "Stand. Dev. InterPiles");
    table_tab->addTab(table_CV, "CV InterPiles");
    table_tab->addTab(table_mean_mass, "Mean Mass");
}

void Blendsim_chart::build_plot_interpile() {
    for(int i= 0; i< grade_props_.size(); ++i) {
        vtkPlotLine* plot_variance = vtkPlotLine::SafeDownCast(chart_variance_widget_->chart()->AddPlot(vtkChart::LINE ));
        plot_variance->SetInputData(table_variance_,0,i+1);
    }
    chart_variance_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Variance");
    switch (this->blending_type) {
    case Blending_types::BLENDING_INTERPILES:
        chart_variance_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle(" Pile Mass (x10^3 t)");
        break;
    }
    //chart_variance_widget_->chart()->SetAutoAxes(true);
    chart_variance_widget_->chart()->SetVisible(true);
    chart_variance_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    chart_variance_widget_->chart()->Update();
    chart_variance_widget_->update();
    for(int i= 0; i< grade_props_.size(); ++i) {
        vtkPlotLine* plot_variance = vtkPlotLine::SafeDownCast(chart_CV_widget_->chart()->AddPlot(vtkChart::LINE ));
        plot_variance->SetInputData(table_CV_,0,i+1);
    }
    chart_CV_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Coefficient of Variation");
    switch (this->blending_type) {
    case Blending_types::BLENDING_INTERPILES:
        chart_CV_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle(" Pile Mass (x10^3 t)");
        break;
    }
    //chart_CV_widget_->chart()->SetAutoAxes(true);
    chart_CV_widget_->chart()->SetVisible(true);
    chart_CV_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    chart_CV_widget_->chart()->Update();
    chart_CV_widget_->update();
    for(int i= 0; i< grade_props_.size(); ++i) {
        vtkPlotLine* plot_variance = vtkPlotLine::SafeDownCast(chart_desvpad_widget_->chart()->AddPlot(vtkChart::LINE ));
        plot_variance->SetInputData(table_desvpad_,0,i+1);
    }
    chart_desvpad_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Standard Deviation");
    switch (this->blending_type) {
    case Blending_types::BLENDING_INTERPILES:
        chart_desvpad_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle(" Pile Mass (x10^3 t)");
        break;
    }
    //chart_desvpad_widget_->chart()->SetAutoAxes(true);
    chart_desvpad_widget_->chart()->SetVisible(true);
    chart_desvpad_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    chart_desvpad_widget_->chart()->Update();
    chart_desvpad_widget_->update();
}

void Blendsim_chart::build_value_table_interpile() {
    std::vector<int> seqmin;
    std::vector<double> blockmass;
    std::vector<double> blockmassacc;
    Blendsim_chart_creator* mp = static_cast<Blendsim_chart_creator*>(this->my_parent_);
    QTime clock_;
    QString out_buf;
    QTextStream out(&out_buf);
    clock_.start();
    for(int i=0; i< sequence_prop_->size(); ++i) {
        if(region_ && !region_->is_inside_region(i)) continue;
        seqmin.push_back(sequence_prop_->get_value(i));
    }
    for(int i=0; i< this->mass_prop_->size(); ++i) {
        if(region_ && !region_->is_inside_region(i)) continue;
        if (mass_prop_->get_value(i) < 0 || !mass_prop_->is_informed(i)) {
            blockmass.push_back(0);
        } else {
            blockmass.push_back(mass_prop_->get_value(i));
        }
        if (i == 0) {
            if (mass_prop_->get_value(i) < 0 || !mass_prop_->is_informed(i)) {
                blockmassacc.push_back(0);
            } else {
                blockmassacc.push_back(mass_prop_->get_value(i));
            }
        } else {
            if(mass_prop_->get_value(i) < 0 || !mass_prop_->is_informed(i)) {
                blockmassacc.push_back(blockmassacc[i - 1]);
            } else {
                blockmassacc.push_back(blockmassacc[i - 1] + mass_prop_->get_value(i));
            }
        }
    }
    sort_info(blockmass, seqmin, blockmass);
    vector<vector<pair<double, double> > >  var_mass_sim(grade_props_.size());
    vector<vector<pair<double, double> > >  desvpad_mass_sim(grade_props_.size());
    vector<vector<pair<double, double> > >  CV_mass_sim(grade_props_.size());
    map<int, map<int, vector<double> > > map_piles_gradacc;
    map<int, map<int, double> > map_piles_gradesum;
    map<int, map<int, vector<double> > >::iterator it_mpg = map_piles_gradacc.begin(), it_ed = map_piles_gradacc.end();
    map<int, map<int, double> >::iterator it_mpgs = map_piles_gradesum.begin(), it_eds = map_piles_gradesum.end();
    int nc_mpg = 0;
    MapPileSeries& pileseries = mp->getMapPileSeries();
    pileseries.clear();
    for(int p=0; p< grade_props_.size(); ++p) {
        Grid_continuous_property* grade_prop = grade_props_[p];
        vector<double> sim;
        std::vector<double> blockteormassacc;
        for (int i = 0; i < grade_prop->size(); ++i) {
            if(region_ && !region_->is_inside_region(i)) continue;
            if (grade_prop->get_value(i) < 0 || !grade_prop->is_informed(i)) {
                sim.push_back(0);
            } else {
                sim.push_back(grade_prop->get_value(i));
            }
            if (i == 0) {
                if (grade_prop->get_value(i) < 0 || !grade_prop->is_informed(i)) {
                    blockteormassacc.push_back(0);
                } else {
                    blockteormassacc.push_back(blockmass[i] * sim[i]);
                }
            } else {
                if (grade_prop->get_value(i) < 0 || !grade_prop->is_informed(i)) {
                    blockteormassacc.push_back(blockteormassacc[i - 1]);
                } else {
                    blockteormassacc.push_back(blockteormassacc[i - 1] + blockmass[i] * sim[i]);
                }
            }
        }
        sort_info(sim, seqmin, sim);
        double gps = grade_pon_sim(blockmass, sim);
        for (int ini_mass = IniMass; ini_mass <= FinalMass; ini_mass += IncMass) {
            BlendingPiles* pile_resultant = create_piles(blockmass, sim, blockmassacc, blockteormassacc, ini_mass, gps);
            vector<BlendingPile>& pile = pile_resultant->pile;
            double var = pile_resultant->sqrt_grade_acc_sum;
            var_mass_sim[p].push_back(pair<double, double>(ini_mass, var));
            desvpad_mass_sim[p].push_back(pair<double, double>(ini_mass, sqrt(var)));
            CV_mass_sim[p].push_back(pair<double, double>(ini_mass, sqrt(var) / gps));
            for (int i = 0; i < pile.size(); ++i) {
                if (p == 0) nc_mpg++;
                PairMinMax& pminmax = pileseries[ini_mass][i];
                pminmax.average_ += pile[i].grade_acc / grade_props_.size();
                if (p == 0) {
                    pminmax.min_ = pminmax.max_ = pile[i].grade_acc;
                    pminmax.addr0_min = pminmax.addr0_max = pile[i].addr0;
                    pminmax.n_seq_min = pminmax.n_seq_max = pile[i].n_seq;
                }
                pminmax.grades.push_back(pile[i].grade_acc);
                if (p == grade_props_.size() - 1) {
                    int target = static_cast<int>(0.9 * grade_props_.size());
                    int ini = 0, fin = pminmax.grades.size() - 1;
                    int p_sol = -1;
                    int m = -1;
                    std::vector<double> g = pminmax.grades;
                    std::sort(g.begin(), g.end());
                    while (ini < fin) {
                        m = p_sol = (ini + fin) >> 1;
                        int t = std::lower_bound(g.begin(), g.end(), g[p_sol]) - g.begin() + 1;
                        if (t < target) {
                            ini = p_sol + 1;
                        } else if (t > target) {
                            fin = p_sol - 1;
                        } else {
                            break;
                        }
                    }
                    pminmax.p90_ = g[m];
                }
                if (pile[i].grade_acc > pminmax.max_) {
                    pminmax.max_ = pile[i].grade_acc;
                    pminmax.addr0_max = pile[i].addr0;
                    pminmax.n_seq_max = pile[i].n_seq;
                    //++pminmax.n_max_;
                }
                if (pile[i].grade_acc < pminmax.min_) {
                    pminmax.min_ = pile[i].grade_acc;
                    pminmax.addr0_min = pile[i].addr0;
                    pminmax.n_seq_min = pile[i].n_seq;
                    //++pminmax.n_min_;
                }
                map_piles_gradacc[ini_mass][i].push_back(pile[i].grade_acc);
                map_piles_gradesum[ini_mass][i] = pile[i].sum_mass;
            }
            if (ini_mass < min_X) {
                min_X = ini_mass;
            }
            if (var < min_Y) {
                min_Y = var;
            }
            if (ini_mass > max_X) {
                max_X = ini_mass;
            }
            if (var > max_Y) {
                max_Y = var;
            }
            delete pile_resultant;
        }
    }
    mp->update_pileseries_selector();
    //////////////////////////////////////////////////////////////////////////////////
    table_variance_ = vtkSmartPointer<vtkTable>::New();
    table_desvpad_ = vtkSmartPointer<vtkTable>::New();
    table_CV_ = vtkSmartPointer<vtkTable>::New();
    table_mean_mass_ = vtkSmartPointer<vtkTable>::New();
    //get size of vector
    vtkSmartPointer<vtkFloatArray> index_array_var = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_desvpad = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_CV = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_mean_mass = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_real_mass = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_mean_mass_pile = vtkSmartPointer<vtkFloatArray>::New();
    index_array_var->SetName("Mass (x10^3 t)");
    index_array_var->SetNumberOfValues(var_mass_sim[0].size());
    index_array_desvpad->SetName("Mass (x10^3 t)");
    index_array_desvpad->SetNumberOfValues(var_mass_sim[0].size());
    index_array_CV->SetName("Mass (x10^3 t)");
    index_array_CV->SetNumberOfValues(var_mass_sim[0].size());
    for(int i = 0; i < var_mass_sim[0].size(); ++i) {
        index_array_var->SetValue(i, var_mass_sim[0][i].first /  1000);
        index_array_desvpad->SetValue(i, var_mass_sim[0][i].first /  1000);
        index_array_CV->SetValue(i, var_mass_sim[0][i].first /  1000);
    }
    ///////////////////////
    index_array_mean_mass->SetName("Exp.Mass(x10^3 t)");
    index_array_mean_mass->SetNumberOfValues(nc_mpg);
    int idx = 0;
    for (it_mpg = map_piles_gradacc.begin(); it_mpg != it_ed; ++it_mpg) {
        map<int, vector<double> >::iterator it_pile = it_mpg->second.begin(), it_pile_ed = it_mpg->second.end();
        int id = it_mpg->first;
        while (it_pile != it_pile_ed) {
            index_array_mean_mass->SetValue(idx, id / 1000);
            ++it_pile;
            ++idx;
        }
    }
    idx = 0;
    ///////////////////////
    index_array_real_mass->SetName("Real Mass(x10^3 t)");
    index_array_real_mass->SetNumberOfValues(nc_mpg);
    for (it_mpgs = map_piles_gradesum.begin(); it_mpgs != it_eds; ++it_mpgs) {
        map<int, double>::iterator it_pile = it_mpgs->second.begin(), it_pile_eds = it_mpgs->second.end();
        while (it_pile != it_pile_eds) {
            double m = it_pile->second;
            index_array_real_mass->SetValue(idx, m);
            ++it_pile;
            ++idx;
        }
    }
    /////////////////////////
    idx = 0;
    index_array_mean_mass_pile->SetName("Pile");
    index_array_mean_mass_pile->SetNumberOfValues(nc_mpg);
    for (it_mpg = map_piles_gradacc.begin(); it_mpg != it_ed; ++it_mpg) {
        map<int, vector<double> >::iterator it_pile = it_mpg->second.begin(), it_pile_ed = it_mpg->second.end();
        while (it_pile != it_pile_ed) {
            int id = it_pile->first;
            index_array_mean_mass_pile->SetValue(idx, id+1);
            ++it_pile;
            ++idx;
        }
    }
    table_mean_mass_->AddColumn(index_array_mean_mass);
    table_mean_mass_->AddColumn(index_array_mean_mass_pile);
    table_mean_mass_->AddColumn(index_array_real_mass);
    for(int p=0; p< grade_props_.size(); ++p) {
        Grid_continuous_property* grade_prop = grade_props_[p];
        vtkSmartPointer<vtkFloatArray> grade_mean_mass_array = vtkSmartPointer<vtkFloatArray>::New();
        grade_mean_mass_array->SetName(grade_prop->name().c_str());
        grade_mean_mass_array->SetNumberOfValues(nc_mpg);
        idx = 0;
        for (it_mpg = map_piles_gradacc.begin(); it_mpg != it_ed; ++it_mpg) {
            map<int, vector<double> >::iterator it_pile = it_mpg->second.begin(), it_pile_ed = it_mpg->second.end();
            while (it_pile != it_pile_ed) {
                double m = it_pile->second.at(p);
                grade_mean_mass_array->SetValue(idx, m);
                ++it_pile;
                ++idx;
            }
        }
        table_mean_mass_->AddColumn(grade_mean_mass_array);
    }
    ///////////////////////
    table_variance_->AddColumn(index_array_var);
    table_desvpad_->AddColumn(index_array_desvpad);
    table_CV_->AddColumn(index_array_CV);
    ///
    for(int p=0; p< grade_props_.size(); ++p) {
        Grid_continuous_property* grade_prop = grade_props_[p];
        vtkSmartPointer<vtkFloatArray> grade_var_array = vtkSmartPointer<vtkFloatArray>::New();
        vtkSmartPointer<vtkFloatArray> grade_desvpad_array = vtkSmartPointer<vtkFloatArray>::New();
        vtkSmartPointer<vtkFloatArray> grade_CV_array = vtkSmartPointer<vtkFloatArray>::New();
        grade_var_array->SetName(grade_prop->name().c_str());
        grade_var_array->SetNumberOfValues(var_mass_sim[p].size());
        for(int i = 0; i < var_mass_sim[p].size(); ++i) {
            grade_var_array->SetValue(i,var_mass_sim[p][i].second);
        }
        table_variance_->AddColumn(grade_var_array);
        grade_desvpad_array->SetName(grade_prop->name().c_str());
        grade_desvpad_array->SetNumberOfValues(desvpad_mass_sim[p].size());
        for(int i = 0; i < desvpad_mass_sim[p].size(); ++i) {
            grade_desvpad_array->SetValue(i,desvpad_mass_sim[p][i].second);
        }
        table_desvpad_->AddColumn(grade_desvpad_array);
        grade_CV_array->SetName(grade_prop->name().c_str());
        grade_CV_array->SetNumberOfValues(CV_mass_sim[p].size());
        for(int i = 0; i < CV_mass_sim[p].size(); ++i) {
            grade_CV_array->SetValue(i,CV_mass_sim[p][i].second);
        }
        table_CV_->AddColumn(grade_CV_array);
    }
    int t = clock_.elapsed();
    out << "Process took " << t << "ms to run\n";
    mp->setTime(out_buf);
}

//PILE SERIES
void Blendsim_chart::build_pileseries_chart() {
    QString title = QString("Pile series");
    this->setWindowTitle(title);
    this->setWindowIcon(QPixmap(":/icons/appli/Pixmaps/ar2gems-icon-256x256.png"));
    QSplitter* main_splitter = new QSplitter(Qt::Horizontal, this);
    if (this->blending_type == Blending_types::BLENDING_PILESERIES) {
        QTabWidget* chart_tab = new QTabWidget(main_splitter);
        QSplitter* chart_pileseries_splitter = new QSplitter(Qt::Vertical, main_splitter);
        chart_pileseries_widget_ = new Chart_widget(chart_pileseries_splitter);
        chart_pileseries_splitter->addWidget( chart_pileseries_widget_ );
        chart_pileseries_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
        chart_tab->addTab(chart_pileseries_splitter, "Pile Series" );
        QFrame* report_pileseries_frame = new QFrame(chart_pileseries_splitter);
        QPushButton* view_pileseries_report_button = new QPushButton("View Pile Series Report",report_pileseries_frame);
        QPushButton* save_pileseries_report_button = new QPushButton("Save Pile Series Report",report_pileseries_frame);
        QPushButton* save_pileseries_figure_button = new QPushButton("Save Pile Series Figure",report_pileseries_frame);
        QHBoxLayout* report_pileseries_layout = new QHBoxLayout(report_pileseries_frame);
        report_pileseries_layout->addWidget(save_pileseries_figure_button);
        report_pileseries_layout->addWidget(save_pileseries_report_button);
        report_pileseries_layout->addWidget(view_pileseries_report_button);
        report_pileseries_frame->setLayout(report_pileseries_layout);
        report_pileseries_frame->setFixedHeight(40);
        chart_pileseries_splitter->addWidget( report_pileseries_frame );
        report_pileseries_frame->setSizePolicy(QSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum));
        bool ok = connect( save_pileseries_figure_button, SIGNAL(clicked()), chart_pileseries_widget_, SLOT(save_figure()) ); ///////
        ok = connect( save_pileseries_report_button, SIGNAL(clicked()), data_pileseries_view_, SLOT(save_report()) );
    }
    main_splitter->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    QVBoxLayout* interpiles_pileseries_layout = new QVBoxLayout(this);
    interpiles_pileseries_layout->addWidget(main_splitter); //AQUI FOI FEITA A ALTERA��O DE "chart_splitter" PARA "main_splitter"!!
    this->setLayout(interpiles_pileseries_layout);
    this->build_value_table();
    this->build_plot();
    ///////////////////////
    QTabWidget* table_tab = new QTabWidget(main_splitter);
    if (this->blending_type == Blending_types::BLENDING_PILESERIES) {
        data_pileseries_view_ = vtkSmartPointer<vtkQtTableView>::New();
        data_pileseries_view_->SetRepresentationFromInput(table_pileseries_);
        data_pileseries_view_->Update();
        QTableView* table_pileseries = dynamic_cast<QTableView*>(data_pileseries_view_->GetWidget());
        bool ok = connect(table_pileseries, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
        table_tab->addTab(table_pileseries, "Pile series");
    } else {
        data_pilelocate_min_view_ = vtkSmartPointer<vtkQtTableView>::New();
        data_pilelocate_max_view_ = vtkSmartPointer<vtkQtTableView>::New();
        data_pilelocate_min_view_->SetRepresentationFromInput(table_pilelocate_min_);
        data_pilelocate_min_view_->Update();
        data_pilelocate_max_view_->SetRepresentationFromInput(table_pilelocate_max_);
        data_pilelocate_max_view_->Update();
        QTableView* table_pilelocate_min = dynamic_cast<QTableView*>(data_pilelocate_min_view_->GetWidget());
        QTableView* table_pilelocate_max = dynamic_cast<QTableView*>(data_pilelocate_max_view_->GetWidget());
        bool ok = connect(table_pilelocate_min, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
        ok = connect(table_pilelocate_max, SIGNAL(clicked(const QModelIndex &)), this, SLOT(cutoff_selected(const QModelIndex &)) );
        table_tab->addTab(table_pilelocate_min, "Pile Locate - Values Below Min");
        table_tab->addTab(table_pilelocate_max, "Pile Locate - Values Above Max");
    }
}

void Blendsim_chart::build_value_table_pileseries() {
    Blendsim_chart_creator* mp = static_cast<Blendsim_chart_creator*>(this->my_parent_);
    MapPileSeries& pileseries = mp->getMapPileSeries();
    int mass = mp->getPile();
    std::map<int, PairMinMax>& m_pile = pileseries[mass];
    std::map<int, PairMinMax>::iterator it = m_pile.begin(), ed = m_pile.end();
    //////////////////////////////////////////////////////////////////////////////////
    table_pileseries_ = vtkSmartPointer<vtkTable>::New();
    //get size of vector
    vtkSmartPointer<vtkFloatArray> index_array_pile = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_pileseries_min = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_pileseries_max = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_pileseries_etype = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_array_pileseries_p90 = vtkSmartPointer<vtkFloatArray>::New();
    index_array_pile->SetName("Pile");
    index_array_pile->SetNumberOfValues(m_pile.size());
    index_array_pileseries_min->SetName("Grade min");
    index_array_pileseries_min->SetNumberOfValues(m_pile.size());
    index_array_pileseries_max->SetName("Grade max");
    index_array_pileseries_max->SetNumberOfValues(m_pile.size());
    index_array_pileseries_etype->SetName("E-Type");
    index_array_pileseries_etype->SetNumberOfValues(m_pile.size());
    index_array_pileseries_p90->SetName("P90");
    index_array_pileseries_p90->SetNumberOfValues(m_pile.size());
    int idx = 0;
    min_X = min_Y = max_X = max_Y = 0;
    while (it != ed) {
        index_array_pile->SetValue(idx,it->first+1);
        index_array_pileseries_min->SetValue(idx,it->second.min_);
        index_array_pileseries_max->SetValue(idx,it->second.max_);
        index_array_pileseries_etype->SetValue(idx, it->second.average_);
        index_array_pileseries_p90->SetValue(idx, it->second.p90_);
        if (it->first > max_X) max_X = it->first;
        if (it->first < min_X) min_X = it->first;
        if (it->second.max_ > max_Y) max_Y = it->second.max_;
        if (it->second.min_ < min_Y) min_Y = it->second.min_;
        ++it;
        ++idx;
    }
    table_pileseries_->AddColumn(index_array_pile);
    table_pileseries_->AddColumn(index_array_pileseries_min);
    table_pileseries_->AddColumn(index_array_pileseries_max);
    table_pileseries_->AddColumn(index_array_pileseries_etype);
    table_pileseries_->AddColumn(index_array_pileseries_p90);
    ///////////////////////
}

void Blendsim_chart::build_plot_pileseries() {
    for (int i = 1; i < 5; ++i) {
        vtkPlotLine* plot_pileseries = vtkPlotLine::SafeDownCast(chart_pileseries_widget_->chart()->AddPlot(vtkChart::LINE ));
        plot_pileseries->SetInputData(table_pileseries_,0, i);
    }
    chart_pileseries_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Grade");
    chart_pileseries_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle(" Pile");
    //chart_pileseries_widget_->chart()->SetAutoAxes(true);
    chart_pileseries_widget_->chart()->SetVisible(true);
    chart_pileseries_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding));
    chart_pileseries_widget_->chart()->Update();
    chart_pileseries_widget_->update();
}


//PILE LOCATE
void Blendsim_chart::build_value_table_pilelocate() {
    Blendsim_chart_creator* mp = static_cast<Blendsim_chart_creator*>(this->my_parent_);
    MapPileSeries& pileseries = mp->getMapPileSeries();
    int mass = mp->getPile();
    double grade_min = mp->get_GradeMeanMin();
    double grade_max = mp->get_GradeMeanMax();
    std::map<int, PairMinMax>& m_pile = pileseries[mass];
    std::map<int, PairMinMax>::iterator it = m_pile.begin(), ed = m_pile.end();
    //////////////////////////////////////////////////////////////////////////////////
    table_pilelocate_min_ = vtkSmartPointer<vtkTable>::New();
    table_pilelocate_max_ = vtkSmartPointer<vtkTable>::New();
    //get size min
    vtkSmartPointer<vtkFloatArray> index_pile_num_min = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_pile_mean_min = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_pile_firstblock_min = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_pile_numblock_min = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_pile_simul_count_min = vtkSmartPointer<vtkFloatArray>::New();
    index_pile_num_min->SetName("Pile Number");
    index_pile_num_min->SetNumberOfValues(m_pile.size());
    index_pile_mean_min->SetName("Mean Min");
    index_pile_mean_min->SetNumberOfValues(m_pile.size());
    index_pile_firstblock_min->SetName("# First Block");
    index_pile_firstblock_min->SetNumberOfValues(m_pile.size());
    index_pile_numblock_min->SetName("# Blocks");
    index_pile_numblock_min->SetNumberOfValues(m_pile.size());
    index_pile_simul_count_min->SetName("% Simulation");
    index_pile_simul_count_min->SetNumberOfValues(m_pile.size());
    //get size max
    vtkSmartPointer<vtkFloatArray> index_pile_num_max = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_pile_mean_max = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_pile_firstblock_max = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_pile_numblock_max = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> index_pile_simul_count_max = vtkSmartPointer<vtkFloatArray>::New();
    index_pile_num_max->SetName("Pile Number");
    index_pile_num_max->SetNumberOfValues(m_pile.size());
    index_pile_mean_max->SetName("Mean Max");
    index_pile_mean_max->SetNumberOfValues(m_pile.size());
    index_pile_firstblock_max->SetName("# First Block");
    index_pile_firstblock_max->SetNumberOfValues(m_pile.size());
    index_pile_numblock_max->SetName("# Blocks");
    index_pile_numblock_max->SetNumberOfValues(m_pile.size());
    index_pile_simul_count_max->SetName("% Simulation");
    index_pile_simul_count_max->SetNumberOfValues(m_pile.size());
    int idx_min = 0, idx_max = 0;
    while (it != ed) {
        PairMinMax& pminmax = it->second;
        double n_sim = pminmax.grades.size();
        pminmax.n_min_ = 0;
        pminmax.n_max_ = 0;
        for (int i = 0; i < pminmax.grades.size(); ++i) {
            if (pminmax.grades[i] <= grade_min) ++pminmax.n_min_;
            if (pminmax.grades[i] >= grade_max) ++pminmax.n_max_;
        }
        if (it->second.min_ <= grade_min) {
            index_pile_num_min->SetValue(idx_min,it->first+1);
            index_pile_mean_min->SetValue(idx_min,it->second.min_);
            index_pile_firstblock_min->SetValue(idx_min, it->second.addr0_min + 1);
            index_pile_numblock_min->SetValue(idx_min, it->second.n_seq_min);
            index_pile_simul_count_min->SetValue(idx_min, 100.0 * it->second.n_min_ / n_sim);
            ++idx_min;
        }
        if (it->second.max_ >= grade_max) {
            index_pile_num_max->SetValue(idx_max, it->first+1);
            index_pile_mean_max->SetValue(idx_max, it->second.max_);
            index_pile_firstblock_max->SetValue(idx_max, it->second.addr0_max + 1);
            index_pile_numblock_max->SetValue(idx_max, it->second.n_seq_max);
            index_pile_simul_count_max->SetValue(idx_max, 100.0 * it->second.n_max_ / n_sim);
            ++idx_max;
        }
        ++it;
    }
    index_pile_num_min->Resize(idx_min);
    index_pile_mean_min->Resize(idx_min);
    index_pile_firstblock_min->Resize(idx_min);
    index_pile_numblock_min->Resize(idx_min);
    index_pile_simul_count_min->Resize(idx_min);
    index_pile_num_max->Resize(idx_max);
    index_pile_mean_max->Resize(idx_max);
    index_pile_firstblock_max->Resize(idx_max);
    index_pile_numblock_max->Resize(idx_max);
    index_pile_simul_count_max->Resize(idx_max);
    table_pilelocate_min_->AddColumn(index_pile_num_min);
    table_pilelocate_min_->AddColumn(index_pile_mean_min);
    table_pilelocate_min_->AddColumn(index_pile_firstblock_min);
    table_pilelocate_min_->AddColumn(index_pile_numblock_min);
    table_pilelocate_min_->AddColumn(index_pile_simul_count_min);
    table_pilelocate_max_->AddColumn(index_pile_num_max);
    table_pilelocate_max_->AddColumn(index_pile_mean_max);
    table_pilelocate_max_->AddColumn(index_pile_firstblock_max);
    table_pilelocate_max_->AddColumn(index_pile_numblock_max);
    table_pilelocate_max_->AddColumn(index_pile_simul_count_max);
    ///////////////////////
}
