/*
Implementação do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/



#include "accplotreport.h"

AccPlotReport::AccPlotReport(QWidget *parent):QDialog(parent) {
    ui.setupUi(this);
    self = 0;
    QObject::connect(this,
                     SIGNAL(setText(QString)),
                     this,
                     SLOT(setReport(QString)),
                     Qt::QueuedConnection
                    );
}

AccPlotReport::~AccPlotReport() {
}
