#ifndef __GTL_MAIN_HEADER_SAMPLER_H__
#define __GTL_MAIN_HEADER_SAMPLER_H__

#include <GsTL/sampler/random_sampler.h>

#endif
