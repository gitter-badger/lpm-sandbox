#ifndef CREATE_AREAL_DATASET_H
#define CREATE_AREAL_DATASET_H

# include <vector>
# include <map>
# include "Struct_Drillhole.h"

std::vector<std::vector<double> > Create_Areal_Dataset(const std::map<int, Struct_Drillhole> &Map_Drillhole);


#endif