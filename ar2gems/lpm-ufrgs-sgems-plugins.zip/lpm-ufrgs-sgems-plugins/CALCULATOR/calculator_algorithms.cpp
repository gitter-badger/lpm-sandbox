/*
Implementação do plugin que efetua transformações nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/


#include "calculator_algorithms.h"
#include "calculator_action.h"
#include "report.h"

#include <geostat/utilities.h>
#include <utils/string_manipulation.h>
#include <grid/utilities.h>
#include <grid/neighbors.h>
#include <geostat/utilities.h>

#include <qstring.h>
#include <qmessagebox.h>
#include <cstdio>

CalculatorAlgorithms::CalculatorAlgorithms() {
}

CalculatorAlgorithms::~CalculatorAlgorithms() {
}

Named_interface* CalculatorAlgorithms::create_new_interface(std::string&) {
    return new CalculatorAlgorithms;
}

bool CalculatorAlgorithms::initialize(const Parameters_handler* parameters,
                                      Error_messages_handler* errors, Progress_notifier* notifier) {
    this->errors_ = errors;
    std::string result_name = parameters->value("result.value");
    if (result_name.size() < 1) {
        errors->report("result", "It's missing the result parameter name.");
        return false;
    }
    std::string cmd = parameters->value("cmd.value");
    if (cmd.size() < 1) {
        errors->report("cmd", "It's missing the evaluation command.");
        return false;
    }
    std::string grid = parameters->value("grid.value");
    if (grid.size() < 1) {
        errors->report("grid", "It's missing the grid.");
        return false;
    }
    std::string props = parameters->value("props.value");
    if (props.size() < 1) {
        errors->report("props", "It's missing the properties list.");
        return false;
    }
    this->params = result_name + "|" + cmd + "|" + grid + "|" + props;
    this->action_ = new CalculatorHandling();
    return static_cast<CalculatorHandling*>(this->action_)->init(this->params, 0, this->errors_);
}

int CalculatorAlgorithms::execute(GsTL_project* proj, Progress_notifier* notifier) {
    return static_cast<CalculatorHandling*>(this->action_)->exec(notifier);
}

