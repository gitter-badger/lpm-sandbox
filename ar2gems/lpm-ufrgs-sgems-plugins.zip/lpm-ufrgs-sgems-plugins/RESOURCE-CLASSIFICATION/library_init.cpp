#include "common.h"
#include "convex_kriging_algo.h"
#include "slope_regression_algo.h"
#include "error_classification_algo.h"
#include "risk_index_algo.h"
#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>

extern "C" PLUGINS_LPM_UFRGS_DECL int plugin_init() {
    GsTLlog << "\n\n registering actions add_properties" << "\n";
    SmartPtr<Named_interface> ni;
    Manager* dir;
    // Register algo
    ni = Root::instance()->interface( geostatAlgo_manager );
    dir = dynamic_cast<Manager*>( ni.raw_ptr() );
    if( !dir ) {
        GsTLlog << "Directory " << geostatAlgo_manager << " does not exist \n";
        return 1;
    }
    dir->factory( Convex_kriging().name(), Convex_kriging::create_new_interface );
    dir->factory( Slope_regression().name(), Slope_regression::create_new_interface );
    dir->factory( Risk_index().name(), Risk_index::create_new_interface );
    dir->factory( Error_classification().name(), Error_classification::create_new_interface );
    return 0;
}
