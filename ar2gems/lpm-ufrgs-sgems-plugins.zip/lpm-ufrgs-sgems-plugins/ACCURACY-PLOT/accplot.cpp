/*
Implementa��o do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/

#include "accplot.h"

AccPlot::AccPlot(QWidget *parent)
    : QFrame(parent) {
    ui.setupUi(this);
}

int AccPlot::getNumberBins() {
    return ui.nBins->value();
}

int AccPlot::getNumberThreads() {
    return ui.nThreads->value();
}

QStringList AccPlot::getProperties() {
    return ui.props->selected_properties();
}

QString AccPlot::getReferenceProperty() {
    return ui.referenceProp->currentText();
}

Geostat_grid* AccPlot::getGrid() {
    return ui.grid->selected_grid_object();
}

bool AccPlot::computeAverageWidth() {
    return ui.computeAverageWidth->isChecked();
}

AccPlot::~AccPlot() {
}

QPushButton* AccPlot::getDisplayButton() {
    return ui.displayButton;
}

double AccPlot::getPrecision() {
    return ui.precision->value();
}