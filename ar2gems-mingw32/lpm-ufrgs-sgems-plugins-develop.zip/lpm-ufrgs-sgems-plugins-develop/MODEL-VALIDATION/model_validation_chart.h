/*
Implementa��o do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/



#ifndef __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_CHART_H___
#define __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_CHART_H___

#include "common.h"

#include <charts/chart_base.h>
#include <charts/chart_widget.h>
#include <charts/chart_display_control.h>
#include <grid/grid_property.h>
#include <grid/grid_weight_property.h>
#include <grid/grid_filter.h>

#include <vtkQtTableView.h>
#include <vtkSmartPointer.h>
#include <vtkLookupTable.h>
#include <vtkChartPie.h>

#include <QModelIndex>
#include <QLabel>
#include <qtextstream.h>
#include <qfiledialog.h>

#include <vector>
#include <map>

#include "model_validation.h"

#include "model_validation_graphout.h"
#include "model_validation_process.h"

enum ModelValidation_types {
    MODEL_VALIDATION              = 0
};

enum ModelValidationOperation_type {
    CALC_MODEL_VALIDATION = 0
};

static const char* model_validation_charts_name = "Model Validation";

struct ModelValidationPoint {
    double x, y;
    ModelValidationPoint(double x = 0, double y = 0) : x(x), y(y) {}
};

inline bool operator<(const ModelValidationPoint& a, const ModelValidationPoint& b) {
    if (a.x < b.x) return true;
    return a.y < b.y;
}

typedef std::vector<ModelValidationPoint> ModelValidationPoints;

class PLUGINS_LPM_UFRGS_DECL ModelValidation_chart : public Chart_base, public ModelValidationAction {
    Q_OBJECT

  public:
    void set_ok(bool ok) {
        is_ok = ok;
    }

    void run_master_process(ModelValidationProcess* process_handler, int number_threads, std::vector<ModelValidationProcess*>& slaves);
    void run_slave_process(ModelValidationProcess* process_handler, int id_thread, int number_threads);

    explicit ModelValidation_chart(
        ModelValidation* my_model_validation,
        QWidget *parent = 0);


    ~ModelValidation_chart() {
    }

  public slots:
    void build_model_validation_chart();

    void repaint_chart(const QString& in);
    void clear_chart();

    void save_report();
    void view_report();

    void build_value_table();
    void build_plot();

    void build_model_validations(int id, int n_threads);

    void import_graphs();


  private:
    bool ok;
    void build_model_validation(ModelValidationPoints& pts,  int i, bool is_reference = false);

    ModelValidationGraphOutput* gout_;

    ModelValidation_types chart_type_;

    ModelValidation* my_model_validation_;

    Chart_widget* chart_model_validation_widget_;

    Chart_display_control* chart_model_validation_control_;

    vtkSmartPointer<vtkTable> table_model_validation_;
    vtkSmartPointer<vtkQtTableView> table_model_validation_view_;
    QTableView* qtable_model_validation_;

    vtkSmartPointer<vtkTable> table_ref_model_validation_;
    vtkSmartPointer<vtkQtTableView> table_ref_model_validation_view_;
    QTableView* qtable_ref_model_validation_;

    void write_table_model_validation(QTextStream& out);


    std::vector<ModelValidationPoints>  model_validations_;
    ModelValidationPoints  model_ref_validations_;

    bool is_ok;
    double dv_;
    QStringList props_names_;
    QString prop_ref_name_;
    Geostat_grid* grid_;
    Geostat_grid* grid_reference_;
    QString weight_;

    int n_bins_;
    QMutex mutex;
    ModelValidationProcess* my_process_handler_;

    ModelValidationDirection dir_;
};

#endif
