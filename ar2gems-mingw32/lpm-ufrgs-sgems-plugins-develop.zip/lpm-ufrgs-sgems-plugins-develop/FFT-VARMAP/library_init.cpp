/*
Implementação do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, Péricles Lopes Machado
*/


/* -----------------------------------------------------------------------------
** Copyright (c) 2012 Advanced Resources and Risk Technology, LLC
** All rights reserved.
**
** This file is part of Advanced Resources and Risk Technology, LLC (AR2TECH)
** version of the open source software sgems.  It is a derivative work by
** AR2TECH (THE LICENSOR) based on the x-free license granted in the original
** version of the software (see notice below) and now sublicensed such that it
** cannot be distributed or modified without the explicit and written permission
** of AR2TECH.
**
** Only AR2TECH can modify, alter or revoke the licensing terms for this
** file/software.
**
** This file cannot be modified or distributed without the explicit and written
** consent of AR2TECH.
**
** Contact Dr. Alex Boucher (aboucher@ar2tech.com) for any questions regarding
** the licensing of this file/software
**
** The open-source version of sgems can be downloaded at
** sourceforge.net/projects/sgems.
** ----------------------------------------------------------------------------*/

#include <geostat/library_geostat_init.h>
#include <geostat/parameters_handler_impl.h>

#include <utils/manager_repository.h>
#include <utils/gstl_messages.h>
#include <geostat/two_point_statistics_initialization.h>
#include <geostat/two_point_lmc_initialization.h>
#include <math/continuous_distribution.h>
#include <math/non_parametric_distribution.h>

#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>

#include <fftw3.h>

#include "common.h"

#include "fftvariogram_chart_creator.h"

#include "fftvarmap.h"
#include "fftcrossvarmap.h"

class VarmapPluginMutex : public FFTMutex {
  public:
    VarmapPluginMutex()
        : FFTMutex(), mutex() {
    }

    void lock() {
        mutex.lock();
    }

    void unlock() {
        mutex.unlock();
    }
  private:
    QMutex mutex;
};

VarmapPluginMutex _g_plugin_mutex;

extern "C" PLUGINS_LPM_UFRGS_DECL
int plugin_init() {
    fftw_init_threads();
    set_fft_mutex(&_g_plugin_mutex);
    // ALGORITHMS
    GsTLlog << "\n\n registering FFTVarmap Algorithms" << "\n";
    SmartPtr<Named_interface> ni = Root::instance()->interface(geostatAlgo_manager);
    Manager* dir = dynamic_cast<Manager*>(ni.raw_ptr());
    if( !dir ) {
        GsTLlog << "Directory " << geostatAlgo_manager << " does not exist \n";
        return 1;
    }
    dir->factory(FFTVarmap().name(), FFTVarmap::create_new_interface);
    GsTLlog << "\n\n registering FFTVarmap_declus Algorithms" << "\n";
    ni = Root::instance()->interface(geostatAlgo_manager);
    dir = dynamic_cast<Manager*>(ni.raw_ptr());
    if (!dir) {
        GsTLlog << "Directory " << geostatAlgo_manager << " does not exist \n";
        return 1;
    }
    dir->factory(FFTVarmap_declus().name(), FFTVarmap_declus::create_new_interface);
    GsTLlog << "\n\n registering FFTCrossVarmap Algorithms" << "\n";
    ni = Root::instance()->interface(geostatAlgo_manager);
    dir = dynamic_cast<Manager*>(ni.raw_ptr());
    if (!dir) {
        GsTLlog << "Directory " << geostatAlgo_manager << " does not exist \n";
        return 1;
    }
    dir->factory(FFTCrossVarmap().name(), FFTCrossVarmap::create_new_interface);
    GsTLlog << "\n\n registering FFTCrossVarmap_declus Algorithms" << "\n";
    ni = Root::instance()->interface(geostatAlgo_manager);
    dir = dynamic_cast<Manager*>(ni.raw_ptr());
    if (!dir) {
        GsTLlog << "Directory " << geostatAlgo_manager << " does not exist \n";
        return 1;
    }
    dir->factory(FFTCrossVarmap_declus().name(), FFTCrossVarmap_declus::create_new_interface);
    // Add the new chart
    GsTLlog << "\n\n registering FFTVariogram charts" << "\n";
    ni = Root::instance()->interface(eda_charts_manager);
    dir = dynamic_cast<Manager*>(ni.raw_ptr());
    if (!dir) {
        GsTLlog << "Directory " << eda_charts_manager << " does not exist \n";
        return 1;
    }
    dir->factory(FFTVariogram_chart_creator_factory().name(),
                 FFTVariogram_chart_creator_factory::create_new_interface);
    return 0;
}
