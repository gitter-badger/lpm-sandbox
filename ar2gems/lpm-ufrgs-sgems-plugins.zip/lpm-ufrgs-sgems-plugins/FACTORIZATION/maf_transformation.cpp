/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/

#include <fstream>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <ctime>

#include <QTextStream>

#include "maf_transformation.h"




#include <vector>
#include <Eigen/Dense>

using Eigen::MatrixXd;
using namespace Eigen;


#include <geostat/utilities.h>

#include <utils/string_manipulation.h>
#include <grid/utilities.h>

Named_interface* MAF_Transformation::create_new_interface( std::string& ) {
    return new MAF_Transformation;
}


// MAFTransformation gridName::res_prop::prop1::prop2[::prop3::propN]
bool MAF_Transformation::init(std::string& parameters, GsTL_project* proj, Error_messages_handler* errors, Progress_notifier* notifier) {
    this->inverse_ = false;
    std::vector<std::string> params = String_Op::decompose_string(parameters, Actions::separator, Actions::unique);
    if (params.size() < 2) {
        errors->report("Parameters are missing");
        return false;
    }
    std::string grid_name = params[0];
    if (grid_name.empty()) {
        errors->report("No grid selected");
        return false;
    }
    grid_ = get_grid_from_manager(grid_name);
    if (grid_ == 0) {
        errors->report("The grid " + grid_name + " does not exist");
        return false;
    }
    for (size_t i = 1; i < params.size(); ++i) {
        Grid_continuous_property* prop = grid_->property(params[i]);
        if (prop == 0) {
            errors->report("The property " + params[i] + " does not exist" );
            return false;
        }
        props_.push_back(prop);
        std::string alr_prop_name = "MAF_" + std::to_string(i);
        Grid_continuous_property* p = grid_->add_property(alr_prop_name);
        if (p == 0) {
            p = grid_->property(alr_prop_name);
            if(p == 0) {
                errors->report( "Could not create the property " + alr_prop_name);
                return false;
            }
        }
        MAF_props_.push_back(p);
    }
    return true;
}

bool MAF_Transformation::init_input(std::string& parameters) {
    std::vector<std::string> params = String_Op::decompose_string(parameters, Actions::separator, Actions::unique);
    std::string grid_name = params[0];
    grid_input_ = get_grid_from_manager(grid_name);
    for (int i = 1; i < params.size(); ++i) {
        Grid_continuous_property* prop = this->grid_input_->property(params[i]);
        if (prop == 0) {
            return false;
        }
        this->props_input_.push_back(prop);
        std::string alr_prop_name = "MAF_INV_" + std::to_string(i);
        Grid_continuous_property* p = this->grid_input_->add_property(alr_prop_name);
        if (p == 0) {
            p = grid_->property(alr_prop_name);
            if(p == 0) {
                return false;
            }
        }
        MAF_INV_props_.push_back(p);
    }
    return true;
}

#define INF 2147483648



bool MAF_Transformation::exec(Progress_notifier* notifier) {
    size_t N = props_[0]->size();
    int M = props_.size();
    std::vector<std::vector<double> > data(N), varmatriz(M), input;
    std::vector<double> x(N), y(N), z(N);
    for (size_t i = 0; i < N; ++i) {
        for (size_t p = 0; p < M; ++p) {
            if (!props_[p]->is_informed(i)) {
                data[i].push_back(INF);
            } else {
                data[i].push_back(props_[p]->get_value(i));
            }
        }
        x[i] = this->grid_->xyz_location(grid_->node_id(i)).x();
        y[i] = this->grid_->xyz_location(grid_->node_id(i)).y();
        z[i] = this->grid_->xyz_location(grid_->node_id(i)).z();
    }
    if (this->inverse_) {
        size_t n = 0;
        for (size_t j = 0; j < props_input_.size(); ++j) {
            if (props_input_[j]->size() > n) {
                n = props_input_[j]->size();
            }
        }
        input.resize(n);
        for (size_t j = 0; j < props_input_.size(); ++j) {
            for (size_t i = 0; i < props_input_[j]->size(); ++i) {
                if (!props_input_[j]->is_informed(i)) {
                    input[i].push_back(INF);
                } else {
                    input[i].push_back(props_input_[j]->get_value(i));
                }
            }
        }
    }
    std::vector<double> media(M);
    for(int i = 0; i < M; ++i) {
        double soma1 = 0;
        for(int j = 0; j < data.size(); ++j) {
            soma1 += data[j][i];
        }
        media[i] = (soma1/data.size());
        double d;
        for(int j = 0; j < data.size(); ++j) {
            d = (data[j][i] - media[i]);
            varmatriz[i].push_back(d);
        }
    }
    int m = M;
    double sum1, mult1, cov;
    std::vector<std::vector<double> > matrizcov(M);
    int k;
    for(int i = 0; i < M; ++i) {
        for(k = 0; k < M; ++k) {
            sum1=0;
            for(int j = 0; j < N; ++j) {
                mult1 = varmatriz[i][j]*varmatriz[k][j];
                sum1 += mult1;
            }
            matrizcov[i].push_back(sum1 / N);
        }
    }
    MatrixXf A(M,M);
    MatrixXf D(M,M);
    MatrixXf E(M,M);
    MatrixXf F(M,M);
    MatrixXf L(M,M);
    MatrixXf RAIZ(M,M);
    VectorXf C(M);
    for(int i= 0; i <M; i++) {
        for(int j= 0; j< M; j++) {
            A(i,j) = matrizcov[i][j];
        }
    }
    SelfAdjointEigenSolver<MatrixXf> eigensolver(A);
    if (eigensolver.info() != Success) return false;
    D << eigensolver.eigenvectors();
    C << eigensolver.eigenvalues();
    for(int i=0; i<M; i++) {
        for(int j=0; j<M; j++) {
            if(i ==j) {
                E(i,j) = C(j);
            } else {
                E(i,j) = 0;
            }
        }
    }
    F = E.inverse();
    double K;
    std::vector<double> raizautovalores;
    for(int it = 0; it < F.size(); ++it) {
        K = sqrt(F(it));
        raizautovalores.push_back(K);
    }
    for(int i = 0; i <M; ++i) {
        for(int j = 0; j < M; ++j) {
            RAIZ(i,j) = raizautovalores[i * M + j];
        }
    }
    L = D*RAIZ;
    std::vector < std::vector<double> > vetormaf(M);
    // cout <<"PCA * info = \n";
    for(int i = 0; i < M; ++i) {
        for(int j = 0; j < N; ++j) {
            vetormaf[i].push_back(0);
        }
        for(int k = 0; k < M; ++k) {
            for(int j = 0; j < N; ++j) {
                vetormaf[i][j] += (L(k,i)*varmatriz[k][j]);
            }
        }
    }
//////////////////////////// DIFERENÇAS ////////////////////////////////////////////////////////////////////
    std::vector<std::vector<double> > soma_dif(M), length(M);
    for(int i = 0; i < M; ++i) {
        soma_dif[i].resize(M);
        length[i].resize(M);
        for(int j = 0; j < M; ++j) {
            soma_dif[i][j] = 0;
            length[i][j] = 0;
        }
    }
    for(int i = 0; i < N; ++i) {
        for(int j = i; j < N; ++j) {
            double dist = 0;
            double dx = x[i] - x[j];
            double dy = y[i] - y[j];
            double dz = z[i] - z[j];
            dist = sqrt(dx * dx + dy * dy + dz * dz);
            if (dist >= this->dmin && dist <= this->dmax) {
                for (int k = 0; k < M; ++k) {
                    for (int l = 0; l < M; ++l) {
                        double d = vetormaf[k][i] - vetormaf[k][j];
                        double d2 = vetormaf[l][i] - vetormaf[l][j];
                        soma_dif[k][l] += d * d2;
                        length[k][l] += 1.0;
                    }
                }
            }
        }
    }
    for (int k = 0; k < M; ++k) {
        for (int l = 0; l < M; ++l) {
            soma_dif[k][l] /= 2 * length[k][l];
        }
    }
    MatrixXf SEMI(M,M);
    MatrixXf INVERSA(M,M);
    MatrixXf MULT(M,M);
    MatrixXf MULTTRANSPOSE(M,M);
    MatrixXf SEMIEINGENVECTORS(M, M);
    VectorXf SEMIEINGENVALUES(M, M);
    for(int i = 0; i < M; ++i) {
        for(int j = 0; j < M; ++j) {
            SEMI(i,j) = soma_dif[i][j];
        }
    }
    SelfAdjointEigenSolver<MatrixXf> es(SEMI);
    if (es.info() != Success) {
        return false;
    }
    SEMIEINGENVECTORS << es.eigenvectors();
    SEMIEINGENVALUES << es.eigenvalues();
    MULT = (L * SEMIEINGENVECTORS);
    std::vector < std::vector<double> > MAF(M);
    if (!this->inverse_) {
        for(int i = 0; i < M; ++i) {
            for(int j = 0; j < N; ++j) {
                MAF[i].push_back(0);
            }
            for(int k = 0; k < M; ++k) {
                for(int j = 0; j < N; ++j) {
                    MAF[i][j] += (MULT(k,i)*data[j][k]);
                }
            }
            for (int j = 0; j < N; ++j) {
                this->MAF_props_[i]->set_value(MAF[i][j], j);
            }
        }
    } else {
        MULTTRANSPOSE = MULT.transpose();
        INVERSA = MULTTRANSPOSE.inverse();
        std::vector < std::vector<double> > MAFINVERSO(M);
        N = input.size();
        for(int i = 0 ; i < M; i++) {
            for(int j = 0; j < N; j++) {
                MAFINVERSO[i].push_back(0);
            }
            for(int k = 0; k < M; ++k) {
                for(int j = 0; j < N; ++j) {
                    if (input[j][k] < INF) {
                        MAFINVERSO[i][j] += (INVERSA(i,k) * input[j][k]);
                    }
                }
            }
            for (int j = 0; j < N; ++j) {
                if (input[j][i] < INF) {
                    this->MAF_INV_props_[i]->set_value(MAFINVERSO[i][j], j);
                } else {
                    this->MAF_INV_props_[i]->set_value(Grid_continuous_property::no_data_value, j);
                }
            }
        }
    }
    if (this->show_ev_) {
        QString s_r;
        QTextStream out(&s_r, QIODevice::ReadWrite);
        out << "MAF REPORT\n";
        out << "___________________________________\n";
        out << "Eigenvalues:\n";
        int n = SEMIEINGENVALUES.rows();
        int c = SEMIEINGENVALUES.cols();
        out << "[\n";
        for (int i = 0; i < n; ++i) {
            if (i > 0) {
                out << ";\n";
            }
            for (int j = 0; j < c; ++j) {
                if (j > 0) {
                    out << "\t";
                }
                if (SEMIEINGENVALUES(i, j) > 0) {
                    out << " ";
                }
                out << SEMIEINGENVALUES(i, j);
            }
        }
        out << "\n]\n";
        out << "\nEigenvectors:\n";
        n = SEMIEINGENVECTORS.rows();
        c = SEMIEINGENVECTORS.cols();
        out << "[\n";
        for (int i = 0; i < n; ++i) {
            if (i > 0) {
                out << ";\n";
            }
            for (int j = 0; j < c; ++j) {
                if (j > 0) {
                    out << "\t";
                }
                if (SEMIEINGENVECTORS(i, j) > 0) {
                    out << " ";
                }
                out << SEMIEINGENVECTORS(i, j);
            }
        }
        out << "\n]\n";
        out << "\nIt's adviced to check this spatial decorrelation using cross-variograms and scatter plots.\n";
        report->write(s_r);
    }
    return true;
}

