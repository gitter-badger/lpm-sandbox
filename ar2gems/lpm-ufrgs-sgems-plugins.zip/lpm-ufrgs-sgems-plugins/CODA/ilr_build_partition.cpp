/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#include "ilr_utils.h"
#include <cmath>

/*
Definição das partições
def build_partition(p, dim, ini, l):
	if l == npl or dim == 1: 
		return
	
	mid = int(math.ceil(dim / 2.0))
	
	for i in range(0, mid):
		p[l][ini + i] = 1
	
	for i in range(mid, dim):	
		p[l][ini + i] = -1
		
	dim1 = mid
	dim2 = dim - mid
	if mid > 1:
		build_partition(p, dim1, ini, l + 1)
		build_partition(p, dim2, ini + dim1, l + mid)
*/

void build_partition(std::vector<std::vector<double> >& p, size_t dim, size_t ini, size_t l, size_t npl)
{
	if (l == npl || dim == 1) {
		return;
	}
	
	size_t mid = static_cast<size_t>(std::ceil(dim * 0.5));
	
	for (size_t i = 0; i < mid; ++i) {
		p[l][ini + i] = 1;
	}
	
	for (size_t i = mid; i < dim; ++i) {
		p[l][ini + i] = -1;
	}
	
	if (mid > 1) {
		build_partition(p, mid, ini, l + 1, npl);
		build_partition(p, dim - mid, ini + mid, l + mid, npl);
	}
}
