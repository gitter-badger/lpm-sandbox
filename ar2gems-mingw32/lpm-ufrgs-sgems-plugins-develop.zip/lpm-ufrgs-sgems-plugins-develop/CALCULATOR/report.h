/*
Implementação do plugin que efetua transformações nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/


#ifndef CALCULATOR_REPORT_H_
#define CALCULATOR_REPORT_H_

#include "common.h"
#include <QDialog>
#include <QMainWindow>
#include <QCloseEvent>
#include <gui/utils/task_manager.h>
#include <ui_report.h>


class Calculator_report : public QDialog {
    Q_OBJECT

  public:
    Calculator_report(QWidget *parent = 0);
    ~Calculator_report();

    void write(QString msg) {
        emit setText(msg);
    }

  signals:
    void setText(QString text);
  public slots:
    void setReport(QString text) {
        this->ui.report_text->setText(text);
        this->show();
    }


  private:

    Ui::Report ui;
};

#endif /* DATA_HANDLING_REPORT_H_ */
