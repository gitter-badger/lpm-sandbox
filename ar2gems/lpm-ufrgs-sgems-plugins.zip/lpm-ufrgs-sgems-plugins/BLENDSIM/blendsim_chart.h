/*
Implementa��o do plugin BLENDSIM.

(c) 2013, LPM/UFRGS, Roberto Menin, P�ricles Lopes Machado
*/

#ifndef __BLENDSIM_CHART_H
#define __BLENDSIM_CHART_H

#include "common.h"

#include <charts/chart_base.h>
#include <charts/chart_widget.h>
#include <charts/chart_display_control.h>
#include <grid/grid_property.h>
#include <grid/grid_weight_property.h>
#include <grid/grid_filter.h>

#include <vtkQtTableView.h>
#include <vtkSmartPointer.h>
#include <vtkLookupTable.h>
#include <vtkChartPie.h>

#include <QModelIndex>
#include <QLabel>

#include <vector>



enum Blending_types {
    BLENDING_INTERPILES,
    BLENDING_INTRAPILES,
    BLENDING_PILESERIES,
    BLENDING_PILELOCATE,
    BLENDING_DISPERSIONVARIANCE
};

class PLUGINS_LPM_UFRGS_DECL Blendsim_chart : public Chart_base {
    Q_OBJECT
  public:
    explicit Blendsim_chart(Geostat_grid* grid,
                            std::vector<Grid_continuous_property*> grade_props,
                            Grid_continuous_property* sequence_prop,
                            Grid_continuous_property* mass_prop_,
                            Grid_region* region, Blending_types bt,
                            double IniMass,
                            double FinalMass,
                            double IncMass,
                            QWidget *parent = 0);

  signals:

  public slots:

  private :
    void build_value_table();
    void build_plot();

    void build_plot_pileseries();
    void build_plot_interpile();
    void build_plot_intrapile();

    void build_value_table_interpile();
    void build_value_table_pileseries();
    void build_value_table_pilelocate();
    void build_value_table_intrapiles();

  private:

    void build_interpiles_chart();
    void build_pileseries_chart();
    void build_intrapiles_chart();


    //dados referentes a plots/tabela da vari�ncia entre as pilhas
    Chart_widget* chart_variance_widget_;
    Chart_display_control* chart_variance_control_;

    vtkSmartPointer<vtkTable> table_permissive_;
    Chart_widget* chart_permissive_widget_;

    vtkSmartPointer<vtkTable> table_CV_permissive_;
    Chart_widget* chart_CV_permissive_widget_;

    Chart_widget*  chart_pileseries_widget_;


    vtkSmartPointer<vtkTable> table_variance_;
    vtkSmartPointer<vtkQtTableView> data_variance_view_;

    vtkSmartPointer<vtkQtTableView> data_permissive_view_;
    vtkSmartPointer<vtkQtTableView> data_CV_permissive_view_;

    vtkSmartPointer<vtkTable> table_pileseries_;
    vtkSmartPointer<vtkQtTableView> data_pileseries_view_;

    vtkSmartPointer<vtkTable> table_pilelocate_min_;
    vtkSmartPointer<vtkQtTableView> data_pilelocate_min_view_;

    vtkSmartPointer<vtkTable> table_pilelocate_max_;
    vtkSmartPointer<vtkQtTableView> data_pilelocate_max_view_;


    //dados referentes a plots/tabela do desvio padr�o entre as pilhas
    Chart_widget* chart_desvpad_widget_;
    //Chart_display_control* chart_desvpad_control_;
    vtkSmartPointer<vtkTable> table_desvpad_;
    vtkSmartPointer<vtkQtTableView> data_desvpad_view_;


    //dados referentes a plots/tabela do CV entre as pilhas
    Chart_widget* chart_CV_widget_;
// Chart_display_control* chart_CV_control_;

    vtkSmartPointer<vtkTable> table_CV_;
    vtkSmartPointer<vtkQtTableView> data_CV_view_;
    ////////////////
    vtkSmartPointer<vtkQtTableView> data_mean_mass_view_;
    vtkSmartPointer<vtkTable> table_mean_mass_;

    Geostat_grid* grid_;
    std::vector<Grid_continuous_property*> grade_props_;
    Grid_continuous_property* sequence_prop_;
    Grid_continuous_property* mass_prop_;
    Grid_region* region_;

    double IniMass, FinalMass, IncMass;



    Blending_types blending_type;

    double min_X, max_X;
    double min_Y, max_Y;

    QWidget * my_parent_;
};

#endif // 
