/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftprocess.h"

#ifdef __linux

#include <unistd.h>

#elif _WIN32 || WIN32

#include <Windows.h>

#else
#include <unistd.h>

#endif

QMutex g_fftprogress_mutex;

void global_fftprogress_lock() {
    g_fftprogress_mutex.lock();
}

void global_fftprogress_unlock() {
    g_fftprogress_mutex.unlock();
}

void fftprogress_sleep(int time) {
    global_fftprogress_lock();
#ifdef  __linux
    usleep(time * 1000);
#elif WIN32 || _WIN32
    Sleep(time);
#else
    usleep(time * 1000);
#endif
    global_fftprogress_unlock();
}

/*

FFTProgressDialog Class implementation

*/

FFTProgressDialog::FFTProgressDialog(int number_steps, QWidget *parent)
    : QDialog(parent),
      current_step_(0),
      number_steps_(number_steps),
      is_paused_(false),
      is_running_(true),
      mutex_() {
    ui_.setupUi(this);
    ui_.progress->setRange(0, number_steps);
    ui_.progress->setValue(0);
    QObject::connect(
        this, SIGNAL(valueChanged(int)),
        ui_.progress, SLOT(setValue(int))
    );
    QObject::connect(
        this, SIGNAL(sendTextAppend(const QString&)),
        ui_.status, SLOT(append(const QString&))
    );
    QObject::connect(
        this, SIGNAL(sendText(const QString&)),
        ui_.status, SLOT(setText(const QString&))
    );
    this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowTitleHint);
}

FFTProgressDialog::~FFTProgressDialog() {
}

bool FFTProgressDialog::isPaused() {
    mutex_.lock();
    bool is_p = is_paused_;
    mutex_.unlock();
    if (is_p) {
        fftprogress_sleep();
    }
    return is_p;
}

void FFTProgressDialog::nextStep() {
    mutex_.lock();
    ++current_step_;
    emit valueChanged(current_step_);
    mutex_.unlock();
}

void FFTProgressDialog::reset() {
    mutex_.lock();
    current_step_ = 0;
    emit valueChanged(0);
    mutex_.unlock();
}

void FFTProgressDialog::setStep(int step) {
    mutex_.lock();
    current_step_ = step;
    emit valueChanged(step);
    mutex_.unlock();
}

void FFTProgressDialog::setNumberSteps(int n) {
    mutex_.lock();
    ui_.progress->setRange(0, n);
    mutex_.unlock();
}

void FFTProgressDialog::setText(const QString& msg) {
    mutex_.lock();
    emit sendText(msg);
    mutex_.unlock();
}

void FFTProgressDialog::appendText(const QString& msg) {
    mutex_.lock();
    emit sendTextAppend(msg);
    mutex_.unlock();
}

void FFTProgressDialog::writeMsg(const QString& msg, bool append) {
    mutex_.lock();
    if (append) {
        emit sendTextAppend(msg);
    } else {
        emit sendText(msg);
    }
    mutex_.unlock();
}

void FFTProgressDialog::setPaused() {
    mutex_.lock();
    if (is_paused_) {
        is_paused_ = false;
        is_running_ = true;
        ui_.pause->setText("Pause");
    } else {
        is_paused_ = true;
        is_running_ = false;
        ui_.pause->setText("Resume");
    }
    mutex_.unlock();
}

void FFTProgressDialog::setRunning() {
    mutex_.lock();
    is_paused_ = false;
    is_running_ = true;
    ui_.pause->setText("Pause");
    mutex_.unlock();
}

void FFTProgressDialog::setDead() {
    mutex_.lock();
    is_paused_ = false;
    is_running_ = false;
    mutex_.unlock();
}

void FFTProgressDialog::lastMsg(const QString& msg) {
    mutex_.lock();
    emit finish(msg);
    mutex_.unlock();
}
/*

FFTProcess Class implementation

*/

FFTProcess::FFTProcess(
    FFTAction* action,
    FFTProgressDialog* notifier,
    int number_threads,
    int id_thread,
    bool is_master)
    :
    is_master_(is_master),
    id_thread_(id_thread),
    number_threads_(number_threads),
    action_(action),
    notifier_(notifier),
    ok_(true) {
    if (!notifier_) {
        notifier_ = new FFTProgressDialog;
    }
    if (is_master) {
        QObject::connect(
            notifier_->getUi().cancel,
            SIGNAL(clicked()),
            this, SLOT(killProcess())
        );
        for (int id = 0; id < number_threads_; ++id) {
            slaves_.push_back(new FFTProcess(action, notifier_, number_threads, id, false));
        }
    }
}


void FFTProcess::lock() {
    notifier_->lock();
}

void FFTProcess::unlock() {
    notifier_->unlock();
}

void FFTProcess::waitProcess() {
    if (is_master_)
        for (auto s : slaves_) {
            s->wait();
        }
}

FFTProcess::~FFTProcess() {
    if (is_master_) {
        for (auto s : slaves_) {
            delete s;
        }
        if (notifier_) {
            notifier_->close();
            delete notifier_;
        }
    }
}

void FFTProcess::killProcess() {
    ok_ = false;
    if (is_master_) {
        for (auto s : slaves_) {
            s->setOk(false);
        }
    }
}

void FFTProcess::run_master() {
    if (is_master_) {
        action_->run_master_process(this, number_threads_, slaves_);
    }
}

void FFTProcess::run_slaves() {
    action_->run_slave_process(this, id_thread_, number_threads_);
}

void FFTProcess::run() {
    if (is_master_) {
        action_->run_master_process(this, number_threads_, slaves_);
        for (auto s : slaves_) {
            s->start();
        }
        for (auto s : slaves_) {
            s->wait();
        }
        emit killMe(this);
    } else {
        action_->run_slave_process(this, id_thread_, number_threads_);
    }
}




