/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftvariogram_chart_creator.h"
#include "fftvariogram_chart.h"

FFTVariogram_chart_creator::FFTVariogram_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent) :Chart_creator(mdi_area, parent) {
    QTabWidget* FFTVariogram_Widget = new QTabWidget(this);
    my_variogram_ = this->build_variogram_page();
    my_crossvariogram_ = this->build_crossvariogram_page();
    my_crossvariogram_declus_ = this->build_crossvariogram_declus_page();
    my_variogram_declus_ = this->build_variogram_declus_page();
    FFTVariogram_Widget->addTab(my_variogram_, QIcon(), "Variogram / Covariance");
    FFTVariogram_Widget->addTab(my_variogram_declus_, QIcon(), "Variogram Declustered");
    FFTVariogram_Widget->addTab(my_crossvariogram_, QIcon(), "Cross Variogram / Cross Covariance");
    FFTVariogram_Widget->addTab(my_crossvariogram_declus_, QIcon(), "Cross Variogram Declustered");
    FFTVariogram_Widget->show();
    QVBoxLayout* main_layout = new QVBoxLayout(this);
    main_layout->setContentsMargins(0, 0, 0, 0);
    main_layout->addWidget(FFTVariogram_Widget);
    this->setLayout(main_layout);
    bool
    ok = connect(my_variogram_->getDisplayButton(), SIGNAL(clicked()),
                 this, SLOT(show_chart_variogram()));
    ok = connect(my_crossvariogram_->getDisplayButton(), SIGNAL(clicked()),
                 this, SLOT(show_chart_crossvariogram()));
    ok = connect(my_crossvariogram_declus_->getDisplayButton(), SIGNAL(clicked()),
                 this, SLOT(show_chart_crossvariogram_declus()));
    ok = connect(my_variogram_declus_->getDisplayButton(), SIGNAL(clicked()),
                 this, SLOT(show_chart_variogram_declus()));
}

FFTVariogram_chart_creator::~FFTVariogram_chart_creator() {
}

void FFTVariogram_chart_creator::kill_process(FFTProcess* process) {
    FFTVariogram_chart* chart = static_cast<FFTVariogram_chart*>(process->getAction());
    if (process->isOk()) {
        chart->build_variogram_chart();
        QMdiSubWindow* sub_window = mdi_area_->addSubWindow(chart);
        sub_window->setAttribute(Qt::WA_DeleteOnClose);
        sub_window->showMaximized();
    } else {
        delete chart;
    }
    if (process) delete process;
}

void FFTVariogram_chart_creator::create_variogram_process(FFTAction* chart, int n_steps, int n_threads) {
    FFTProcess* process = new FFTProcess(
        chart,
        new FFTProgressDialog(n_steps),
        n_threads);
    QObject::connect(
        process, SIGNAL(killMe(FFTProcess*)),
        this, SLOT(kill_process(FFTProcess*)));
    process->getNotifier()->show();
    process->start();
}

void FFTVariogram_chart_creator::show_chart_crossvariogram() {
    int nprops1 = my_crossvariogram_->getProperties1().size();
    int nprops2 = my_crossvariogram_->getProperties2().size();
    if (my_crossvariogram_->getGrid() != 0 &&
            nprops1 > 0 &&
            nprops1 == nprops2) {
        FFTVariogram_chart* chart = new  FFTVariogram_chart(
            my_crossvariogram_,
            0);
        create_variogram_process(chart, nprops1 * chart->getNMaps(), 1);
    }
}

void FFTVariogram_chart_creator::show_chart_crossvariogram_declus() {
    int nprops1 = my_crossvariogram_declus_->getProperties1().size();
    int nprops2 = my_crossvariogram_declus_->getProperties2().size();
    if (my_crossvariogram_declus_->getGrid() != 0 &&
            nprops1 > 0 &&
            nprops1 == nprops2) {
        FFTVariogram_chart* chart = new  FFTVariogram_chart(
            my_crossvariogram_declus_,
            0);
        create_variogram_process(chart, nprops1 * chart->getNMaps(), 1);
    }
}

void FFTVariogram_chart_creator::show_chart_variogram() {
    if (my_variogram_->getGrid() != 0 &&
            my_variogram_->getProperties().size() > 0) {
        FFTVariogram_chart* chart = new  FFTVariogram_chart(
            my_variogram_,
            0);
        create_variogram_process(chart, chart->getNMaps() * my_variogram_->getProperties().size(), 1);
    }
}

void FFTVariogram_chart_creator::show_chart_variogram_declus() {
    if (my_variogram_declus_->getGrid() != 0 &&
            my_variogram_declus_->getProperties().size() > 0) {
        FFTVariogram_chart* chart = new  FFTVariogram_chart(
            my_variogram_declus_,
            0);
        create_variogram_process(chart,
                                 chart->getNMaps() * my_variogram_declus_->getProperties().size(),
                                 1);
    }
}


FFTVariogram* FFTVariogram_chart_creator::build_variogram_page() {
    return new FFTVariogram(this);
}

FFTCrossVariogram* FFTVariogram_chart_creator::build_crossvariogram_page() {
    return new FFTCrossVariogram(this);
}

FFTCrossVariogramDeclus* FFTVariogram_chart_creator::build_crossvariogram_declus_page() {
    return new FFTCrossVariogramDeclus(this);
}


FFTVariogramDeclus* FFTVariogram_chart_creator::build_variogram_declus_page() {
    return new FFTVariogramDeclus(this);
}
