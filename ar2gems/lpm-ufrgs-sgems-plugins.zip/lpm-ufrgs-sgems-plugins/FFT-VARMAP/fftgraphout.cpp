/*
Implementação do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, Péricles Lopes Machado
*/

#include "fftgraphout.h"


GraphOutput::GraphOutput(QWidget *parent)
: QFrame(parent)
{
	ui.setupUi(this);

}

GraphOutput::~GraphOutput()
{
}