/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/


#ifndef PLUGINS_LPM_UFRGS_PCA_TRANSFORMATION_H_
#define PLUGINS_LPM_UFRGS_PCA_TRANSFORMATION_H_

#include "common.h"

#include <common.h>
#include <appli/action.h> 
#include <grid/grid_property.h>
#include <grid/geostat_grid.h>
#include <utils/named_interface.h>

#include "report.h"

class PLUGINS_LPM_UFRGS_DECL PCA_Transformation :  public Action 
{
	public: 
		static Named_interface* create_new_interface(std::string&);

        PCA_Transformation() : Action() {
            report = new FACTORIZATION_report(0);
			show_report_ = false;
			//report->hide();
        }

        virtual ~PCA_Transformation() {
            if (report){
				delete report;
            }
        }
		virtual bool init(std::string& parameters, GsTL_project* proj,
						  Error_messages_handler* errors = 0, Progress_notifier* notifier = 0); 
		virtual bool exec(Progress_notifier* notifier = 0); 

		bool init_input(std::string& parameters);

		bool set_inv(std::string& params) { 
			this->inverse_ = true; 
			return this->init_input(params);
		}

		void show_ev(bool s) {
			this->show_ev_ = s;
		}

	private :
      FACTORIZATION_report* report;

	  Geostat_grid* grid_;
	  Geostat_grid* grid_input_;
	  bool inverse_;
	  bool show_ev_;
	  std::vector<Grid_continuous_property*> props_;
	  std::vector<Grid_continuous_property*> props_input_;
	  std::vector<Grid_continuous_property*> PCA_props_;
	  std::vector<Grid_continuous_property*> PCA_INV_props_;

	  bool show_report_;
};

#endif // PLUGINS_LPM_UFRGS_PCA_TRANSFORMATION_H_
