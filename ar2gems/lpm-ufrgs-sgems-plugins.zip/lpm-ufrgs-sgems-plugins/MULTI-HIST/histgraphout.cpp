/*
Implementação do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/


#include "histgraphout.h"


HistogramGraphOutput::HistogramGraphOutput(QWidget *parent)
: QFrame(parent)
{
	ui.setupUi(this);

}

HistogramGraphOutput::~HistogramGraphOutput()
{
}