/*
Implementa��o do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "histogram.h"

LPMHistogram::LPMHistogram(QWidget *parent)
: QFrame(parent)
{
	ui.setupUi(this);
}

int LPMHistogram::getNumberBins()
{
	return ui.nBins->value();
}

int LPMHistogram::getNumberThreads()
{
	return ui.nThreads->value();
}

QStringList LPMHistogram::getProperties()
{
	return ui.props->selected_properties();
}

Geostat_grid* LPMHistogram::getGrid()
{
	return ui.grid->selected_grid_object();
}

LPMHistogram::~LPMHistogram()
{

}

QPushButton* LPMHistogram::getDisplayButton()
{
	return ui.displayButton;
}

