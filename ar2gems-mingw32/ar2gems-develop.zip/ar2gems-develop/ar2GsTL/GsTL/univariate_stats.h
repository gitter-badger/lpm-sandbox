#ifndef __GTL_MAIN_HEADER_UNIVARIATE_STATS_H__
#define __GTL_MAIN_HEADER_UNIVARIATE_STATS_H__

#include <GsTL/univariate_stats/build_cdf.h>
#include <GsTL/univariate_stats/cdf_transform.h>

#endif
