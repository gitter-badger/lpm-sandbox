/*
Implementação do plugin que realiza o moving window.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/

#ifndef PLUGINS_LPM_UFRGS_MOVING_WINDOW_ACTION_H_
#define PLUGINS_LPM_UFRGS_MOVING_WINDOW_ACTION_H_

#include "common.h"

#include <common.h>
#include <appli/action.h>
#include <grid/grid_property.h>
#include <grid/geostat_grid.h>
#include <utils/named_interface.h>
#include <geostat/utilities.h>

class PLUGINS_LPM_UFRGS_DECL MovingWindow :  public Action {
  public:
    static Named_interface* create_new_interface(std::string&);

    virtual ~MovingWindow() {}
    virtual bool init(std::string& parameters, GsTL_project* proj,
                      Error_messages_handler* errors = 0, Progress_notifier* notifier = 0);
    virtual bool exec(Progress_notifier* notifier = 0);


  private :
    Geostat_grid* grid_input_;
    Geostat_grid* grid_output_;

    Grid_continuous_property* grid_mean_;
    Grid_continuous_property* grid_var_;
    Grid_continuous_property* grid_prop_;

    GsTL_project* proj_;

    Error_messages_handler* errors_;

    std::string grid_output_name;

    double dx, dy, dz, x_size, y_size, z_size;
};


#endif // PLUGINS_LPM_UFRGS_MOVING_WINDOW_ACTION_H_


