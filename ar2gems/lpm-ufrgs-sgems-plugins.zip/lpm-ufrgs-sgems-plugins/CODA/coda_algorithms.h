/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#ifndef PLUGINS_LPM_UFRGS_CODA_ALGORITHMS_H_
#define PLUGINS_LPM_UFRGS_CODA_ALGORITHMS_H_

#include "common.h"

#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>
#include <grid/grid_property.h>
#include <grid/grid_region.h>
#include <grid/neighborhood.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>
#include <geostat/parameters_handler.h>

namespace LPM_UFRGS {
	enum Coda_Algorithm_Type {
		ALR = 0,
		CLR = 1,
		ILR = 2,
		ALR_INV = 3,
		CLR_INV = 4,
		ILR_INV = 5
	};
}


class CodaAlgorithms : public Geostat_algo {
	public:
		CodaAlgorithms();
		virtual ~CodaAlgorithms();

		virtual bool initialize(const Parameters_handler* parameters,
								Error_messages_handler* errors = 0, Progress_notifier* notifier = 0);
		
		virtual int execute(GsTL_project* proj=0, Progress_notifier* notifier = 0);
		
		virtual std::string name() const 
		{ 
			return "coda_algorithms"; 
		}
		
		static Named_interface* create_new_interface(std::string&);

		void set_constant(const double& v) {
			closure_const = v;
		}

	private :
	    double closure_const;
		LPM_UFRGS::Coda_Algorithm_Type algorithm_type_;
		Error_messages_handler* errors_;
		std::string params;
		Named_interface* action_;
};



#endif // PLUGINS_LPM_UFRGS_CODA_ALGORITHMS_H_
