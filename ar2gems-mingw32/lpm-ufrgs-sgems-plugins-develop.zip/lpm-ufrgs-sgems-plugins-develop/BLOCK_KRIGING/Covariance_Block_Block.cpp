# include "Covariance_Block_Block.h"
# include "Covariance_Point_Point.h"
# include <vector>

using namespace std;

double Covariance_Block_Block(Geostat_grid *block_i_grid, const vector<vector<double> > &block_i, Geostat_grid *block_j_grid, const vector<vector<double> > &block_j, const  Two_point_nested_structure &covar_) {
    int count = 0;
    double sum_cova_point_point = 0;
    double cova_point_point = 0;
    double cova_block_block = 0;
    for(size_t i = 0; i < block_i.size(); ++i) {
        for(size_t j = 0; j < block_j.size(); ++j) {
            cova_point_point = Covariance_Point_Point(block_i_grid, block_i[i][4], block_j_grid, block_j[j][4], covar_) ;
            sum_cova_point_point = sum_cova_point_point + cova_point_point;
            ++count;
        }
    }
    cova_block_block = sum_cova_point_point/count;
    return cova_block_block;
}
