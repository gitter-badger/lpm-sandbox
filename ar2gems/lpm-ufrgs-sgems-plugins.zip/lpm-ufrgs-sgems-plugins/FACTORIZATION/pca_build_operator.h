/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/


#ifndef PLUGINS_LPM_UFRGS_PCA_BUILD_OPERATOR_H_
#define PLUGINS_LPM_UFRGS_PCA_BUILD_OPERATOR_H_

#include <vector>
#include <Eigen/Core>
#include <Eigen/Eigenvalues>

using namespace Eigen;

void build_operator(Matrix2f& D, const std::vector<std::vector<double> >& data,
                    bool& status, std::vector<std::vector<double> >& varmatriz);

#endif // PLUGINS_LPM_UFRGS_PCA_BUILD_OPERATOR_H_
