/*
Implementação do plugin que realiza o moving window.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/

#ifndef PLUGINS_LPM_UFRGS_MOVING_WINDOW_ALGO_H_
#define PLUGINS_LPM_UFRGS_MOVING_WINDOW_ALGO_H_

#include "common.h"

#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>
#include <grid/grid_property.h>
#include <grid/grid_region.h>
#include <grid/neighborhood.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>
#include <geostat/parameters_handler.h>
#include <geostat/utilities.h>


class MovingWindowAlgorithms : public Geostat_algo {
  public:
    MovingWindowAlgorithms();
    virtual ~MovingWindowAlgorithms();

    virtual bool initialize(const Parameters_handler* parameters,
                            Error_messages_handler* errors = 0, Progress_notifier* notifier = 0 );

    virtual int execute(GsTL_project* proj=0, Progress_notifier* notifier = 0);

    virtual std::string name() const {
        return "lpm_ufrgs_moving_window";
    }

    static Named_interface* create_new_interface(std::string&);

  private :
    Error_messages_handler* errors_;
    std::string params;
    Named_interface* action_;
    Geostat_grid* grid_output_;
};



#endif // PLUGINS_LPM_UFRGS_MOVING_WINDOW_ALGO_H_
