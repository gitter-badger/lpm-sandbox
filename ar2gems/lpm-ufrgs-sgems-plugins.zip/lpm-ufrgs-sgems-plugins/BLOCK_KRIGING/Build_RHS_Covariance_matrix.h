#ifndef BUILD_RHS_COVARIANCE_MATRIX_H
#define BUILD_RHS_COVARIANCE_MATRIX_H
# include <vector>

std::vector<double> Build_RHS_Covariance_Matrix(Geostat_grid *Point_samples_grid, Geostat_grid *Point_u_grid, const std::vector<std::vector<double> > &samples, std::vector<std::vector<double> > &Point_To_Block_Covariance_Lookup_Table, std::vector<int> &block_ids, const Two_point_nested_structure &covar_, const int &kriging_option, int &node_id_point_u);
#endif
