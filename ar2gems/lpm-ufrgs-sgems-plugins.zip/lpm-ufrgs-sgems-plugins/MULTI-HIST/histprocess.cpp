/*
Implementa��o do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "histprocess.h"

#ifdef __linux

#include <unistd.h>

#elif _WIN32 || WIN32

#include <Windows.h>

#else
#include <unistd.h>

#endif

QMutex g_histprogress_mutex;

void global_histprogress_lock()
{
	g_histprogress_mutex.lock();
}

void global_histprogress_unlock()
{
	g_histprogress_mutex.unlock();
}

void histprogress_sleep(int time)
{
	global_histprogress_lock();
#ifdef  __linux

	usleep(time * 1000);

#elif WIN32 || _WIN32

	Sleep(time);
#else
	usleep(time * 1000);
#endif
	global_histprogress_unlock();
}

/*

HistogramProgressDialog Class implementation

*/

HistogramProgressDialog::HistogramProgressDialog(int number_steps, QWidget *parent)
: QDialog(parent), 
current_step_(0), 
number_steps_(number_steps), 
is_paused_(false), 
is_running_(true),
mutex_()
{
	
	ui_.setupUi(this);

	ui_.progress->setRange(0, number_steps);
	ui_.progress->setValue(0);

	QObject::connect(
		this, SIGNAL(valueChanged(int)),
		ui_.progress, SLOT(setValue(int))
	);

	QObject::connect(
		this, SIGNAL(sendTextAppend(const QString&)),
		ui_.status, SLOT(append(const QString&))
	);

	QObject::connect(
		this, SIGNAL(sendText(const QString&)),
		ui_.status, SLOT(setText(const QString&))
	);

	this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowTitleHint);
}

HistogramProgressDialog::~HistogramProgressDialog()
{

}

bool HistogramProgressDialog::isPaused()
{
	mutex_.lock();
	bool is_p = is_paused_;
	mutex_.unlock();


	if (is_p) {
		histprogress_sleep();
	}
	return is_p;
}

void HistogramProgressDialog::nextStep()
{
	mutex_.lock();
	++current_step_;
	emit valueChanged(current_step_);
	mutex_.unlock();
}

void HistogramProgressDialog::reset()
{
	mutex_.lock();
	current_step_ = 0;
	emit valueChanged(0);
	mutex_.unlock();
}

void HistogramProgressDialog::setStep(int step)
{
	mutex_.lock();
	current_step_ = step;
	emit valueChanged(step);
	mutex_.unlock();
}

void HistogramProgressDialog::setNumberSteps(int n)
{
	mutex_.lock();
	ui_.progress->setRange(0, n);
	mutex_.unlock();
}

void HistogramProgressDialog::setText(const QString& msg)
{
	mutex_.lock();
	emit sendText(msg);
	mutex_.unlock();
}

void HistogramProgressDialog::appendText(const QString& msg)
{
	mutex_.lock();
	emit sendTextAppend(msg);
	mutex_.unlock();
}

void HistogramProgressDialog::writeMsg(const QString& msg, bool append)
{
	mutex_.lock();
	if (append) {
		emit sendTextAppend(msg);
	}
	else {
		emit sendText(msg);
	}
	mutex_.unlock();
}

void HistogramProgressDialog::setPaused()
{
	mutex_.lock();
	if (is_paused_) {
		is_paused_ = false;
		is_running_ = true;
		ui_.pause->setText("Pause");
	} else {
		is_paused_ = true;
		is_running_ = false;
		ui_.pause->setText("Resume");
	}
	mutex_.unlock();
}

void HistogramProgressDialog::setRunning()
{
	mutex_.lock();
	is_paused_ = false;
	is_running_ = true;
	ui_.pause->setText("Pause");
	mutex_.unlock();
}

void HistogramProgressDialog::setDead()
{
	mutex_.lock();
	is_paused_ = false;
	is_running_ = false;
	mutex_.unlock();
}

void HistogramProgressDialog::lastMsg(const QString& msg)
{
	mutex_.lock();
	emit finish(msg);
	mutex_.unlock();
}
/*

HistogramProcess Class implementation

*/

HistogramProcess::HistogramProcess(
	HistogramAction* action,
	HistogramProgressDialog* notifier,
	int number_threads,
	int id_thread,
	bool is_master)
:
is_master_(is_master),
id_thread_(id_thread),
number_threads_(number_threads),
action_(action),
notifier_(notifier),
ok_(true)
{
	if (!notifier_) {
		notifier_ = new HistogramProgressDialog;
	}

	if (is_master) {
		QObject::connect(
			notifier_->getUi().cancel,
			SIGNAL(clicked()),
			this, SLOT(killProcess())
			);

		for (int id = 0; id < number_threads_; ++id) {
			slaves_.push_back(new HistogramProcess(action, notifier_, number_threads, id, false));
		}
	}
}


void HistogramProcess::lock()
{
	notifier_->lock();
}

void HistogramProcess::unlock()
{
	notifier_->unlock();
}

void HistogramProcess::waitProcess()
{
	if (is_master_)
		for (auto s : slaves_) {
			s->wait();
		}
}

HistogramProcess::~HistogramProcess()
{
	if (is_master_) {
		for (auto s : slaves_) {
			delete s;
		}

		if (notifier_) {
			notifier_->close();
			delete notifier_;
		}
	}
}

void HistogramProcess::killProcess()
{
	ok_ = false;
	if (is_master_) {
		for (auto s : slaves_) {
			s->setOk(false);
		}
	}
}

void HistogramProcess::run_master()
{
	if (is_master_) {
		action_->run_master_process(this, number_threads_, slaves_);
	}
}

void HistogramProcess::run_slaves()
{
	action_->run_slave_process(this, id_thread_, number_threads_);
}

void HistogramProcess::run()
{
	if (is_master_) {
		action_->run_master_process(this, number_threads_, slaves_);

		for (auto s : slaves_) {
			s->start();
		}

		for (auto s : slaves_) {
			s->wait();
		}

		emit killMe(this);
	} else {
		action_->run_slave_process(this, id_thread_, number_threads_);
	}
}




