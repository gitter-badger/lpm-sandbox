/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#include <cmath>
#include <cstdlib>
#include <ctime>

#include "alr_inv_transformation.h"

#include <utils/string_manipulation.h>
#include <grid/utilities.h>

#define INF 2147483648

Named_interface* ALR_Inv_Transformation::create_new_interface( std::string& ) {
    return new ALR_Inv_Transformation;
}


// ALRTransformation gridName::res_prop::prop1::prop2[::prop3::propN]
bool ALR_Inv_Transformation::init(std::string& parameters, GsTL_project* proj, Error_messages_handler* errors, Progress_notifier* notifier) {
    std::vector<std::string> params = String_Op::decompose_string(parameters, Actions::separator, Actions::unique);
    if (params.size() < 2) {
        errors->report("Parameters are missing");
        return false;
    }
    std::string grid_name = params[0];
    if (grid_name.empty()) {
        errors->report("No grid selected");
        return false;
    }
    grid_ = get_grid_from_manager(grid_name);
    if (grid_ == 0) {
        errors->report("The grid " + grid_name + " does not exist");
        return false;
    }
    for (int i = 1; i < params.size(); ++i) {
        Grid_continuous_property* prop = grid_->property(params[i]);
        if (prop == 0) {
            errors->report("The property " + params[i] + " does not exist" );
            return false;
        }
        props_.push_back(prop);
        std::string alr_prop_name = "ALR_INV_"  + this->prop_name +  "_" + std::to_string(i);
        Grid_continuous_property* p = grid_->add_property(alr_prop_name);
        if (p == 0) {
            p = grid_->property(alr_prop_name);
            if(p == 0) {
                errors->report( "Could not create the property " + alr_prop_name);
                return false;
            }
        }
        ALR_props_.push_back(p);
    }
    std::string alr_prop_name = "ALR_INV_"  + this->prop_name +  "_" + std::to_string(params.size());
    Grid_continuous_property* p = grid_->add_property(alr_prop_name);
    if (p == 0) {
        p = grid_->property(alr_prop_name);
        if(p == 0) {
            errors->report( "Could not create the property " + alr_prop_name);
            return false;
        }
    }
    ALR_props_.push_back(p);
    return true;
}


bool ALR_Inv_Transformation::exec(Progress_notifier* notifier) {
    size_t N = props_[0]->size();
    size_t M = props_.size();
    std::vector<std::vector<double> > data(N);
    std::vector<bool> data_ok(N, true);
    for (size_t i = 0; i < N; ++i) {
        for (size_t p = 0; p < M; ++p) {
            if( !props_[p]->is_informed(i) ) {
                data_ok[i] = false;
            } else {
                double value = props_[p]->get_value(i);
                if (fabs(value) < 5e-3) value = 5e-3;
                data[i].push_back(value);
            }
        }
    }
    size_t d = String_Op::to_number<size_t>(this->pivot_name);
    /*
    Executando ALR - inv
    */
    for (size_t i = 0; i < N; ++i) {
        if (!data_ok[i]) continue;
        double sum = 1;
        for (size_t j = 0; j < M; ++j) {
            if (data[i][j] < INF)
                sum += exp(data[i][j]);
        }
        for (size_t j = 0; j <= M; ++j) {
            if (j < d - 1) {
                if (data[i][j] < INF)
                    ALR_props_[j]->set_value(exp(data[i][j]) / sum * this->closure_const, i);
            } else if (j > d - 1) {
                if (data[i][j] < INF)
                    ALR_props_[j]->set_value(exp(data[i][j-1]) / sum * this->closure_const, i);
            } else {
                if (data[i][j] < INF)
                    ALR_props_[j]->set_value(1.0 / sum * this->closure_const, i);
            }
        }
    }
    return true;
}
