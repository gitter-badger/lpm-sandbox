// Template Numerical Toolkit (TNT) for Linear Algebra
//
// BETA VERSION INCOMPLETE AND SUBJECT TO CHANGE
// Please see http://math.nist.gov/tnt for updates
//
// R. Pozo
// Mathematical and Computational Sciences Division
// National Institute of Standards and Technology


#ifndef TNT_VERSION_H
#define TNT_VERSION_H


#define TNT_MAJOR_VERSION    '0'
#define TNT_MINOR_VERSION    '9'
#define TNT_SUBMINOR_VERSION '4'
#define TNT_VERSION_STRING "0.9.4"

#endif
