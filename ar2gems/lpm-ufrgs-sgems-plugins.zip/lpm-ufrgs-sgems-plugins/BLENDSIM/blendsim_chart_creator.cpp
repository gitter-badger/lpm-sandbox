/*
Implementação do plugin BLENDSIM.

(c) 2013, LPM/UFRGS, Roberto Menin, Péricles Lopes Machado
*/

#include "blendsim_chart_creator.h"
#include "blendsim_chart.h"

#include <utils/manager_repository.h>

#include <QDialog>
#include <QTreeView>
#include <QToolBox>
#include <QSplitter>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QModelIndexList>
#include <QGroupBox>
#include <QLabel>
#include <QDockWidget>
#include <QToolBar>
#include <QAction>
#include <QMdiSubWindow>
#include <QButtonGroup>
#include <QTextEdit>
#include <QCheckBox>
#include <qtextstream.h>

Blendsim_chart_creator::Blendsim_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent) :Chart_creator(mdi_area, parent) {
    QTabWidget* Blend_Widget = new QTabWidget(this);
    Blend_Widget->addTab(this->build_interpiles_page(), QIcon(),"Interpiles");
    Blend_Widget->addTab(this->build_pileseries_page(), QIcon(),"Pile Series/Locate");
    Blend_Widget->addTab(this->build_intrapiles_page(), QIcon(),"IntraPiles");
    Blend_Widget->addTab(this->build_dispersionvariance_page(), QIcon(),"Dispersion Variance");
    QVBoxLayout* main_layout = new QVBoxLayout(this);
    main_layout->setContentsMargins(0,0,0,0);
    main_layout->addWidget(Blend_Widget);
    this->setLayout(main_layout);
}

void Blendsim_chart_creator::show_chart_interpiles() {
    QString grid_name = grid_selector_->selectedGrid();
    QString region_name = grid_selector_->selectedRegion();
    if(grid_name.isEmpty() ) return;
    SmartPtr<Named_interface> grid_ni =
        Root::instance()->interface( gridModels_manager + "/" + grid_name.toStdString() );
    Geostat_grid* grid = dynamic_cast<Geostat_grid*>( grid_ni.raw_ptr() );
    if(grid == 0) return;
    Grid_continuous_property* sequence_prop = grid->property(sequence_prop_selector_->currentText().toStdString());
    Grid_region* region = grid->region(region_name.toStdString());
    if(sequence_prop == 0 ) return;
    std::vector<Grid_continuous_property*> grades_prop;
    QStringList grade_prop_names = grades_selector_->selected_properties();
    if(grade_prop_names.size() == 0) return;
    for(int i=0; i<grade_prop_names.size(); ++i ) {
        grades_prop.push_back(  grid->property( grade_prop_names.at(i).toStdString()  ) );
    }
    Grid_continuous_property* mass_prop = grid->property(mass_prop_selector_->currentText().toStdString());
    if(mass_prop == 0 ) return;
    Blendsim_chart* chart = new Blendsim_chart(grid, grades_prop, sequence_prop,
            mass_prop, region, Blending_types::BLENDING_INTERPILES,
            this->initial_mass_interpiles->value(),
            this->final_mass_interpiles->value(),
            this->increase_mass_interpiles->value(),
            this );
    QMdiSubWindow* sub_window = mdi_area_->addSubWindow(chart);
    sub_window->setAttribute( Qt::WA_DeleteOnClose );
    sub_window->showMaximized();
    //sub_window->show();
}


void Blendsim_chart_creator::show_chart_pileseries() {
    std::vector<Grid_continuous_property*> grades_prop;
    Blendsim_chart* chart = new Blendsim_chart(0, grades_prop, 0,
            0, 0, Blending_types::BLENDING_PILESERIES,
            0,
            0,
            0,
            this );
    QMdiSubWindow* sub_window = mdi_area_->addSubWindow(chart);
    sub_window->setAttribute( Qt::WA_DeleteOnClose );
    sub_window->showMaximized();
    //sub_window->show();
}


void Blendsim_chart_creator::show_chart_pilelocate() {
    std::vector<Grid_continuous_property*> grades_prop;
    Blendsim_chart* chart = new Blendsim_chart(0, grades_prop, 0,
            0, 0, Blending_types::BLENDING_PILELOCATE,
            0,
            0,
            0,
            this );
    QMdiSubWindow* sub_window = mdi_area_->addSubWindow(chart);
    sub_window->setAttribute( Qt::WA_DeleteOnClose );
    sub_window->showMaximized();
    //sub_window->show();
}


Grid_continuous_property* Blendsim_chart_creator::getVolumeProp() {
    QString grid_name = grid_selector_->selectedGrid();
    if (grid_name.isEmpty()) return 0;
    SmartPtr<Named_interface> grid_ni =
        Root::instance()->interface( gridModels_manager + "/" + grid_name.toStdString() );
    Geostat_grid* grid = dynamic_cast<Geostat_grid*>( grid_ni.raw_ptr() );
    if (grid)
        return grid->property(this->choose_volume_prop_selector_->currentText().toStdString());
    return 0;
}

void Blendsim_chart_creator::show_chart_intrapiles() {
    QString grid_name = grid_selector_->selectedGrid();
    QString region_name = grid_selector_->selectedRegion();
    if(grid_name.isEmpty() ) return;
    SmartPtr<Named_interface> grid_ni =
        Root::instance()->interface( gridModels_manager + "/" + grid_name.toStdString() );
    Geostat_grid* grid = dynamic_cast<Geostat_grid*>( grid_ni.raw_ptr() );
    if(grid == 0) return;
    Grid_continuous_property* sequence_prop = grid->property(sequence_prop_selector_->currentText().toStdString());
    Grid_region* region = grid->region(region_name.toStdString());
    if(sequence_prop == 0 ) return;
    std::vector<Grid_continuous_property*> grades_prop;
    QStringList grade_prop_names = grades_selector_->selected_properties();
    if(grade_prop_names.size() == 0) return;
    for(int i=0; i<grade_prop_names.size(); ++i ) {
        grades_prop.push_back(  grid->property( grade_prop_names.at(i).toStdString()  ) );
    }
    Grid_continuous_property* mass_prop = grid->property(mass_prop_selector_->currentText().toStdString());
    if(mass_prop == 0 ) return;
    Blendsim_chart* chart = new Blendsim_chart(grid, grades_prop, sequence_prop,
            mass_prop, region, Blending_types::BLENDING_INTRAPILES,
            this->initial_mass_interpiles->value(),
            this->final_mass_interpiles->value(),
            this->increase_mass_interpiles->value(),
            this );
    QMdiSubWindow* sub_window = mdi_area_->addSubWindow(chart);
    sub_window->setAttribute( Qt::WA_DeleteOnClose );
    sub_window->showMaximized();
}


void Blendsim_chart_creator::update_pileseries_selector() {
    MapPileSeries::iterator it = this->pileseries_.begin(), ed = this->pileseries_.end();
    averagepile_1_prop_selector_->clear();
    choose_mass_prop_selector_->clear();
    while (it != ed) {
        QString item;
        QTextStream out(&item);
        out << it->first;
        averagepile_1_prop_selector_->addItem(item);
        choose_mass_prop_selector_->addItem(item);
        ++it;
    }
}


void Blendsim_chart_creator::show_chart_dispersionvariance() {
}

//Inter Pile function
QWidget* Blendsim_chart_creator::build_interpiles_page() {
    QWidget* interpiles_container = new QWidget(this);
    QVBoxLayout* interpiles_layout = new QVBoxLayout(interpiles_container);
    grid_selector_ = new GridSelector(interpiles_container);
    grid_selector_->setToolTip("Use this selector to choose grid with properties");
    grades_selector_ = new OrderedPropertySelector(interpiles_container);
    grades_selector_->setToolTip("Select all simulations here!");
    sequence_prop_selector_ = new SinglePropertySelector(interpiles_container);
    sequence_prop_selector_->setToolTip("Select property with Sequence Mine");
    mass_prop_selector_ = new SinglePropertySelector(interpiles_container);
    mass_prop_selector_->setToolTip("Select property with Block Mass");
    interpiles_layout->addWidget(new QLabel("Grid with property",interpiles_container));
    interpiles_layout->addWidget(grid_selector_);
    interpiles_layout->addSpacing(15);
    interpiles_layout->addWidget(new QLabel("Mine Sequence",interpiles_container));
    interpiles_layout->addWidget(sequence_prop_selector_);
    interpiles_layout->addSpacing(15);
    interpiles_layout->addWidget(new QLabel("Mass",interpiles_container));
    interpiles_layout->addWidget(mass_prop_selector_);
    interpiles_layout->addSpacing(15);
    interpiles_layout->addWidget(new QLabel("Minimum Block Mass: ",interpiles_container));
    minimum_block_mass_interpiles = new QLabel("0 ",interpiles_container);
    interpiles_layout->addWidget(minimum_block_mass_interpiles);
    interpiles_layout->addWidget(new QLabel("Maximum Block Mass: ",interpiles_container));
    maximum_block_mass_interpiles = new QLabel(" 0 ",interpiles_container);
    interpiles_layout->addWidget(maximum_block_mass_interpiles);
    interpiles_layout->addWidget(new QLabel("Maximum Increase Mass: ",interpiles_container));
    maximum_increase_mass_interpiles = new QLabel("0 ",interpiles_container);
    interpiles_layout->addWidget(maximum_increase_mass_interpiles);
    interpiles_layout->addWidget(new QLabel("Sum Mass: ",interpiles_container));
    sum_block_mass_interpiles = new QLabel("0 ",interpiles_container);
    interpiles_layout->addWidget(sum_block_mass_interpiles);
    interpiles_layout->addSpacing(30);
    interpiles_layout->addWidget(new QLabel("Simulation",interpiles_container));
    interpiles_layout->addWidget(grades_selector_);
    interpiles_layout->addSpacing(25);
    interpiles_layout->addWidget(new QLabel("Pile - Initial Mass",interpiles_container));
    QDoubleSpinBox* initial_mass  = new QDoubleSpinBox(interpiles_container);
    initial_mass_interpiles = initial_mass;
    initial_mass->setMaximum(1e20);
    initial_mass->setMinimum(0);
    interpiles_layout->addWidget(initial_mass);
    interpiles_layout->addWidget(new QLabel("Increase Mass",interpiles_container));
    QDoubleSpinBox* increase_mass  = new QDoubleSpinBox(interpiles_container);
    increase_mass_interpiles = increase_mass;
    increase_mass->setMaximum(1e20);
    increase_mass->setMinimum(0);
    interpiles_layout->addWidget(increase_mass);
    interpiles_layout->addSpacing(25);
    interpiles_layout->addWidget(new QLabel("Pile - Final Mass",interpiles_container));
    QDoubleSpinBox* final_mass  = new QDoubleSpinBox(interpiles_container);
    final_mass_interpiles = final_mass;
    final_mass->setMaximum(1e20);
    final_mass->setMinimum(0);
    interpiles_layout->addWidget(final_mass);
    interpiles_layout->addStretch();
    QPushButton* show_button = new QPushButton("Run interpiles",interpiles_container);
    interpiles_layout->addWidget(show_button);
    interpiles_layout->setContentsMargins(0,0,0,0);
    interpiles_layout->addWidget(new QLabel("__________________",interpiles_container));
    QLabel* count_time  = new QLabel(interpiles_container);
    count_time_interpiles = count_time;
    interpiles_layout->addWidget(count_time);
    interpiles_container->setLayout(interpiles_layout);
    bool ok = connect( grid_selector_, SIGNAL(activated( const QString&)),sequence_prop_selector_, SLOT(show_properties( const QString&))   );
    ok = connect( grid_selector_, SIGNAL(activated( const QString&)),grades_selector_, SLOT(show_properties( const QString&))   );
    ok = connect( grid_selector_, SIGNAL(activated( const QString&)),mass_prop_selector_, SLOT(show_properties( const QString&))   );
    ok = connect( show_button, SIGNAL(clicked()),this, SLOT(show_chart_interpiles())   );
    ok = connect( mass_prop_selector_, SIGNAL(activated( const QString&)),this, SLOT(update_block_mass( const QString&))   );
    ok = connect( mass_prop_selector_, SIGNAL(currentIndexChanged( const QString&)),this, SLOT(update_block_mass( const QString&))   );
    ok = connect( initial_mass_interpiles, SIGNAL(valueChanged( double)),this, SLOT(update_increase_mass( double ))   );
    //ok = connect( final_mass_interpiles, SIGNAL(valueChanged( double)),this, SLOT(update_increase_mass( double ))   );
// ok = connect( increase_mass_interpiles, SIGNAL(valueChanged( double)),this, SLOT(update_increase_mass( double ))   );
    return interpiles_container;
}

//Pile Series function
QWidget* Blendsim_chart_creator::build_pileseries_page() {
    QWidget* pileseries_container = new QWidget(this);
    QVBoxLayout* pileseries_layout = new QVBoxLayout(pileseries_container);
    averagepile_1_prop_selector_ = new SinglePropertySelector(pileseries_container);
    averagepile_1_prop_selector_->setToolTip("Select pile mass to check uncertainty space");
    pileseries_layout->addWidget(new QLabel("PILE SERIES routine",pileseries_container));
    pileseries_layout->addSpacing(10);
    pileseries_layout->addWidget(new QLabel("Pile Mass",pileseries_container));
    pileseries_layout->addWidget(averagepile_1_prop_selector_);
    pileseries_layout->addSpacing(25);
    QPushButton* show_button = new QPushButton("RUN pile SERIES",pileseries_container);
    pileseries_layout->addWidget(show_button);
    pileseries_layout->addSpacing(250);
//  pileseries_layout->addStretch();
    pileseries_layout->addWidget(new QLabel("PILE LOCATE routine",pileseries_container));
    pileseries_layout->addSpacing(10);
    pileseries_layout->addWidget(new QLabel("Atual Pile Mass: ",pileseries_container));
    atual_pile_mass_pileseries = new QLabel(" 0 ",pileseries_container);
    pileseries_layout->addWidget(atual_pile_mass_pileseries);
    pileseries_layout->addSpacing(10);
    pileseries_layout->addWidget(new QLabel("Define Grade Max",pileseries_container));
    QDoubleSpinBox* grade_max_mass  = new QDoubleSpinBox(pileseries_container);
    grade_max_mass_locate = grade_max_mass;
    grade_max_mass->setMaximum(1e20);
    grade_max_mass->setMinimum(0);
    pileseries_layout->addWidget(grade_max_mass);
    pileseries_layout->addSpacing(10);
    pileseries_layout->addWidget(new QLabel("Define Grade Min",pileseries_container));
    QDoubleSpinBox* grade_min_mass  = new QDoubleSpinBox(pileseries_container);
    grade_min_mass_locate = grade_min_mass;
    grade_min_mass->setMaximum(1e20);
    grade_min_mass->setMinimum(0);
    pileseries_layout->addWidget(grade_min_mass);
    QPushButton* show_button_locate = new QPushButton("RUN Locate Pile LOCATE",pileseries_container);
    pileseries_layout->addWidget(show_button_locate);
    pileseries_container->setLayout(pileseries_layout);
    pileseries_layout->addStretch();
    bool ok = connect( show_button, SIGNAL(clicked()),this, SLOT(show_chart_pileseries()));
    ok = connect( show_button_locate, SIGNAL(clicked()),this, SLOT(show_chart_pilelocate()));
    ok = connect(this->averagepile_1_prop_selector_, SIGNAL(activated(QString)), this->atual_pile_mass_pileseries, SLOT(setText(const QString&)));
    return pileseries_container;
}

//Intra Pile function
QWidget* Blendsim_chart_creator::build_intrapiles_page() {
    QWidget* intrapiles_container = new QWidget(this);
    QVBoxLayout* intrapiles_layout = new QVBoxLayout(intrapiles_container);
    intrapiles_layout->addSpacing(15);
    choose_mass_prop_selector_ = new SinglePropertySelector(intrapiles_container);
    choose_mass_prop_selector_->setToolTip("Select Average Pile Mass");
    intrapiles_layout->addWidget(new QLabel("Average Pile Mass",intrapiles_container));
    intrapiles_layout->addWidget(choose_mass_prop_selector_);
    intrapiles_layout->addSpacing(15);
    choose_volume_prop_selector_ = new SinglePropertySelector(intrapiles_container);
    choose_volume_prop_selector_->setToolTip("Select Volume of Block");
    intrapiles_layout->addWidget(new QLabel("Volume of Block",intrapiles_container));
    intrapiles_layout->addWidget(choose_volume_prop_selector_);
    intrapiles_layout->addSpacing(30);
    intrapiles_layout->addWidget(new QLabel("Bulk Factor",intrapiles_container));
    QDoubleSpinBox* bulk_factor  = new QDoubleSpinBox(intrapiles_container);
    bulk_factor_intrapiles = bulk_factor;
    bulk_factor->setMaximum(1e20);
    bulk_factor->setMinimum(0);
    intrapiles_layout->addWidget(bulk_factor);
    intrapiles_layout->addSpacing(5);
    intrapiles_layout->addWidget(new QLabel("Material of Staker (m^3/m)",intrapiles_container));
    QDoubleSpinBox* material_staker  = new QDoubleSpinBox(intrapiles_container);
    material_staker_intrapiles = material_staker;
    material_staker->setMaximum(1e20);
    material_staker->setMinimum(0);
    intrapiles_layout->addWidget(material_staker);
    intrapiles_layout->addSpacing(25);
    intrapiles_layout->addWidget(new QLabel("Layers Analysis ",intrapiles_container));
    intrapiles_layout->addSpacing(10);
    intrapiles_layout->addWidget(new QLabel("Initial Layers",intrapiles_container));
    QSpinBox* initial_layer  = new QSpinBox(intrapiles_container);
    ini_layer_intrapiles = initial_layer;
    initial_layer->setMaximum(1<<20);
    initial_layer->setMinimum(1);
    intrapiles_layout->addWidget(initial_layer);
    intrapiles_layout->addSpacing(5);
    intrapiles_layout->addWidget(new QLabel("Final Layers",intrapiles_container));
    QSpinBox* final_layer  = new QSpinBox(intrapiles_container);
    final_layer_intrapiles = final_layer;
    final_layer->setMaximum(1<<20);
    final_layer->setMinimum(1);
    intrapiles_layout->addWidget(final_layer);
    intrapiles_layout->addSpacing(5);
    intrapiles_layout->addWidget(new QLabel("Interval Layers",intrapiles_container));
    QSpinBox* interval_layer  = new QSpinBox(intrapiles_container);
    interval_layer_intrapiles = interval_layer;
    interval_layer->setMaximum(1<<20);
    interval_layer->setMinimum(1);
    intrapiles_layout->addWidget(interval_layer);
    intrapiles_layout->addSpacing(25);
    intrapiles_layout->addWidget(new QLabel("Angle of Repose",intrapiles_container));
    QDoubleSpinBox* repose_angle  = new QDoubleSpinBox(intrapiles_container);
    repose_angle_intrapiles = repose_angle;
    repose_angle->setMaximum(1e20);
    repose_angle->setMinimum(0);
    intrapiles_layout->addWidget(repose_angle);
    intrapiles_layout->addSpacing(5);
    intrapiles_layout->addWidget(new QLabel("Base Lenght",intrapiles_container));
    QDoubleSpinBox* base_lenght  = new QDoubleSpinBox(intrapiles_container);
    base_lenght_intrapiles = base_lenght;
    base_lenght->setMaximum(1e20);
    base_lenght->setMinimum(0);
    intrapiles_layout->addWidget(base_lenght);
    intrapiles_layout->addSpacing(25);
    intrapiles_layout->addStretch();
    QPushButton* show_button = new QPushButton("Run intrapiles",intrapiles_container);
    intrapiles_layout->addWidget(show_button);
    intrapiles_layout->setContentsMargins(0,0,0,0);
    intrapiles_container->setLayout(intrapiles_layout);
    bool  ok = connect( show_button, SIGNAL(clicked()),this, SLOT(show_chart_intrapiles())   );
    ok = connect( grid_selector_, SIGNAL(activated( const QString&)),choose_volume_prop_selector_, SLOT(show_properties( const QString&))   );
    return intrapiles_container;
}

//Dispersion Variance function
QWidget* Blendsim_chart_creator::build_dispersionvariance_page() {
    QWidget* dispersionvariance_container = new QWidget(this);
    QVBoxLayout* dispersionvariance_layout = new QVBoxLayout(dispersionvariance_container);
    dispersionvariance_layout->addStretch();
    QPushButton* show_button = new QPushButton("Calculate Dispersion Variance",dispersionvariance_container);
    dispersionvariance_layout->addWidget(show_button);
    dispersionvariance_container->setLayout(dispersionvariance_layout);
    bool ok = connect( show_button, SIGNAL(clicked()),this, SLOT(show_chart_dispersionvariance())   );
    return dispersionvariance_container;
}


void Blendsim_chart_creator::update_increase_mass(double value_increase) {
    double initial_mass = initial_mass_interpiles->value();
    //double increase_mass = increase_mass_interpiles->value();
    double final_mass = final_mass_interpiles->value();
    increase_mass_interpiles->setValue(final_mass - initial_mass);
//	final_mass_interpiles->setValue(initial_mass + increase_mass);
}


void Blendsim_chart_creator::update_block_mass(const QString& prop_name) {
    QString grid_name = grid_selector_->selectedGrid();
    QString region_name = grid_selector_->selectedRegion();
    if(grid_name.isEmpty() ) return;
    SmartPtr<Named_interface> grid_ni =
        Root::instance()->interface( gridModels_manager + "/" + grid_name.toStdString() );
    Geostat_grid* grid = dynamic_cast<Geostat_grid*>( grid_ni.raw_ptr() );
    if(grid == 0) return;
    Grid_region* region = grid->region(region_name.toStdString());
    Grid_continuous_property* mass_prop = grid->property(mass_prop_selector_->currentText().toStdString());
    if(mass_prop == 0) return;
    double min_mass = 0, max_mass = 0, sum_mass = 0;
    for(int i=0; i< mass_prop->size(); ++i) {
        if(region && !region->is_inside_region(i)) continue;
        double mass = mass_prop->get_value(i);
        if (mass < min_mass || i == 0) {
            min_mass = mass;
        }
        if (mass > max_mass) {
            max_mass = mass;
        }
        sum_mass += mass;
    }
    QString b;
    QTextStream out_buf(&b);
    out_buf << " " << min_mass << " ";
    this->minimum_block_mass_interpiles->setText(b);
    b = "";
    out_buf << " " << max_mass << " ";
    this->maximum_block_mass_interpiles->setText(b);
    b = "";
    out_buf << " " << sum_mass << " ";
    this->sum_block_mass_interpiles->setText(b);
    b = "";
    out_buf << " " << sum_mass - max_mass << " ";
    this->maximum_increase_mass_interpiles->setText(b);
    initial_mass_interpiles->setMinimum(max_mass);
    increase_mass_interpiles->setMinimum(max_mass);
    increase_mass_interpiles->setMaximum(sum_mass - min_mass);
    //final_mass_interpiles->setMaximum(sum_mass);
    //final_mass_interpiles->setMinimum(max_mass);
    increase_mass_interpiles->setValue(sum_mass - max_mass);
    final_mass_interpiles->setValue(sum_mass);
}


