#ifndef __LPM_UFRGS_CELL_DECLUSTERING_H
#define __LPM_UFRGS_CELL_DECLUSTERING_H


# include <map>

# include "Struct_Drillhole.h"

#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>
#include <grid/grid_property.h>
#include <grid/grid_region.h>
#include <grid/neighborhood.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>
#include <geostat/parameters_handler.h>
#include <grid/neighborhood.h>
# include <grid/rgrid_neighborhood.h>
# include <grid/rgrid.h>
# include <grid/point_set.h>

#include <geostat/kriging.h>

#include <GsTL/geometry/covariance.h>
# include <QFile>
# include <fstream>


enum {
    SIMPLE_KRIGING = 0,
    ORDINARY_KRIGING = 1
};

class LPM_UFRGS_Cell_Declustering : public Geostat_algo {
  public:
    LPM_UFRGS_Cell_Declustering();
    virtual ~LPM_UFRGS_Cell_Declustering();

    virtual bool initialize(const Parameters_handler* parameters,
                            Error_messages_handler* errors, Progress_notifier* notifier = 0);
    virtual int execute(GsTL_project* proj = 0, Progress_notifier* notifier = 0);
    virtual std::string name() const {
        return "LPM_UFRGS_Cell_Declustering";
    }

  public:
    static Named_interface* create_new_interface( std::string& );

  protected:
    void clean( const std::string& prop );

  private :/*need files below*/
    typedef Geostat_grid::location_type Location;
    typedef GsTL_neighborhood< SmartPtr<Neighborhood> > NeighborhoodHandle;


    Geostat_grid *Dataset;

    //Point_set *Block_Locations_Point_Set;


    // b) Map declaration
    std::map<int, Struct_Drillhole> Map_ID_Blocks;


    //double Contribution_Of_The_Variogram, Range_Of_The_Variogram;
    double tmin;
    double tmax;

    double anisy;
    double anisz;

    int imin;

    int Look_For_Minimum_Declustered_Mean;
    int Look_For_Maximum_Declustered_Mean;

    int noff;

    double roff;

    int ncell;

    double cmin;
    double cmax;

    std::string File_Path;


    std::ofstream Myfile;

    Grid_continuous_property *Grades;
    Grid_continuous_property *BHID;


    GsTL_project* proj_;

    Error_messages_handler* errors_;




    std::string Estimate_Name;




};

#endif /* GEOBODY_H_ */
