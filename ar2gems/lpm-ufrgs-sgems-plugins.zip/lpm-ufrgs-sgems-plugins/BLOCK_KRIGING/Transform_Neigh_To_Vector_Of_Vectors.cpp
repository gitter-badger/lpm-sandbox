# include "Transform_Neigh_To_Vector_Of_Vectors.h"
# include <vector>
# include <grid/geovalue.h>

using namespace std;

std::vector<std::vector<double> > Transform_Neigh_To_Vector_Of_Vectors(const std::vector<Geovalue> &neigh_)
{
	vector<vector<double> > Sample_Points;
	double x = 0, y = 0, z = 0, data = 0;
	int node_id = 0;

	for(size_t i = 0; i < neigh_.size(); ++i){
		vector<double> row;
		x = neigh_[i].xyz_location().x();
		row.push_back(x);

		y = neigh_[i].xyz_location().y();
		row.push_back(y);

		z = neigh_[i].xyz_location().z();
		row.push_back(z);

		data = neigh_[i].property_value();
		row.push_back(data);

		node_id = neigh_[i].node_id();
		row.push_back(node_id);

		Sample_Points.push_back(row);
	}

	return Sample_Points;
}