#include <iostream>
# include <iomanip>
# include <fstream>
# include <vector>
# include <string>
# include <map>
# include <math/gstlpoint.h>
# include <geostat/utilities.h>
# include <utils/string_manipulation.h>
# include <grid/utilities.h>
# include <grid/neighbors.h>
# include <geostat/utilities.h>
# include <grid/point_set.h>

# include <grid/point_set_neighborhood.h>
# include <grid/gval_iterator.h>
# include <grid/grid_path.h>
# include <appli/utilities.h>
# include <grid/geostat_grid.h>
# include <grid/neighborhood.h>
# include <grid/rgrid_neighborhood.h>
# include <grid/rgrid.h>
# include <grid/point_set.h>
# include <utils/gstl_messages.h>
# include <utils/manager_repository.h>
# include <iostream>
# include <fstream>
# include <QTime>
# include "Struct_Drillhole.h"
# include "Create_Map_BHID.h"
# include "LPM_UFRGS_Cell_Declustering.h"
# include "Create_Areal_Dataset.h"
# include "Transform_Areal_Dataset_To_3D_Dataset.h"
 #include <QMessageBox>
# include <QFile>


LPM_UFRGS_Cell_Declustering::LPM_UFRGS_Cell_Declustering() {

}

LPM_UFRGS_Cell_Declustering::~LPM_UFRGS_Cell_Declustering() {

}

Named_interface* LPM_UFRGS_Cell_Declustering::create_new_interface( std::string& ) {
	return new LPM_UFRGS_Cell_Declustering;
}

bool LPM_UFRGS_Cell_Declustering::initialize( const Parameters_handler* parameters,
	Error_messages_handler* errors, Progress_notifier* notifier) {

		//Read dataset grid
		std::string Dataset_Name = parameters->value( "Dataset.value" );
		errors->report( Dataset_Name.empty(),
		  "Dataset", "No grid selected" );
		// Set the string "Point_Samples_Grid_Name" To the string field of the Object Point_Locations_And_Values (class Geostat_grid). The method get_grid_from_manager sets the string to the correct place
		this->Dataset = get_grid_from_manager(Dataset_Name);
	
	if (this->Dataset == 0) {
		
		errors->report("The grid " +  Dataset_Name + " does not exist");
		return false;
	}


	// Read Grade
	std::string Grade_Name = parameters->value( "Grade.value" );
		errors->report( Grade_Name.empty(),
		  "Grade.property", "No property name specified" );

	this->Grades = this->Dataset->property(Grade_Name);

	if (this->Grades == 0) {
		
			errors->report("The property " + Grade_Name + " does not exist");
			return false;
	}

	//Read BHID

	std::string BHID_Name = parameters->value( "BHID.value" );
		errors->report( Grade_Name.empty(),
		  "BHID.property", "No property name specified" );

	this->BHID = this->Dataset->property(BHID_Name);

	if (this->BHID == 0) {
		
			errors->report("The property " + BHID_Name + " does not exist");
			return false;
	}
	
	//test if property for Grade is equal to property
	if(BHID_Name == Grade_Name){
		QMessageBox::critical(0,"FATAL ERROR!!!!  WHAT ARE YOU DOING???","Property for grades must be different from property for BHID");
		return false;
	}



	ncell = String_Op::to_number<int>( parameters->value( "Number_Of_Cells.value" ) );
	noff =  String_Op::to_number<int>( parameters->value( "Number_Of_Origin_Offsets.value" ) );

	roff = noff;
	
	cmin = String_Op::to_number<double>( parameters->value( "Minimum_Cell_Size.value" ) );
	cmax = String_Op::to_number<double>( parameters->value( "Maximum_Cell_Size.value" ) );
	
	if(cmin > cmax){// test if cmin more than cmac

		QMessageBox::critical(0,"FATAL ERROR!!!!  WHAT ARE YOU DOING???","Maximum cell size must be greater than minimum cell size");
		return false;
	
	}

	//ReaY anisotropy
	anisy = String_Op::to_number<double>( parameters->value( "Y_Anisotropy.value" ) );

	// Because declustering is performerly arealy, Z anisotropy does not matter
	anisz = 1;

	//Read trimming limits
	//tmin = String_Op::to_number<double>(parameters->value("Trim_Min.value"));
	//tmax = String_Op::to_number<double>(parameters->value("Trim_Max.value"));


	//Read string for File name which receives cell sizes and declustered means
	File_Path = parameters->value("File_Path.value");
	//Chek if string is not empty
	
	Myfile.open(File_Path);
	Myfile << "LPM_UFRGS_CELL_DECLUSTERING.\n";
	Myfile << "2\n";
	Myfile << "Cell_Size\n";
	Myfile << "Declustered_Mean\n";

	//Myfile.close();
	if ((QFile::exists(QString::fromStdString(File_Path))) == false){
		QMessageBox::critical(0,"FATAL ERROR!!!!  WHAT ARE YOU DOING???","Please write a valid file path to write cell sizes and declustered means");
		return false;
	}

	
	Look_For_Minimum_Declustered_Mean = String_Op::to_number<int>( parameters->value("Look_For_Minimum_Declustered_Mean.value"));
	Look_For_Maximum_Declustered_Mean = String_Op::to_number<int>( parameters->value("Look_For_Maximum_Declustered_Mean.value"));
	
	if ( abs(Look_For_Minimum_Declustered_Mean-Look_For_Maximum_Declustered_Mean) < 0.00001){//test if option for declustered mean were chosen?
		QMessageBox::critical(0,"FATAL ERROR!!!!  WHAT ARE YOU DOING???","Please choose an option for declustered mean, minimum ou maximum ?");
		//errors->report("Please select an option for declustered mean", "Minimum or Maximum declustered mean?");
			return false;
	}

	if (Look_For_Minimum_Declustered_Mean == 1){
		imin = 0;
	}else{
		imin = 1;
	}

	


		return true;
}

void LPM_UFRGS_Cell_Declustering::clean( const std::string& prop ) {
  
}
		
int LPM_UFRGS_Cell_Declustering::execute(GsTL_project* proj, Progress_notifier* notifier) {

/*Variable dictionary

ncell: number of cell sizes
cmin: mininmum size
cmax: maximum size

anisy: y anisotropy (Ysize = Xsize*yanis)
anisz: z anisotropy

imin (imin = 0 -> look for minimum declustered mean, imin =  1 = look for maximum declustered mean)

noff (number of origin offsets)

tmin, tmax (trimming limits)



    */







//Convert data grid to data vector for better manipulation

size_t N_Data = Dataset->size();

using namespace std;

vector<vector<double> > data_vector;

for (size_t i = 0; i < N_Data ; ++i){
    vector<double> row;
	double value = Grades->get_value(i);
	if(Grades->is_informed(i)){	//trim this data?

		double x = Dataset->xyz_location(i).x();
		row.push_back(x);

		double y = Dataset->xyz_location(i).y();
		row.push_back(y);

		double z = Dataset->xyz_location(i).z();
		row.push_back(z);

		double grade = Grades->get_value(i);
		row.push_back(grade);

		int bhid = BHID->get_value(i);
		row.push_back(bhid);

		int node_id = Dataset->node_id(i);
		row.push_back(node_id);

		data_vector.push_back(row);
	}
}

map<int, Struct_Drillhole > Map_BHID;


//data vector contains the following columns sequence:X,Y,Z,Grade,BHID and node_id
Create_Map_BHID (Map_BHID, data_vector);

std::vector<std::vector<double> > Areal_Dataset = Create_Areal_Dataset(Map_BHID);
//Areal_Dataset Contains the following information: X_Centroid, Y_Centroid, Z (equals to 0.00), Average, BHID, weight_for_drillhole

// put the data into the vector x, y, z, vr, bhid, weight drillhole and initialize vector index
vector<double> x, y, z, var, wtopt, wt_drillhole;
vector<int> bhid, index;
for (size_t i = 0; i < Areal_Dataset.size(); ++i){
        x.push_back(Areal_Dataset[i][0]);
        y.push_back(Areal_Dataset[i][1]);
        z.push_back(Areal_Dataset[i][2]);
        var.push_back(Areal_Dataset[i][3]);
		bhid.push_back(Areal_Dataset[i][4]);
		wt_drillhole.push_back(Areal_Dataset[i][5]);
		index.push_back(0);

}

// initialize weights wtopt 
for (size_t i = 0; i < var.size(); ++i){
	wtopt.push_back(1.00);
}

double xmin = 1.0e21, ymin = 1.0e21, zmin = 1.0e21;
double xmax = -1.0e21, ymax = -1.0e21, zmax = -1.0e21;
//Calculate x, y, and z minimum and maximum and average

//int counter = 0;
double vrav = 0, vrcr = 0;
double sum_var_times_weight = 0;
double sum_weight = 0;
double best = 0;
// calculate mean and find bounding box
for (size_t i = 0; i < var.size(); ++i){
	   
	sum_var_times_weight = sum_var_times_weight + (var[i]*(wtopt[i]*wt_drillhole[i]));
    sum_weight = sum_weight + (wtopt[i]*wt_drillhole[i]);

    if (x[i] > xmax){
        xmax = x[i];
    }
    if (x[i] < xmin){
        xmin = x[i];
    }
    if (y[i] > ymax){
        ymax = y[i];
    }
    if (y[i] < ymin){
        ymin = y[i];
	}
	if (z[i] > zmax){
        zmax = z[i];
    }
    if (z[i] < zmin){
        zmin = z[i];
	}
	    
}
vrav = sum_var_times_weight/sum_weight;
double vrop = vrav;

Myfile<<"0.00"<<"    "<< std::setprecision(4) << vrav <<"\n";


//Define lower origing to use for cell sizes
double xo1 = 0, yo1 = 0, zo1 = 0;

xo1 = xmin - 0.01;
yo1 = ymin - 0.01;
zo1 = zmin - 0.01;

//Define increment for cell size
double xinc = 0.00, yinc = 0.00, zinc = 0.00;
xinc = (cmax - cmin) / ncell;
yinc = anisy * xinc;
zinc = anisz * xinc;

int ncellx = 0, ncelly = 0, ncellz = 0, ncellt = 0;
ncellx = int((xmax-(xo1-cmin))/cmin)+1;
ncelly = int((ymax-(yo1-cmin*anisy))/(cmin*anisy))+1;
ncellz = int((zmax-(zo1-cmin*anisz))/(cmin*anisz))+1;
ncellt = ncellx*ncelly*ncellz;

vector<double> cellwt;
for(size_t i = 0; i < ncellt; ++i){
	cellwt.push_back(0);
}




double xcs = 0.00, ycs = 0.00, zcs = 0.00;

xcs =  cmin        - xinc;
ycs = (cmin*anisy) - yinc;
zcs = (cmin*anisz) - zinc;


vector<double> wt;
for (size_t i = 0; i <var.size(); ++i){
    wt.push_back(0.00);
}




//Main loop over cell sizes
for(size_t lp = 0; lp < ncell + 1; ++lp){
	

    xcs = xcs + xinc;
    ycs = ycs + yinc;
    zcs = zcs + zinc;

    for(size_t i = 0; i < var.size(); ++i){
        wt[i] = 0.00;
    }

	//determine the maximum of cells in the grid network
	ncellx = int((xmax-(xo1-xcs))/xcs) + 1;
	ncelly = int((ymax-(yo1-ycs))/ycs) + 1;
	ncellz = int((zmax-(zo1-zcs))/zcs) + 1;

    ncellt = (ncellx*ncelly*ncellz);

	//initialize weights (wt)
	

    // loop over all the origin offsets
    double xfac = min((xcs/roff),(0.5*(xmax-xmin)));
    double yfac = min((ycs/roff),(0.5*(ymax-ymin)));
    double zfac = min((zcs/roff),(0.5*(zmax-zmin)));
    for (size_t kp = 0; kp < noff; ++kp){
        double xo = xo1 - (kp)*xfac;
        double yo = yo1 - (kp)*yfac;
        double zo = zo1 - (kp)*zfac;

        //initialize the cumulative weight
        for (size_t i = 0; i < ncellt; ++i){
            cellwt[i] = 0;
        }

        //determine which cell each datum is in:
        for (size_t i = 0; i <var.size(); ++i){
            int icellx = int((x[i] - xo)/xcs) + 1;
            int icelly = int((y[i] - yo)/ycs) + 1;
            int icellz = int((z[i] - zo)/zcs) + 1;
            int icell  = icellx + (icelly-1)*ncellx + (icellz-1)*ncelly*ncellx;
            index[i] = icell;
        //count the number of data for each cell
            cellwt[icell] = cellwt[icell] + 1.0;
        }
        double sumw = 0.0;

        int ipoint = 0;
        for(size_t i = 0; i < var.size(); ++i){
            ipoint = index[i];
            sumw = sumw + (1.0/cellwt[ipoint]);
        }
        sumw = 1.0/sumw;

        //Acumulate the array of the weights
		for(size_t i = 0; i < var.size(); ++i){
			ipoint = index[i];
			wt[i] = wt[i] + (1.0/cellwt[ipoint])*sumw;
		}
    }//end loop of origin offsets
	//compute the weighted average for this cell size
	
	// To calculate the mean, the length of the drillholes should be accounted for
	double sumw = 0.0;
	double sumwg = 0.0;
	for (size_t i = 0; i < var.size(); ++i){ 
        sumw = sumw + (wt[i]*wt_drillhole[i]);
        sumwg = sumwg + (wt[i]*wt_drillhole[i]*var[i]);
	}
    vrcr = sumwg/sumw;
	Myfile << std::fixed << std::setprecision(2) << xcs <<"     "<< std::fixed << std::setprecision(3) << vrcr << "\n";

	//see if this weighting is optimal
	if((imin == 0 && vrcr < vrop) || (imin == 1 && vrcr > vrop) || (ncell == 1)){
		best = xcs;
        vrop = vrcr;
        for (size_t i = 0; i < var.size(); ++i){
			wtopt[i] = wt[i];
		}
	}

}
Myfile.close();

// get the optimum weights

double sumw = 0.00;
for (size_t i = 0; i < var.size(); ++i){
    sumw = sumw + wtopt[i];
}

double wtmin = 1.0e21;
double wtmax =-1.0e21;
double facto = var.size() / sumw;

for (size_t i = 0; i < var.size(); ++i){
    wtopt[i] = wtopt[i] * facto;
	if(wtopt[i] < wtmin){wtmin = wtopt[i];};
	if(wtopt[i] > wtmax){wtmax = wtopt[i];};
}

std::vector<std::vector<double> > Three_Dimensional_Dataset = Transform_Areal_Dataset_To_3D_Dataset(Map_BHID, wtopt, bhid);

Grid_weight_property* wprop = Dataset->weight_property("weight");
if(wprop == NULL){
	wprop = Dataset->add_weight_property("weight");
}


// standardize the weights because sgems works only with weights whose sum is equal to one
// calculate the sum of the weights
double sum_wt = 0;
for(size_t i = 0; i < Three_Dimensional_Dataset.size(); ++i){
	double weight = Three_Dimensional_Dataset[i][6];
	sum_wt = sum_wt + weight;
}

// standardize the weights
for (size_t i = 0; i < Three_Dimensional_Dataset.size(); ++i){
	int node_id = Three_Dimensional_Dataset[i][5];
	double weight = Three_Dimensional_Dataset[i][6];
	double std_wt = (weight / sum_wt);
	wprop->set_value(std_wt, node_id);
}

// For grades unsampled, the assign weights equal to zero
for(size_t j = 0; j < Grades->size(); ++j){
	//Grades->is_informed_value(j)
	if (Grades->is_informed(j)){
		continue;
	} else {wprop->set_value(0.00000000000000, j);
	}
}


return true;

}
