#ifndef BUILD_LHS_COVARIANCE_MATRIX_H
#define BUILD_LHS_COVARIANCE_MATRIX_H

# include <vector>
# include <map>

std::vector<std::vector<double> > Build_LHS_Covariance_Matrix(Geostat_grid *Point_samples_grid, const std::vector<std::vector<double> > &samples, const std::vector<std::vector<double> > &Point_To_Block_Covariance_Lookup_Table, std::vector<std::vector<double> > &Block_To_Block_Covariance_Lookup_Table, const std::vector<int> &block_ids, const Two_point_nested_structure &covar_, const int &kriging_option);

#endif
