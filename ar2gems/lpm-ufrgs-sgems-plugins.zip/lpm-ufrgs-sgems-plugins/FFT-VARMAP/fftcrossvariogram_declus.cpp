/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftcrossvariogram_declus.h"

FFTCrossVariogramDeclus::FFTCrossVariogramDeclus(QWidget *parent)
    : QFrame(parent) {
    ui.setupUi(this);
    QStringList labels;
    labels << "x" << "y" << "z";
    ui.varPropTable->setColumnCount(3);
    ui.varPropTable->setRowCount(1);
    ui.varPropTable->setHorizontalHeaderLabels(labels);
}

QString FFTCrossVariogramDeclus::getWeigth() {
    return ui.weigth->currentText();
}

void FFTCrossVariogramDeclus::updateNumberVariograms(int nVariograms) {
    ui.varPropTable->setRowCount(nVariograms);
}


double FFTCrossVariogramDeclus::getX(int row, bool* ok) {
    if (ui.varPropTable->item(row, 0) == 0) return 0;
    return ui.varPropTable->item(row, 0)->text().toDouble(ok);
}

double FFTCrossVariogramDeclus::getY(int row, bool* ok) {
    if (ui.varPropTable->item(row, 1) == 0) return 0;
    return ui.varPropTable->item(row, 1)->text().toDouble(ok);
}

double FFTCrossVariogramDeclus::getZ(int row, bool* ok) {
    if (ui.varPropTable->item(row, 2) == 0) return 0;
    return ui.varPropTable->item(row, 2)->text().toDouble(ok);
}

void FFTCrossVariogramDeclus::checkCell(int x, int y) {
    bool ok = true;
    if (ui.varPropTable->item(x, y) == 0) {
        ui.varPropTable->item(x, y)->setText("0");
        return;
    }
    double v = ui.varPropTable->item(x, y)->text().toDouble(&ok);
    if (!ok) {
        ui.varPropTable->item(x, y)->setText("0");
    }
}

int FFTCrossVariogramDeclus::getNumberVariograms() {
    return ui.varPropTable->rowCount();
}

int FFTCrossVariogramDeclus::getNumberLags() {
    return ui.nLags->value();
}

int FFTCrossVariogramDeclus::getNumberThreads() {
    return ui.nThreads->value();
}

QStringList FFTCrossVariogramDeclus::getProperties1() {
    return ui.props1->selected_properties();
}

QStringList FFTCrossVariogramDeclus::getProperties2() {
    return ui.props2->selected_properties();
}

Geostat_grid* FFTCrossVariogramDeclus::getGrid() {
    return ui.grid->selected_grid_object();
}

FFTCrossVariogramDeclus::~FFTCrossVariogramDeclus() {
}

QPushButton* FFTCrossVariogramDeclus::getDisplayButton() {
    return ui.displayButton;
}

double FFTCrossVariogramDeclus::getDx() {
    return ui.dx->value();
}

double FFTCrossVariogramDeclus::getDy() {
    return ui.dy->value();
}

double FFTCrossVariogramDeclus::getDz() {
    return ui.dz->value();
}

