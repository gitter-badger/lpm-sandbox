/*
Implementa��o do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/

#ifndef __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_H___
#define __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_H___

#include "common.h"

#include <qstring.h>
#include <qstringlist.h>
#include <QFrame>

#include "ui_model_validation.h"

enum ModelValidationDirection {
    MV_DIR_X = 0,
    MV_DIR_Y = 1,
    MV_DIR_Z = 2
};

class ModelValidation : public QFrame {
    Q_OBJECT

  public:
    ModelValidation(QWidget *parent = 0);
    ~ModelValidation();

    int getNumberBins();
    int getNumberThreads();

    QPushButton* getDisplayButton();

    QStringList getProperties();
    QString getRefProp();
    Geostat_grid* getGrid();
    Geostat_grid* getRefGrid();

    Ui::ModelValidation& getUi() {
        return ui;
    }

    ModelValidationDirection getDirection();

  private:
    Ui::ModelValidation ui;
};

#endif

