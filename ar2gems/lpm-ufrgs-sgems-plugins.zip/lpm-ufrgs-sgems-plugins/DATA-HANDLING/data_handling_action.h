/*
Implementação do plugin que efetua transformações nos dados.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado & Luiz Gustavo Rasera
*/


#ifndef PLUGINS_LPM_UFRGS_DATA_HANDLING_ACTION_H_
#define PLUGINS_LPM_UFRGS_DATA_HANDLING_ACTION_H_

#include "common.h"

#include <common.h>
#include <appli/action.h> 
#include <grid/grid_property.h>
#include <grid/geostat_grid.h>
#include <utils/named_interface.h>


class PLUGINS_LPM_UFRGS_DECL DataHandling :  public Action 
{
	public: 
		static Named_interface* create_new_interface(std::string&);

		virtual ~DataHandling() {} 
		virtual bool init(std::string& parameters, GsTL_project* proj,
						  Error_messages_handler* errors = 0, Progress_notifier* notifier = 0); 
		virtual bool exec(Progress_notifier* notifier = 0); 


	private :
		
		double min_, max_, value_;	//caping parameters
		double tol_, const_;        //closure parameters

		int type, cap_type;
		Geostat_grid* grid_;
		
		std::vector<Grid_continuous_property*> grid_props_;
		
		Grid_continuous_property* log_geo_mean_grid_props_;

		std::vector<Grid_continuous_property*> result_grid_props_;
};

#endif // PLUGINS_LPM_UFRGS_DATA_HANDLING_ACTION_H_
