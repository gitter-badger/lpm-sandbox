/*
Implementa��o do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "accplotprocess.h"

#ifdef __linux

#include <unistd.h>

#elif _WIN32 || WIN32

#include <Windows.h>

#else
#include <unistd.h>

#endif

QMutex g_accplotprogress_mutex;

void global_accplotprogress_lock() {
    g_accplotprogress_mutex.lock();
}

void global_accplotprogress_unlock() {
    g_accplotprogress_mutex.unlock();
}

void accplotprogress_sleep(int time) {
    global_accplotprogress_lock();
#ifdef  __linux
    usleep(time * 1000);
#elif WIN32 || _WIN32
    Sleep(time);
#else
    usleep(time * 1000);
#endif
    global_accplotprogress_unlock();
}

/*

AccPlotProgressDialog Class implementation

*/

AccPlotProgressDialog::AccPlotProgressDialog(int number_steps, QWidget *parent)
    : QDialog(parent),
      current_step_(0),
      number_steps_(number_steps),
      is_paused_(false),
      is_running_(true),
      mutex_() {
    ui_.setupUi(this);
    ui_.progress->setRange(0, number_steps);
    ui_.progress->setValue(0);
    QObject::connect(
        this, SIGNAL(valueChanged(int)),
        ui_.progress, SLOT(setValue(int))
    );
    QObject::connect(
        this, SIGNAL(sendTextAppend(const QString&)),
        ui_.status, SLOT(append(const QString&))
    );
    QObject::connect(
        this, SIGNAL(sendText(const QString&)),
        ui_.status, SLOT(setText(const QString&))
    );
    this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowTitleHint);
}

AccPlotProgressDialog::~AccPlotProgressDialog() {
}

bool AccPlotProgressDialog::isPaused() {
    mutex_.lock();
    bool is_p = is_paused_;
    mutex_.unlock();
    if (is_p) {
        accplotprogress_sleep();
    }
    return is_p;
}

void AccPlotProgressDialog::nextStep() {
    mutex_.lock();
    ++current_step_;
    emit valueChanged(current_step_);
    mutex_.unlock();
}

void AccPlotProgressDialog::reset() {
    mutex_.lock();
    current_step_ = 0;
    emit valueChanged(0);
    mutex_.unlock();
}

void AccPlotProgressDialog::setStep(int step) {
    mutex_.lock();
    current_step_ = step;
    emit valueChanged(step);
    mutex_.unlock();
}

void AccPlotProgressDialog::setNumberSteps(int n) {
    mutex_.lock();
    ui_.progress->setRange(0, n);
    mutex_.unlock();
}

void AccPlotProgressDialog::setText(const QString& msg) {
    mutex_.lock();
    emit sendText(msg);
    mutex_.unlock();
}

void AccPlotProgressDialog::appendText(const QString& msg) {
    mutex_.lock();
    emit sendTextAppend(msg);
    mutex_.unlock();
}

void AccPlotProgressDialog::writeMsg(const QString& msg, bool append) {
    mutex_.lock();
    if (append) {
        emit sendTextAppend(msg);
    } else {
        emit sendText(msg);
    }
    mutex_.unlock();
}

void AccPlotProgressDialog::setPaused() {
    mutex_.lock();
    if (is_paused_) {
        is_paused_ = false;
        is_running_ = true;
        ui_.pause->setText("Pause");
    } else {
        is_paused_ = true;
        is_running_ = false;
        ui_.pause->setText("Resume");
    }
    mutex_.unlock();
}

void AccPlotProgressDialog::setRunning() {
    mutex_.lock();
    is_paused_ = false;
    is_running_ = true;
    ui_.pause->setText("Pause");
    mutex_.unlock();
}

void AccPlotProgressDialog::setDead() {
    mutex_.lock();
    is_paused_ = false;
    is_running_ = false;
    mutex_.unlock();
}

void AccPlotProgressDialog::lastMsg(const QString& msg) {
    mutex_.lock();
    emit finish(msg);
    mutex_.unlock();
}
/*

AccPlotProcess Class implementation

*/

AccPlotProcess::AccPlotProcess(
    AccPlotAction* action,
    AccPlotProgressDialog* notifier,
    int number_threads,
    int id_thread,
    bool is_master)
    :
    is_master_(is_master),
    id_thread_(id_thread),
    number_threads_(number_threads),
    action_(action),
    notifier_(notifier),
    ok_(true) {
    if (!notifier_) {
        notifier_ = new AccPlotProgressDialog;
    }
    if (is_master) {
        QObject::connect(
            notifier_->getUi().cancel,
            SIGNAL(clicked()),
            this, SLOT(killProcess())
        );
        for (int id = 0; id < number_threads_; ++id) {
            slaves_.push_back(new AccPlotProcess(action, notifier_, number_threads, id, false));
        }
    }
}


void AccPlotProcess::lock() {
    notifier_->lock();
}

void AccPlotProcess::unlock() {
    notifier_->unlock();
}

void AccPlotProcess::waitProcess() {
    if (is_master_)
        for (auto s : slaves_) {
            s->wait();
        }
}

AccPlotProcess::~AccPlotProcess() {
    if (is_master_) {
        for (auto s : slaves_) {
            delete s;
        }
        if (notifier_) {
            notifier_->close();
            delete notifier_;
        }
    }
}

void AccPlotProcess::killProcess() {
    ok_ = false;
    if (is_master_) {
        for (auto s : slaves_) {
            s->setOk(false);
        }
    }
}

void AccPlotProcess::run_master() {
    if (is_master_) {
        action_->run_master_process(this, number_threads_, slaves_);
    }
}

void AccPlotProcess::run_slaves() {
    action_->run_slave_process(this, id_thread_, number_threads_);
}

void AccPlotProcess::run() {
    if (is_master_) {
        action_->run_master_process(this, number_threads_, slaves_);
        for (auto s : slaves_) {
            s->start();
        }
        for (auto s : slaves_) {
            s->wait();
        }
        emit killMe(this);
    } else {
        action_->run_slave_process(this, id_thread_, number_threads_);
    }
}




