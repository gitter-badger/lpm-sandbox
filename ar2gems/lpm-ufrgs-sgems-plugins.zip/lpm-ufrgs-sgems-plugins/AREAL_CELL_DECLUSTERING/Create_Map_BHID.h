#ifndef CREATE_MAP_BHID_H
#define CREATE_MAP_BHID_H

# include <vector>
# include <map>
# include "Struct_Drillhole.h"

bool Create_Map_BHID (std::map<int, Struct_Drillhole > &Map_Drillhole, const std::vector<std::vector<double> > &data_vector);

	

#endif