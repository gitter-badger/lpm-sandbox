#ifndef __GTL_MAIN_HEADER_SIMULATION_H__
#define __GTL_MAIN_HEADER_SIMULATION_H__

#include <GsTL/simulation/sequential_simulation.h>
#include <GsTL/simulation/sequential_cosimulation.h>

#endif
