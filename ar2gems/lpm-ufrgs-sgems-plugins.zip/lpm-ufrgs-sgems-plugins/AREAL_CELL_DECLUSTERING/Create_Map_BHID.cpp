# include "Create_Map_BHID.h"
# include <vector>
# include <map>
# include "Struct_Drillhole.h"

using namespace std;

bool Create_Map_BHID (std::map<int, Struct_Drillhole > &Map_Drillhole, const std::vector<std::vector<double> > &data_vector) {
    for(size_t i = 0; i < data_vector.size(); ++i) {
        int BHID = data_vector[i][4];
        Struct_Drillhole  &Drillhole = Map_Drillhole[BHID];
        Drillhole.X_Locations.push_back(data_vector[i][0]);
        Drillhole.Y_Locations.push_back(data_vector[i][1]);
        Drillhole.Z_Locations.push_back(data_vector[i][2]);
        Drillhole.Grades.push_back(data_vector[i][3]);
        Drillhole.Node_ID.push_back(data_vector[i][5]);
        Drillhole.BHID = BHID;
    }
    map<int, Struct_Drillhole>::iterator it = Map_Drillhole.begin(), end = Map_Drillhole.end();
    for(map<int, Struct_Drillhole>::iterator it = Map_Drillhole.begin(), ed = Map_Drillhole.end(); it != end; ++it) {
        int ID = it->first;
        Struct_Drillhole &Drillhole = it->second;
        int N_Points = Drillhole.X_Locations.size();
        double sum_X = 0, sum_Y = 0, sum_Z = 0, sum_Grade = 0;
        int count;
        for(size_t i = 0; i < N_Points; ++i) {
            sum_X = sum_X + Drillhole.X_Locations[i];
            sum_Y = sum_Y + Drillhole.Y_Locations[i];
            sum_Z = sum_Z + Drillhole.Z_Locations[i];
            sum_Grade = sum_Grade + Drillhole.Grades[i];
        };
        Drillhole.X_Centroid = (sum_X/N_Points);
        Drillhole.Y_Centroid = (sum_Y/N_Points);
        Drillhole.Z_Centroid = (sum_Z/N_Points);
        Drillhole.Average = (sum_Grade/N_Points);
    }
    return true;
}