/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#ifndef PLUGINS_LPM_UFRGS_ALR_TRANSFORMATION_H_
#define PLUGINS_LPM_UFRGS_ALR_TRANSFORMATION_H_

#include "common.h"

#include <common.h>
#include <appli/action.h> 
#include <grid/grid_property.h>
#include <grid/geostat_grid.h>
#include <utils/named_interface.h>

class PLUGINS_LPM_UFRGS_DECL ALR_Transformation :  public Action 
{
	public: 
		static Named_interface* create_new_interface(std::string&);

		virtual ~ALR_Transformation() {} 
		virtual bool init(std::string& parameters, GsTL_project* proj,
						  Error_messages_handler* errors = 0, Progress_notifier* notifier = 0); 
		virtual bool exec(Progress_notifier* notifier = 0); 

		void set_pivot(std::string& name) {
			pivot_name = name;
		}

		void set_constant(const double& v) {
			closure_const = v;
		}

		void set_prop_name(std::string& name) {
			prop_name = name;
		}

	private :

		std::string prop_name;
	  Geostat_grid* grid_;
	  std::string pivot_name;
	  std::vector<Grid_continuous_property*> props_;
	  std::vector<Grid_continuous_property*> ALR_props_;
	  Grid_continuous_property* ALR_d;
	  std::vector<std::string> prop_names;

	  double closure_const;
};

#endif // PLUGINS_LPM_UFRGS_ALR_TRANSFORMATION_H_
