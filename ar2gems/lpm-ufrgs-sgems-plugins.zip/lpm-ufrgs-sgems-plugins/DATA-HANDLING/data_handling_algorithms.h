/*
Implementação do plugin que efetua transformações nos dados.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado & Luiz Gustavo Rasera
*/

#ifndef PLUGINS_LPM_UFRGS_DATA_HANDLING_ALGORITHMS_H_
#define PLUGINS_LPM_UFRGS_DATA_HANDLING_ALGORITHMS_H_

#include "common.h"

#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>
#include <grid/grid_property.h>
#include <grid/grid_region.h>
#include <grid/neighborhood.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>
#include <geostat/parameters_handler.h>


enum {
    CAP      = 1,
    CLOSURE  = 2,
    GEO_MEAN = 3
};

enum CapTypes {
    LOWER    = 1,
    UPPER    = 2,
    INSIDE   = 3,
    OUTSIDE  = 4
};

class DataHandlingAlgorithms : public Geostat_algo {
  public:
    DataHandlingAlgorithms();
    virtual ~DataHandlingAlgorithms();

    virtual bool initialize(const Parameters_handler* parameters,
                            Error_messages_handler* errors =0, Progress_notifier* notifier = 0 );

    virtual int execute(GsTL_project* proj=0, Progress_notifier* notifier = 0);

    virtual std::string name() const {
        return "data_handling";
    }

    static Named_interface* create_new_interface(std::string&);

  private :
    Error_messages_handler* errors_;
    std::string params;
    Named_interface* action_;
};



#endif // PLUGINS_LPM_UFRGS_DATA_HANDLING_ALGORITHMS_H_
