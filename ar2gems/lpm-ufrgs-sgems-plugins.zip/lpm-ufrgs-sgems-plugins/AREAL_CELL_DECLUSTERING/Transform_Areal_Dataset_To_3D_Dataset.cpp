

# include <vector>
# include <map>
# include "Struct_Drillhole.h"


std::vector<std::vector<double> > Transform_Areal_Dataset_To_3D_Dataset(std::map<int, Struct_Drillhole > &Map_Drillhole, const std::vector<double> &wopt, const std::vector<int> &bhid) {
    //Create Areal
    std::vector<std::vector<double> > Three_Dimensional_Dataset;
    std::map<int, Struct_Drillhole>:: const_iterator it;
    for (size_t i = 0; i < bhid.size(); ++i) {
        int bhid_int = bhid[i];
        double weight = wopt[i];
        Struct_Drillhole &Drillhole = Map_Drillhole[bhid_int];
        for(size_t j = 0; j < Drillhole.X_Locations.size(); ++j) {
            std::vector<double> row;
            row.push_back(Drillhole.X_Locations.at(j));
            row.push_back(Drillhole.Y_Locations.at(j));
            row.push_back(Drillhole.Z_Locations.at(j));
            row.push_back(Drillhole.Grades.at(j));
            row.push_back(bhid_int);
            row.push_back(Drillhole.Node_ID.at(j));
            row.push_back(weight);
            Three_Dimensional_Dataset.push_back(row);
        }
    }
    return Three_Dimensional_Dataset;
}