/*
Implementação do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/



#ifndef __PLUGINS_LPM_UFRGS_HISTOGRAMGRAPHOUT_H___ 
#define __PLUGINS_LPM_UFRGS_HISTOGRAMGRAPHOUT_H___

#include "common.h"

#include <qstring.h>
#include <qstringlist.h>
#include <QFrame>

#include "ui_histgraphout.h"

class HistogramGraphOutput : public QFrame
{
	Q_OBJECT

public:
	HistogramGraphOutput(QWidget *parent = 0);
	~HistogramGraphOutput();

	Ui::HistogramGraphOutput& getUI() { return ui; }
private:
	Ui::HistogramGraphOutput ui;
};

#endif
