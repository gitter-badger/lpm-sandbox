/*
Implementação do plugin que realiza o moving window.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/

#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <map>

#include "moving_window_action.h"

#include <utils/string_manipulation.h>
#include <grid/utilities.h>

#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>

#include <grid/point_set.h>
#include <grid/cartesian_grid.h>
#include <grid/grid_property_manager.h>
#include <grid/point_set_neighborhood.h>
#include <grid/geovalue.h>
#include <utils/string_manipulation.h>
#include <math/random_numbers.h>

#include <GsTL/math/math_functions.h>

#include <algorithm>

#include <grid/point_set.h>

using namespace std;

Named_interface* MovingWindow::create_new_interface( std::string& )
{
	return new MovingWindow;
}


bool create_new_grid(std::string& grid_name_, GsTL_project* proj_, Error_messages_handler* errors_, int Nps) {
	std::string full_name( "/GridObject/Model/" + grid_name_);
	SmartPtr<Named_interface> ni =
	//Root::instance()->new_interface("cgrid://"+grid_name_, full_name);
	Root::instance()->new_interface("point_set://"+grid_name_+"::"+LPM_UFRGS::to_string(Nps), full_name);

	if( ni.raw_ptr() == 0 ) {
		errors_->report("output_grid_name", "Object " + full_name + " already exists. Use a different name." );
		//    appli_warning( "object " << full_name << "already exists" );
		return false;
	}

    if (proj_) proj_->new_object( grid_name_ );

	return true;
}

// ResourceClassification gridName::res_prop::prop1::prop2[::prop3::propN]
bool MovingWindow::init(std::string& parameters, GsTL_project* proj, Error_messages_handler* errors, Progress_notifier* notifier)
{
	this->proj_ = proj;
	this->errors_ = errors;

	std::vector<std::string> params = String_Op::decompose_string(parameters, Actions::separator, Actions::unique);

	std::string grid_input_name = params[0];

	if (grid_input_name.size() < 1) {
		return false;
	}

	std::string prop_name = params[1];
	
	if (prop_name.size() < 1) {
		return false;
	}

	grid_output_name = params[2];

	if (grid_output_name.size() < 1) {
		return false;
	}
	
	dx = String_Op::to_number<double>(params[3]);
	dy = String_Op::to_number<double>(params[4]);
	dz = String_Op::to_number<double>(params[5]);

	x_size = String_Op::to_number<double>(params[6]);
	y_size = String_Op::to_number<double>(params[7]);
	z_size = String_Op::to_number<double>(params[8]);

	if (dx < 1e-8 || dy < 1e-8 || dz < 1e-8 ||
		x_size < 1e-8 || y_size < 1e-8 || z_size < 1e-8) {
		return false;
	}


	this->grid_input_ = get_grid_from_manager(grid_input_name);

	if (!this->grid_input_) {
		return false;
	}


	this->grid_prop_ = this->grid_input_->property(prop_name);

	if (!this->grid_prop_) {
		return false;
	}

	return true;
}

typedef Const_geovalue::location_type loc_point;

bool MovingWindow::exec(Progress_notifier* notifier) {
	
	size_t N = this->grid_prop_->size();
	std::vector<double> data(N);
	std::vector<Const_geovalue::location_type> loc(N), ans_loc;

	double xmin, xmax, ymin, ymax, zmin, zmax;

	xmin = xmax = this->grid_input_->xyz_location(grid_input_->node_id(0)).x();
	ymin = ymax = this->grid_input_->xyz_location(grid_input_->node_id(0)).y();
	zmin = zmax = this->grid_input_->xyz_location(grid_input_->node_id(0)).z();
	
	for (size_t i = 0; i < N; ++i) {
		if (!grid_prop_->is_informed(i)) continue;
		data[i] = grid_prop_->get_value(i);
		loc[i] = this->grid_input_->xyz_location(grid_input_->node_id(i));

		if (loc[i].x() > xmax) {
			xmax = loc[i].x();
		}

		if (loc[i].y() > ymax) {
			ymax = loc[i].y();
		}

		if (loc[i].y() > zmax) {
			zmax = loc[i].z();
		}

		if (loc[i].x() < xmin) {
			xmin = loc[i].x();
		}

		if (loc[i].y() < ymin) {
			ymin = loc[i].y();
		}

		if (loc[i].z() < zmin) {
			zmin = loc[i].z();
		}
	}

	double Lx = xmax - xmin + 1;
	double Ly = ymax - ymin + 1;
	double Lz = zmax - zmin + 1;

	int nx = static_cast<int>(ceil(Lx / dx));
	int ny = static_cast<int>(ceil(Ly / dy));
	int nz = static_cast<int>(ceil(Lz / dy));
	int M = nx + ny + nz;

	map<int, double> acc;
	map<int, double> mean;
	map<int, double> var;
	map<int, int> cnt;
	map<loc_point, double> m_pm, v_pm;


	for (int i = 0; i < N; ++i) {
		if (!grid_prop_->is_informed(i)) continue;

		double x = loc[i].x();
		double y = loc[i].y();
		double z = loc[i].z();

		int px = static_cast<int>(ceil((x - xmin) / dx));
		int py = static_cast<int>(ceil((y - ymin) / dy));
		int pz = static_cast<int>(ceil((z - zmin) / dz));

		for (int ix = px; ix > -1 && (px - ix) * dx < x_size; --ix) 
			for (int iy = py; iy > -1 && (py - iy) * dy < y_size; --iy) 
				for (int iz = pz; iz > -1 && (pz - iz) * dz < z_size; --iz) {
					int P = ix * M * M + iy * M + iz;

					if (acc.find(P) == acc.end()) {
						acc[P] = data[i];
						cnt[P] = 1;
					} else {
						acc[P] += data[i];
						++cnt[P];
					}
				}
	}

	/*Calculate mean*/
	for (map<int, double>::iterator it = acc.begin(); it != acc.end(); ++it) {
		int p = it->first;
		double& v = it->second;
		int n = cnt[p];

		mean[p] = v / n;
	}

	/*Calculate variance*/
	for (int i = 0; i < N; ++i) {
		if (!grid_prop_->is_informed(i)) continue;
		double x = loc[i].x();
		double y = loc[i].y();
		double z = loc[i].z();

		int px = static_cast<int>(ceil((x - xmin) / dx));
		int py = static_cast<int>(ceil((y - ymin) / dy));
		int pz = static_cast<int>(ceil((z - zmin) / dz));

		for (int ix = px; ix > -1 && (px - ix) * dx < x_size; --ix) 
			for (int iy = py; iy > -1 && (py - iy) * dy < y_size; --iy)
				for (int iz = pz; iz > -1 && (pz - iz) * dz < z_size; --iz) {
					int P = ix * M * M + iy * M + iz;
					if (var.find(P) == var.end()) {
						double v = data[i] - mean[P];
						var[P] = v * v / cnt[P];
					} else {
						double v = data[i] - mean[P];
						var[P] += v * v / cnt[P];
					}
				} 
				
	}
	
	for (map<int, double>::iterator it = acc.begin(); it != acc.end(); ++it) {
		int p = it->first;

		loc_point my_p;
		int iz = p % M;
		int iy = ((p - iz) % (M*M)) / M;
		int ix = (p - iy * M - iz) / (M*M);
		
		my_p.x() = (2 * ix + 1) * 0.5 * dx + xmin;
		my_p.y() = (2 * iy + 1) * 0.5 *dy + ymin;
		my_p.z() = (2 * iz + 1) * 0.5 *dz + zmin;

		m_pm[my_p] = mean[p];
		v_pm[my_p] = var[p];
		ans_loc.push_back(my_p);
	}

	size_t Nps = ans_loc.size();

	create_new_grid(grid_output_name, proj_, errors_, Nps);
	this->grid_output_ = get_grid_from_manager(grid_output_name);

	if (!this->grid_output_) {
		return false;
	}

	Point_set* ps = dynamic_cast<Point_set*>(this->grid_output_);

	ps->point_locations(ans_loc);

	ps->add_property("mean");
	ps->add_property("variance");

	this->grid_mean_ = ps->property("mean");

	if (!this->grid_mean_) {
		return false;
	}

	this->grid_var_ = ps->property("variance");

	if (!this->grid_var_) {
		return false;
	}

	for (size_t i = 0; i < Nps; ++i) {
		loc_point my_p = ps->xyz_location(ps->node_id(i));
		double m = m_pm[my_p];
		double v = v_pm[my_p];

		this->grid_mean_->set_value(m, ps->node_id(i));
		this->grid_var_->set_value(v, ps->node_id(i));
	}


	return true;
}

