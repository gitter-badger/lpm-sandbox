/*
Implementa��o do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "histogram_chart_creator.h"
#include "histogram_chart.h"
#include "histgraphout.h"
#include "histreport.h"

#include <qfiledialog.h>

#include <cmath>

#include <utils/string_manipulation.h>

#include <vtkAxis.h>
#include <vtkPlotLine.h>
#include <vtkPlotPoints.h>
#include <vtkPlotPie.h>
#include <vtkPlotBar.h>
#include <vtkIntArray.h>
#include <vtkFloatArray.h>
#include <vtkDoubleArray.h>
#include <vtkColorSeries.h>
#include <vtkTextProperty.h>

#define INF 1e9

Histogram_chart::Histogram_chart(
    LPMHistogram* my_histogram,
	QWidget *parent)
	: 
	HistogramAction(),
	Chart_base(parent), 
	my_histogram_(my_histogram)
{
	HistogramGraphOutput* gout = new HistogramGraphOutput(this);
	gout_ = gout;
	my_process_handler_ = 0;
	dv_ = INF;
	table_histogram_ = 0;
	is_ok = false;
	
	n_bins_ = my_histogram_->getNumberBins();

	grid_ = my_histogram_->getGrid();
	props_names_ = my_histogram_->getProperties();
	histograms_.resize(props_names_.size());


	this->hide();
}

void Histogram_chart::run_master_process(HistogramProcess* process_handler, int number_threads, std::vector<HistogramProcess*>& slaves)
{
	if (process_handler->isOk()) {
		process_handler->getNotifier()->appendText("Creating histograms...\n");
		this->my_process_handler_ = process_handler;
	}
}

void Histogram_chart::run_slave_process(HistogramProcess* process_handler, int id_thread, int number_threads)
{
	if (process_handler->isOk()) {
		build_histograms(id_thread, number_threads);
	}
}


void Histogram_chart::repaint_chart(const QString& in)
{
	if (is_ok) {
		this->build_value_table();
		this->build_plot();
	}
}


void Histogram_chart::build_value_table()
{	
	table_histogram_ = vtkSmartPointer<vtkTable>::New();

	QStringList& props = props_names_;
	
	vtkSmartPointer<vtkFloatArray> index_histogram = vtkSmartPointer<vtkFloatArray>::New();
	std::vector<vtkSmartPointer<vtkFloatArray> > values(props.size());
	
	std::vector<Points> vars(props.size());
	std::map<int, std::vector<double> > hists;

	for (int i = 0; i < props.size(); ++i) {
		values[i] = vtkSmartPointer<vtkFloatArray>::New();

		Points& pts = histograms_[i];

		for (int k = 0; k < pts.size(); ++k) {
			if (hists[static_cast<int>(pts[k].x / dv_)].size() < props.size()) 
				hists[static_cast<int>(pts[k].x / dv_)] = std::vector<double>(props.size(), 0);
			hists[static_cast<int>(pts[k].x / dv_)][i] = pts[k].y;
		}
	}

	index_histogram->SetName("Value");
	index_histogram->SetNumberOfValues(hists.size());

	for (int i = 0; i < values.size(); ++i) {
		QString name;
		QTextStream in(&name);

		in << "Histogram  [ " << props[i] << " ]";

		values[i]->SetName(name.toStdString().c_str());
		values[i]->SetNumberOfValues(hists.size());
	}

	std::map<int, std::vector<double> >::iterator it = hists.begin(), ed = hists.end();

	int idx = 0;
	std::vector<double> last_value(props.size(), 0);
	while (it != ed) {
		index_histogram->SetValue(idx, it->first * dv_);
		std::vector<double>& v = it->second;

		for (int i = 0; i < v.size(); ++i) {
			if (v[i] > last_value[i]) {
				last_value[i] = v[i];
			} else {
				v[i] = last_value[i];
			}
			values[i]->SetValue(idx, v[i]);
		}

		++it;
		++idx;
	}
	
	table_histogram_->AddColumn(index_histogram);
	for (int i = 0; i < values.size(); ++i) {
		table_histogram_->AddColumn(values[i]);
	}

	this->table_histogram_view_->SetRepresentationFromInput(table_histogram_);
	this->table_histogram_view_->Update();
}


void Histogram_chart::build_histogram(Points& pts,  int i)
{
	Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());

	std::map<int, double> hist;
	double acc = 0;
	bool is_first = true;
	double vmin = 0, vmax = 0;
	
	
	for (int p = 0; p < prop->size(); ++p) {
		if (prop->is_informed(p)) {
			double v = prop->get_value(p);
			if (fabs(v) < INF) {
				if (is_first) {
					is_first = false;
					vmin = vmax = v;
				}
				else if (v > vmax) {
					vmax = v;
				}
				else if (v < vmin) {
					vmin = v;
				}
			}
		}
	}
	
	double dv =  (vmax - vmin) / n_bins_;
	
	for (int p = 0; p < prop->size(); ++p) {
		if (prop->is_informed(p)) {
			double v = prop->get_value(p);
			if (fabs(v) < INF) {
				++hist[static_cast<int>(v / dv)];
			}
		}
	}
	
	std::map<int, double>::iterator it = hist.begin(), ed = hist.end();
	acc = 0;
	while (it != ed) {
		double v = it->second;
		it->second += acc;
		acc += v;
	
		++it;	
	}

	it = hist.begin();
	ed = hist.end();
	while (it != ed) {
		it->second /= acc;
		
		pts.push_back(Point(it->first * dv, it->second));
		++it;
	}

	mutex.lock();
	if (dv < dv_) dv_ = dv;
	mutex.unlock();
}

void Histogram_chart::build_histograms(int id, int n_threads)
{
	for (int i = id; i < props_names_.size(); i += n_threads) {
		if (this->my_process_handler_) {
			if (!this->my_process_handler_->isOk()){
				return;
			}

			if (this->my_process_handler_->getNotifier()->isPaused()) {
				my_process_handler_->getNotifier()->appendText("Paused...");
				while (this->my_process_handler_->getNotifier()->isPaused()) {
				}
			}
		}

		Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());

		if (my_process_handler_) my_process_handler_
			->getNotifier()
			->appendText("Creating histogram to property <" + 
			props_names_[i] +  ">");

		Points pts;
		build_histogram(pts,  i);
		histograms_[i] = pts;
		
		if (my_process_handler_) my_process_handler_->getNotifier()->nextStep();
	}
}


void Histogram_chart::clear_chart()
{
	chart_histogram_widget_->chart()->ClearPlots();
}

void Histogram_chart::build_plot()
{
	for (int i = 1; i < table_histogram_->GetNumberOfColumns(); ++i) {

		if (gout_->getUI().line->isChecked()) {
			vtkPlotLine* plot_hist = vtkPlotLine::SafeDownCast(chart_histogram_widget_->chart()->AddPlot(vtkChart::LINE));

			plot_hist->SetInputData(table_histogram_, 0, i);
			plot_hist->SetColor(1.0, 0.0, 0.0);
		}

		if (gout_->getUI().point->isChecked()) {
			vtkPlotPoints* plot_hist = vtkPlotPoints::SafeDownCast(chart_histogram_widget_->chart()->AddPlot(vtkChart::POINTS));

			plot_hist->SetInputData(table_histogram_, 0, i);
			plot_hist->SetColor(1.0, 0.0, 0.0);
		}	
	}

	chart_histogram_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Histogram");
	chart_histogram_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle("Value");

	//chart_histogram_widget_->chart()->SetAutoAxes(true);
	chart_histogram_widget_->chart()->SetVisible(true);
	chart_histogram_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));
	chart_histogram_widget_->chart()->Update();

	chart_histogram_widget_->update();
}

void Histogram_chart::build_histogram_chart()
{
	if (grid_ == 0) return;
	if (props_names_.size() == 0) return;

	QString title = QString(histogram_charts_name).arg(grid_->name().c_str());

	this->setWindowTitle(title);
	this->setWindowIcon(QPixmap(":/icons/appli/Pixmaps/ar2gems-icon-256x256.png"));

	chart_histogram_widget_ = new Chart_widget(this);
	chart_histogram_control_ = new Chart_display_control( chart_histogram_widget_ );
	chart_histogram_widget_->set_controler(chart_histogram_control_);

	table_histogram_view_ = vtkSmartPointer<vtkQtTableView>::New();

	QVBoxLayout* histogram_layout = new QVBoxLayout(this);

	histogram_layout->addWidget(gout_); 
	this->setLayout(histogram_layout);
	
	ok = connect(gout_->getUI().line, SIGNAL(clicked()), this, SLOT(build_plot()));
	ok = connect(gout_->getUI().point, SIGNAL(clicked()), this, SLOT(build_plot()));

	this->build_value_table();
	this->build_plot();

	QTableView* table_histogram = dynamic_cast<QTableView*>(table_histogram_view_->GetWidget());
	qtable_histogram_ = table_histogram;

	ok = connect(
		table_histogram, SIGNAL(clicked(const QModelIndex &)), 
		this, SLOT(cutoff_selected(const QModelIndex &)));

	gout_->getUI().graphViewer->addWidget(chart_histogram_widget_);
	gout_->getUI().graphControl->addWidget(chart_histogram_control_);
	gout_->getUI().tabWidget->addTab(table_histogram, "Data");

	ok = connect(gout_->getUI().saveFigureButton, SIGNAL(clicked()), chart_histogram_widget_, SLOT(save_figure()));
	ok = connect(gout_->getUI().saveReportButton, SIGNAL(clicked()), this, SLOT(save_report()));
	ok = connect(gout_->getUI().viewReportButton, SIGNAL(clicked()), this, SLOT(view_report()));
	ok = connect(gout_->getUI().clear, SIGNAL(clicked()), this, SLOT(clear_chart()));
	ok = connect(gout_->getUI().importGraphsButton, SIGNAL(clicked()), this, SLOT(import_graphs()));

	is_ok = true;
	this->show();
	
}

void Histogram_chart::save_report()
{
	QString fileName = QFileDialog::getSaveFileName(this, tr("Save File"),
		"report.csv",
		tr("CSV Files (*.csv)"));

	if (fileName.size() > 0) {
		QString msg;
		QTextStream output(&msg);

		write_table_histogram(output);

		FILE* fout = fopen(fileName.toStdString().c_str(), "w+");
		fprintf(fout, "%s\n", msg.toStdString().c_str());
		fclose(fout);
	}
}

void Histogram_chart::view_report()
{
	HistogramReport* report = new HistogramReport(0);
	QString msg;
	QTextStream output(&msg, QIODevice::WriteOnly);

	write_table_histogram(output);

	report->setText(msg);
	report->show();
}

void Histogram_chart::write_table_histogram(QTextStream& out)
{
	int nr = this->table_histogram_->GetNumberOfRows();
	int nc = this->table_histogram_->GetNumberOfColumns();

	for (int i = 0; i < nc; ++i) {
		if (i > 0) out << ", ";

		out << "\"" << QString(this->table_histogram_->GetColumnName(i)) << "\"";
	}
	out << "\n";

	for (int j = 0; j < nr; ++j) {
		for (int k = 0; k < nc; ++k) {
			if (k > 0) out << ", ";

			out << this->table_histogram_->GetValue(j, k).ToDouble();
		}
		out << "\n";
	}
}


void Histogram_chart::import_graphs()
{
	QString file_name = QFileDialog::getOpenFileName(this, "Import graphs", "", tr("CSV Files (*.csv)"));

	if (file_name == "") return;

	std::ifstream fin(file_name.toStdString().c_str());

	if (fin.fail()) return;

	bool is_first = true;

	std::vector<std::string> titles;
	std::vector<std::vector<double> > data;

	size_t min_size = 0;
	while (!fin.eof()) {

		std::string line;
		std::getline(fin, line);

		std::vector<std::string> values = String_Op::decompose_string(line, ",");

		if (is_first) {
			is_first = false;
			titles = values;
			data.resize(values.size());
		}
		else {
			for (int i = 0; i < std::min(values.size(), data.size()); ++i) {
				double v = String_Op::to_number<double>(values[i]);
				data[i].push_back(v);
			}
		}
	}

	for (int i = 0; i < data.size(); ++i) {
		if (i == 0) {
			min_size = data[i].size();
		}
		else {
			min_size = std::min(min_size, data[i].size());
		}
	}

	std::vector<vtkSmartPointer<vtkFloatArray> > values(titles.size());
	vtkSmartPointer<vtkTable> table_values = vtkSmartPointer<vtkTable>::New();

	for (int i = 0; i < titles.size(); ++i) {
		values[i] = vtkSmartPointer<vtkFloatArray>::New();
		values[i]->SetName(titles[i].c_str());
		values[i]->SetNumberOfValues(min_size);
		for (int j = 0; j < min_size; ++j) {
			values[i]->SetValue(j, data[i][j]);
		}
		table_values->AddColumn(values[i]);
	}


	for (int i = 1; i < table_values->GetNumberOfColumns(); ++i) {

		if (gout_->getUI().line->isChecked()) {
			vtkPlotLine* plot_variog = vtkPlotLine::SafeDownCast(chart_histogram_widget_->chart()->AddPlot(vtkChart::LINE));

			plot_variog->SetInputData(table_values, 0, i);
			plot_variog->SetColor(0.0, 0.0, 1.0);
		}

		if (gout_->getUI().point->isChecked()) {
			vtkPlotPoints* plot_variog = vtkPlotPoints::SafeDownCast(chart_histogram_widget_->chart()->AddPlot(vtkChart::POINTS));

			plot_variog->SetInputData(table_values, 0, i);
			plot_variog->SetColor(0.0, 0.0, 1.0);
		}
	}

	fin.close();
	chart_histogram_widget_->update();
}
