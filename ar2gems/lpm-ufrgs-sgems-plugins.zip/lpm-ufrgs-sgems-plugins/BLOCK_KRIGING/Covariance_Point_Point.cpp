# include "Covariance_Point_Point.h"
# include <math.h>
#include <grid/geostat_grid.h>
#include <GsTL/geometry/covariance.h>
#include <geostat/kriging.h>

 typedef Geostat_grid::location_type Location; 
 

double Covariance_Point_Point( Geostat_grid *point_i_grid, const int &node_id_point_i, Geostat_grid *point_j_grid, const int &node_id_point_j, const  Two_point_nested_structure &covar_){
	
	double cova_point_point = -99;
	cova_point_point = covar_(point_i_grid->xyz_location(node_id_point_i),point_j_grid->xyz_location(node_id_point_j));
		

	return cova_point_point;
}
