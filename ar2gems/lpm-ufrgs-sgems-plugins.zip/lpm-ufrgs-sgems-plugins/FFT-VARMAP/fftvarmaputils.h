/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_FFTVARMAPUTILS_H___
#define __PLUGINS_LPM_UFRGS_FFTVARMAPUTILS_H___

#include <appli/utilities.h>

#include <grid/utilities.h>
#include <grid/geostat_grid.h>
#include <grid/combined_neighborhood.h>
#include <grid/gval_iterator.h>
#include <grid/cartesian_grid.h>
#include <grid/point_set.h>
#include <grid/grid_path.h>

#include <vector>

#include "fftvarmapcalc.h"

class At {
  public:
    At(int nx, int ny, int nz)
        : nx(nx), ny(ny), nz(nz) {
    }

    int operator()(int ix, int iy, int iz) {
        return (ix * ny + iy) * nz + iz;
    }

  private:
    int nx, ny, nz;
};

struct Point {
    double x, y;
    Point(double x = 0, double y = 0)
        : x(x), y(y) {}
};

struct GeometryData {
    int nx, ny, nz;
    double dx, dy, dz;
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;

    GeometryData(
        int nx = 0, int ny = 0, int nz = 0,
        double dx = 0, double dy = 0, double dz = 0,
        double xmin = 0, double ymin = 0, double zmin = 0,
        double xmax = 0, double ymax = 0, double zmax = 0)
        :
        nx(nx), ny(ny), nz(nz),
        dx(dx), dy(dy), dz(dz),
        xmin(xmin), ymin(ymin), zmin(zmin),
        xmax(xmax), ymax(ymax), zmax(zmax) {
    }

};

typedef std::vector<Point> Points;

bool process_grid(
    std::vector<double>& data,
    std::vector<int>& has_point,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x = false, bool inv_y = false, bool inv_z = false
);

////////////////////////////////////////////////////////////////////////
bool compute_variogram(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap = 0,
    VarOut* varmap_out = 0,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_varmap(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_varmap(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_varmap(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);


////////////////////////////////////////////////////////////////////////
bool compute_covariogram(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap = 0,
    VarOut* varmap_out = 0,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_covarmap(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_covarmap(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_covarmap(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);

////////////////////////////////////////////////////////////////////////
bool compute_variogram_declus(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* weigth,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap = 0,
    VarOut* varmap_out = 0,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_varmap_declus(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* weigth,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_varmap_declus(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* weigth,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_varmap_declus(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* weigth,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool compute_crosscovariogram(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap = 0,
    VarOut* varmap_out = 0,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crosscovarmap(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crosscovarmap(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crosscovarmap(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);

////////////////////////////////////////////////////////////////////////
bool compute_crossvariogram(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap = 0,
    VarOut* varmap_out = 0,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crossvarmap(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crossvarmap(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crossvarmap(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);


////////////////////////////////////////////////////////////////////////
bool compute_crossvariogram_declus(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* weigth1,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap = 0,
    VarOut* varmap_out = 0,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crossvarmap_declus(
    Geostat_grid* input_grid,
    Grid_continuous_property* weigth1,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crossvarmap_declus(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* weigth1,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo = 0,
    bool use_geo = false
);

bool compute_crossvarmap_declus(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* weigth1,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x = false, bool inv_y = false, bool inv_z = false,
    GeometryData* geo = 0,
    bool use_geo = false);

#endif

