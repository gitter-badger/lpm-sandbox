/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_FFTVARIOGRAM_CHART_H___
#define __PLUGINS_LPM_UFRGS_FFTVARIOGRAM_CHART_H___

#include "common.h"

#include <charts/chart_base.h>
#include <charts/chart_widget.h>
#include <charts/chart_display_control.h>
#include <grid/grid_property.h>
#include <grid/grid_weight_property.h>
#include <grid/grid_filter.h>

#include <gui/variogram2/variogram_controls.h>

#include <vtkQtTableView.h>
#include <vtkSmartPointer.h>
#include <vtkLookupTable.h>
#include <vtkChartPie.h>

#include <QModelIndex>
#include <QLabel>
#include <qtextstream.h>
#include <qfiledialog.h>

#include <vector>
#include <map>

#include "fftvariogram.h"
#include "fftcrossvariogram.h"
#include "fftcrossvariogram_declus.h"
#include "fftvariogram_declus.h"
#include "fftgraphout.h"
#include "fftvarmaputils.h"
#include "fftprocess.h"

enum FFTVariogram_types {
    FFTVARIOGRAM              = 0,
    FFTVARIOGRAM_DECLUS       = 1,
    FFTCROSSVARIOGRAM         = 2,
    FFTCROSSVARIOGRAM_DECLUS  = 3,
    FFTCORRELOGRAM            = 4
};

enum FFTOperation_type {
    CALC_VARMAP = 0,
    CALC_VARIOGRAM = 1,
    CALC_CORRELOGRAM = 2
};

static const char* variogram_charts_names[] = {
    "Variogram",
    "Variogram Declustered",
    "CrossVariogram",
    "CrossVariogram Declustered",
    "Correlogram"
};


typedef std::pair<std::string, Point3D> Variogram_desc;

class PLUGINS_LPM_UFRGS_DECL FFTVariogram_chart : public Chart_base, public FFTAction {
    Q_OBJECT

  public:
    int getNMaps() {
        return n_maps_;
    }
    void set_ok(bool ok) {
        is_ok = ok;
    }

    void run_master_process(FFTProcess* process_handler, int number_threads, std::vector<FFTProcess*>& slaves);
    void run_slave_process(FFTProcess* process_handler, int id_thread, int number_threads);

    explicit FFTVariogram_chart(
        FFTVariogram* my_variogram,
        QWidget *parent = 0);

    FFTVariogram_chart(
        FFTCrossVariogram* my_crossvariogram,
        QWidget *parent = 0);

    FFTVariogram_chart(
        FFTCrossVariogramDeclus* my_crossvariogram_declus,
        QWidget *parent = 0);

    FFTVariogram_chart(
        FFTVariogramDeclus* my_variogram_declus,
        QWidget *parent = 0);

    ~FFTVariogram_chart() {
    }

  public slots:
    void build_variogram_chart();

    void repaint_chart(const QString& in);
    void clear_chart();

    void save_report();
    void view_report();

    void build_value_table();
    void build_plot();

    void build_varmaps(int id, int n_threads);
    void build_crossvarmaps(int id, int n_threads);
    void build_crossvarmaps_declus(int id, int n_threads);
    void build_varmaps_declus(int id, int n_threads);

    void import_graphs();
    void import_model();

  private:

    void init_varmaps();
    void build_variogram(Points& pts, const Point3D& dir, FFTVariogram_types chart_type_, VarOut* varmap, int i);

    void build_variogram(Points& pts, const Point3D& dir, VarOut* varmap, int i);
    void build_crossvariogram(Points& pts, const Point3D& dir, VarOut* varmap, int i);
    void build_crossvariogram_declus(Points& pts, const Point3D& dir, VarOut* varmap, int i);
    void build_variogram_declus(Points& pts, const Point3D& dir, VarOut* varmap, int i);

    void build_varmaps(FFTVariogram_types chart_type_, int id, int n_threads);

    GraphOutput* gout_;

    FFTVariogram_types chart_type_;

    union {
        FFTVariogram* my_variogram_;
        FFTCrossVariogram* my_crossvariogram_;
        FFTCrossVariogramDeclus* my_crossvariogram_declus_;
        FFTVariogramDeclus* my_variogram_declus_;
    };

    Chart_widget* chart_variogram_widget_;

    Chart_display_control* chart_variogram_control_;

    vtkSmartPointer<vtkTable> table_variogram_;
    vtkSmartPointer<vtkQtTableView> table_variogram_view_;
    QTableView* qtable_variogram_;

    void write_table_variogram(QTextStream& out);

    std::vector<Point3D> variograms_dirs_;
    std::map<std::string, Point3D> directions_;

    std::vector<Variogram_desc> varmaps_[2][2][2];
    std::map<std::string, std::vector<Points> > variograms_;

    bool is_ok;

    QStringList props_names_;
    QStringList props_names2_;
    Geostat_grid* grid_;
    QString weight_;

    double dx_, dy_, dz_;
    int n_lags_;
    int n_maps_;
    FFTProcess* my_process_handler_;

    bool use_geo_;
    GeometryData geo_;

    bool compute_variogram_;
    bool compute_covariance_;
    bool compute_crossvariogram_;
    bool compute_crosscovariance_;
};

#endif
