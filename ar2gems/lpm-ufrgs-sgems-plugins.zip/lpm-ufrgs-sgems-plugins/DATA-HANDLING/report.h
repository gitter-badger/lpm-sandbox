/*
Implementação do plugin que efetua transformações nos dados.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado & Luiz Gustavo Rasera
*/

#ifndef DATA_HANDLING_REPORT_H_
#define DATA_HANDLING_REPORT_H_

#include "common.h"
#include <QDialog>
#include <QMainWindow>
#include <QCloseEvent>
#include <ui_report.h>


class DataHandling_report : public QDialog
{
	Q_OBJECT

public:
	DataHandling_report(QWidget *parent = 0);
	~DataHandling_report();

	void setReport(const QString& text) {
		this->ui.report_text->setText(text);
	}

private:

	Ui::Report ui;
};

#endif /* DATA_HANDLING_REPORT_H_ */
