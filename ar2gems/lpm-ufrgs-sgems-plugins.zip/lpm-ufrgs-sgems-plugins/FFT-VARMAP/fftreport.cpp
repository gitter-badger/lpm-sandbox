/*
Implementação do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, Péricles Lopes Machado
*/


#include "fftreport.h"

FFT_report::FFT_report(QWidget *parent):QDialog(parent) {
    ui.setupUi(this);
    self = 0;
    QObject::connect(this,
                     SIGNAL(setText(QString)),
                     this,
                     SLOT(setReport(QString)),
                     Qt::QueuedConnection
                    );
}

FFT_report::~FFT_report() {
}
