# include "Covariance_Point_Point.h"
# include "Covariance_Point_Block.h"
# include <vector>

using namespace std;

std::vector<double> Build_RHS_Covariance_Matrix(Geostat_grid *Point_samples_grid, Geostat_grid *Point_u_grid, const std::vector<std::vector<double> > &samples, std::vector<std::vector<double> > &Point_To_Block_Covariance_Lookup_Table, vector<int> &block_ids, const Two_point_nested_structure &covar_, const int &kriging_option, int &node_id_point_u) {
    vector<double> RHS_Covariance_Matrix; // Define the matrix which will receive the covariances
    // Add Covariance Point_Sample_Point_to_be_estimated
    int Number_Of_Samples = samples.size();
    int Number_Of_Blocks = block_ids.size();
    for(size_t i = 0; i < (Number_Of_Samples + Number_Of_Blocks); ++i) {
        if(i < Number_Of_Samples) { //Calculate covariance point_sample_point_to_be_estimated
            double covariance_point_sample_point_to_be_estimated = Covariance_Point_Point(Point_samples_grid, samples[i][4], Point_u_grid, node_id_point_u, covar_);
            RHS_Covariance_Matrix.push_back(covariance_point_sample_point_to_be_estimated);
        } else { //Calculate covariance block_sample_point_to_be_estimated
            int point_node_id = node_id_point_u;
            int Block_indice_i = i - Number_Of_Samples;
            int block_node_id = block_ids[Block_indice_i];
            double covariance_point_to_be_estimated_block = Point_To_Block_Covariance_Lookup_Table[point_node_id][block_node_id];
            RHS_Covariance_Matrix.push_back(covariance_point_to_be_estimated_block);
        }
    }
    // if kriging option equals to 1, then ordinary kriging is performed
    // It is necessary to add the unbiasedness constraint
    if (kriging_option == 1)
        RHS_Covariance_Matrix.push_back(1.00);
    return RHS_Covariance_Matrix;
}
