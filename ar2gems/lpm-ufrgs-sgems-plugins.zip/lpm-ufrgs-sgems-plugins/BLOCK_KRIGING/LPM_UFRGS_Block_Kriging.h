#ifndef __LPM_UFRGS_BLOCK_KRIGING_H
#define __LPM_UFRGS_BLOCK_KRIGING_H


# include <map>
# include "Struct_Block.h"

#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>
#include <grid/grid_property.h>
#include <grid/grid_region.h>
#include <grid/neighborhood.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>
#include <geostat/parameters_handler.h>
#include <grid/neighborhood.h>
# include <grid/rgrid_neighborhood.h>
# include <grid/rgrid.h>
# include <grid/point_set.h>

#include <geostat/kriging.h>

#include <GsTL/geometry/covariance.h>

# include <fstream>


enum {
    SIMPLE_KRIGING = 0,
    ORDINARY_KRIGING = 1
};

class LPM_UFRGS_Block_Kriging : public Geostat_algo {
  public:
    LPM_UFRGS_Block_Kriging();
    virtual ~LPM_UFRGS_Block_Kriging();

    virtual bool initialize( const Parameters_handler* parameters,
                             Error_messages_handler* errors, Progress_notifier* notifier = 0);
    virtual int execute( GsTL_project* proj=0, Progress_notifier* notifier = 0);
    virtual std::string name() const {
        return "LPM_UFRGS_Block_Kriging";
    }

  public:
    static Named_interface* create_new_interface( std::string& );

  protected:
    void clean( const std::string& prop );

  private :/*need files below*/
    typedef Geostat_grid::location_type Location;
    typedef GsTL_neighborhood< SmartPtr<Neighborhood> > NeighborhoodHandle;


    Geostat_grid *Point_Locations_And_Value;
    Geostat_grid *Block_Locations;
    Point_set *Block_Centroids_Point_Set;
    //Point_set *Block_Locations_Point_Set;

    // b) Map declaration
    std::map<int, Struct_Block> Map_ID_Blocks;


    //double Contribution_Of_The_Variogram, Range_Of_The_Variogram;
    int Kriging_Option, min_neigh_, max_neigh_, min_neigh_Block, max_neigh_Block;

    double Simple_Kriging_Mean;


    Grid_continuous_property *Point_Sample_Values;
    Grid_continuous_property *Block_Sample_Values;
    Grid_continuous_property *Block_Sample_ID;
    Grid_continuous_property *Block_Sample_ID_Point_Set;
    Grid_continuous_property *Block_Sample_ID_Block_Centroids_Point_Set;
    Grid_continuous_property *Estimates;
    Grid_continuous_property *False_Estimates;

    GsTL_project* proj_;

    Error_messages_handler* errors_;

    Grid_region* target_grid_region_;
    Grid_region* hd_grid_region_;

    SmartPtr<Neighborhood> neighborhood_;

    SmartPtr<Neighborhood> neighborhood_Block_;


    Two_point_nested_structure covar_;
    //Covariance<Location> covar_;
    Two_point_nested_structure* rhs_covar_;
    //Covariance<Location>*  rhs_covar_;

    std::string Estimate_Name;



};

#endif /* GEOBODY_H_ */
