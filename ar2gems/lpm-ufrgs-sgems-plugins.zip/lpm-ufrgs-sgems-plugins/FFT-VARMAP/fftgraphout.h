/*
Implementação do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, Péricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_FFTGRAPHOUT_H___ 
#define __PLUGINS_LPM_UFRGS_FFTGRAPHOUT_H___

#include "common.h"

#include <qstring.h>
#include <qstringlist.h>
#include <QFrame>

#include "ui_fftgraphout.h"

class GraphOutput : public QFrame
{
	Q_OBJECT

public:
	GraphOutput(QWidget *parent = 0);
	~GraphOutput();

	Ui::GraphOutput& getUI() { return ui; }
private:
	Ui::GraphOutput ui;
};

#endif
