/*
 * LPM_UFRGS_Block_Kriging.cpp
 *
 *  Created on: March 10, 2014
 *      Author: Marcel
 */
# include "Covariance_Point_Point.h"
# include "Covariance_Block_Block.h"
# include "Covariance_Point_Block.h"
# include "Build_LHS_Covariance_Matrix.h"
# include "Build_RHS_Covariance_matrix.h"
# include "Solve_Kriging_System.h"
# include "Calculate_Estimates.h"
# include "LPM_UFRGS_Block_Kriging.h"
# include "Read_Input_Block_Data.h"
# include "Block_Points_Search.h"
# include "Transform_Neigh_To_Vector_Of_Vectors.h"
# include "Select_Valid_Block_Points.h"
# include "Create_Block_Centroid_Point_Set_From_Block_Map.h"
# include "Create_Point_Set_From_Geostat_Grid.h"
# include "Create_Point_To_Block_Covariance_Lookup_Table.h"
# include "Create_Block_To_Block_Covariance_Lookup_Table.h"

# include <math/gstlpoint.h>

# include <geostat/utilities.h>
# include <utils/string_manipulation.h>
# include <grid/utilities.h>
# include <grid/neighbors.h>
# include <geostat/utilities.h>
# include <grid/point_set.h>

# include <grid/point_set_neighborhood.h>
# include <grid/gval_iterator.h>
# include <grid/grid_path.h>
# include <appli/utilities.h>
# include <grid/geostat_grid.h>
# include <grid/neighborhood.h>
# include <grid/rgrid_neighborhood.h>
# include <grid/rgrid.h>
# include <grid/point_set.h>
# include <utils/gstl_messages.h>
# include <utils/manager_repository.h>
# include <iostream>
# include <fstream>
# include <QTime>

using namespace std;

LPM_UFRGS_Block_Kriging::LPM_UFRGS_Block_Kriging() {
}

LPM_UFRGS_Block_Kriging::~LPM_UFRGS_Block_Kriging() {
}

Named_interface* LPM_UFRGS_Block_Kriging::create_new_interface( std::string& ) {
    return new LPM_UFRGS_Block_Kriging;
}

/*
bool create_new_grid(std::string& grid_name_, GsTL_project* proj_, Error_messages_handler* errors_, int Nps) {
	std::string full_name( "/GridObject/Model/" + grid_name_);
	SmartPtr<Named_interface> ni =
	//Root::instance()->new_interface("cgrid://"+grid_name_, full_name);
	Root::instance()->new_interface("point_set://"+grid_name_+"::"+LPM_UFRGS_Block_Kriging::to_string(Nps), full_name);

	if( ni.raw_ptr() == 0 ) {
		errors_->report("output_grid_name", "Object " + full_name + " already exists. Use a different name." );
		//    appli_warning( "object " << full_name << "already exists" );
		return false;
	}

	proj_->new_object( grid_name_ );

	return true;
}
*/


bool LPM_UFRGS_Block_Kriging::initialize( const Parameters_handler* parameters,
        Error_messages_handler* errors, Progress_notifier* notifier ) {
    // Read grid name of the samples
    std::string Point_Samples_Grid_Name = parameters->value( "Location_And_Value_Of_The_Point_Samples.grid" );
    errors->report( Point_Samples_Grid_Name.empty(),
                    "Location_And_Value_Of_The_Point_Samples", "No grid selected" );
    // Set the string "Point_Samples_Grid_Name" To the string field of the Object Point_Locations_And_Values (class Geostat_grid). The method get_grid_from_manager sets the string to the correct place
    this->Point_Locations_And_Value = get_grid_from_manager(Point_Samples_Grid_Name);
    if (this->Point_Locations_And_Value == 0) {
        errors->report("The grid " + Point_Samples_Grid_Name + " does not exist");
        return false;
    }
    // Read name of the property of the sample grid
    std::string Point_Samples_Value_Name = parameters->value( "Location_And_Value_Of_The_Point_Samples.property" );
    errors->report( Point_Samples_Value_Name.empty(),
                    "Location_And_Value_Of_The_Point_Samples", "No property name specified" );
    this->Point_Sample_Values = this->Point_Locations_And_Value->property(Point_Samples_Value_Name);
    // Read the region of the sample grid
    std::string harddata_region_name = parameters->value( "Location_And_Value_Of_The_Point_Samples.region" );
    hd_grid_region_ = Point_Locations_And_Value->region(harddata_region_name);
    if (this->Point_Sample_Values == 0) {
        errors->report("The property " + Point_Samples_Value_Name + " does not exist");
        return false;
    }
    // Read the property name of the estimates
    Estimate_Name = parameters->value( "Property_Which_Will_Receive_The_Estimates.value" );
    errors->report( Estimate_Name.empty(),
                    "Property_Which_Will_Receive_The_Estimates", "No property name specified" );
    //Read Grid Name
    std::string Block_Grid_Name = parameters->value( "Location_Of_The_Block_Samples.value" );
    errors->report( Block_Grid_Name.empty(),
                    "Location_Of_The_Block_Samples", "No grid selected" );
    this->Block_Locations = get_grid_from_manager(Block_Grid_Name);
    if (this->Block_Locations == 0) {
        errors->report("The grid " + Block_Grid_Name + " does not exist");
        return false;
    }
    // Read Block Sample Values
    string Block_Sample_Values_Name = parameters->value( "Value_Of_The_Block_Samples.value" );
    errors->report(Block_Sample_Values_Name.empty(),
                   "Value_Of_The_Block_Samples.value", "No property name specified" );
    this->Block_Sample_Values = this->Block_Locations->property(Block_Sample_Values_Name);
    // Read Region of the grid
    std::string target_grid_region_name = parameters->value( "Location_Of_The_Block_Samples.region" );
    target_grid_region_ = Block_Locations->region(target_grid_region_name);
    if (this->Block_Sample_Values == 0) {
        errors->report("The property " + Block_Sample_Values_Name + " does not exist");
        return false;
    }
    // Read Block ID
    std::string Block_ID_Name = parameters->value( "ID_Of_The_Block_Samples.value" );
    errors->report( Block_ID_Name.empty(),
                    "ID_Of_The_Block_Samples.property", "No property name specified" );
    this->Block_Sample_ID = this->Block_Locations->property(Block_ID_Name);
    if (this->Block_Sample_ID == 0) {
        errors->report("The property " + Block_Sample_Values_Name + " does not exist");
        return false;
    }
    //1. Create Block Centroids Point Set
    // a) put the blocks into vector of vectors
    size_t N_block = Block_Locations->size();
    std::vector<std::vector<double> > Block_Sample_Points;
    for (size_t i = 0; i < N_block; ++i) {
        std::vector<double> row;
        double x, y, z, block_value;
        int block_id, node_id;
        x = Block_Locations->xyz_location(Block_Locations->node_id(i)).x();
        row.push_back(x);// fill the first column of the row with X location
        y = Block_Locations->xyz_location(Block_Locations->node_id(i)).y();
        row.push_back(y);
        z = Block_Locations->xyz_location(Block_Locations->node_id(i)).z();
        row.push_back(z);
        block_value = Block_Sample_Values->get_value(i);
        row.push_back(block_value);
        block_id = Block_Sample_ID->get_value(i);
        row.push_back(block_id);
        node_id = Block_Locations->node_id(i);
        row.push_back(node_id);
        Block_Sample_Points.push_back(row);
    }
    // The Function Read_Input Block Data put the blocks information into the Block_Map.
    // The Function also calculates de X centroid, Y centroid and Z centroid of the Block.
    // Only blocks whose Block_ID > 0 and Block_Value > -999 are considered.
    Read_Input_Block_Data(Map_ID_Blocks, Block_Sample_Points);
    // Create Point Set with the X centroid, Y centroid and Z centroid of each block.
    // This is done so that it is possible to iterate over the centroids of the blocks.
    bool Create_Block_Centroids_Point_Set_From_Map = Create_Block_Centroid_Point_Set_From_Block_Map(Block_Centroids_Point_Set, "Block_Centroids_Point_Set", Map_ID_Blocks);
    this->Block_Sample_ID_Block_Centroids_Point_Set = this->Block_Centroids_Point_Set->property("Block_ID");
    if (notifier) {
        int total_stepsOne = target_grid_region_ == 0 ? this->Block_Locations->size() : target_grid_region_->active_size();
        int total_stepsTwo = target_grid_region_ == 0 ? this->Block_Centroids_Point_Set->size() : target_grid_region_->active_size();
        int total_steps = total_stepsOne + total_stepsTwo;
        notifier->total_steps(total_steps);
        notifier->frequency(1);
    }
    this->Simple_Kriging_Mean = String_Op::to_number<double>(parameters->value("Simple_Kriging_Mean.value"));
    std::string Kriging_Option = parameters->value( "Kriging_Option.value" );
    if (Kriging_Option == "Simple Kriging")
        this->Kriging_Option = SIMPLE_KRIGING;
    else
        this->Kriging_Option = ORDINARY_KRIGING;
    // Set up the covar
//	bool init_cov_ok =
    //  geostat_utils::initialize_covariance( &covar_, "Variogram",
    //                        		            parameters, errors );
    bool init_cov_ok =
        geostat_utils::initialize_two_point_nested_structure(&covar_, "Variogram", parameters, errors, Block_Locations);
    if( !init_cov_ok ) return false;
    //rhs_covar_ = new Covariance<Location>(covar_);
    rhs_covar_ = new Two_point_nested_structure(covar_);
    // Set up the search neighborhood for the Point Samples . It iterates through the Block_Locations grid and get the Point Sample Values
    int max_neigh_ =
        String_Op::to_number<int>( parameters->value( "Max_Conditioning_Data.value" ) );
    min_neigh_ = String_Op::to_number<int>( parameters->value( "Min_Conditioning_Data.value" ) );
    errors->report( min_neigh_ >= max_neigh_, "Min_Conditioning_Data", "Min must be less than Max" );
    GsTLTriplet ellips_ranges;
    GsTLTriplet ellips_angles;
    bool extract_ok = geostat_utils::extract_ellipsoid_definition( ellips_ranges, ellips_angles, "Search_Ellipsoid.value", parameters, errors );
    if( !extract_ok ) return false;
    extract_ok = geostat_utils::is_valid_range_triplet( ellips_ranges );
    errors->report( !extract_ok,
                    "Search_Ellipsoid",
                    "Ranges must verify: major range >= "
                    "medium range >= minor range >= 0" );
    if( !extract_ok ) return false;
    Point_Locations_And_Value->select_property(Point_Samples_Value_Name);
    if( dynamic_cast<Point_set*>(Point_Locations_And_Value) ) {
        Point_Locations_And_Value->set_coordinate_mapper(Block_Locations->coordinate_mapper());
        neighborhood_ = SmartPtr<Neighborhood>(
                            Point_Locations_And_Value->neighborhood( ellips_ranges, ellips_angles, &covar_, true, hd_grid_region_ ) );
        //Point_Locations_And_Value->neighborhood( ellips_ranges, ellips_angles, &covar_, true, hd_region, simul_grid_->coordinate_mapper() ) );
    } else {
        neighborhood_ =  SmartPtr<Neighborhood>(
                             Point_Locations_And_Value->neighborhood( ellips_ranges, ellips_angles, &covar_, false, hd_grid_region_ ));
    }
    neighborhood_->select_property( Point_Samples_Value_Name );
    neighborhood_->max_size( max_neigh_ );
    geostat_utils::set_advanced_search(neighborhood_.raw_ptr(),
                                       "AdvancedSearch", parameters, errors);
    // Set up the search neighborhood for the Block Samples. It iterates through the Block_Locations grid and find the Block_ID from the Block_Centroids_Point_Set
    int max_neigh_Block = String_Op::to_number<int>( parameters->value( "Max_Blocks_Retained_In_The_Block_Search.value" ) );
    int min_neigh_Block = 0;
    // ;
    errors->report( min_neigh_Block >= max_neigh_Block, "Min_Conditioning_Data", "Min must be less than Max" );
    GsTLTriplet ellips_ranges_2;
    GsTLTriplet ellips_angles_2;
    bool extract_ok_2 = geostat_utils::extract_ellipsoid_definition( ellips_ranges_2, ellips_angles_2, "Search_Ellipsoid_2.value", parameters, errors );
    if( !extract_ok_2 ) return false;
    extract_ok_2 = geostat_utils::is_valid_range_triplet( ellips_ranges_2 );
    errors->report( !extract_ok_2,
                    "Search_Ellipsoid_2",
                    "Ranges must verify: major range >= "
                    "medium range >= minor range >= 0" );
    if( !extract_ok_2 ) return false;
    Block_Centroids_Point_Set->select_property("Block_ID");
    if( dynamic_cast<Point_set*>(Block_Centroids_Point_Set) ) {
        Block_Centroids_Point_Set->set_coordinate_mapper(Block_Locations->coordinate_mapper());
        neighborhood_Block_ = SmartPtr<Neighborhood>(
                                  Block_Centroids_Point_Set->neighborhood(ellips_ranges_2, ellips_angles_2, &covar_, false, target_grid_region_ )) ;
    } else {
        neighborhood_Block_ =  SmartPtr<Neighborhood>(
                                   Block_Centroids_Point_Set->neighborhood( ellips_ranges_2, ellips_angles_2, &covar_, false, target_grid_region_ ))
                               ;
    }
    neighborhood_Block_->select_property( "Block_ID" );
    neighborhood_Block_->max_size(max_neigh_Block);
    Grid_continuous_property *Estimate_Pointer = Block_Locations->add_property(Estimate_Name);
    if (Estimate_Pointer == 0) {
        Estimate_Pointer = Block_Locations->property(Estimate_Name);
        if(Estimate_Pointer == 0) {
            errors->report("Could not create the property" + Estimate_Name);
            return false;
        }
    }
    Estimates = Estimate_Pointer;
    return true;
}


void LPM_UFRGS_Block_Kriging::clean( const std::string& prop ) {
    Block_Locations->remove_property( prop );
}


#define INF -9999

int LPM_UFRGS_Block_Kriging::execute( GsTL_project* proj, Progress_notifier* notifier ) {
    if (notifier) notifier->write("Start kriging... ", 0);
    if (notifier) notifier->write("Creating Point Samples to Block Covariance Table", 0);
    vector<vector<double> > Point_Samples_To_Block_Covariance_Lookup_Table = Create_Point_To_Block_Covariance_Lookup_Table(Point_Locations_And_Value, Block_Centroids_Point_Set, Block_Locations, covar_, Map_ID_Blocks);
    if (notifier) notifier->write("Creating Point Unknown to Block Covariance Table", 0);
    vector<vector<double> > Point_Unknown_To_Block_Covariance_Lookup_Table = Create_Point_To_Block_Covariance_Lookup_Table(Block_Locations, Block_Centroids_Point_Set, Block_Locations, covar_, Map_ID_Blocks);
    if (notifier) notifier->write("Creating Block to Block Covariance Table", 0);
    vector<vector<double> > Block_To_Block_Covariance_Lookup_Table = Create_Block_To_Block_Covariance_Lookup_Table(Point_Unknown_To_Block_Covariance_Lookup_Table, Block_Centroids_Point_Set, Map_ID_Blocks);
    // those flags will be used to signal if some of the nodes could not be
    // informed
    bool issue_singular_system_warning = false;
    bool issue_no_conditioning_data_warning = false;
    // Set up a progress notifier
    int total_steps = Block_Locations->size();
    int frequency = std::max( total_steps / 20, 1 );
    //SmartPtr<Progress_notifier> progress_notifier =
    // utils::create_notifier( "Running Kriging",
    //	    total_steps, frequency );
    Grid_path path(Block_Locations, Estimates, target_grid_region_);
    Grid_path::iterator begin =path.begin();
    Grid_path::iterator end = path.end();
    for( ; begin != end; ++begin ) {
        if (notifier) {
            notifier->write("Processing node " + QString::number((begin->node_id())).toStdString(), 0);
            if (!notifier->notify()) break;
            while (notifier->is_paused()) {
                notifier->write("Paused", 0);
            }
        }
        //if (notifier != 0){ //Check if notifier exists
        //  if (!notifier->notify()) {
        //  LPM_UFRGS_Block_Kriging::clean(Estimate_Name);
        // return 1;
        //}
        //}
        // Do the normal path if the point to be estimated does not belong to any block
        if(Block_Sample_ID->get_value( ( begin->node_id() ) ) <= 0) {
            const std::vector<Geovalue> &neigh_ = neighborhood_->get_neighbors();
            const std::vector<Geovalue> &neigh_Block_ = neighborhood_Block_->get_neighbors();
            if( begin->is_informed() ) continue;
            //vector<Geovalue> neighbors;
            neighborhood_->find_neighbors( *begin );
            if( neighborhood_->size() < min_neigh_)  continue;
            if(!neighborhood_->is_valid()) continue;
            neighborhood_Block_->find_neighbors(*begin);
            min_neigh_Block = 0;
            if( neighborhood_Block_->size() < min_neigh_Block)  continue;
            if(!neighborhood_Block_->is_valid()) continue;
            //double x = neighborhood_Block_->center().xyz_location().x();
            //double y = neighborhood_Block_->center().xyz_location().y();
            //Neighborhood *teste = Rgrid_ellips_neighborhood();
            vector<vector<double> > Points_For_Covariance_Matrix = Transform_Neigh_To_Vector_Of_Vectors(neigh_);
            vector<double> Point_Values;
            for (size_t j = 0; j < Points_For_Covariance_Matrix.size(); ++j) {
                double point_value = Points_For_Covariance_Matrix[j][3];
                Point_Values.push_back(point_value);
            }
            vector<vector<double> > Block_Points_Inside_Neighborhood = Transform_Neigh_To_Vector_Of_Vectors(neigh_Block_);
            vector<vector<double> > Valid_Block_Points_Inside_Neighborhood = Select_Valid_Block_Points(Block_Points_Inside_Neighborhood);
            vector<int> Block_Node_Ids;
            vector<double> Block_Values_For_Covariance_Matrix;
            for (size_t i = 0; i < Valid_Block_Points_Inside_Neighborhood.size(); ++i) {
                int block_node_id = Valid_Block_Points_Inside_Neighborhood[i][4];
                Block_Node_Ids.push_back(block_node_id);
                int block_id = Valid_Block_Points_Inside_Neighborhood[i][3];
                double block_value = Map_ID_Blocks.at(block_id).Block_Value;
                Block_Values_For_Covariance_Matrix.push_back(block_value);
            }
            vector<vector<double> > LHS_Covariance_Matrix = Build_LHS_Covariance_Matrix(Point_Locations_And_Value, Points_For_Covariance_Matrix, Point_Samples_To_Block_Covariance_Lookup_Table, Block_To_Block_Covariance_Lookup_Table, Block_Node_Ids, covar_, Kriging_Option);
            int node_id_point_u = begin->node_id();
            vector<double> RHS_Covariance_Matrix = Build_RHS_Covariance_Matrix(Point_Locations_And_Value, Block_Locations, Points_For_Covariance_Matrix, Point_Unknown_To_Block_Covariance_Lookup_Table, Block_Node_Ids, covar_, Kriging_Option, node_id_point_u);
            vector <double> Kriging_Weights = Solve_Kriging_System(LHS_Covariance_Matrix, RHS_Covariance_Matrix);
            double estimate = Calculate_Estimates(Point_Values, Block_Values_For_Covariance_Matrix, Kriging_Weights, Kriging_Option, Simple_Kriging_Mean);
            Estimates->set_value(estimate, node_id_point_u);
        } else {
            continue;
        }
    }
    Grid_continuous_property *False_Estimate_Pointer = Block_Centroids_Point_Set->add_property(Estimate_Name);
    if (False_Estimate_Pointer == 0) {
        False_Estimate_Pointer = Block_Centroids_Point_Set->property(Estimate_Name);
        if(False_Estimate_Pointer == 0) {
            //errors->report("Could not create the property" + Estimate_Name);
            return false;
        }
    }
    False_Estimates = False_Estimate_Pointer;
    Grid_path path_2(Block_Centroids_Point_Set, False_Estimates, target_grid_region_);
    Grid_path::iterator begin_2 =path_2.begin();
    Grid_path::iterator end_2 = path_2.end();
    for( ; begin_2 != end_2; ++begin_2 ) {
        if (notifier) {
            notifier->write("Processing node " + QString::number(begin_2->node_id()).toStdString(), 0);
            if (!notifier->notify()) break;
            while (notifier->is_paused()) {
                notifier->write("Paused", 0);
            }
        }
        neighborhood_->find_neighbors( *begin_2 );
        double x = neighborhood_->center().xyz_location().x();
        double y = neighborhood_->center().xyz_location().y();
        double z = neighborhood_->center().xyz_location().z();
        if( neighborhood_->size() < min_neigh_)  continue;
        if(!neighborhood_->is_valid()) continue;
        neighborhood_Block_->find_neighbors(*begin_2);
        min_neigh_Block = 0;
        if( neighborhood_Block_->size() < min_neigh_Block)  continue;
        if(!neighborhood_Block_->is_valid()) continue;
        const std::vector<Geovalue> &neigh_ = neighborhood_->get_neighbors();
        const std::vector<Geovalue> &neigh_Block_ = neighborhood_Block_->get_neighbors();
        vector<vector<double> > Points_For_Covariance_Matrix = Transform_Neigh_To_Vector_Of_Vectors(neigh_);
        vector<double> Point_Values;
        for (size_t j = 0; j < Points_For_Covariance_Matrix.size(); ++j) {
            double point_value = Points_For_Covariance_Matrix[j][3];
            Point_Values.push_back(point_value);
        }
        vector<vector<double> > Block_Points_Inside_Neighborhood = Transform_Neigh_To_Vector_Of_Vectors(neigh_Block_);
        vector<vector<double> > Valid_Block_Points_Inside_Neighborhood = Select_Valid_Block_Points(Block_Points_Inside_Neighborhood);
        vector<int> Block_Node_Ids;
        vector<double> Block_Values_For_Covariance_Matrix;
        for (size_t i = 0; i < Valid_Block_Points_Inside_Neighborhood.size(); ++i) {
            int block_node_id = Valid_Block_Points_Inside_Neighborhood[i][4];
            Block_Node_Ids.push_back(block_node_id);
            int block_id = Valid_Block_Points_Inside_Neighborhood[i][3];
            double block_value = Map_ID_Blocks.at(block_id).Block_Value;
            Block_Values_For_Covariance_Matrix.push_back(block_value);
        }
        vector<vector<double> > LHS_Covariance_Matrix = Build_LHS_Covariance_Matrix(Point_Locations_And_Value, Points_For_Covariance_Matrix, Point_Samples_To_Block_Covariance_Lookup_Table, Block_To_Block_Covariance_Lookup_Table, Block_Node_Ids, covar_, Kriging_Option);
        int node_id_point_u = begin->node_id();
        vector<double> RHS_Covariance_Matrix = Build_RHS_Covariance_Matrix(Point_Locations_And_Value, Block_Locations, Points_For_Covariance_Matrix, Point_Unknown_To_Block_Covariance_Lookup_Table, Block_Node_Ids, covar_, Kriging_Option, node_id_point_u);
        vector <double> Kriging_Weights = Solve_Kriging_System(LHS_Covariance_Matrix, RHS_Covariance_Matrix);
        int temp_node_id = begin_2->node_id();
        int Block_ID = Block_Sample_ID_Block_Centroids_Point_Set->get_value(temp_node_id);
        int Block_Size = Map_ID_Blocks[Block_ID].X_Locations.size();
        /*
        //std::string s = std::to_string(temp_node_id);
        if (abs(Block_ID - 45) < 0.0001){
        	int ponto_de_debug = Block_ID;
        	ofstream myfile;
        	myfile.open("C:\\Users\\sgems\\Documents\\Teste_Plugin\\Covarince_Slice_45_1.txt");
        	for (size_t i = 0; i < LHS_Covariance_Matrix[0].size(); ++i){
        		myfile<<"\n";
        		for(size_t j = 0; j < LHS_Covariance_Matrix.size(); ++j){
        			myfile << LHS_Covariance_Matrix[i][j] << "	";

        		}
        	}
        	myfile.close();

        }*/
        // iterate through all the points that belong to the block
        for(size_t Block_Points_Index = 0; Block_Points_Index < Block_Size; ++Block_Points_Index) {
            int node_id_point_u = Map_ID_Blocks[Block_ID].node_id.at(Block_Points_Index);
            vector<double> RHS_Covariance_Matrix = Build_RHS_Covariance_Matrix(Point_Locations_And_Value, Block_Locations, Points_For_Covariance_Matrix, Point_Unknown_To_Block_Covariance_Lookup_Table, Block_Node_Ids, covar_, Kriging_Option, node_id_point_u);
            vector <double> Kriging_Weights = Solve_Kriging_System(LHS_Covariance_Matrix, RHS_Covariance_Matrix);
            double estimate = Calculate_Estimates(Point_Values, Block_Values_For_Covariance_Matrix, Kriging_Weights, Kriging_Option, Simple_Kriging_Mean);
            Estimates->set_value(estimate, node_id_point_u);
        }
    }
    //delete Block_Centroids_Point_Set;
    Block_Centroids_Point_Set->delete_ref();
    return true;
}

