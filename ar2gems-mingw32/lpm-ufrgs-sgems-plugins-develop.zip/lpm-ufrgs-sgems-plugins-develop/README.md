# lpm-ufrgs-sgems-plugins
A repository with SGEMS plugins.

Building instructions
---------------------

* Debian

Just use the bash script 'build_debian.sh'. This script will install all ar2gems dependencies.

```
$ ./build_debian.sh
```

Docker container
----------------

There are a container with a complete development environment available in https://registry.hub.docker.com/u/gogo40/lpm-sandbox/


Dependencies
-----------

* AR2GEMS (https://github.com/ar2tech/ar2gems)
* VTK (https://github.com/Kitware/VTK)
* QT 5 (http://download.qt.io)
* Flex
* Bison
* Boost
