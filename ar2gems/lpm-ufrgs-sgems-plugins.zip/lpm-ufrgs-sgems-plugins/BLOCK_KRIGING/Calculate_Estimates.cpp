# include "Calculate_Estimates.h"
# include <vector>

using namespace std;


double Calculate_Estimates(const std::vector<double> &point_values, const std::vector<double> &block_values, const std::vector<double> &Kriging_Weights, const int &kriging_option, const double SK_mean) {
    int Number_Of_Samples = point_values.size();
    double estimate = 0;
    if (kriging_option == 0) {
        for (size_t i = 0; i < Kriging_Weights.size(); ++i) {
            if (i < Number_Of_Samples) {
                estimate = estimate + Kriging_Weights[i] * (point_values[i] - SK_mean);
            } else {
                estimate = estimate + Kriging_Weights[i] * (block_values[i - Number_Of_Samples] - SK_mean);
            }
        }
    } else {
        for (size_t i = 0; i < Kriging_Weights.size()-1; ++i) {
            if (i < point_values.size()) {
                estimate = estimate + Kriging_Weights[i] * point_values[i];
            } else {
                estimate = estimate + Kriging_Weights[i] * (block_values[i - Number_Of_Samples]);
            }
        }
    }
    if (kriging_option == 0)
        estimate = estimate + SK_mean;
    return estimate;
}