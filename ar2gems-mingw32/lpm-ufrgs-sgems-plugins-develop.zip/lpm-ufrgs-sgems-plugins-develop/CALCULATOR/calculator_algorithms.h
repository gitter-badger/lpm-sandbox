/*
Implementação do plugin que efetua transformações nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/


#ifndef CALCULATOR_ALGORITHMS_H_
#define CALCULATOR_ALGORITHMS_H_

#include "common.h"

#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>
#include <grid/grid_property.h>
#include <grid/grid_region.h>
#include <grid/neighborhood.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>
#include <geostat/parameters_handler.h>


class CalculatorAlgorithms : public Geostat_algo {
  public:
    CalculatorAlgorithms();
    virtual ~CalculatorAlgorithms();

    virtual bool initialize(const Parameters_handler* parameters,
                            Error_messages_handler* errors, Progress_notifier* notifier = 0 );

    virtual int execute(GsTL_project* proj=0, Progress_notifier* notifier = 0);

    virtual std::string name() const {
        return "calculator";
    }

    static Named_interface* create_new_interface(std::string&);

  private :
    Error_messages_handler* errors_;
    std::string params;
    Named_interface* action_;
};



#endif // CALCULATOR_ALGORITHMS_H_
