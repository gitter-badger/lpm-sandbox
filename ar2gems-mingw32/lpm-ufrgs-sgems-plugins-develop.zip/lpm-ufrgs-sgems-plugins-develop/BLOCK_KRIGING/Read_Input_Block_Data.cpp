# include "Read_Input_Block_Data.h"


using namespace std;

bool Read_Input_Block_Data(std::map<int, Struct_Block> &Map_ID_Blocks, const std::vector<std::vector<double> > &Block_Locations) {
    for(size_t i = 0; i < Block_Locations.size(); ++i) {
        if(Block_Locations[i][4] > 0 & Block_Locations[i][3] > -999) {
            int ID = Block_Locations[i][4];
            double Block_Value = Block_Locations[i][3];
            Struct_Block& block = Map_ID_Blocks[ID];
            block.X_Locations.push_back(Block_Locations[i][0]);
            block.Y_Locations.push_back(Block_Locations[i][1]);
            block.Z_Locations.push_back(Block_Locations[i][2]);
            block.node_id.push_back(Block_Locations[i][5]);
            block.Block_ID = ID;
            block.Block_Value = Block_Value;
        }
    }
    map<int, Struct_Block>::iterator it = Map_ID_Blocks.begin(), ed = Map_ID_Blocks.end();
    while (it != ed) {
        int ID  = it->first;
        Struct_Block& block = it->second;
        double sum[3];
        sum[0] = sum[1] = sum[2] = 0;
        int N_points = block.X_Locations.size();
        for (size_t i = 0; i < N_points; ++i) {
            sum[0] += block.X_Locations[i];
            sum[1] += block.Y_Locations[i];
            sum[2] += block.Z_Locations[i];
        }
        block.X_centroid = sum[0] / N_points;
        block.Y_centroid = sum[1] / N_points;
        block.Z_centroid = sum[2] / N_points;
        ++it;
    }
    return true;
}