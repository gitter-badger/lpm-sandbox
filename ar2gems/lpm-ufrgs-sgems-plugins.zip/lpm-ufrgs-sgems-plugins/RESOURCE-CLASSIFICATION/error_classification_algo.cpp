/*
 * error_classification.cpp
 *
 *  Created on: Maio 2, 2014
 *      Author: Henrique Y.Shibata
 */

#include "error_classification_algo.h"

#include <geostat/utilities.h>
#include <utils/string_manipulation.h>
#include <grid/utilities.h>
#include <grid/neighbors.h>
#include <geostat/utilities.h>



Error_classification::Error_classification() {

}

Error_classification::~Error_classification() {

}

Named_interface* Error_classification::create_new_interface( std::string& ) {
	return new Error_classification;
}

bool Error_classification::initialize( const Parameters_handler* parameters,
                                       Error_messages_handler* errors,
                                   Progress_notifier* notifier ) {

	std::string grid_name = parameters->value( "Data_selector.grid" ); //
	errors->report( grid_name.empty(),
		  "Data_selector", "No grid selected" );

  std::string input_prop_name = parameters->value( "Data_selector.property" );
  errors->report( input_prop_name.empty(),
		  "Data_selector", "No property name specified" );

	error_val_[0] = String_Op::to_number<double>(parameters->value( "medido_value.value" ) );
    error_val_[1] = String_Op::to_number<double>(parameters->value( "indicado_value.value" ) );
    error_val_[2] = String_Op::to_number<double>(parameters->value( "inferido_value.value" ) );

  //std::string estimate_grid = parameters->value( "Grid_selector.value" );
	//errors->report( estimate_grid.empty(),
		  //"Data_selector", "No grid selected" );

  out_name_ = parameters->value( "output_name.value" );
	errors->report( out_name_.empty(),
		  "output", "No property name specified" );

  data_grid_ = get_grid_from_manager( grid_name );
  errors->report(data_grid_ == 0, "Data_selector", "Grid does not exist" );
  
  prop_ = data_grid_->property(input_prop_name);
  if(prop_==0){
	  errors->report("Data_selector", "Prop does not exist" );
	  return false;
  }

  est_grid_ = get_grid_from_manager( grid_name );
  errors->report(est_grid_ == 0, "Data_selector", "Grid does not exist" );

  if(!errors->empty()) {
    return false;
  }

 

  if(!errors->empty()) {
    return false;
  }

  //region_ = grid_->region( parameters->value( "Data_selector.region" ));

  GsTLTriplet ranges;
  GsTLTriplet angles;

  //bool ok = geostat_utils::extract_ellipsoid_definition( ranges, angles, "Ellipsoid.value",parameters, errors );

 // if(!ok) {
 //   return false;
//  }

 // neigh_ = data_grid_->neighborhood(ranges, angles, 0, false, 0 );

  //threshold_ = String_Op::to_number<float>( parameters->value( "threshold.value" ) );

  return true;

}

int Error_classification::execute( GsTL_project* proj, Progress_notifier* notifier  ){

   Grid_continuous_property* error_prop = geostat_utils::add_property_to_grid(est_grid_, out_name_ );

  data_grid_->select_property( prop_->name() );

  float value;
  
  int grid_size = est_grid_->size();
  double c = 0.0;
  double medido = error_val_[0] ;
  double indicado = error_val_[1];
  double inferido = error_val_[2];
  int m =0,ind = 0,inf = 0, nc=0;
  #pragma omp parallel for
  for(int i=0; i< grid_size; ++i) {
	  
	  //classificando o erro
	  c = prop_->get_value(i);
   
	  if(c <= medido){
		
		  ++m;
		 error_prop->set_value(3,i);
	  }

	  else if(medido< c && c <= indicado){
		
		  ++ind;
		  error_prop->set_value(2,i);

		   }

	  else if( indicado < c && c <= inferido){
		
		  ++inf;
		 error_prop->set_value(1,i);
	 }


	  else if(c>inferido) {
		
		 ++nc;
		error_prop->set_value(0,i);
	 
  
	 }
   
  }
	

  return 0;

}
