/*
Implementação do plugin que efetua transformações nos dados.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado & Luiz Gustavo Rasera
*/

#include "data_handling_algorithms.h"

#include "data_handling_action.h"

#include <geostat/utilities.h>
#include <utils/string_manipulation.h>
#include <grid/utilities.h>
#include <grid/neighbors.h>
#include <geostat/utilities.h>

#include <qstring.h>
#include <qmessagebox.h>
#include <cstdio>

DataHandlingAlgorithms::DataHandlingAlgorithms() 
{
}

DataHandlingAlgorithms::~DataHandlingAlgorithms() 
{
}

Named_interface* DataHandlingAlgorithms::create_new_interface(std::string&) 
{
	return new DataHandlingAlgorithms;
}

bool DataHandlingAlgorithms::initialize(const Parameters_handler* parameters,
								   Error_messages_handler* errors, Progress_notifier* notifier) 
{	
	this->errors_ = errors;

	bool cap = String_Op::to_number<bool>(parameters->value("Caping.value"));
	bool closure = String_Op::to_number<bool>(parameters->value("Closure.value"));
	bool geo_mean = String_Op::to_number<bool>(parameters->value("GeoMean.value"));

	this->params = "";

	int type = 0;

	if (cap) {
		this->params = "CAP";
		type = CAP;
	} else if (closure) {
		this->params = "CLOSURE";
		type = CLOSURE;
	} else if (geo_mean) {
		this->params = "GEO_MEAN";
		type = GEO_MEAN;
	}

	std::string grid_name = parameters->value("grid_name.value");
	std::string props = parameters->value("properties.value");
	std::string suffix = parameters->value("suffix_prop.value");

	if (suffix.size() < 1) {
		errors->report("properties", "suffix is missing");
		return false;
	}

	this->params += "|" + suffix;

	std::vector<std::string> vprops = String_Op::decompose_string(props, ";");
	this->params += "|";

	if (vprops.size() < 1) {
		errors->report("properties", "parameters missing");
		return false;
	}

	if (vprops.size() > 1 && cap) {
		errors->report("properties", "[CAP] You must select only one property at time");
		return false;
	}

	this->params += grid_name;
	for (size_t i = 0; i < vprops.size(); ++i) {
		this->params  += "::" + vprops[i];
	}

	bool lower_cap = String_Op::to_number<bool>(parameters->value("lower_cap.value"));
	bool upper_cap = String_Op::to_number<bool>(parameters->value("upper_cap.value"));
	bool inside_cap = String_Op::to_number<bool>(parameters->value("inside_cap.value"));
	bool outside_cap = String_Op::to_number<bool>(parameters->value("outside_cap.value"));

	switch (type) {
		case CAP:
			if (lower_cap) {
				this->params += "|0|0|" + parameters->value("value_cap.value") + "|LOWER";
			} else if (upper_cap) {
				this->params += "|0|0|" + parameters->value("value_cap.value") + "|UPPER";
			} else if (inside_cap) {
				this->params += "|" + parameters->value("min_cap.value") +
							"|" + parameters->value("max_cap.value") +
							"|" + parameters->value("value_cap.value");
				this->params += "|INSIDE";
			} else if (outside_cap) {
				this->params += "|" + parameters->value("min_cap.value") +
							"|" + parameters->value("max_cap.value") +
							"|" + parameters->value("value_cap.value");
				this->params += "|OUTSIDE";
			}
		break;

		case CLOSURE:
			this->params += "|" + parameters->value("tol_closure.value");
			this->params += "|" + parameters->value("const_closure.value");
		break;

		case GEO_MEAN:
		break;
	}

	this->action_ = new DataHandling();
	return static_cast<DataHandling*>(this->action_)->init(this->params, 0, this->errors_);
}

int DataHandlingAlgorithms::execute(GsTL_project* proj, Progress_notifier* notifier)
{	
	return static_cast<DataHandling*>(this->action_)->exec();
}

