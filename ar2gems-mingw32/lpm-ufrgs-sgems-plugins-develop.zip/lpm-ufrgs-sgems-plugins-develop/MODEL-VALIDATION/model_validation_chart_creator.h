/*
Implementa��o do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/



#ifndef __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_CHART_CREATOR_H___
#define __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_CHART_CREATOR_H___

#include "common.h"

#include <charts/chart_widget.h>
#include <charts/chart_creator.h>
#include <charts/chart_mdi_area.h>
#include <qtplugins/selectors.h>
#include <qtplugins/categorical_selectors.h>
#include <grid/grid_filter.h>

#include <QDialog>
#include <QMainWindow>
#include <QItemSelectionModel>
#include <QLineEdit>
#include <QDoubleSpinBox>
#include <QRadioButton>

#include <map>

#include "model_validation.h"

#include "model_validation_process.h"


class PLUGINS_LPM_UFRGS_DECL ModelValidation_chart_creator : public Chart_creator {
    Q_OBJECT

  public:
    ModelValidation_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent = 0);
    ~ModelValidation_chart_creator();

  private slots:
    void kill_process(ModelValidationProcess*);

    void show_chart_model_validation();

    void create_model_validation_process(ModelValidationAction* chart, int n_steps, int n_threads);

    ModelValidation* getModelValidation() {
        return my_model_validation_;
    }

  private:

    ModelValidation* build_model_validation_page();


    ModelValidation* my_model_validation_;
};

class PLUGINS_LPM_UFRGS_DECL ModelValidation_chart_creator_factory : public Chart_creator_factory {

  public:

    static Named_interface* create_new_interface(std::string&) {
        return new ModelValidation_chart_creator_factory;
    }

    ModelValidation_chart_creator_factory() {}
    ~ModelValidation_chart_creator_factory() {}

    virtual QString title_name() const {
        return "Model Validation";
    }
    virtual QString tab_name() const {
        return "LPM_UFRGS";
    }
    std::string name() const {
        return "Model Validation";
    }

    virtual Chart_creator* get_interface(Chart_mdi_area* mdi_area) {
        return new ModelValidation_chart_creator(mdi_area);
    }

};


#endif
