/*
Implementação do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, Péricles Lopes Machado
*/

#ifndef FFT_VARMAP_REPORT_H_
#define FFT_VARMAP_REPORT_H_

#include "common.h"
#include <QDialog>
#include <QMainWindow>
#include <QCloseEvent>
#include <ui_fftreport.h>


class FFT_report : public QDialog
{
	Q_OBJECT

public:
	FFT_report(QWidget *parent = 0);
	~FFT_report();

    void write(QString msg){
        emit setText(msg);
    }

signals:
    void setText(QString text);
	
public slots:
    void setReport(QString text) {
        this->ui.report_text->setText(text);
        this->show();
    }

	void setSelf(FFT_report* r) {
		self = r;
	}

	void autoDestroy() {
		if (self) delete self;
	}


private:
	FFT_report* self;
	Ui::FFT_report ui;
};

#endif /* FFT_REPORT_H_ */
