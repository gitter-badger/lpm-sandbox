/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_FFTCROSSVARIOGRAM_H___
#define __PLUGINS_LPM_UFRGS_FFTCROSSVARIOGRAM_H___

#include "common.h"

#include <qstring.h>
#include <qstringlist.h>
#include <QFrame>

#include "ui_fftcrossvariogram.h"


class FFTCrossVariogram : public QFrame {
    Q_OBJECT

  public:
    FFTCrossVariogram(QWidget *parent = 0);
    ~FFTCrossVariogram();

    double getX(int row, bool* ok = 0);
    double getY(int row, bool* ok = 0);
    double getZ(int row, bool* ok = 0);

    double getDx();
    double getDy();
    double getDz();

    int getNumberVariograms();
    int getNumberLags();
    int getNumberThreads();

    QPushButton* getDisplayButton();

    QStringList getProperties1();
    QStringList getProperties2();

    Geostat_grid* getGrid();

    bool computeVariogram();
    bool computeCovariance();

  public slots:
    void updateNumberVariograms(int nVariograms);

    void checkCell(int, int);

  signals:

  private:
    Ui::FFTCrossVariogram ui;
};

#endif

