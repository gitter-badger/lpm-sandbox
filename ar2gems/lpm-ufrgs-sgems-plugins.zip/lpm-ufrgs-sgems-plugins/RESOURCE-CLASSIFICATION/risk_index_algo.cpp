/*
 * risk_indice.cpp
 *
 Created on: Setembro 2, 2014
 *      Author: Henrique Y.Shibata
 */

#include "risk_index_algo.h"

#include <geostat/utilities.h>
#include <utils/string_manipulation.h>
#include <grid/utilities.h>
#include <grid/neighbors.h>
#include <geostat/utilities.h>



Risk_index::Risk_index() {

}

Risk_index::~Risk_index() {

}

Named_interface* Risk_index::create_new_interface( std::string& ) {
	return new Risk_index;
}

bool Risk_index::initialize( const Parameters_handler* parameters,
                             Error_messages_handler* errors,
                         Progress_notifier* notifier ) {

	std::string grid_name = parameters->value( "Data_selector.grid" ); //
	errors->report( grid_name.empty(),
		  "Data_selector", "No grid selected" );

  std::string input_prop_name = parameters->value( "Data_selector.property" );
  errors->report( input_prop_name.empty(),
		  "Data_selector", "No property name specified" );

    p_val_[0] = String_Op::to_number<double>(parameters->value( "medido_value.value" ) );
    p_val_[1] = String_Op::to_number<double>(parameters->value( "indicado_value.value" ) );
    p_val_[2] = String_Op::to_number<double>(parameters->value( "inferido_value.value" ) );

  out_name_ = parameters->value( "output_name.value" );
	errors->report( out_name_.empty(),
		  "output", "No property name specified" );

  data_grid_ = get_grid_from_manager( grid_name );
  errors->report(data_grid_ == 0, "Data_selector", "Grid does not exist" );
  
  prop_ = data_grid_->property(input_prop_name);
  if(prop_==0){
	  errors->report("Data_selector", "Prop does not exist" );
	  return false;
  }

  est_grid_ = get_grid_from_manager( grid_name );
  errors->report(est_grid_ == 0, "Data_selector", "Grid does not exist" );

  

  if(!errors->empty()) {
    return false;
  }

 

  if(!errors->empty()) {
    return false;
  }

  //region_ = grid_->region( parameters->value( "Data_selector.region" ));

  GsTLTriplet ranges;
  GsTLTriplet angles;

 // bool ok = geostat_utils::extract_ellipsoid_definition( ranges, angles, "Ellipsoid.value",parameters, errors );

//  if(!ok) {
  //  return false;
  //}

  //neigh_ = data_grid_->neighborhood(ranges, angles, 0, false, 0 );

  //threshold_ = String_Op::to_number<float>( parameters->value( "threshold.value" ) );

  return true;

}

int Risk_index::execute( GsTL_project* proj, Progress_notifier* notifier ){

  Grid_continuous_property* ri_prop = geostat_utils::add_property_to_grid(est_grid_, out_name_ );

  data_grid_->select_property( prop_->name() );

  float value;
  
  int grid_size = est_grid_->size();
  double ri = 0.0;
  double medido = p_val_[0] ;
  double indicado = p_val_[1];
  double inferido = p_val_[2];
  int m =0,ind = 0,inf = 0, nc=0;
  #pragma omp parallel for
  for(int i=0; i< grid_size; ++i) {
	  
	  //classificando o p
	  ri = prop_->get_value(i);
   
	  if(ri < medido){
		
		  ++m;
		 ri_prop->set_value(3,i);
	  }

	  else if(medido< ri && ri < indicado){
		
		  ++ind;
		  ri_prop->set_value(2,i);

		   }

	  else if(ri > inferido){
		
		  ++inf;
		 ri_prop->set_value(1,i);
	 }


	 else{
		
		 ++nc;
		ri_prop->set_value(0,i);
	 }
   
  }
	

  return 0;

}
