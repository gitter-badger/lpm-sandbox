# include "Create_Point_Set_From_Geostat_Grid.h"
# include <grid/point_set.h>
# include <grid/point_set_impl.h>
# include <grid/geostat_grid.h>
# include <grid/grid_path.h>
# include <vector>
# include <string>
# include <math/gstlpoint.h>

using namespace std;

bool Create_Point_Set_From_Geostat_Grid(Point_set *&Block_Locations_Point_Set, Geostat_grid * &Block_Locations, Grid_continuous_property * &Block_Sample_Values, Grid_continuous_property * &Block_Sample_ID){

    Block_Locations_Point_Set = new Point_set_property_impl_template<Grid_property_manager, Grid_region_manager>("Block_Locations_Point_Set", Block_Locations->size());
	
	vector<GsTLPoint> xyz_location;
	

	Grid_continuous_property *Block_ID_Pointer = Block_Locations_Point_Set->add_property("Block_ID");
	Grid_continuous_property *Block_Value_Pointer = Block_Locations_Point_Set->add_property("Block_Value");
	
	for(size_t i = 0; i < Block_Locations->size(); ++i){
		xyz_location.push_back(Block_Locations->xyz_location(i));
		Block_ID_Pointer->set_value(Block_Sample_ID->get_value(i), i);
		Block_Value_Pointer->set_value(Block_Sample_Values->get_value(i), i);
	}
	Block_Locations_Point_Set->point_locations(xyz_location);

	return true;

}
