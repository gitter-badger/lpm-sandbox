/*
Implementação do plugin BLENDSIM.

(c) 2013, LPM/UFRGS, Roberto Menin, Péricles Lopes Machado
*/

#ifndef __BLENDSIM_CALC_H
#define __BLENDSIM_CALC_H

#include <cmath>
#include <cstdlib>
#include <vector>
#include <map>

struct BlendingPile {
    double sum_mass;
    double grade_acc;
    double sqrt_grade_acc;

	int addr0;
	int n_seq;

    BlendingPile(double sum_mass = 0,
    double grade_acc = 0,
    double sqrt_grade_acc = 0)
    : sum_mass(sum_mass),
    grade_acc(grade_acc),
    sqrt_grade_acc(sqrt_grade_acc)
    {
	
	 addr0 = 0;
	 n_seq = 0;
	}
};

struct BlendingPiles {
    double sqrt_grade_acc_sum;
    std::vector<BlendingPile> pile;
};

double grade_pon_sim(const std::vector<double>& MassaBloco, const std::vector<double>& TeorBloco);

double calc_median(std::vector<BlendingPile>& PileDif);

int find_lower_bound(int io, double SumMass, const std::vector<double>& MassaBloco, const std::vector<double>& MassaBlocoAcc, double MaxMass);

void build_layers(std::vector<std::vector<double> >& m, std::vector<double>& volume, std::vector<double>& sim, double bulk_factor, int l, double pile_length, double staker_material, int io, int n_b);

BlendingPiles* create_piles(
	const std::vector<double>& MassaBloco,
	const std::vector<double>& TeorBloco,
	const std::vector<double>& MassaBlocoAcc,
	const std::vector<double>& MassaTeorBlocoAcc,
    double IniMass,
    double GradeAccSim);

void sort_info(std::vector<double>& res, const std::vector<int>& seq, const std::vector<double>& info);

#endif

