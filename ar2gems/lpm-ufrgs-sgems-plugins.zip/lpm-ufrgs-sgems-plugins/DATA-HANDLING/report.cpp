/*
Implementação do plugin que efetua transformações nos dados.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado & Luiz Gustavo Rasera
*/

#include "report.h"

DataHandling_report::DataHandling_report(QWidget *parent):QDialog(parent) {
    ui.setupUi(this);
}

DataHandling_report::~DataHandling_report() {
}
