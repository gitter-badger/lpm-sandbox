/*
Implementação do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/



#include "model_validation_report.h"

ModelValidationReport::ModelValidationReport(QWidget *parent):QDialog(parent) {
    ui.setupUi(this);
    self = 0;
    QObject::connect(this,
                     SIGNAL(setText(QString)),
                     this,
                     SLOT(setReport(QString)),
                     Qt::QueuedConnection
                    );
}

ModelValidationReport::~ModelValidationReport() {
}
