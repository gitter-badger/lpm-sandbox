# include "Covariance_Point_Point.h"
# include "Covariance_Point_Block.h"
# include <vector>

using namespace std;
typedef Geostat_grid::location_type Location;

double Covariance_Point_Block(Geostat_grid *point_i_grid, const int &node_id_point_i, Geostat_grid *block_j_grid, const vector<vector<double> > &block_j, const  Two_point_nested_structure &covar_) {
    int count = 0;
    double sum_cova_point_point = 0;
    double cova_point_point = 0;
    double cova_point_block = 0;
    for(size_t j = 0; j < block_j.size(); ++j) {
        cova_point_point = Covariance_Point_Point(point_i_grid, node_id_point_i, block_j_grid, block_j[j][4], covar_) ;
        sum_cova_point_point = sum_cova_point_point + cova_point_point;
        ++count;
    }
    cova_point_block = sum_cova_point_point/count;
    return cova_point_block;
}
