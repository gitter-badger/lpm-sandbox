#ifndef SELECT_VALID_BLOCK_POINTS_H
#define SELECT_VALID_BLOCK_POINTS_H

# include <vector>

std::vector<std::vector<double> > Select_Valid_Block_Points(const std::vector<std::vector<double> > &Block_Points_Inside_Neighborhood);


#endif