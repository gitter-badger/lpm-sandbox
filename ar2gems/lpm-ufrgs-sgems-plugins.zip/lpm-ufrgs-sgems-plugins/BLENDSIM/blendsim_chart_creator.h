/*
Implementação do plugin BLENDSIM.

(c) 2013, LPM/UFRGS, Roberto Menin, Péricles Lopes Machado
*/

#ifndef __BLENDSIM_CHART_CREATOR_H
#define __BLENDSIM_CHART_CREATOR_H

#include "common.h"

#include <charts/chart_widget.h>
#include <charts/chart_creator.h>
#include <charts/chart_mdi_area.h>
#include <qtplugins/selectors.h>
#include <qtplugins/categorical_selectors.h>
#include <grid/grid_filter.h>

#include <QDialog>
#include <QMainWindow>
#include <QItemSelectionModel>
#include <QLineEdit>
#include <QDoubleSpinBox>
#include <QRadioButton>

#include <map>

struct PairMinMax {
	double min_, max_, average_, p90_;

	int addr0_min;
	int n_seq_min;

	int addr0_max;
	int n_seq_max;

	std::vector<double> grades;

	int n_min_;
	int n_max_;

	PairMinMax(double min_ = 0, double max_ = 0)
		: min_(min_), max_(max_), n_min_(0), n_max_(0), average_(0), p90_(0) {}
};

typedef std::map<int, std::map<int, PairMinMax> > MapPileSeries;

class PLUGINS_LPM_UFRGS_DECL Blendsim_chart_creator : public Chart_creator 
{
  Q_OBJECT

public:
    Blendsim_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent=0);
    ~Blendsim_chart_creator(){}

	double getBulkFactor() {
		return this->bulk_factor_intrapiles->value();
	}

	double getMaterialStaker() {
		return this->material_staker_intrapiles->value();
	}

	int getInitialLayers() {
		return this->ini_layer_intrapiles->value();
	}

	int getFinalLayers() {
		return this->final_layer_intrapiles->value();
	}

	int getIntervalLayers() {
		return this->interval_layer_intrapiles->value();
	}

	double getReposeAngle() {
		return this->repose_angle_intrapiles->value();
	}

	double getBaseLength() {
		return this->base_lenght_intrapiles->value();
	}

	double get_GradeMeanMax(){
		return grade_max_mass_locate->value();
	}
	double get_GradeMeanMin(){
		return grade_min_mass_locate->value();
	}
	void update_pileseries_map(MapPileSeries& m) {
		this->pileseries_ = m;
	}

	int getMassIntrapile() {
		return this->choose_mass_prop_selector_->currentText().toInt();
	}
	
	Grid_continuous_property* getVolumeProp();

	MapPileSeries& getMapPileSeries() {
		return this->pileseries_;
	}

	int getPile() {
		return this->averagepile_1_prop_selector_->currentText().toInt();
	}
	
	void update_pileseries_selector();
	void update_pilelocate_selector();


	void setTime(const QString& msg) {
		this->count_time_interpiles->setText(msg);
	}

private slots:
  void update_block_mass(const QString&);
  void update_increase_mass(double);
  void show_chart_interpiles();
  void show_chart_intrapiles();
  void show_chart_pileseries();
  void show_chart_pilelocate();
  void show_chart_dispersionvariance();

private:
  QWidget* build_interpiles_page();
  QWidget* build_intrapiles_page();
  QWidget* build_pileseries_page();
  QWidget* build_pilelocate_page();
  QWidget* build_dispersionvariance_page();


private :

  QDoubleSpinBox* initial_mass_interpiles;
  QDoubleSpinBox* final_mass_interpiles;
  QDoubleSpinBox* increase_mass_interpiles;
  QDoubleSpinBox* material_staker_intrapiles;
  QDoubleSpinBox* bulk_factor_intrapiles;
  QDoubleSpinBox* repose_angle_intrapiles;
  QDoubleSpinBox* base_lenght_intrapiles;
  QDoubleSpinBox* grade_max_mass_interpiles;
  QDoubleSpinBox* grade_min_mass_interpiles;
  QDoubleSpinBox* grade_max_mass_locate;
  QDoubleSpinBox* grade_min_mass_locate;
  QSpinBox* ini_layer_intrapiles;
  QSpinBox* final_layer_intrapiles;
  QSpinBox* interval_layer_intrapiles;
  QLabel* minimum_block_mass_interpiles;
  QLabel* maximum_block_mass_interpiles;
  QLabel* sum_block_mass_interpiles;
  QLabel* maximum_increase_mass_interpiles;
  QLabel* atual_pile_mass_pileseries;
  QLabel* count_time_interpiles;
  
  
  GridSelector* grid_selector_;
  SinglePropertySelector* sequence_prop_selector_;
  SinglePropertySelector* mass_prop_selector_;
  SinglePropertySelector* averagepile_1_prop_selector_;
  SinglePropertySelector* choose_volume_prop_selector_;
  SinglePropertySelector* choose_mass_prop_selector_;
  OrderedPropertySelector* grades_selector_;

  MapPileSeries pileseries_;


};

class PLUGINS_LPM_UFRGS_DECL Blendsim_chart_creator_factory : public Chart_creator_factory 
{

public:

  static Named_interface* create_new_interface(std::string&) {
    return new Blendsim_chart_creator_factory;
  }

  Blendsim_chart_creator_factory(){}
  ~Blendsim_chart_creator_factory(){}

  virtual QString title_name() const {return "BlendPile";}
  virtual QString tab_name() const{return "LPM_UFRGS";}
  std::string name() const {return "BlendPiles";}

  virtual Chart_creator* get_interface(Chart_mdi_area* mdi_area){return new Blendsim_chart_creator(mdi_area);}

};

#endif

