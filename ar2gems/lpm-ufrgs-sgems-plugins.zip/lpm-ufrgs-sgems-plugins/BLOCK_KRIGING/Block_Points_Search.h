# ifndef BLOCK_POINTS_SEARCH_H
# define BLOCK_POINTS_SEARCH_H

# include <map>
# include <vector>
# include "Struct_Block.h"

std::vector<std::vector<std::vector<double> > > Block_Points_Search(const std::vector<std::vector<double> > &Block_Points, const std::map<int, Struct_Block> &Map_ID_Blocks);

# endif