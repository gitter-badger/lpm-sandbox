/*
Implementação do plugin que efetua transformações nos dados.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado & Luiz Gustavo Rasera
*/

#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <map>

#include "data_handling_action.h"
#include "data_handling_algorithms.h"

#include <utils/string_manipulation.h>
#include <grid/utilities.h>

Named_interface* DataHandling::create_new_interface( std::string& ) {
    return new DataHandling;
}


// MODELVALIDATION gridName::res_prop::prop1::prop2[::prop3::propN]
bool DataHandling::init(std::string& parameters, GsTL_project* proj, Error_messages_handler* errors, Progress_notifier* notifier) {
    std::vector<std::string> params = String_Op::decompose_string(parameters, "|", Actions::unique);
    if (params.size() < 2) {
        errors->report("Parameters are missing");
        return false;
    }
    std::string algo = params[0];
    std::string suffix_prop = params[1];
    std::vector<std::string> params1 = String_Op::decompose_string(params[2], Actions::separator, Actions::unique);
    if (params1.size() < 1) {
        return false;
    }
    this->grid_ = get_grid_from_manager(params1[0]);
    if (grid_ == 0) {
        errors->report("The grid " + params1[0] + " does not exist");
        return false;
    }
    for (int i = 1; i < params1.size(); ++i) {
        Grid_continuous_property* prop = grid_->property(params1[i]);
        if (prop == 0) {
            errors->report("The property " + params1[i] + " does not exist" );
            return false;
        }
        this->grid_props_.push_back(prop);
        ////////////////////////////////////////////////////////////////////////////
        if (i > 1 && algo == "GEO_MEAN") continue;
        std::string alr_prop_name;
        if (algo != "GEO_MEAN") {
            alr_prop_name = params1[i] + "_" + suffix_prop;
        } else {
            alr_prop_name = "GEO_MEAN_" + suffix_prop;
        }
        Grid_continuous_property* p = grid_->add_property(alr_prop_name);
        if (p == 0) {
            p = grid_->property(alr_prop_name);
            if(p == 0) {
                errors->report( "Could not create the property " + alr_prop_name);
                return false;
            }
        }
        this->result_grid_props_.push_back(p);
    }
    this->type = 0;
    if (algo == "CAP") {
        this->type = CAP;
        this->min_ = String_Op::to_number<double>(params[3]);
        this->max_ = String_Op::to_number<double>(params[4]);
        this->value_ = String_Op::to_number<double>(params[5]);
        if (params[6] == "LOWER") {
            this->cap_type = CapTypes::LOWER;
        } else if (params[6] == "UPPER") {
            this->cap_type = CapTypes::UPPER;
        } else if (params[6] == "INSIDE") {
            this->cap_type = CapTypes::INSIDE;
        } else if (params[6] == "OUTSIDE") {
            this->cap_type = CapTypes::OUTSIDE;
        }
    } else if (algo == "CLOSURE") {
        this->type = CLOSURE;
        this->tol_ = String_Op::to_number<double>(params[3]);
        this->const_ = String_Op::to_number<double>(params[4]);
    } else if (algo == "GEO_MEAN") {
        this->type = GEO_MEAN;
    }
    return true;
}

inline size_t min(size_t a, size_t b) {
    return a < b? a: b;
}



#define INF 2147483648

void do_cap(std::vector<std::vector<double> >& result, std::vector<std::vector<double> >& data,
            int cap_type, double min_, double max_, double value_) {
    size_t N = data.size();
    for (int i = 0; i < N; ++i) {
        if (data[i][0] < INF) {
            double v = data[i][0];
            switch (cap_type) {
            case CapTypes::LOWER:
                if (v < value_) {
                    result[i][0] = value_;
                } else {
                    result[i][0] = v;
                }
                break;
            case CapTypes::UPPER:
                if (v > value_) {
                    result[i][0] = value_;
                } else {
                    result[i][0] = v;
                }
                break;
            case CapTypes::INSIDE:
                if (v > min_ && v < max_) {
                    result[i][0] = value_;
                } else {
                    result[i][0] = v;
                }
                break;
            case CapTypes::OUTSIDE:
                if (v > min_ && v < max_) {
                    result[i][0] = v;
                } else {
                    result[i][0] = value_;
                }
                break;
            }
        }
    }
}

void do_closure(std::vector<std::vector<double> >& result, std::vector<std::vector<double> >& data,
                double tol_, double const_) {
    size_t N = data.size();
    for (size_t i = 0; i < N; ++i) {
        if (data[i][0] < INF) {
            size_t M = data[i].size();
            double sum = 0;
            for (size_t p = 0; p < M; ++p) {
                sum = data[i][p] + sum;
            }
            if (fabs((const_ - sum) / const_) * 100 <= tol_)  {
                for (size_t p = 0; p < M; ++p) {
                    result[i][p] = const_ * (data[i][p] / sum);
                }
            }
        }
    }
}

void do_geo_mean(std::vector<std::vector<double> >& result, std::vector<std::vector<double> >& data) {
    size_t N = data.size();
    for (size_t i = 0; i < N; ++i) {
        if (data[i][0] < INF) {
            size_t M = data[i].size();
            double sum = 0;
            double prod = 0;
            bool iszero = false;
            for (size_t p = 0; p < M; ++p) {
                if (fabs(data[i][p]) < 1e-8) {
                    iszero = true;
                    break;
                }
                sum = log(fabs(data[i][p])) + sum;
            }
            if (iszero) result[i][0] = 0;
            else result[i][0] = exp(sum / M);
        }
    }
}


bool DataHandling::exec(Progress_notifier* notifier) {
    size_t N = grid_props_[0]->size();
    size_t M = grid_props_.size();
    std::vector<std::vector<double> > data(N);
    for (size_t i = 0; i < N; ++i) {
        for (size_t p = 0; p < M; ++p) {
            if (grid_props_[p]->is_informed(i)) {
                data[i].push_back(grid_props_[p]->get_value(i));
            } else {
                data[i].push_back(INF);
            }
        }
    }
    std::vector<std::vector<double> > result(N);
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < M; ++j)  {
            result[i].push_back(INF);
        }
    }
    switch (this->type) {
    case CAP:
        do_cap(result, data, this->cap_type, this->min_, this->max_, this->value_);
        break;
    case CLOSURE:
        do_closure(result, data, this->tol_, this->const_);
        break;
    case GEO_MEAN:
        do_geo_mean(result, data);
        break;
    }
    for (size_t i = 0; i < N; ++i) {
        for (size_t p = 0; p < this->result_grid_props_.size(); ++p) {
            if (result[i][p] < INF) {
                this->result_grid_props_[p]->set_value(result[i][p], i);
            }
        }
    }
    return true;
}

