# include "Block_Points_Search.h"
# include <vector>
# include <map>
# include "Struct_Block.h"
# include <iostream>

using namespace std;

vector<vector<vector<double> > > Block_Points_Search(const vector<vector<double> > &Block_Points, const map<int, Struct_Block> &Map_ID_Blocks) {
    vector<vector<double> > Block_For_Covariance_Matrix;
    vector<vector<vector<double> > > Blocks_For_Covariance_Matrix;
    // Build the block locations for using in the covariance matrix
    for(int k = 0; k <Block_Points.size(); ++k) {
        int Block_ID = Block_Points[k][3];
        for(size_t i = 0; i < Map_ID_Blocks.at(Block_ID).X_Locations.size(); ++i) {
            vector<double> row;
            row.push_back(Map_ID_Blocks.at(Block_ID).X_Locations[i]);
            row.push_back(Map_ID_Blocks.at(Block_ID).Y_Locations[i]);
            row.push_back(Map_ID_Blocks.at(Block_ID).Z_Locations[i]);
            row.push_back(Map_ID_Blocks.at(Block_ID).Block_Value);
            row.push_back(Map_ID_Blocks.at(Block_ID).node_id[i]);
            Block_For_Covariance_Matrix.push_back(row);
        }
        Blocks_For_Covariance_Matrix.push_back(Block_For_Covariance_Matrix);
    }
    return Blocks_For_Covariance_Matrix;
}
