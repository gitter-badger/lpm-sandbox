/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/

#include "report.h"

FACTORIZATION_report::FACTORIZATION_report(QWidget *parent):QDialog(parent){
	ui.setupUi(this);
    QObject::connect(this,
                     SIGNAL(setText(QString)),
                     this,
                     SLOT(setReport(QString)),
                     Qt::QueuedConnection
                     );
}

FACTORIZATION_report::~FACTORIZATION_report(){

}
