/*
Implementação do RANDOM WALK.

(c) 2014, LPM/UFRGS, Rafael Caixeta, Péricles Lopes Machado

BASED ON AR2GEMS KRIGING IMPLEMENTATION
*/

/* -----------------------------------------------------------------------------
** Copyright (c) 2012 Advanced Resources and Risk Technology, LLC
** All rights reserved.
**
** This file is part of Advanced Resources and Risk Technology, LLC (AR2TECH)
** version of the open source software sgems.  It is a derivative work by
** AR2TECH (THE LICENSOR) based on the x-free license granted in the original
** version of the software (see notice below) and now sublicensed such that it
** cannot be distributed or modified without the explicit and written permission
** of AR2TECH.
**
** Only AR2TECH can modify, alter or revoke the licensing terms for this
** file/software.
**
** This file cannot be modified or distributed without the explicit and written
** consent of AR2TECH.
**
** Contact Dr. Alex Boucher (aboucher@ar2tech.com) for any questions regarding
** the licensing of this file/software
**
** The open-source version of sgems can be downloaded at
** sourceforge.net/projects/sgems.
** ----------------------------------------------------------------------------*/



/**********************************************************************
** Author: Nicolas Remy
** Copyright (C) 2002-2004 The Board of Trustees of the Leland Stanford Junior
**   University
** All rights reserved.
**
** This file is part of the "geostat" module of the Geostatistical Earth
** Modeling Software (GEMS)
**
** This file may be distributed and/or modified under the terms of the
** license defined by the Stanford Center for Reservoir Forecasting and
** appearing in the file LICENSE.XFREE included in the packaging of this file.
**
** This file may be distributed and/or modified under the terms of the
** GNU General Public License version 2 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** See http://www.gnu.org/copyleft/gpl.html for GPL licensing information.
**
** Contact the Stanford Center for Reservoir Forecasting, Stanford University
** if any conditions of this licensing are not clear to you.
**
**********************************************************************/

#ifndef __LPM_UFRGS_RANDOM_WALK_H__
#define __LPM_UFRGS_RANDOM_WALK_H__


#include <geostat/common.h>
#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>

#include <string>

#include <geostat/kriging_system.h>
#include <geostat/kriging_estimator.h>


#include <grid/property_copier.h>
#include <grid/two_point_statistics.h>
#include <grid/two_point_regular_block_model.h>
#include <qthread.h>
#include <random>

#include "common.h"
#include "report.h"

class Neighborhood;
class Neighbors;
class RGrid;

struct RandomWalkParameters {
    int seed;
    int nb_of_randomwalks;
    int nb_of_realizations;
    double lag;
    double dmax;
    double scale_factor;
    int nb_of_threads;
    double ns_var;
    int assign;
    double nugget;
    bool is_cross_validation;
    double ns_mean;
    bool rw_manual_calib;

    RandomWalkParameters(
        int seed = 0,
        int nb_of_randomwalks = 0,
        int nb_of_realizations = 0,
        double lag = 0,
        double dmax = 0,
        double scale_factor = 0,
        int nb_of_threads = 0,
        double ns_var = 0,
        int assign = 0,
        double nugget = 0,
        bool is_cross_validation = false,
        double ns_mean = 0,
        bool rw_manual_calib = false)
        : seed(seed), nb_of_randomwalks(nb_of_randomwalks), nb_of_realizations(nb_of_realizations),
          lag(lag), dmax(dmax), scale_factor(scale_factor), nb_of_threads(nb_of_threads), ns_var(ns_var), assign(assign), nugget(nugget),
          is_cross_validation(is_cross_validation), ns_mean(ns_mean), rw_manual_calib(rw_manual_calib) {
    }

    ~RandomWalkParameters() {
    }
};


class PLUGINS_LPM_UFRGS_DECL RandomWalk : public Geostat_algo {
  public:
    RandomWalk();
    ~RandomWalk();

    virtual bool initialize( const Parameters_handler* parameters,
                             Error_messages_handler* errors,
                             Progress_notifier* notifier = 0 );
    virtual int execute( GsTL_project* proj=0, Progress_notifier* notifier = 0  );

    virtual std::string name() const {
        return "random_walk";
    }

  public:
    static Named_interface* create_new_interface( std::string& );

  protected:
    void clean( const std::string& prop );
    RW_report* report_;

  private:

    void init_option_properties(std::string base_name,
                                Grid_continuous_property*& var_prop,Grid_continuous_property*& nsamples_prop,
                                Grid_continuous_property*& aver_dist_prop,Grid_continuous_property*& sum_pos_prop,
                                Grid_continuous_property*& sum_weights_prop, Grid_continuous_property*& kriging_prop);

  public:
    typedef Geostat_grid::location_type Location;

    Geostat_grid* simul_grid_;
    std::string property_name_;

    Geostat_grid* harddata_grid_;
    Grid_continuous_property* hdata_prop_;
    Grid_continuous_property* blk_hdata_prop_;
    std::string harddata_property_name_;

    std::vector<SmartPtr<Neighborhood> > neighborhood_;

    // Two_point_stat
    std::vector<Two_point_nested_structure> two_point_stat_;
    std::vector<Regular_block_covariance*> block_covar_;

    std::vector<Kriging_system> kriging_system_;
    std::vector<Kriging_estimator*> kriging_estimator_;

    int min_neigh_;
    int max_neigh_;

    bool use_target_hist_;
    SmartPtr<Continuous_distribution> target_cdf_;

    Grid_region* target_grid_region_;
    Grid_region* hd_grid_region_;


    //output options
    bool output_n_samples_;
    bool output_average_distance_;
    bool output_sum_positive_weights_;
    bool output_sum_weights_;
    bool output_kriging_;


    RandomWalkParameters rw_parameters_;

    Multi_property_generator* multireal_rw_property_;


    Grid_continuous_property* var_prop;
    Grid_continuous_property* nsamples_prop;
    Grid_continuous_property* aver_dist_prop;
    Grid_continuous_property* sum_pos_prop;
    Grid_continuous_property* sum_weights_prop;
    Grid_continuous_property* kriging_prop;

    Grid_continuous_property* harddata_property_;
    SmartPtr<Property_copier> property_copier_;
  protected:
};

typedef std::vector<std::vector<double> > Vector2D;
typedef std::vector<double> Vector1D;
typedef std::normal_distribution<double> GaussNoise;
typedef std::vector<Grid_continuous_property*> Prop_real;

class RandomWalkMatrixProcess : public QThread {
  public:
    RandomWalkMatrixProcess(
        int id_thread, int nb_of_threads,
        int seed, Vector2D* output, double f, double lag, double dmax, int n_random_walks)
        :
        id_thread(id_thread), nb_of_threads(nb_of_threads),
        output(output), f(f), lag(lag), dmax(dmax), n_random_walks(n_random_walks) {
        gen.seed(seed);
    }


    void execute_random_walk(int id_thread, int nb_of_threads,
                             int seed, Vector2D* output, double f, double lag, double dmax, int n_random_walks);

    void run() {
        execute_random_walk(id_thread, nb_of_threads,
                            gen(), output, f, lag, dmax, n_random_walks);
    }

  private:
    std::mt19937 gen;
    Vector2D* output;
    double f;
    double lag;
    double dmax;
    int n_random_walks;
    int  nb_of_threads;
    int id_thread;
};

class RandomWalkProcess : public QThread {
  public:


    RandomWalkProcess(
        int id_thread,
        int n_threads,
        Progress_notifier* notifier,
        RandomWalk* handler,
        Prop_real* prop,
        const Vector2D* oracle,
        bool* issue_singular_system_warning,
        bool* issue_no_conditioning_data_warning,
        const Vector2D* path_pos,
        Vector1D* VarVector,
        Vector1D* krig_vect)
        :
        id_thread(id_thread),
        n_threads(n_threads),
        notifier(notifier),
        handler(handler),
        prop(prop),
        oracle(oracle),
        issue_singular_system_warning(issue_singular_system_warning),
        issue_no_conditioning_data_warning(issue_no_conditioning_data_warning),
        path_pos(path_pos),
        VarVector(VarVector),
        krig_vect(krig_vect) {
    }


    void execute_simulation(
        int id_thread,
        int n_threads,
        Progress_notifier* notifier,
        RandomWalk& handler,
        Prop_real& prop,
        const Vector2D& oracle,
        bool& issue_singular_system_warning,
        bool& issue_no_conditioning_data_warning,
        const Vector2D& path_pos,
        Vector1D& VarVector,
        Vector1D& krig_vect);

    void run() {
        execute_simulation(id_thread, n_threads,
                           notifier, *handler, *prop, *oracle,
                           *issue_singular_system_warning,
                           *issue_no_conditioning_data_warning, *path_pos, *VarVector, *krig_vect);
    }

  private:
    int id_thread;
    int n_threads;
    Progress_notifier* notifier;
    RandomWalk* handler;
    Prop_real* prop;
    const Vector2D* oracle;
    bool* issue_singular_system_warning;
    bool* issue_no_conditioning_data_warning;
    const Vector2D* path_pos;
    Vector1D* VarVector;
    Vector1D* krig_vect;
};

class Calib : public QThread {
  public:
    Calib(
        int id_thread,
        int n_threads,
        const Vector1D* restore_calib,
        const RandomWalk* handler,
        Prop_real* prop,
        const Vector1D* krig_vect,
        const Continuous_distribution* from,
        const Continuous_distribution* to,
        const Vector2D* ngt_effect)
        :
        id_thread(id_thread), n_threads(n_threads),
        restore_calib(restore_calib), handler(handler), prop(prop), krig_vect(krig_vect), from(from), to(to), ngt_effect(ngt_effect) {
    }


    void calibration(
        int id_thread,
        int n_threads,
        const Vector1D& restore_calib,
        const RandomWalk& handler,
        Prop_real& prop,
        const Vector1D& krig_vect,
        const Continuous_distribution& from,
        const Continuous_distribution& to,
        const Vector2D& ngt_effect);


    void run() {
        calibration(id_thread, n_threads,
                    *restore_calib, *handler, *prop, *krig_vect, *from, *to, *ngt_effect);
    }

  private:
    int id_thread;
    int n_threads;
    const Vector1D* restore_calib;
    const RandomWalk* handler;
    Prop_real* prop;
    const Vector1D* krig_vect;
    const Continuous_distribution* from;
    const Continuous_distribution* to;
    const Vector2D* ngt_effect;
};

#endif
