/*
Implementação do plugin BLENDSIM.

(c) 2013, LPM/UFRGS, Roberto Menin, Péricles Lopes Machado
*/

#include "blendsim_calc.h"



double grade_pon_sim(const std::vector<double>& MassaBloco, const std::vector<double>& TeorBloco) {
    double grade_pon_sim_ = 0;
    double grade_block_ = 0;
    double mass_block_ = 0;
    size_t n = MassaBloco.size();
    for (size_t i = 0; i < n; ++i) {
        mass_block_ += MassaBloco[i];
        grade_block_ += MassaBloco[i] * TeorBloco[i];
    }
    grade_pon_sim_ = grade_block_ / mass_block_;
    return grade_pon_sim_;
}

double calc_median(std::vector<BlendingPile>& PileDif) {
    /*	map<double, int> hist;
    	double median = 0;

    	for (int i = 0; i < PileDif.size(); ++i) {
    		++hist[PileDif[i].sum_mass];
    	}

    	int m = PileDif.size() / 2;
    	map<double, int>::iterator it = hist.begin(), ed = hist.end();
    	int acc = 0;
    	while (it != ed) {
    		acc += it->second;

    		if (acc >= m) {
    			median = it->first;
    		}

    		++it;
    	}*/
    return PileDif.size();
}

int find_lower_bound(int io, double SumMass, const std::vector<double>& MassaBloco, const std::vector<double>& MassaBlocoAcc, double MaxMass) {
    int ini = io;
    int fim = MassaBlocoAcc.size() - 1;
    int p = 0;
    while (ini < fim) {
        p = (ini + fim) >> 1;
        double m = SumMass + MassaBlocoAcc[p] - MassaBlocoAcc[io] + MassaBloco[io];
        if (m > MaxMass) {
            fim = p - 1;
        } else {
            ini = p + 1;
        }
    }
    ++p;
    if (p >= MassaBlocoAcc.size()) p =  MassaBlocoAcc.size() - 1;
    while (SumMass + MassaBlocoAcc[p] - MassaBlocoAcc[io] + MassaBloco[io] > MaxMass && p > io) p--;
    if (p < -1) p = 0;
    return p;
}

void build_layers(std::vector<std::vector<double> >& m, std::vector<double>& volume,
                  std::vector<double>& sim, double bulk_factor, int l,
                  double pile_length, double staker_material, int io, int n_b) {
    int idx = io;
    int cl = 0;
    std::vector<double> v;
    bool invert = false;
    while (cl < l && idx < io + n_b) {
        double vol = volume[idx] * bulk_factor;
        double len_block = vol / staker_material;
        while (len_block > 0 && cl < l && idx < volume.size()) {
            v.push_back(sim[idx]);
            if (v.size() * staker_material >= pile_length) {
                // printf("l = %d %d %d\n", l, m.size(), v.size());
                m.push_back(v);
                if (invert) {
                    invert = false;
                    int k = m.size() - 1;
                    for (int ini = 0, fim = m[k].size() - 1; ini < fim; ++ini, --fim) {
                        double p = m[k][ini];
                        m[k][ini] = m[k][fim];
                        m[k][fim] = p;
                    }
                } else {
                    invert = true;
                }
                v.clear();
                ++cl;
                if (cl >= l) break;
            }
            len_block -= staker_material;
        }
        ++idx;
    }
}

BlendingPiles* create_piles(
    const std::vector<double>& MassaBloco,
    const std::vector<double>& TeorBloco,
    const std::vector<double>& MassaBlocoAcc,
    const std::vector<double>& MassaTeorBlocoAcc,
    double IniMass,
    double GradeAccSim) {
    size_t n = MassaBloco.size();
    size_t i = 0, io = 0, i_ant = -1;
    double SumMass = 0;
    double GradeMass = 0;
    double GradeMassSum = 0;
    std::vector<BlendingPile> PileDif;
    BlendingPiles* pile_resultant = new BlendingPiles;
    while(i<n) {
        i = find_lower_bound(io, SumMass, MassaBloco, MassaBlocoAcc, IniMass);
        SumMass += MassaBlocoAcc[i] - MassaBlocoAcc[io] + MassaBloco[io];
        GradeMassSum += MassaTeorBlocoAcc[i] - MassaTeorBlocoAcc[io] + MassaBloco[io] * TeorBloco[io];
        if (i == i_ant) {
            BlendingPile pile(SumMass, GradeMassSum);
            pile.addr0 = io;
            pile.n_seq = i - io;
            PileDif.push_back(pile);
            break;
        }
        i_ant = i;
        ++i;
        bool ok = false;
        if (i < n) {
            if (SumMass + MassaBloco[i] >= IniMass) ok = true;
        }
        if (i >= n || ok) {
            BlendingPile pile(SumMass, GradeMassSum);
            pile.addr0 = io;
            pile.n_seq = i - io;
            PileDif.push_back(pile);
            SumMass = 0;
            GradeMassSum = 0;
            io = i;
        }
    }
    std::vector<BlendingPile>::iterator it = PileDif.begin(), ed = PileDif.end();
    pile_resultant->sqrt_grade_acc_sum = 0;
    while (it != ed) {
        BlendingPile& p = *it;
        double GradeAcc = p.grade_acc / p.sum_mass;
        double SqrtGradeAcc = pow(GradeAcc - GradeAccSim, 2.0);
        p.sqrt_grade_acc = SqrtGradeAcc;
        p.grade_acc = GradeAcc;
        pile_resultant->sqrt_grade_acc_sum += SqrtGradeAcc;
        pile_resultant->pile.push_back(p);
        ++it;
    }
    double median = calc_median(PileDif);
    pile_resultant->sqrt_grade_acc_sum /= median;
    return pile_resultant;
}

void sort_info(std::vector<double>& res, const std::vector<int>& seq, const std::vector<double>& info) {
    size_t n = info.size();
    std::map<int, std::vector<double> > data;
    for (size_t i = 0; i < n; ++i) {
        data[seq[i]].push_back(info[i]);
    }
    res.clear();
    std::map<int, std::vector<double> >::iterator it = data.begin(), ed = data.end();
    while (it != ed) {
        std::vector<double>::iterator it2 = it->second.begin(), ed2 = it->second.end();
        while (it2 != ed2) {
            res.push_back(*it2);
            ++it2;
        }
        ++it;
    }
}

