/*
Implementa��o do plugin que efetua transforma��es nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "Expression.h"
#include <cmath>
#include <map>

#include <limits>

using namespace std;


typedef double (*p_func)(vector<double>* args);

map<string, p_func> functions_map;

/*Function library*/


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////TRIGRONOMETRIC
double m_sin(vector<double>* args)
{
	if (args->size() < 1) return INF;
	return sin(args->at(0));
}

double m_cos(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return cos(args->at(0));
}

double m_tan(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return tan(args->at(0));
}

double m_asin(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return asin(args->at(0));
}

double m_acos(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return acos(args->at(0));
}

double m_atan(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return atan(args->at(0));
}

double m_atan2(vector<double>* args)
{
	if (args->size() < 2) return INF;

	return atan2(args->at(0), args->at(1));
}


////HYPERBOLIC

double m_sinh(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return sinh(args->at(0));
}

double m_cosh(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return cosh(args->at(0));
}

double m_tanh(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return tanh(args->at(0));
}

/*
double m_asinh(vector<double>& args)
{
	return asinh(args[0]);
}

double m_acosh(vector<double>& args)
{
	return acosh(args[0]);
}

double m_atanh(vector<double>& args)
{
	return atanh(args[0]);
}*/


////LOG AND EXPONENTIAL
double m_log(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return log(args->at(0));
}

double m_log10(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return log10(args->at(0));
}

double m_exp(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return exp(args->at(0));
}

double m_ldexp(vector<double>* args)
{
	if (args->size() < 2) return INF;

	return ldexp(args->at(0), args->at(1));
}

double m_pow(vector<double>* args)
{
	if (args->size() < 2) return INF;

	return pow(args->at(0), args->at(1));
}

double m_sqrt(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return sqrt(args->at(0));
}


///ABSOLUTE
double m_abs(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return fabs(args->at(0));
}

//NUMBER THEORY
double m_ceil(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return ceil(args->at(0));
}

double m_floor(vector<double>* args)
{
	if (args->size() < 1) return INF;

	return floor(args->at(0));
}

double m_mod(vector<double>* args)
{
	if (args->size() < 2) return INF;

	return fmod(args->at(0), args->at(1));
}

double m_pi(vector<double>* args)
{
	return acos(-1.0);
}

double m_e(vector<double>* args)
{
	return exp(1.0);
}

double m_mean(vector<double>* args)
{
	double acc = 0;
	for (size_t i = 0; i < args->size(); ++i) {
		acc += args->at(i);
	}
	return acc / args->size();
}

double m_variance(vector<double>* args)
{
	double acc = 0;
	for (size_t i = 0; i < args->size(); ++i) {
		acc += args->at(i);
	}
	return acc / args->size();
}

double m_isnan(vector<double>* args)
{
	return args->at(0) != args->at(0);
}

double m_isinf(vector<double>* args)
{

	double value = args->at(0);
	return !(value < INF);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*Generic call function*/
double call_function(const string& id, vector<double>* args)
{
	if (functions_map.find(id) != functions_map.end()) {
		return functions_map[id](args);
	}
	return INF;
}

/*Initialize library*/
void init_library()
{
	//TRIGONOMETRICS
	functions_map["sin"] = m_sin;
	functions_map["cos"] = m_cos;
	functions_map["tan"] = m_tan;

	functions_map["asin"] = m_asin;
	functions_map["acos"] = m_acos;
	functions_map["atan"] = m_atan;
	functions_map["atan2"] = m_atan2;

	//HYPERBOLICS
	functions_map["sinh"] = m_sinh;
	functions_map["cosh"] = m_cosh;
	functions_map["tanh"] = m_tanh;

	////LOG AND EXPONENTIAL
	functions_map["ln"] = m_log;
	functions_map["log"] = m_log10;
	functions_map["exp"] = m_exp;
	functions_map["ldexp"] = m_ldexp;
	functions_map["pow"] = m_pow;
	functions_map["sqrt"] = m_sqrt;

	///ABSOLUTE
	functions_map["abs"] = m_abs;

	///NUMBER THEORY
	functions_map["ceil"] = m_ceil;
	functions_map["floor"] = m_floor;
	functions_map["mod"] = m_mod;

	functions_map["pi"] = m_pi;
	functions_map["e"] = m_e;

	functions_map["mean"] = m_mean;
	functions_map["var"] = m_variance;
	functions_map["stdev"] = m_variance;
	
	functions_map["min"] = m_variance;
	functions_map["LQ"] = m_variance;
	functions_map["med"] = m_variance;
	functions_map["UQ"] = m_variance;
	functions_map["max"] = m_variance;
	functions_map["IQR"] = m_variance;

	functions_map["sum"] = m_variance;

	//utilities functions
	functions_map["isnan"] = m_isnan;
	functions_map["isinf"] = m_isinf;
}
