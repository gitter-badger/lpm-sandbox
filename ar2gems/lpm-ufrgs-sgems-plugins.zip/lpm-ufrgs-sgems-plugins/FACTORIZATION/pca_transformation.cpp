/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/


#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <ctime>

#include "pca_transformation.h"
#include "pca_build_operator.h"

#include <QTextStream>

#include "report.h"


#include <utils/string_manipulation.h>
#include <grid/utilities.h>

Named_interface* PCA_Transformation::create_new_interface( std::string& )
{
	return new PCA_Transformation;
}


// PCATransformation gridName::res_prop::prop1::prop2[::prop3::propN]
bool PCA_Transformation::init(std::string& parameters, GsTL_project* proj, Error_messages_handler* errors, Progress_notifier* notifier)
{
	this->inverse_ = false;
	std::vector<std::string> params = String_Op::decompose_string(parameters, Actions::separator, Actions::unique);

	if (params.size() < 2) {
		errors->report("Parameters are missing");  
		return false;
	}

	std::string grid_name = params[0];
	if (grid_name.empty()) {
		errors->report("No grid selected");
		return false;
	}

	grid_ = get_grid_from_manager(grid_name);
	if (grid_ == 0) {
		errors->report("The grid " + grid_name + " does not exist");
		return false;
	}
	
	for (size_t i = 1; i < params.size(); ++i) {
		Grid_continuous_property* prop = grid_->property(params[i]);
		if (prop == 0) {
			errors->report("The property " + params[i] + " does not exist" );
			return false;
		}
		
		props_.push_back(prop);
		
		std::string alr_prop_name = "PCA_" + LPM_UFRGS::to_string(i);
		
		Grid_continuous_property* p = grid_->add_property(alr_prop_name);
		if (p == 0) {
			p = grid_->property(alr_prop_name);
			if(p == 0) {
				errors->report( "Could not create the property " + alr_prop_name);
				return false;
			}
		} 
		PCA_props_.push_back(p);
	}

	return true;
}

bool PCA_Transformation::init_input(std::string& parameters) 
{
	std::vector<std::string> params = String_Op::decompose_string(parameters, Actions::separator, Actions::unique);
	std::string grid_name = params[0];
	grid_input_ = get_grid_from_manager(grid_name);

	
	for (int i = 1; i < params.size(); ++i) {
		Grid_continuous_property* prop = grid_input_->property(params[i]);
		if (prop == 0) {
			return false;
		}

		this->props_input_.push_back(prop);

		std::string alr_prop_name = "PCA_INV_" + LPM_UFRGS::to_string(i);
		
		Grid_continuous_property* p = grid_input_->add_property(alr_prop_name);

		if (p == 0) {
			p = grid_->property(alr_prop_name);
			if(p == 0) {
				return false;
			}
		} 
		PCA_INV_props_.push_back(p);
	}
	
	return true;
}

#define INF 2147483648

bool PCA_Transformation::exec(Progress_notifier* notifier) {
	size_t N = props_[0]->size();
	int M = props_.size();
	std::vector<std::vector<double> > data(N), varmatriz(M), input;

	for (size_t i = 0; i < N; ++i) {
		for (size_t p = 0; p < M; ++p) {
			if( !props_[p]->is_informed(i) ) {
				data[i].push_back(INF);
			} else {
				data[i].push_back(props_[p]->get_value(i));
			}
		}
	}

	
	if (this->inverse_) {
		size_t n = 0;
		for (size_t j = 0; j < props_input_.size(); ++j) {
			if (props_input_[j]->size() > n) {
				n = props_input_[j]->size();
			}
		}

		input.resize(n);
	
		for (size_t j = 0; j < props_input_.size(); ++j) {
			for (size_t i = 0; i < props_input_[j]->size(); ++i) {
				if (!props_input_[j]->is_informed(i)) {
					input[i].push_back(INF);
				} else {
					input[i].push_back(props_input_[j]->get_value(i));
				}
			}
		}
	}


	Eigen::MatrixXf D(M, M);
	std::vector<double> media(M);
	
    for (size_t i = 0; i < M; ++i) {
        double soma = 0, cnt = 0;
		
        for(size_t j = 0; j < data.size(); ++j) {
            if (data[j][i] < INF) {
                soma += data[j][i];
                cnt += 1.0;
            }
        }
     
        if (cnt > 1)
            media[i] = soma / cnt;
        else
            media[i] = 0;
        
		double d;

        for(size_t j = 0; j < data.size(); ++j) {
            if (data[j][i] < INF) {
                d = data[j][i] - media[i];

                varmatriz[i].push_back(d);
            } else varmatriz[i].push_back(INF);
        }
    }


    int m = data.size();
    double sum, mult, cov;
    std::vector<std::vector<double> > matrizcov(M);
    
    for (size_t i = 0; i < M; ++i) {
        for (size_t k = 0; k < M; ++k) {
            sum = 0;
            for (size_t j = 0; j < data.size(); ++j) {
                mult = varmatriz[i][j] * varmatriz[k][j];
                sum += mult;

                cov = sum / (m - 1);
            }
			
            matrizcov[i].push_back(cov);
        }
    }


    Eigen::MatrixXf A(M, M);
	MatrixXf EVEC(M, M);
	VectorXf EVAL(M, M);

    for(int i = 0; i < M; ++i) {
        for(int j = 0; j < M; ++j) {
            A(i,j) = (float) matrizcov[i][j];
        }
    }

    SelfAdjointEigenSolver<MatrixXf> eigensolver(A);
    
	if (eigensolver.info() != Success) {
		return false;
	}

    D << eigensolver.eigenvectors();
	
	EVEC << eigensolver.eigenvectors();
	EVAL << eigensolver.eigenvalues();

	/*
	Gera a PCA
	ALR_props_[j - 1]->set_value(log(data[i][j] / data[i][d]), i);
	*/
	
	if (this->inverse_) {
		std::vector <std::vector<double> > retransformadopca(M);
		
		for(int i = 0; i < M; ++i) {
			for(int j = 0; j < input.size(); ++j) {
				retransformadopca[i].push_back(media[i]);
			}

			for(int k = 0; k < M; ++k) {
				for(int j = 0;j < input.size(); ++j) {

					if (retransformadopca[i][j] < INF && input[j][k] < INF) {
						retransformadopca[i][j] += D(i,k) * input[j][k]; 
					} else {
						retransformadopca[i][j] = INF;
					}
				}
			}

			for (size_t k = 0; k < input.size(); ++k) {
				if (retransformadopca[i][k] < INF) {
					PCA_INV_props_[i]->set_value(retransformadopca[i][k], k);
				} else {
					PCA_INV_props_[i]->set_value(Grid_continuous_property::no_data_value, k);
				}
			}
		}

	} else {
		std::vector <std::vector<double> > vetorpca(M);

		for (int i = 0; i < M; ++i) {
			for (size_t j = 0; j < data.size(); ++j) {
				vetorpca[i].push_back(0);
			}

			for (int k = 0; k < M; ++k) {
				for (size_t j = 0; j < data.size(); ++j) {
					vetorpca[i][j] += D(k,i) * varmatriz[k][j];
				}
			}
		
			for (size_t k = 0; k < data.size(); ++k) {
				PCA_props_[i]->set_value(vetorpca[i][k], k);
			}
		}
	}


	if (this->show_ev_) {
		QString s_r;
		QTextStream out(&s_r, QIODevice::ReadWrite);

		out << "PCA REPORT\n";
		out << "___________________________________\n";
		out << "Eigenvalues:\n";

		int n = EVAL.rows();
		int c = EVAL.cols();
		out << "[\n";
		
			for (int i = 0; i < n; ++i) {
				if (i > 0) {
					out << ";\n";
				}

				for (int j = 0; j < c; ++j) {
					if (j > 0) {
						out << "\t";
					}

					if (EVAL(i, j) > 0) {
						out << " ";
					}
					out << EVAL(i, j);
				}
			}
		out << "\n]\n";

		out << "\nEigenvectors:\n";
		n = EVEC.rows();
		c = EVEC.cols();

		out << "[\n";
		
			for (int i = 0; i < n; ++i) {
				if (i > 0) {
					out << ";\n";
				}

				for (int j = 0; j < c; ++j) {
					if (j > 0) {
						out << "\t";
					}

					if (EVEC(i, j) > 0) {
						out << " ";
					}
					out << EVEC(i, j);
				}
			}
		out << "\n]\n";


		out << "\nIt's adviced to check this spatial decorrelation using cross-variograms and scatter plots.\n"; 

        report->write(s_r);
		show_report_ = true;
	}
	return true;
}
