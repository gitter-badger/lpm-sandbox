/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftcrossvariogram.h"

FFTCrossVariogram::FFTCrossVariogram(QWidget *parent)
: QFrame(parent) 
{
	ui.setupUi(this);

	QStringList labels;

	labels << "x" << "y" << "z";

	ui.varPropTable->setColumnCount(3);
	ui.varPropTable->setRowCount(1);
	ui.varPropTable->setHorizontalHeaderLabels(labels);

}

void FFTCrossVariogram::updateNumberVariograms(int nVariograms)
{
	ui.varPropTable->setRowCount(nVariograms);
}


double FFTCrossVariogram::getX(int row, bool* ok)
{
	if (ui.varPropTable->item(row, 0) == 0) return 0;
	return ui.varPropTable->item(row, 0)->text().toDouble(ok);
}

double FFTCrossVariogram::getY(int row, bool* ok)
{
	if (ui.varPropTable->item(row, 1) == 0) return 0;
	return ui.varPropTable->item(row, 1)->text().toDouble(ok);
}

double FFTCrossVariogram::getZ(int row, bool* ok)
{
	if (ui.varPropTable->item(row, 2) == 0) return 0;
	return ui.varPropTable->item(row, 2)->text().toDouble(ok);
}

void FFTCrossVariogram::checkCell(int x, int y)
{
	bool ok = true;
	
	if (ui.varPropTable->item(x, y) == 0) {
		ui.varPropTable->item(x, y)->setText("0");
		return;
	}

	double v = ui.varPropTable->item(x, y)->text().toDouble(&ok);

	if (!ok) {
		ui.varPropTable->item(x, y)->setText("0");
	}
}

int FFTCrossVariogram::getNumberVariograms()
{
	return ui.varPropTable->rowCount();
}

int FFTCrossVariogram::getNumberLags()
{
	return ui.nLags->value();
}

int FFTCrossVariogram::getNumberThreads()
{
	return ui.nThreads->value();
}

QStringList FFTCrossVariogram::getProperties1()
{
	return ui.props1->selected_properties();
}

QStringList FFTCrossVariogram::getProperties2()
{
	return ui.props2->selected_properties();
}

Geostat_grid* FFTCrossVariogram::getGrid()
{
	return ui.grid->selected_grid_object();
}

FFTCrossVariogram::~FFTCrossVariogram()
{

}

QPushButton* FFTCrossVariogram::getDisplayButton()
{
	return ui.displayButton;
}

double FFTCrossVariogram::getDx()
{
	return ui.dx->value();
}

double FFTCrossVariogram::getDy()
{
	return ui.dy->value();
}

double FFTCrossVariogram::getDz()
{
	return ui.dz->value();
}

bool FFTCrossVariogram::computeCovariance()
{
	return ui.compute_covariance->isChecked();
}

bool FFTCrossVariogram::computeVariogram()
{
	return ui.compute_variogram->isChecked();
}
