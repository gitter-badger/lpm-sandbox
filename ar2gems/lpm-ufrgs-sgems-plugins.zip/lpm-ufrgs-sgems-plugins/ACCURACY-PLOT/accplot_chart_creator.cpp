/*
Implementa��o do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "accplot_chart_creator.h"
#include "accplot_chart.h"

AccPlot_chart_creator::AccPlot_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent)
    : Chart_creator(mdi_area, parent)
{


    QTabWidget* AccPlot_Widget = new QTabWidget(this);

    my_accplot_ = this->build_accplot_page();

    AccPlot_Widget->addTab(my_accplot_, QIcon(), "Accuracy Plot");


    AccPlot_Widget->show();
    //my_histogram_->show();

    QVBoxLayout* main_layout = new QVBoxLayout(this);
    main_layout->setContentsMargins(0, 0, 0, 0);
    main_layout->addWidget(AccPlot_Widget);

    this->setLayout(main_layout);



    bool ok = connect(my_accplot_->getDisplayButton(), SIGNAL(clicked()),
                this, SLOT(show_chart_accplot()));
	
}

AccPlot_chart_creator::~AccPlot_chart_creator()
{
}

void AccPlot_chart_creator::kill_process(AccPlotProcess* process)
{
	AccPlot_chart* chart = static_cast<AccPlot_chart*>(process->getAction());

	if (process->isOk()) {
		chart->build_accplot_chart();

		QMdiSubWindow* sub_window = mdi_area_->addSubWindow(chart);
		sub_window->setAttribute(Qt::WA_DeleteOnClose);
		sub_window->showMaximized();
	} else {
		delete chart;
	}

	if (process) delete process;
}

void AccPlot_chart_creator::create_accplot_process(AccPlotAction* chart, int n_steps, int n_threads)
{
	AccPlotProcess* process = new AccPlotProcess(
		chart,
		new AccPlotProgressDialog(n_steps),
		n_threads);


	QObject::connect(
		process, SIGNAL(killMe(AccPlotProcess*)),
		this, SLOT(kill_process(AccPlotProcess*)));

	process->getNotifier()->show();
	process->start();
}

void AccPlot_chart_creator::show_chart_accplot()
{
	int nprops = my_accplot_->getProperties().size();
	
	if (my_accplot_->getGrid() != 0 && 
		nprops > 0) {
		AccPlot_chart* chart = new  AccPlot_chart(
			my_accplot_,
			0);

		create_accplot_process(chart, nprops, my_accplot_->getNumberThreads());
	}
}


AccPlot* AccPlot_chart_creator::build_accplot_page()
{
    return new AccPlot(0);
}

