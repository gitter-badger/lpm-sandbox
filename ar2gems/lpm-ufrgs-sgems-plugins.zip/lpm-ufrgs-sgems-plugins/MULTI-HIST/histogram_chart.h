/*
Implementa��o do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/



#ifndef __PLUGINS_LPM_UFRGS_HISTOGRAM_CHART_H___ 
#define __PLUGINS_LPM_UFRGS_HISTOGRAM_CHART_H___

#include "common.h"

#include <charts/chart_base.h>
#include <charts/chart_widget.h>
#include <charts/chart_display_control.h>
#include <grid/grid_property.h>
#include <grid/grid_weight_property.h>
#include <grid/grid_filter.h>

#include <vtkQtTableView.h>
#include <vtkSmartPointer.h>
#include <vtkLookupTable.h>
#include <vtkChartPie.h>

#include <QModelIndex>
#include <QLabel>
#include <qtextstream.h>
#include <qfiledialog.h>

#include <vector>
#include <map>

#include "histogram.h"

#include "histgraphout.h"
#include "histprocess.h"

enum Histogram_types {
	HISTOGRAM              = 0
};

enum HistogramOperation_type {
	CALC_HISTOGRAM = 0
};

static const char* histogram_charts_name = "Histogram";

struct Point {
	double x, y;
	Point(double x = 0, double y = 0) : x(x), y(y) {}
};

inline bool operator<(const Point& a, const Point& b) {
	if (a.x < b.x) return true;
	return a.y < b.y;
}

typedef std::vector<Point> Points;

class PLUGINS_LPM_UFRGS_DECL Histogram_chart : public Chart_base, public HistogramAction {
	Q_OBJECT

public:
	void set_ok(bool ok) { is_ok = ok; }

	void run_master_process(HistogramProcess* process_handler, int number_threads, std::vector<HistogramProcess*>& slaves);
	void run_slave_process(HistogramProcess* process_handler, int id_thread, int number_threads);

	explicit Histogram_chart(
        LPMHistogram* my_variogram,
		QWidget *parent = 0);


	~Histogram_chart() {
	}

public slots:
	void build_histogram_chart();
	
	void repaint_chart(const QString& in);
	void clear_chart();

	void save_report();
	void view_report();

	void build_value_table();
	void build_plot();

	void build_histograms(int id, int n_threads);

	void import_graphs();
	

private:
	bool ok;
	void build_histogram(Points& pts,  int i);
	
	HistogramGraphOutput* gout_;

	Histogram_types chart_type_;
	
    LPMHistogram* my_histogram_;

	Chart_widget* chart_histogram_widget_;
	
	Chart_display_control* chart_histogram_control_;
	
	vtkSmartPointer<vtkTable> table_histogram_;
	vtkSmartPointer<vtkQtTableView> table_histogram_view_;
	QTableView* qtable_histogram_;

	void write_table_histogram(QTextStream& out);
	

	std::vector<Points>  histograms_;

	bool is_ok;
	double dv_;
	QStringList props_names_;
	Geostat_grid* grid_;
	QString weight_;

	int n_bins_;
	QMutex mutex;
	HistogramProcess* my_process_handler_;
};

#endif
