/*
Implementação do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_ACCPLOTGRAPHOUT_H___
#define __PLUGINS_LPM_UFRGS_ACCPLOTGRAPHOUT_H___

#include "common.h"

#include <qstring.h>
#include <qstringlist.h>
#include <QFrame>

#include "ui_accplotgraphout.h"

class AccPlotGraphOutput : public QFrame {
    Q_OBJECT

  public:
    AccPlotGraphOutput(QWidget *parent = 0);
    ~AccPlotGraphOutput();

    Ui::AccPlotGraphOutput& getUI() {
        return ui;
    }
  private:
    Ui::AccPlotGraphOutput ui;
};

#endif
