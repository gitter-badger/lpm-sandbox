/*
Implementação do plugin que efetua transformações nos dados.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado & Luiz Gustavo Rasera
*/

#ifndef PLUGINS_LPM_UFRGS_COMMON_H_
#define PLUGINS_LPM_UFRGS_COMMON_H_

#include <string>

#if defined(_WIN32) || defined(WIN32)
#ifdef LIB_STATIC
#define PLUGINS_LPM_UFRGS_DECL
#else
#ifdef PLUGINS_LPM_UFRGS_EXPORT
#define PLUGINS_LPM_UFRGS_DECL __declspec(dllexport)
#else
#define PLUGINS_LPM_UFRGS_DECL __declspec(dllimport)
#endif
#endif
#else
#define PLUGINS_LPM_UFRGS_DECL
#endif

#include <cstring>

namespace LPM_UFRGS {
inline std::string to_string(int i) {
    char buffer[100];
    sprintf(buffer, "%07d", i);
    return buffer;
}
}



#endif // PLUGINS_LPM_UFRGS_COMMON_H_
