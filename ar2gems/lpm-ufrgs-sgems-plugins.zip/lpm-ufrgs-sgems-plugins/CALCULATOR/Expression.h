/*
Implementa��o do plugin que efetua transforma��es nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, P�ricles Lopes Machado
*/


/*
 * Expression.h
 * Definition of the structure used to build the syntax tree.
 */
#ifndef __EXPRESSION_H__
#define __EXPRESSION_H__

#include "common.h"
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

#define INF 2147483648

/**
 * @brief The operation type
 */
typedef enum tagEOperationType
{
    eVALUE,
    eMULTIPLY,
    ePLUS,
	eSTRING,
	eDIV,
	eSUB,
	eMOD,
	ePOW,
	eNEG,
	eAND,
	eOR,
	eNOT,
	eLE,
	eGE,
	eLEQ,
	eGEQ,
	eEQ,
	eDIFF,
	eIF,
	eFUNCTION
} EOperationType;
 
class FExpression;

/**
 * @brief The expression structure
 */
typedef struct tagSExpression
{
    EOperationType type;///< type of operation
 
	union {
		double value;///< valid only when type is eVALUE
		char* str;
		FExpression* func;
	};

    struct tagSExpression *left; ///< left side of the tree
    struct tagSExpression *right;///< right side of the tree
	struct tagSExpression *cond;
} SExpression;


/**
 * @brief It creates an identifier
 * @param value The number value
 * @return The expression or NULL in case of no memory
 */
SExpression *createNumber(double value);

SExpression *createString(char* str);
 
 
/**
 * @brief It creates an operation
 * @param type The operation type
 * @param left The left operand
 * @param right The right operand
 * @return The expression or NULL in case of no memory
 */
SExpression *createOperation(EOperationType type, SExpression *left, SExpression *right);

/**
 * @brief It creates an conditional operation
 * @param type The operation type
 * @param cond The conditional operand
 * @param left The left operand
 * @param right The right operand
 * @return The expression or NULL in case of no memory
 */
SExpression *createConditional(EOperationType type, SExpression *cond, SExpression *left, SExpression *right);
 
/**
 * @brief Deletes a expression
 * @param b The expression
 */
PLUGINS_LPM_UFRGS_DECL void deleteExpression(SExpression *b);

#include <grid/grid_property.h>
#include <grid/geostat_grid.h>
#include <QTextStream>

typedef std::map<std::string, Grid_continuous_property*> MapVar;

PLUGINS_LPM_UFRGS_DECL double evaluate(SExpression *e, MapVar* m, int i, QTextStream& out, int n_props);

PLUGINS_LPM_UFRGS_DECL SExpression *getAST(char *expr);


class FuncArgs {
public:
	FuncArgs()
		: n_args(0) 
		{}

	~FuncArgs()
	{
		for (size_t i = 0; i < n_args; ++i) {
			deleteExpression(args[i]);
		}
	}
	
	void addArgument(SExpression* arg) 
	{
		++n_args;
		args.push_back(arg);
	}

	SExpression* getArgument(size_t i) 
	{
		return args[i];
	}

	size_t size() 
	{ 
		return n_args; 
	}

	vector<double> evaluate(MapVar* m, int i, QTextStream& out, int n_props)
	{
		vector<double> args_(n_args);
		for (size_t k = 0; k < n_args; ++k) {
			args_[k] = ::evaluate(args[k], m, i, out, n_props);
		}
		return args_;
	}

private:
	size_t n_args;
	vector<SExpression*> args;
};

/**
 * @brief It creates an function call operation
 * @param type The operation type
 * @param fname The function name
 * @param func_args The function arguments
 * @return The expression or NULL in case of no memory
 */
SExpression* createFunction(EOperationType type, const char* fname, FuncArgs* func_args);

double call_function(const string& id, vector<double>* args);

class FExpression {
public:
	FExpression(const char* id, FuncArgs* args)
		: is_special(false), id(id), args(args)
	{
	
		memo = 0;
		is_memo = true;
		if (this->id == "mean") {
			is_special = true;
		} else if (this->id == "var") {
			is_special = true;
		} else if (this->id == "stdev") {
			is_special = true;
		} else if (this->id == "min") {
			is_special = true;
		} else if (this->id == "LQ") {
			is_special = true;
		} else if (this->id == "med") {
			is_special = true;
		} else if (this->id == "UQ") {
			is_special = true;
		} else if (this->id == "max") {
			is_special = true;
		} else if (this->id == "IQR") {
			is_special = true;
		} else if (this->id == "size") {
			is_special = true;
		} else if (this->id == "sum") {
			is_special = true;
		}
	}

	string& getId() 
	{
		return id;
	}

	FuncArgs* getArgs() 
	{
		return args;
	}

	double evaluate(MapVar* m, int i, QTextStream& out, int n_samples) 
	{
		if (is_special) {
			if (is_memo) {
				is_memo = false;
				
				if (id == "size") {
					memo = n_samples;
					return memo;
				}

				double acc = 0;
				vector<double>* v = new vector<double>(n_samples);
				for (int k = 0; k < n_samples; ++k) {
					vector<double> res = args->evaluate(m, k, out, n_samples);
					(*v)[k] = call_function(id, &res);
					acc += (*v)[k];
				}
			
				double mean = acc / n_samples;

				if (id == "mean") {
					delete v;
					memo = mean;
					return mean;
				}

				if (id == "sum") {
					delete v;
					memo = acc;
					return acc;
				}

				acc = 0;
				for (int k = 0; k < n_samples; ++k) {
					acc += (v->at(k) - mean) * (v->at(k) - mean);
				}
				double variance = acc / (n_samples - 1);

				
					
				if (id == "var" ) {
					delete v;
					memo = variance;
					return variance;
				} 
				
				if (id == "stdev") {
					memo = sqrt(variance);
					return sqrt(variance);
				}

				sort(v->begin(), v->end());

				if (id == "min") {
					memo = v->at(0);
					delete v;
					return memo;
				} else if (id == "max") {
					memo = * v->rbegin();
					delete v;
					return memo;
				} else if (id == "med") {
					if (v->size() & 1) {
						memo = v->at(v->size() / 2);
						delete v;
						return memo;
					} else {
						double a = v->at(v->size() / 2);
						double b = v->at(v->size() / 2 - 1); 
						memo = 0.5 * (a + b);
						delete v;
						return memo;
					}
				} else if (id == "LQ") {
					memo = v->at(v->size() / 4);
					delete v;
					return memo;
				} else if (id == "UQ") {
					memo = v->at(v->size() * 3 / 4);
					delete v;
					return memo;
				} else if (id == "IQR") {
					double a = v->at(v->size() / 4);
					double b = v->at(v->size() * 3 / 4);
					memo = b - a;
					delete v;
					return memo;
				}
			} else {
				return memo;
			}
		} else {
			vector<double> res = args->evaluate(m, i, out, n_samples);
			return call_function(id, &res);
		}
	}

	~FExpression() 
	{
		if (args) {
			delete args;
		}
	}
private:
	bool is_special;
	string id;
	FuncArgs* args;

	bool is_memo;
	double memo;
};

void init_library();

#endif // __EXPRESSION_H__
