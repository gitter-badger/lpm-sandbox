/*
Implementação do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/

#ifndef MODEL_VALIDATION_REPORT_H_
#define MODEL_VALIDATION_REPORT_H_

#include "common.h"
#include <QDialog>
#include <QMainWindow>
#include <QCloseEvent>
#include <ui_model_validation_report.h>


class ModelValidationReport : public QDialog
{
	Q_OBJECT

public:
    ModelValidationReport(QWidget *parent = 0);
    ~ModelValidationReport();

    void write(QString msg){
        emit setText(msg);
    }

signals:
    void setText(QString text);
	
public slots:
    void setReport(QString text) {
        this->ui.report_text->setText(text);
        this->show();
    }

    void setSelf(ModelValidationReport* r) {
		self = r;
	}

	void autoDestroy() {
		if (self) delete self;
	}


private:
    ModelValidationReport* self;
    Ui::ModelValidationReport ui;
};

#endif /* MODEL_VALIDATION_REPORT_H_ */
