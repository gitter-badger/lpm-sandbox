/*
Implementação do plugin que efetua transformações nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/


#ifndef CALCULATOR_ACTION_H_
#define CALCULATOR_ACTION_H_

#include "common.h"

#include <common.h>
#include <appli/action.h> 
#include <grid/grid_property.h>
#include <grid/geostat_grid.h>
#include <utils/named_interface.h>
#include <map>

#include "Expression.h"

#include "report.h"

class PLUGINS_LPM_UFRGS_DECL CalculatorHandling :  public Action 
{
	public: 
        CalculatorHandling() : Action() {
           calc_report = new Calculator_report(0);
        }

		static Named_interface* create_new_interface(std::string&);

        virtual ~CalculatorHandling()
        {
            if (calc_report)
                delete calc_report;
        }

		virtual bool init(std::string& parameters, GsTL_project* proj,
						  Error_messages_handler* errors,
                          Progress_notifier* notifier = 0); 
		virtual bool exec(Progress_notifier* notifier = 0); 


	private :

		size_t n_props;
		std::string result;
		std::string cmd;
		std::string grid_name;
		std::string props;
	
		Geostat_grid* grid;
		
		Grid_continuous_property* result_prop;

		MapVar prop_map;

        Calculator_report* calc_report;
};

#endif // CALCULATOR_ACTION_H_
