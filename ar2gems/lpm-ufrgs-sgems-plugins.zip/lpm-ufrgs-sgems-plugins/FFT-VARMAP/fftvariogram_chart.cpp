
/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftvariogram_chart_creator.h"
#include "fftvariogram_chart.h"
#include "fftgraphout.h"
#include "fftreport.h"

#include "fftvarmapcalc.h"
#include "fftvarmaputils.h"

#include <utils/string_manipulation.h>

#include <fstream>

#include <vtkAxis.h>
#include <vtkPlotLine.h>
#include <vtkPlotPoints.h>
#include <vtkPlotPie.h>
#include <vtkPlotBar.h>
#include <vtkIntArray.h>
#include <vtkFloatArray.h>
#include <vtkDoubleArray.h>
#include <vtkColorSeries.h>
#include <vtkTextProperty.h>


FFTVariogram_chart::FFTVariogram_chart(
    FFTCrossVariogramDeclus* my_crossvariogram_declus,
    QWidget *parent)
    :
    FFTAction(),
    Chart_base(parent),
    chart_type_(FFTCROSSVARIOGRAM_DECLUS),
    my_crossvariogram_declus_(my_crossvariogram_declus) {
    GraphOutput* gout = new GraphOutput(this);
    gout_ = gout;
    my_process_handler_ = 0;
    table_variogram_ = 0;
    is_ok = false;
    dx_ = my_crossvariogram_declus_->getDx();
    dy_ = my_crossvariogram_declus_->getDy();
    dz_ = my_crossvariogram_declus_->getDz();
    n_lags_ = my_crossvariogram_declus_->getNumberLags();
    weight_ = my_crossvariogram_declus_->getWeigth();
    grid_ = my_crossvariogram_declus_->getGrid();
    props_names_ = my_crossvariogram_declus_->getProperties1();
    props_names2_ = my_crossvariogram_declus_->getProperties2();
    int n_threads = my_crossvariogram_declus_->getNumberThreads();
    fft_set_num_threads(n_threads);
    for (int i = 0; i < my_crossvariogram_declus_->getNumberVariograms(); ++i) {
        variograms_dirs_.push_back(Point3D(
                                       my_crossvariogram_declus_->getX(i),
                                       my_crossvariogram_declus_->getY(i),
                                       my_crossvariogram_declus_->getZ(i)));
    }
    this->hide();
    use_geo_ = false;
    init_varmaps();
}

FFTVariogram_chart::FFTVariogram_chart(
    FFTCrossVariogram* my_crossvariogram,
    QWidget *parent)
    :
    FFTAction(),
    Chart_base(parent),
    chart_type_(FFTCROSSVARIOGRAM),
    my_crossvariogram_(my_crossvariogram) {
    GraphOutput* gout = new GraphOutput(this);
    gout_ = gout;
    my_process_handler_ = 0;
    table_variogram_ = 0;
    is_ok = false;
    compute_variogram_ = false;
    compute_covariance_ = false;
    compute_crossvariogram_ = my_crossvariogram_->computeVariogram();
    compute_crosscovariance_ = my_crossvariogram_->computeCovariance();
    dx_ = my_crossvariogram_->getDx();
    dy_ = my_crossvariogram_->getDy();
    dz_ = my_crossvariogram_->getDz();
    n_lags_ = my_crossvariogram_->getNumberLags();
    grid_ = my_crossvariogram_->getGrid();
    props_names_ = my_crossvariogram_->getProperties1();
    props_names2_ = my_crossvariogram_->getProperties2();
    int n_threads = my_crossvariogram_->getNumberThreads();
    fft_set_num_threads(n_threads);
    for (int i = 0; i < my_crossvariogram_->getNumberVariograms(); ++i) {
        variograms_dirs_.push_back(Point3D(
                                       my_crossvariogram_->getX(i),
                                       my_crossvariogram_->getY(i),
                                       my_crossvariogram_->getZ(i)));
    }
    this->hide();
    use_geo_ = false;
    init_varmaps();
}


FFTVariogram_chart::FFTVariogram_chart(
    FFTVariogram* my_variogram,
    QWidget *parent)
    :
    FFTAction(),
    Chart_base(parent),
    chart_type_(FFTVARIOGRAM),
    my_variogram_(my_variogram) {
    GraphOutput* gout = new GraphOutput(this);
    gout_ = gout;
    my_process_handler_ = 0;
    table_variogram_ = 0;
    is_ok = false;
    compute_variogram_ = my_variogram_->computeVariogram();
    compute_covariance_ = my_variogram_->computeCovariance();
    compute_crosscovariance_ = false;
    compute_crossvariogram_ = false;
    dx_ = my_variogram_->getDx();
    dy_ = my_variogram_->getDy();
    dz_ = my_variogram_->getDz();
    n_lags_ = my_variogram_->getNumberLags();
    grid_ = my_variogram_->getGrid();
    props_names_ = my_variogram_->getProperties();
    int n_threads = my_variogram_->getNumberThreads();
    fft_set_num_threads(n_threads);
    for (int i = 0; i < my_variogram_->getNumberVariograms(); ++i) {
        variograms_dirs_.push_back(Point3D(my_variogram_->getX(i), my_variogram_->getY(i), my_variogram_->getZ(i)));
    }
    this->hide();
    use_geo_ = false;
    init_varmaps();
}

FFTVariogram_chart::FFTVariogram_chart(
    FFTVariogramDeclus* my_variogram_declus,
    QWidget *parent)
    :
    FFTAction(),
    Chart_base(parent),
    chart_type_(FFTVARIOGRAM_DECLUS),
    my_variogram_declus_(my_variogram_declus) {
    GraphOutput* gout = new GraphOutput(this);
    gout_ = gout;
    my_process_handler_ = 0;
    table_variogram_ = 0;
    is_ok = false;
    dx_ = my_variogram_declus_->getDx();
    dy_ = my_variogram_declus_->getDy();
    dz_ = my_variogram_declus_->getDz();
    n_lags_ = my_variogram_declus_->getNumberLags();
    grid_ = my_variogram_declus_->getGrid();
    props_names_ = my_variogram_declus_->getProperties();
    weight_ = my_variogram_declus_->getWeigth();
    int n_threads = my_variogram_declus_->getNumberThreads();
    fft_set_num_threads(n_threads);
    for (int i = 0; i < my_variogram_declus_->getNumberVariograms(); ++i) {
        variograms_dirs_.push_back(Point3D(my_variogram_declus_->getX(i), my_variogram_declus_->getY(i), my_variogram_declus_->getZ(i)));
    }
    this->hide();
    use_geo_ = false;
    init_varmaps();
}

void FFTVariogram_chart::run_master_process(FFTProcess* process_handler, int number_threads, std::vector<FFTProcess*>& slaves) {
    if (process_handler->isOk()) {
        process_handler->getNotifier()->appendText("Creating varmaps...\n");
        this->my_process_handler_ = process_handler;
    }
}

void FFTVariogram_chart::run_slave_process(FFTProcess* process_handler, int id_thread, int number_threads) {
    if (process_handler->isOk()) {
        build_varmaps(chart_type_, id_thread, number_threads);
    }
}

void FFTVariogram_chart::init_varmaps() {
    int nvarmaps = props_names_.size();
    directions_.clear();
    n_maps_ = 0;
    for (int i = 0; i < variograms_dirs_.size(); ++i) {
        double x = variograms_dirs_[i].x;
        double y = variograms_dirs_[i].y;
        double z = variograms_dirs_[i].z;
        QString name_prop;
        QTextStream in(&name_prop);
        in << "(" << x << " | " << y << " | " << z << ")";
        directions_[name_prop.toStdString()] = Point3D(x, y, z);
        gout_->getUI().direction->addItem(name_prop);
        bool inv_x = x < 0;
        bool inv_y = y < 0;
        bool inv_z = z < 0;
        if (varmaps_[inv_x][inv_y][inv_z].size() < 1) {
            n_maps_++;
        }
        varmaps_[inv_x][inv_y][inv_z].push_back(Variogram_desc(name_prop.toStdString(), Point3D(x, y, z)));
    }
}

void FFTVariogram_chart::repaint_chart(const QString& in) {
    if (is_ok) {
        this->build_value_table();
        this->build_plot();
    }
}


void FFTVariogram_chart::build_value_table() {
    table_variogram_ = vtkSmartPointer<vtkTable>::New();
    QStringList& props = props_names_;
    vtkSmartPointer<vtkFloatArray> index_variogram = vtkSmartPointer<vtkFloatArray>::New();
    std::vector<vtkSmartPointer<vtkFloatArray> > values(props.size());
    Point3D dir = directions_[gout_->getUI().direction->currentText().toStdString()];
    std::vector<Points> vars(props.size());
    std::map<double, std::vector<double> > variogs;
    for (int i = 0; i < props.size(); ++i) {
        values[i] = vtkSmartPointer<vtkFloatArray>::New();
        Points& pts = variograms_[gout_->getUI().direction->currentText().toStdString()][i];
        for (int k = 0; k < pts.size(); ++k) {
            if (variogs[pts[k].x].size() < props.size()) variogs[pts[k].x] = std::vector<double>(props.size(), 0);
            variogs[pts[k].x][i] = pts[k].y;
        }
    }
    index_variogram->SetName("Lag");
    index_variogram->SetNumberOfValues(variogs.size());
    for (int i = 0; i < values.size(); ++i) {
        QString name;
        QTextStream in(&name);
        in << "Y " << gout_->getUI().direction->currentText() << " [ " << props[i];
        if (this->chart_type_ == FFTVariogram_types::FFTCROSSVARIOGRAM ||
                this->chart_type_ == FFTVariogram_types::FFTCROSSVARIOGRAM_DECLUS) {
            in << " X " << props_names2_[i];
        }
        in << " ]";
        values[i]->SetName(name.toStdString().c_str());
        values[i]->SetNumberOfValues(variogs.size());
    }
    std::map<double, std::vector<double> >::iterator it = variogs.begin(), ed = variogs.end();
    int idx = 0;
    while (it != ed) {
        index_variogram->SetValue(idx, it->first);
        std::vector<double>& v = it->second;
        for (int i = 0; i < v.size(); ++i) {
            values[i]->SetValue(idx, v[i]);
        }
        ++it;
        ++idx;
    }
    table_variogram_->AddColumn(index_variogram);
    for (int i = 0; i < values.size(); ++i) {
        table_variogram_->AddColumn(values[i]);
    }
    this->table_variogram_view_->SetRepresentationFromInput(table_variogram_);
    this->table_variogram_view_->Update();
}

void FFTVariogram_chart::build_variogram(Points& pts, const Point3D& dir, FFTVariogram_types chart_type_, VarOut* varmap, int i) {
    switch (chart_type_) {
    case FFTVariogram_types::FFTVARIOGRAM:
        this->build_variogram(pts, dir, varmap, i);
        break;
    case FFTVariogram_types::FFTCROSSVARIOGRAM:
        this->build_crossvariogram(pts, dir, varmap, i);
        break;
    case FFTVariogram_types::FFTCROSSVARIOGRAM_DECLUS:
        this->build_crossvariogram_declus(pts, dir, varmap, i);
        break;
    case FFTVariogram_types::FFTVARIOGRAM_DECLUS:
        this->build_variogram_declus(pts, dir, varmap, i);
        break;
    }
}

void FFTVariogram_chart::build_variogram(Points& pts, const Point3D& dir, VarOut* varmap, int i) {
    Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());
    bool inv_x = dir.x < 0;
    bool inv_y = dir.y < 0;
    bool inv_z = dir.z < 0;
    if (!varmap) {
        varmap = new VarOut;
        if (compute_variogram_) {
            compute_variogram(pts, grid_, prop,
                              dx_, dy_, dz_,
                              dir.x, dir.y, dir.z,
                              n_lags_, 0, varmap);
        }  else if (compute_covariance_) {
            compute_covariogram(pts, grid_, prop,
                                dx_, dy_, dz_,
                                dir.x, dir.y, dir.z,
                                n_lags_, 0, varmap);
        }
        delete varmap;
    } else {
        if (compute_variogram_) {
            compute_variogram(pts, grid_, prop,
                              dx_, dy_, dz_,
                              dir.x, dir.y, dir.z,
                              n_lags_, varmap);
        } else if (compute_covariance_) {
            compute_covariogram(pts, grid_, prop,
                                dx_, dy_, dz_,
                                dir.x, dir.y, dir.z,
                                n_lags_, varmap);
        }
    }
}

void FFTVariogram_chart::build_crossvariogram(Points& pts, const Point3D& dir, VarOut* varmap, int i) {
    Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());
    Grid_continuous_property* prop2 = grid_->property(props_names2_[i].toStdString());
    bool inv_x = dir.x < 0;
    bool inv_y = dir.y < 0;
    bool inv_z = dir.z < 0;
    if (!varmap) {
        varmap = new VarOut;
        if (compute_crossvariogram_) {
            compute_crossvariogram(pts, grid_, prop, prop2,
                                   dx_, dy_, dz_,
                                   dir.x, dir.y, dir.z,
                                   n_lags_, 0, varmap);
        } else if (compute_crosscovariance_) {
            compute_crosscovariogram(pts, grid_, prop, prop2,
                                     dx_, dy_, dz_,
                                     dir.x, dir.y, dir.z,
                                     n_lags_, 0, varmap);
        }
        delete varmap;
    } else {
        if (compute_crossvariogram_) {
            compute_crossvariogram(pts, grid_, prop, prop2,
                                   dx_, dy_, dz_,
                                   dir.x, dir.y, dir.z,
                                   n_lags_, varmap);
        } else if (compute_crosscovariance_) {
            compute_crosscovariogram(pts, grid_, prop, prop2,
                                     dx_, dy_, dz_,
                                     dir.x, dir.y, dir.z,
                                     n_lags_, varmap);
        }
    }
}

void FFTVariogram_chart::build_crossvariogram_declus(Points& pts, const Point3D& dir, VarOut* varmap, int i) {
    Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());
    Grid_continuous_property* prop2 = grid_->property(props_names2_[i].toStdString());
    Grid_continuous_property* weigth = grid_->property(weight_.toStdString());
    bool inv_x = dir.x < 0;
    bool inv_y = dir.y < 0;
    bool inv_z = dir.z < 0;
    if (!varmap) {
        varmap = new VarOut;
        compute_crossvariogram_declus(pts, grid_, weigth, prop, prop2,
                                      dx_, dy_, dz_,
                                      dir.x, dir.y, dir.z,
                                      n_lags_, 0, varmap);
        delete varmap;
    } else {
        compute_crossvariogram_declus(pts, grid_, weigth, prop, prop2,
                                      dx_, dy_, dz_,
                                      dir.x, dir.y, dir.z,
                                      n_lags_, varmap);
    }
}


void FFTVariogram_chart::build_variogram_declus(Points& pts, const Point3D& dir, VarOut* varmap, int i) {
    Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());
    Grid_continuous_property* w = grid_->property(weight_.toStdString());
    bool inv_x = dir.x < 0;
    bool inv_y = dir.y < 0;
    bool inv_z = dir.z < 0;
    if (!varmap) {
        varmap = new VarOut;
        compute_variogram_declus(pts, grid_, prop, w,
                                 dx_, dy_, dz_,
                                 dir.x, dir.y, dir.z,
                                 n_lags_, 0, varmap);
        delete varmap;
    } else {
        compute_variogram_declus(pts, grid_, prop, w,
                                 dx_, dy_, dz_,
                                 dir.x, dir.y, dir.z,
                                 n_lags_, varmap);
    }
}

void FFTVariogram_chart::build_varmaps(FFTVariogram_types chart_type, int id, int n_threads) {
    switch (chart_type) {
    case FFTVariogram_types::FFTVARIOGRAM:
        this->build_varmaps(id, n_threads);
        break;
    case FFTVariogram_types::FFTVARIOGRAM_DECLUS:
        this->build_varmaps_declus(id, n_threads);
        break;
    case FFTVariogram_types::FFTCROSSVARIOGRAM:
        this->build_crossvarmaps(id, n_threads);
        break;
    case FFTVariogram_types::FFTCROSSVARIOGRAM_DECLUS:
        this->build_crossvarmaps_declus(id, n_threads);
        break;
    }
}

void FFTVariogram_chart::build_varmaps(int id, int n_threads) {
    VarOut* varmap_ = new VarOut;
    for (int x = 0; x < 2; ++x) {
        for (int y = 0; y < 2; ++y) {
            for (int z = 0; z < 2; ++z) {
                if (varmaps_[x][y][z].size() > 0)
                    for (int i = id; i < props_names_.size(); i += n_threads) {
                        if (this->my_process_handler_) {
                            if (!this->my_process_handler_->isOk()) {
                                if (varmap_) delete varmap_;
                                return;
                            }
                            if (this->my_process_handler_->getNotifier()->isPaused()) {
                                my_process_handler_->getNotifier()->appendText("Paused...");
                                while (this->my_process_handler_->getNotifier()->isPaused()) {
                                }
                            }
                        }
                        Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());
                        if (my_process_handler_) my_process_handler_->getNotifier()->appendText("Creating Varmap to property <" + props_names_[i] + ">");
                        if (compute_variogram_) {
                            compute_varmap(grid_, prop,
                                           dx_, dy_, dz_,
                                           varmap_,
                                           x, y, z, &geo_, use_geo_);
                        } else if (compute_covariance_) {
                            compute_covarmap(grid_, prop,
                                             dx_, dy_, dz_,
                                             varmap_,
                                             x, y, z, &geo_, use_geo_);
                        }
                        use_geo_ = true;
                        for (int k = 0; k < varmaps_[x][y][z].size(); ++k) {
                            const std::string& dir_name = varmaps_[x][y][z][k].first;
                            const Point3D& dir = varmaps_[x][y][z][k].second;
                            Points pts;
                            build_variogram(pts, dir, varmap_, i);
                            variograms_[dir_name].push_back(pts);
                        }
                        if (my_process_handler_) my_process_handler_->getNotifier()->nextStep();
                    }
            }
        }
    }
    delete varmap_;
}

void FFTVariogram_chart::build_crossvarmaps(int id, int n_threads) {
    VarOut* varmap_ = new VarOut;
    for (int x = 0; x < 2; ++x) {
        for (int y = 0; y < 2; ++y) {
            for (int z = 0; z < 2; ++z) {
                if (varmaps_[x][y][z].size() > 0)
                    for (int i = id; i < props_names_.size(); i += n_threads) {
                        if (this->my_process_handler_) {
                            if (!this->my_process_handler_->isOk()) {
                                if (varmap_) delete varmap_;
                                return;
                            }
                            if (this->my_process_handler_->getNotifier()->isPaused()) {
                                my_process_handler_->getNotifier()->appendText("Paused...");
                                while (this->my_process_handler_->getNotifier()->isPaused()) {
                                }
                            }
                        }
                        Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());
                        Grid_continuous_property* prop2 = grid_->property(props_names2_[i].toStdString());
                        if (my_process_handler_) my_process_handler_
                            ->getNotifier()
                            ->appendText("Creating CrossVarmap to properties <" +
                                         props_names_[i] + "," + props_names2_[i] +  ">");
                        if (compute_crossvariogram_) {
                            compute_crossvarmap(grid_,
                                                prop,
                                                prop2,
                                                dx_, dy_, dz_,
                                                varmap_,
                                                x, y, z, &geo_, use_geo_);
                        } else if (compute_crosscovariance_) {
                            compute_crosscovarmap(grid_,
                                                  prop,
                                                  prop2,
                                                  dx_, dy_, dz_,
                                                  varmap_,
                                                  x, y, z, &geo_, use_geo_);
                        }
                        use_geo_ = true;
                        for (int k = 0; k < varmaps_[x][y][z].size(); ++k) {
                            const std::string& dir_name = varmaps_[x][y][z][k].first;
                            const Point3D& dir = varmaps_[x][y][z][k].second;
                            Points pts;
                            build_crossvariogram(pts, dir, varmap_, i);
                            variograms_[dir_name].push_back(pts);
                        }
                        if (my_process_handler_) my_process_handler_->getNotifier()->nextStep();
                    }
            }
        }
    }
    delete varmap_;
}

void FFTVariogram_chart::build_crossvarmaps_declus(int id, int n_threads) {
    VarOut* varmap_ = new VarOut;
    for (int x = 0; x < 2; ++x) {
        for (int y = 0; y < 2; ++y) {
            for (int z = 0; z < 2; ++z) {
                if (varmaps_[x][y][z].size() > 0)
                    for (int i = id; i < props_names_.size(); i += n_threads) {
                        if (this->my_process_handler_) {
                            if (!this->my_process_handler_->isOk()) {
                                if (varmap_) delete varmap_;
                                return;
                            }
                            if (this->my_process_handler_->getNotifier()->isPaused()) {
                                my_process_handler_->getNotifier()->appendText("Paused...");
                                while (this->my_process_handler_->getNotifier()->isPaused()) {
                                }
                            }
                        }
                        Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());
                        Grid_continuous_property* prop2 = grid_->property(props_names2_[i].toStdString());
                        Grid_continuous_property* w = grid_->property(weight_.toStdString());
                        if (my_process_handler_) my_process_handler_
                            ->getNotifier()
                            ->appendText("Creating CrossVarmap  Declus to properties <" +
                                         props_names_[i] + "," + props_names2_[i] + ">");
                        compute_crossvarmap_declus(grid_,
                                                   w,
                                                   prop,
                                                   prop2,
                                                   dx_, dy_, dz_,
                                                   varmap_,
                                                   x, y, z, &geo_, use_geo_);
                        use_geo_ = true;
                        for (int k = 0; k < varmaps_[x][y][z].size(); ++k) {
                            const std::string& dir_name = varmaps_[x][y][z][k].first;
                            const Point3D& dir = varmaps_[x][y][z][k].second;
                            Points pts;
                            build_crossvariogram_declus(pts, dir, varmap_, i);
                            variograms_[dir_name].push_back(pts);
                        }
                        if (my_process_handler_) my_process_handler_
                            ->getNotifier()
                            ->nextStep();
                    }
            }
        }
    }
    delete varmap_;
}

void FFTVariogram_chart::build_varmaps_declus(int id, int n_threads) {
    VarOut* varmap_ = new VarOut;
    for (int x = 0; x < 2; ++x) {
        for (int y = 0; y < 2; ++y) {
            for (int z = 0; z < 2; ++z) {
                if (varmaps_[x][y][z].size() > 0)
                    for (int i = id; i < props_names_.size(); i += n_threads) {
                        if (this->my_process_handler_) {
                            if (!this->my_process_handler_->isOk()) {
                                if (varmap_) delete varmap_;
                                return;
                            }
                            if (this->my_process_handler_->getNotifier()->isPaused()) {
                                my_process_handler_->getNotifier()->appendText("Paused...");
                                while (this->my_process_handler_->getNotifier()->isPaused()) {
                                }
                            }
                        }
                        Grid_continuous_property* prop = grid_->property(props_names_[i].toStdString());
                        Grid_continuous_property* w = grid_->property(weight_.toStdString());
                        if (my_process_handler_) my_process_handler_
                            ->getNotifier()
                            ->appendText("Creating Declus Varmap to property <" +
                                         props_names_[i] + ">");
                        compute_varmap_declus(grid_, prop, w,
                                              dx_, dy_, dz_,
                                              varmap_,
                                              x, y, z, &geo_, use_geo_);
                        use_geo_ = true;
                        for (int k = 0; k < varmaps_[x][y][z].size(); ++k) {
                            const std::string& dir_name = varmaps_[x][y][z][k].first;
                            const Point3D& dir = varmaps_[x][y][z][k].second;
                            Points pts;
                            build_variogram_declus(pts, dir, varmap_, i);
                            variograms_[dir_name].push_back(pts);
                        }
                        if (my_process_handler_) my_process_handler_
                            ->getNotifier()
                            ->nextStep();
                    }
            }
        }
    }
    delete varmap_;
}

void FFTVariogram_chart::clear_chart() {
    chart_variogram_widget_->chart()->ClearPlots();
}

void FFTVariogram_chart::build_plot() {
    for (int i = 1; i < table_variogram_->GetNumberOfColumns(); ++i) {
        if (gout_->getUI().line->isChecked()) {
            vtkPlotLine* plot_variog = vtkPlotLine::SafeDownCast(chart_variogram_widget_->chart()->AddPlot(vtkChart::LINE));
            plot_variog->SetInputData(table_variogram_, 0, i);
            plot_variog->SetColor(0.0, 1.0, 0.0);
        }
        if (gout_->getUI().point->isChecked()) {
            vtkPlotPoints* plot_variog = vtkPlotPoints::SafeDownCast(chart_variogram_widget_->chart()->AddPlot(vtkChart::POINTS));
            plot_variog->SetInputData(table_variogram_, 0, i);
            plot_variog->SetColor(0.0, 1.0, 0.0);
        }
    }
    chart_variogram_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Y(h)");
    chart_variogram_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle("Lags");
    //chart_variogram_widget_->chart()->SetAutoAxes(true);
    chart_variogram_widget_->chart()->SetVisible(true);
    chart_variogram_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));
    chart_variogram_widget_->chart()->Update();
    chart_variogram_widget_->update();
}

void FFTVariogram_chart::build_variogram_chart() {
    if (grid_ == 0) return;
    if (props_names_.size() == 0) return;
    QString title = QString(variogram_charts_names[this->chart_type_]).arg(grid_->name().c_str());
    if (compute_covariance_) title = "Covariance";
    else if (compute_variogram_) title = "Variogram";
    else if (compute_crosscovariance_) title = "Cross Covariance";
    else if (compute_crossvariogram_) title = "Cross variogram";
    this->setWindowTitle(title);
    this->setWindowIcon(QPixmap(":/icons/appli/Pixmaps/ar2gems-icon-256x256.png"));
    chart_variogram_widget_ = new Chart_widget(this);
    chart_variogram_control_ = new Chart_display_control( chart_variogram_widget_ );
    chart_variogram_widget_->set_controler(chart_variogram_control_);
    table_variogram_view_ = vtkSmartPointer<vtkQtTableView>::New();
    QVBoxLayout* variogram_layout = new QVBoxLayout(this);
    variogram_layout->addWidget(gout_);
    this->setLayout(variogram_layout);
    bool ok = connect(gout_->getUI().direction, SIGNAL(currentIndexChanged(const QString&)), this, SLOT(repaint_chart(const QString&)));
    ok = connect(gout_->getUI().line, SIGNAL(clicked()), this, SLOT(build_plot()));
    ok = connect(gout_->getUI().point, SIGNAL(clicked()), this, SLOT(build_plot()));
    this->build_value_table();
    this->build_plot();
    QTableView* table_variogram = dynamic_cast<QTableView*>(table_variogram_view_->GetWidget());
    qtable_variogram_ = table_variogram;
    ok = connect(
             table_variogram, SIGNAL(clicked(const QModelIndex &)),
             this, SLOT(cutoff_selected(const QModelIndex &)));
    gout_->getUI().graphViewer->addWidget(chart_variogram_widget_);
    gout_->getUI().graphControl->addWidget(chart_variogram_control_);
    gout_->getUI().tabWidget->addTab(table_variogram, "Data");
    ok = connect(gout_->getUI().saveFigureButton, SIGNAL(clicked()), chart_variogram_widget_, SLOT(save_figure()));
    ok = connect(gout_->getUI().saveReportButton, SIGNAL(clicked()), this, SLOT(save_report()));
    ok = connect(gout_->getUI().viewReportButton, SIGNAL(clicked()), this, SLOT(view_report()));
    ok = connect(gout_->getUI().clear, SIGNAL(clicked()), this, SLOT(clear_chart()));
    ok = connect(gout_->getUI().importGraphsButton, SIGNAL(clicked()), this, SLOT(import_graphs()));
    ok = connect(gout_->getUI().importModelButton, SIGNAL(clicked()), this, SLOT(import_model()));
    is_ok = true;
    this->show();
}

void FFTVariogram_chart::import_model() {
    QString filename =
        QFileDialog::getOpenFileName(this, "Load Variogram Model");
    if (filename == QString::null) return;
    // Open the file and put the content into a string (using a stringstream)
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        GsTLcerr << "Can't open file " << filename.toStdString().c_str() << "\n" << gstlIO::end;
        return;
    }
    QTextStream stream(&file);
    QString qstr = stream.readAll();
    QDomDocument doc;
    bool parsed = doc.setContent(qstr);
    appli_assert(parsed);
    QDomElement root_element = doc.documentElement();
    // Get the nugget value and the number of structures
    QString val = root_element.attribute("nugget");
    double nugget = String_Op::to_number<double>(val.toStdString());
    val = root_element.attribute("structures_count");
    int structures_count_ = val.toInt();
    Covariance<GsTLPoint> model;
    //  QDomElement elem = root_element;
    model.nugget(nugget);
    // work on each structure
    for (unsigned int i = 0; i < structures_count_; i++) {
        double r1, r2, r3;
        double a1, a2, a3;
        double sill;
        QString type;
        // Get the node describing the structure and initialize the contribution
        // and variogram type values
        QString id;
        id.setNum(i + 1);
        QString structure_tagname = "structure_" + id;
        QDomNodeList nodes = root_element.elementsByTagName(structure_tagname);
        if (nodes.count() == 0) {
            return;
        }
        QDomNode structure_node = nodes.item(0);
        QDomElement structure_elem = structure_node.toElement();
        val = structure_elem.attribute("contribution");
        sill = val.toFloat();
        type = structure_elem.attribute("type");
        // Get the ranges
        QDomNodeList ranges_node_list = structure_elem.elementsByTagName("ranges");
        if (ranges_node_list.count() == 0) {
            return;
        }
        QDomNode ranges_node = ranges_node_list.item(0);
        QDomElement ranges_elem = ranges_node.toElement();
        val = ranges_elem.attribute("max");
        r1 = val.toFloat();
        val = ranges_elem.attribute("medium");
        r2 = val.toFloat();
        val = ranges_elem.attribute("min");
        r3 = val.toFloat();
        // Get the angles
        QDomNodeList angles_node_list = structure_elem.elementsByTagName("angles");
        if (angles_node_list.count() == 0) {
            return;
        }
        QDomNode angles_node = angles_node_list.item(0);
        QDomElement angles_elem = angles_node.toElement();
        val = angles_elem.attribute("x");
        a1 = val.toFloat();
        val = angles_elem.attribute("y");
        a2 = val.toFloat();
        val = angles_elem.attribute("z");
        a3 = val.toFloat();
        unsigned int id_  = model.add_structure(type.toStdString());
        model.set_ranges(id_, r1, r2, r3);
        model.set_angles(id_, a1, a2, a3);
        model.sill(id_, sill);
    }
    GsTLPoint p1(0, 0, 0);
    std::string direction = gout_->getUI().direction->currentText().toStdString();
    Point3D dir = directions_[direction];
    vtkSmartPointer<vtkTable> table_values = vtkSmartPointer<vtkTable>::New();
    vtkSmartPointer<vtkFloatArray> x = vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray> y = vtkSmartPointer<vtkFloatArray>::New();
    x->SetName("Lag");
    y->SetName("Model");
    x->SetNumberOfValues(n_lags_);
    y->SetNumberOfValues(n_lags_);
    for (int i = 0; i < n_lags_; ++i) {
        GsTLPoint p2(p1.x() + dir.y * i, p1.y() + dir.x * i, p1.z() + dir.z * i);
        double v = 0;
        if (compute_covariance_) {
            v = model(p1, p2);
        } else if (compute_variogram_) {
            v = model.c0() - model(p1, p2);
        }
        GsTLVector<double> d = (p2 - p1);
        x->SetValue(i, euclidean_norm(d));
        y->SetValue(i, v);
    }
    table_values->AddColumn(x);
    table_values->AddColumn(y);
    for (int i = 1; i < table_values->GetNumberOfColumns(); ++i) {
        if (gout_->getUI().line->isChecked()) {
            vtkPlotLine* plot_variog = vtkPlotLine::SafeDownCast(chart_variogram_widget_->chart()->AddPlot(vtkChart::LINE));
            plot_variog->SetInputData(table_values, 0, i);
            plot_variog->SetWidth(5.0);
            plot_variog->SetColor(1.0, 0.0, 0.0);
        }
        if (gout_->getUI().point->isChecked()) {
            vtkPlotPoints* plot_variog = vtkPlotPoints::SafeDownCast(chart_variogram_widget_->chart()->AddPlot(vtkChart::POINTS));
            plot_variog->SetInputData(table_values, 0, i);
            plot_variog->SetWidth(5.0);
            plot_variog->SetColor(1.0, 0.0, 0.0);
        }
    }
    chart_variogram_widget_->update();
}

void FFTVariogram_chart::import_graphs() {
    QString file_name = QFileDialog::getOpenFileName(this, "Import graphs", "", tr("CSV Files (*.csv)"));
    if (file_name == "") return;
    ifstream fin(file_name.toStdString().c_str());
    if (fin.fail()) return;
    bool is_first = true;
    std::vector<std::string> titles;
    std::vector<std::vector<double> > data;
    size_t min_size = 0;
    while (!fin.eof()) {
        std::string line;
        std::getline(fin, line);
        std::vector<std::string> values = String_Op::decompose_string(line, ",");
        if (is_first) {
            is_first = false;
            titles = values;
            data.resize(values.size());
        } else {
            for (int i = 0; i < std::min(values.size(), data.size()); ++i) {
                double v = String_Op::to_number<double>(values[i]);
                data[i].push_back(v);
            }
        }
    }
    for (int i = 0; i < data.size(); ++i) {
        if (i == 0) {
            min_size = data[i].size();
        } else {
            min_size = std::min(min_size, data[i].size());
        }
    }
    std::vector<vtkSmartPointer<vtkFloatArray> > values(titles.size());
    vtkSmartPointer<vtkTable> table_values = vtkSmartPointer<vtkTable>::New();
    for (int i = 0; i < titles.size(); ++i) {
        values[i] = vtkSmartPointer<vtkFloatArray>::New();
        values[i]->SetName(titles[i].c_str());
        values[i]->SetNumberOfValues(min_size);
        for (int j = 0; j < min_size; ++j) {
            values[i]->SetValue(j, data[i][j]);
        }
        table_values->AddColumn(values[i]);
    }
    for (int i = 1; i < table_values->GetNumberOfColumns(); ++i) {
        if (gout_->getUI().line->isChecked()) {
            vtkPlotLine* plot_variog = vtkPlotLine::SafeDownCast(chart_variogram_widget_->chart()->AddPlot(vtkChart::LINE));
            plot_variog->SetInputData(table_values, 0, i);
            plot_variog->SetColor(0.0, 0.0, 1.0);
        }
        if (gout_->getUI().point->isChecked()) {
            vtkPlotPoints* plot_variog = vtkPlotPoints::SafeDownCast(chart_variogram_widget_->chart()->AddPlot(vtkChart::POINTS));
            plot_variog->SetInputData(table_values, 0, i);
            plot_variog->SetColor(0.0, 0.0, 1.0);
        }
    }
    fin.close();
    chart_variogram_widget_->update();
}


void FFTVariogram_chart::save_report() {
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save File"),
                       "report.csv",
                       tr("CSV Files (*.csv)"));
    if (fileName.size() > 0) {
        QString msg;
        QTextStream output(&msg);
        write_table_variogram(output);
        FILE* fout = fopen(fileName.toStdString().c_str(), "w+");
        fprintf(fout, "%s\n", msg.toStdString().c_str());
        fclose(fout);
    }
}

void FFTVariogram_chart::view_report() {
    FFT_report* report = new FFT_report(0);
    QString msg;
    QTextStream output(&msg, QIODevice::WriteOnly);
    write_table_variogram(output);
    report->setText(msg);
    report->show();
}

void FFTVariogram_chart::write_table_variogram(QTextStream& out) {
    int nr = this->table_variogram_->GetNumberOfRows();
    int nc = this->table_variogram_->GetNumberOfColumns();
    for (int i = 0; i < nc; ++i) {
        if (i > 0) out << ", ";
        out << "\"" << QString(this->table_variogram_->GetColumnName(i)) << "\"";
    }
    out << "\n";
    for (int j = 0; j < nr; ++j) {
        for (int k = 0; k < nc; ++k) {
            if (k > 0) out << ", ";
            out << this->table_variogram_->GetValue(j, k).ToDouble();
        }
        out << "\n";
    }
}
