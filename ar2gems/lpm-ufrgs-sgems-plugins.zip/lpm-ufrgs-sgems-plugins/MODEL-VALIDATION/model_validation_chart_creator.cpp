/*
Implementa��o do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "model_validation_chart_creator.h"
#include "model_validation_chart.h"

ModelValidation_chart_creator::ModelValidation_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent)
    : Chart_creator(mdi_area, parent) {
    QTabWidget* ModelValidation_Widget = new QTabWidget(this);
    my_model_validation_ = this->build_model_validation_page();
    ModelValidation_Widget->addTab(my_model_validation_, QIcon(), "Model Validation");
    ModelValidation_Widget->show();
    //my_histogram_->show();
    QVBoxLayout* main_layout = new QVBoxLayout(this);
    main_layout->setContentsMargins(0, 0, 0, 0);
    main_layout->addWidget(ModelValidation_Widget);
    this->setLayout(main_layout);
    bool ok = connect(my_model_validation_->getDisplayButton(), SIGNAL(clicked()),
                      this, SLOT(show_chart_model_validation()));
}

ModelValidation_chart_creator::~ModelValidation_chart_creator() {
}

void ModelValidation_chart_creator::kill_process(ModelValidationProcess* process) {
    ModelValidation_chart* chart = static_cast<ModelValidation_chart*>(process->getAction());
    if (process->isOk()) {
        chart->build_model_validation_chart();
        QMdiSubWindow* sub_window = mdi_area_->addSubWindow(chart);
        sub_window->setAttribute(Qt::WA_DeleteOnClose);
        sub_window->showMaximized();
    } else {
        delete chart;
    }
    if (process) delete process;
}

void ModelValidation_chart_creator::create_model_validation_process(ModelValidationAction* chart, int n_steps, int n_threads) {
    ModelValidationProcess* process = new ModelValidationProcess(
        chart,
        new ModelValidationProgressDialog(n_steps),
        n_threads);
    QObject::connect(
        process, SIGNAL(killMe(ModelValidationProcess*)),
        this, SLOT(kill_process(ModelValidationProcess*)));
    process->getNotifier()->show();
    process->start();
}

void ModelValidation_chart_creator::show_chart_model_validation() {
    int nprops = my_model_validation_->getProperties().size();
    if (my_model_validation_->getGrid() != 0 &&
            nprops > 0) {
        ModelValidation_chart* chart = new  ModelValidation_chart(
            my_model_validation_,
            0);
        create_model_validation_process(chart, nprops, my_model_validation_->getNumberThreads());
    }
}


ModelValidation* ModelValidation_chart_creator::build_model_validation_page() {
    return new ModelValidation(0);
}

