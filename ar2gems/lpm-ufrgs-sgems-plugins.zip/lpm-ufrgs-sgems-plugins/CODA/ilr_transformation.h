/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#ifndef PLUGINS_LPM_UFRGS_ILR_TRANSFORMATION_H_
#define PLUGINS_LPM_UFRGS_ILR_TRANSFORMATION_H_

#include "common.h"

#include <common.h>
#include <appli/action.h>
#include <grid/grid_property.h>
#include <grid/geostat_grid.h>
#include <utils/named_interface.h>

class PLUGINS_LPM_UFRGS_DECL ILR_Transformation :  public Action {
  public:
    static Named_interface* create_new_interface(std::string&);

    virtual ~ILR_Transformation() {}
    virtual bool init(std::string& parameters, GsTL_project* proj,
                      Error_messages_handler* errors = 0, Progress_notifier* notifier = 0);
    virtual bool exec(Progress_notifier* notifier = 0);

    void set_constant(const double& v) {
        closure_const = v;
    }

    void set_prop_name(std::string& name) {
        prop_name = name;
    }

  private :

    std::string prop_name;
    double closure_const;

    Geostat_grid* grid_;
    std::vector<Grid_continuous_property*> props_;
    std::vector<Grid_continuous_property*> ILR_props_;
    std::vector<std::string> prop_names;
};

#endif // PLUGINS_LPM_UFRGS_ILR_TRANSFORMATION_H_
