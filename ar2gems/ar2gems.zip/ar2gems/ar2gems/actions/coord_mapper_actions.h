/* -----------------------------------------------------------------------------
** Copyright (c) 2012 Advanced Resources and Risk Technology, LLC
** All rights reserved.
**
** This file is part of Advanced Resources and Risk Technology, LLC (AR2TECH) 
** version of the open source software sgems.  It is a derivative work by 
** AR2TECH (THE LICENSOR) based on the x-free license granted in the original 
** version of the software (see notice below) and now sublicensed such that it 
** cannot be distributed or modified without the explicit and written permission 
** of AR2TECH.
**
** Only AR2TECH can modify, alter or revoke the licensing terms for this 
** file/software.
**
** This file cannot be modified or distributed without the explicit and written 
** consent of AR2TECH.
**
** Contact Dr. Alex Boucher (aboucher@ar2tech.com) for any questions regarding
** the licensing of this file/software
**
** The open-source version of sgems can be downloaded at 
** sourceforge.net/projects/sgems.
** ----------------------------------------------------------------------------*/


#ifndef __COORD_MAPPER_ACTIONS_H__ 
#define __COORD_MAPPER_ACTIONS_H__ 
 
#include <grid/sgrid_cursor.h>
#include <grid/rgrid_geometry.h>


#include <actions/common.h>
#include <appli/action.h> 
#include <grid/geostat_grid.h> 
#include <grid/rgrid.h> 

#include <qstring.h>
#include <string> 
#include <set>
 
; 
class GsTL_project; 
class Error_messages_handler;

 

class ACTIONS_DECL Coord_mapper_set_uvw : public Action { 
 public: 
   static Named_interface* create_new_interface( std::string& );
//  Coord_mapper_set_uvw(): grid_(0),region_(0),initial_property_(0),tiebroken_property_(0) {}
  virtual ~Coord_mapper_set_uvw() {}
  virtual bool init( std::string& parameters, GsTL_project* proj,
                     Error_messages_handler* errors,
                     Progress_notifier* notifier = 0); 
  virtual bool exec(Progress_notifier* notifier = 0); 

protected: 
  Grid_continuous_property* prop_u_;
  Grid_continuous_property* prop_v_;
  Grid_continuous_property* prop_w_;
  Geostat_grid* grid_;

}; 


class ACTIONS_DECL Coord_mapper_set_to_xyz : public Action { 
 public: 
   static Named_interface* create_new_interface( std::string& );
//  Coord_mapper_set_uvw(): grid_(0),region_(0),initial_property_(0),tiebroken_property_(0) {}
  virtual ~Coord_mapper_set_to_xyz() {}
  virtual bool init( std::string& parameters, GsTL_project* proj,
                     Error_messages_handler* errors,
                     Progress_notifier* notifier = 0); 
  virtual bool exec(Progress_notifier* notifier = 0); 

protected: 
  Geostat_grid* grid_;

}; 



#endif 
