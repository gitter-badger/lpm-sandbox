/*
Implementa��o do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_ACCPLOT_CHART_CREATOR_H___ 
#define __PLUGINS_LPM_UFRGS_ACCPLOT_CHART_CREATOR_H___

#include "common.h"

#include <charts/chart_widget.h>
#include <charts/chart_creator.h>
#include <charts/chart_mdi_area.h>
#include <qtplugins/selectors.h>
#include <qtplugins/categorical_selectors.h>
#include <grid/grid_filter.h>

#include <QDialog>
#include <QMainWindow>
#include <QItemSelectionModel>
#include <QLineEdit>
#include <QDoubleSpinBox>
#include <QRadioButton>

#include <map>

#include "accplot.h"

#include "accplotprocess.h"


class PLUGINS_LPM_UFRGS_DECL AccPlot_chart_creator : public Chart_creator
{
	Q_OBJECT

public:
	AccPlot_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent = 0);
	~AccPlot_chart_creator();

private slots:
	void kill_process(AccPlotProcess*);

	void show_chart_accplot();

	void create_accplot_process(AccPlotAction* chart, int n_steps, int n_threads);

    AccPlot* getAccPlot() { return my_accplot_;  }

private:

    AccPlot* build_accplot_page();


    AccPlot* my_accplot_;
};

class PLUGINS_LPM_UFRGS_DECL AccPlot_chart_creator_factory : public Chart_creator_factory
{

public:

	static Named_interface* create_new_interface(std::string&) {
		return new AccPlot_chart_creator_factory;
	}

	AccPlot_chart_creator_factory(){}
	~AccPlot_chart_creator_factory(){}

	virtual QString title_name() const { return "Accuracy Plot"; }
	virtual QString tab_name() const{ return "LPM_UFRGS"; }
	std::string name() const { return "Accuracy Plot"; }

	virtual Chart_creator* get_interface(Chart_mdi_area* mdi_area){ return new AccPlot_chart_creator(mdi_area); }

};


#endif
