/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_FFTVARMAP_H___
#define __PLUGINS_LPM_UFRGS_FFTVARMAP_H___

#include <qmessagebox.h>
#include <qthread.h>

#include <geostat/common.h>
#include <geostat/geostat_algo.h>
#include <geostat/utilities.h>
#include <grid/geostat_grid.h>
#include <grid/property_copier.h>

#include <grid/two_point_statistics.h>
#include <geostat/kriging_system.h>
#include <geostat/kriging_constraint.h>
#include <geostat/gaussian_cdf_kestimator.h>

//#include <GsTL/geometry/covariance.h>
#include <GsTL/cdf/non_param_cdf.h>
//#include <GsTL/kriging/kriging_constraints.h>
//#include <GsTL/kriging/kriging_combiner.h>
#include <GsTL/utils/smartptr.h>
#include <string>
#include <geostat/parameters_handler_impl.h>
#include <QDomDocument>

#include <qtimer.h>
#include <QTime>
#include <qtextstream.h>
#include <qmessagebox.h>

#include <geostat/sgsim.h>
#include <geostat/parameters_handler.h>
#include <geostat/utilities.h>
#include <utils/gstl_messages.h>
#include <utils/error_messages_handler.h>
#include <utils/string_manipulation.h>
#include <grid/geostat_grid.h>
#include <grid/combined_neighborhood.h>
#include <grid/gval_iterator.h>
#include <grid/cartesian_grid.h>
#include <grid/point_set.h>
#include <grid/grid_path.h>
#include <utils/manager_repository.h>
//#include <math/random_numbers.h>
#include <GsTL/math/random_number_generators.h>
#include <appli/utilities.h>

#include <grid/utilities.h>

#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>

#include <geostat/sequential_simulation.h>
#include <geostat/kriging_constraint.h>
#include <math/continuous_distribution.h>
#include <math/non_parametric_distribution.h>


#include <GsTL/cdf/gaussian_cdf.h>
#include <GsTL/sampler/monte_carlo_sampler.h>
#include <GsTL/univariate_stats/cdf_transform.h>
#include <GsTL/univariate_stats/build_cdf.h>

#include <grid/point_set_neighborhood.h>

#include <qmutex.h>

#include <iterator>
#include <vector>
#include <algorithm>
#include <fstream>

#include <grid/reduced_grid.h>


#include "common.h"

#include "fftvarmapcalc.h"
#include "fftvarmaputils.h"


class PLUGINS_LPM_UFRGS_DECL FFTVarmap : public Geostat_algo {
  public:
    FFTVarmap();
    ~FFTVarmap();

    virtual bool initialize( const Parameters_handler* parameters,
                             Error_messages_handler* errors,
                             Progress_notifier* notifier = 0);
    virtual int execute( GsTL_project* proj=0, Progress_notifier* notifier = 0 );
    virtual std::string name() const {
        return "fftvarmap";
    }

  public:
    static Named_interface* create_new_interface( std::string& );

  protected:
    int n_threads_;

    std::string input_grid_name_;
    std::string output_grid_name_;
    std::string varmap_name_;

    Geostat_grid* input_grid_;
    Geostat_grid* output_grid_;

    std::vector<std::string> props_;

    double lag_x_, lag_y_, lag_z_;
};

class PLUGINS_LPM_UFRGS_DECL FFTVarmap_declus : public Geostat_algo {
  public:
    FFTVarmap_declus();
    ~FFTVarmap_declus();

    virtual bool initialize(const Parameters_handler* parameters,
                            Error_messages_handler* errors,
                            Progress_notifier* notifier = 0);
    virtual int execute(GsTL_project* proj = 0, Progress_notifier* notifier = 0);
    virtual std::string name() const {
        return "fftvarmap_declus";
    }

  public:
    static Named_interface* create_new_interface(std::string&);

  protected:
    int n_threads_;

    std::string input_grid_name_;
    std::string output_grid_name_;
    std::string varmap_name_;
    std::string weigth_name_;

    Geostat_grid* input_grid_;
    Geostat_grid* output_grid_;

    std::vector<std::string> props_;

    double lag_x_, lag_y_, lag_z_;
};


#endif
