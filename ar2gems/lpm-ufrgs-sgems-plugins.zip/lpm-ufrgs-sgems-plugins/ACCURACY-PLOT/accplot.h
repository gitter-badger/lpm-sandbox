/*
Implementa��o do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/

#ifndef __PLUGINS_LPM_UFRGS_ACCPLOT_H___ 
#define __PLUGINS_LPM_UFRGS_ACCPLOT_H___

#include "common.h"

#include <qstring.h>
#include <qstringlist.h>
#include <QFrame>

#include "ui_accplot.h"

class AccPlot : public QFrame
{
	Q_OBJECT

public:
    AccPlot(QWidget *parent = 0);
    ~AccPlot();

	int getNumberBins();
	int getNumberThreads();

	double getPrecision();

	QPushButton* getDisplayButton();

	QStringList getProperties();
	QString getReferenceProperty();

	Geostat_grid* getGrid();
	
	bool computeAverageWidth();

    Ui::AccPlot& getUi() { return ui; }

private:	
    Ui::AccPlot ui;
};

#endif

