/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftcrossvarmap.h"

#include <array>
#include <cmath>


typedef Const_geovalue::location_type loc_point;

int FFTCrossVarmap::execute(GsTL_project*, Progress_notifier* notifier) {
    double dx = this->lag_x_, dy = this->lag_y_, dz = this->lag_z_;
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    for (size_t i = 0; i < input_grid_->size(); ++i) {
        double x = input_grid_->xyz_location(i).x();
        double y = input_grid_->xyz_location(i).y();
        double z = input_grid_->xyz_location(i).z();
        if (i == 0) {
            xmin = xmax = x;
            ymin = ymax = y;
            zmin = zmax = z;
        } else {
            if (x < xmin) {
                xmin = x;
            } else if (x > xmax) {
                xmax = x;
            }
            if (y < ymin) {
                ymin = y;
            } else if (y > ymax) {
                ymax = y;
            }
            if (z < zmin) {
                zmin = z;
            } else if (z > zmax) {
                zmax = z;
            }
        }
    }
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    for (size_t i = 0; i < props1_.size(); ++i) {
        std::string prop_name = varmap_name_ + "_" + props1_.at(i) + "X" + props2_.at(i);
        Grid_continuous_property* p1 = input_grid_->property(props1_.at(i));
        Grid_continuous_property* p2 = input_grid_->property(props2_.at(i));
        Grid_continuous_property* pout = output_grid_->add_property(prop_name);
        Grid_continuous_property* pout_np = output_grid_->add_property(prop_name + "_np");
        if (!p1 || !p2 || !pout) {
            return 1;
        }
        if (notifier) {
            notifier->write("Working on variogram <" + prop_name + ">", 0);
            if (!notifier->notify()) {
                return 1;
            }
            while (notifier->is_paused()) {
                notifier->write("Paused", 0);
            }
        }
        if (!compute_crossvarmap(
                    input_grid_, output_grid_, p1, p2, pout, pout_np,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax))  return 1;
    }
    return 0;
}


bool FFTCrossVarmap::initialize(const Parameters_handler* parameters,
                                Error_messages_handler* errors, Progress_notifier* notifier) {
    input_grid_name_ = parameters->value("grid.value");
    output_grid_name_ = parameters->value("varmap_grid.value");
    varmap_name_ = parameters->value("varmap_name.value");
    n_threads_ = String_Op::to_number<int>(parameters->value("nthreads.value"));
    fft_set_num_threads(n_threads_);
    lag_x_ = String_Op::to_number<double>(parameters->value("lag_x.value"));
    lag_y_ = String_Op::to_number<double>(parameters->value("lag_y.value"));
    lag_z_ = String_Op::to_number<double>(parameters->value("lag_z.value"));
    std::string props1 = parameters->value("props1.value");
    props1_ = String_Op::decompose_string(props1, ";");
    std::string props2 = parameters->value("props2.value");
    props2_ = String_Op::decompose_string(props2, ";");
    if (notifier) {
        notifier->total_steps(props1_.size());
        notifier->frequency(1);
    }
    if (props1_.size() != props2_.size()) {
        errors->report(props1_.size() != props2_.size(), "props1", "It's necessary select the same number of properties.");
        errors->report(props1_.size() != props2_.size(), "props2", "It's necessary select the same number of properties.");
        return false;
    }
    if (props1_.size() < 1) {
        errors->report(props1_.size() < 1, "props1", "No property selected");
        return false;
    }
    if (output_grid_name_.empty()) {
        errors->report(output_grid_name_.empty(),
                       "varmap_name", "No varmap grid selected");
        return false;
    } else {
        output_grid_ = get_grid_from_manager(output_grid_name_);
        if (!output_grid_) {
            return false;
        }
    }
    if (!input_grid_name_.empty()) {
        input_grid_ = get_grid_from_manager(input_grid_name_);
        if (!input_grid_) {
            return false;
        }
    } else {
        errors->report(input_grid_name_.empty(),
                       "grid", "No input grid selected");
        return false;
    }
    return true;
}


Named_interface* FFTCrossVarmap::create_new_interface(std::string&) {
    return new FFTCrossVarmap;
}


FFTCrossVarmap::FFTCrossVarmap() {
}


FFTCrossVarmap::~FFTCrossVarmap() {
}

///////////////////////////////////////////////////////////////////////////////

int FFTCrossVarmap_declus::execute(GsTL_project*, Progress_notifier* notifier) {
    double dx = this->lag_x_, dy = this->lag_y_, dz = this->lag_z_;
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    for (size_t i = 0; i < input_grid_->size(); ++i) {
        double x = input_grid_->xyz_location(i).x();
        double y = input_grid_->xyz_location(i).y();
        double z = input_grid_->xyz_location(i).z();
        if (i == 0) {
            xmin = xmax = x;
            ymin = ymax = y;
            zmin = zmax = z;
        } else {
            if (x < xmin) {
                xmin = x;
            } else if (x > xmax) {
                xmax = x;
            }
            if (y < ymin) {
                ymin = y;
            } else if (y > ymax) {
                ymax = y;
            }
            if (z < zmin) {
                zmin = z;
            } else if (z > zmax) {
                zmax = z;
            }
        }
    }
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    Grid_continuous_property* w1 = input_grid_->property(weigth1_);
    for (size_t i = 0; i < props1_.size(); ++i) {
        std::string prop_name = varmap_name_ + "_" + props1_.at(i) + "X" + props2_.at(i);
        Grid_continuous_property* p1 = input_grid_->property(props1_.at(i));
        Grid_continuous_property* p2 = input_grid_->property(props2_.at(i));
        Grid_continuous_property* pout = output_grid_->add_property(prop_name);
        Grid_continuous_property* pout_np = output_grid_->add_property(prop_name + "_np");
        if (!p1 || !p2 || !pout || !w1) {
            return 1;
        }
        if (notifier) {
            notifier->write("Working on variogram <" + prop_name + ">", 0);
            if (!notifier->notify()) {
                return 1;
            }
            while (notifier->is_paused()) {
                notifier->write("Paused", 0);
            }
        }
        if (!compute_crossvarmap_declus(
                    input_grid_, output_grid_, w1, p1, p2, pout, pout_np,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax))  return 1;
    }
    return 0;
}


bool FFTCrossVarmap_declus::initialize(const Parameters_handler* parameters,
                                       Error_messages_handler* errors, Progress_notifier* notifier) {
    input_grid_name_ = parameters->value("grid.value");
    output_grid_name_ = parameters->value("varmap_grid.value");
    varmap_name_ = parameters->value("varmap_name.value");
    weigth1_ = parameters->value("weigth.value");
    n_threads_ = String_Op::to_number<int>(parameters->value("nthreads.value"));
    fft_set_num_threads(n_threads_);
    lag_x_ = String_Op::to_number<double>(parameters->value("lag_x.value"));
    lag_y_ = String_Op::to_number<double>(parameters->value("lag_y.value"));
    lag_z_ = String_Op::to_number<double>(parameters->value("lag_z.value"));
    std::string props1 = parameters->value("props1.value");
    props1_ = String_Op::decompose_string(props1, ";");
    std::string props2 = parameters->value("props2.value");
    props2_ = String_Op::decompose_string(props2, ";");
    if (notifier) {
        notifier->total_steps(props1_.size());
        notifier->frequency(1);
    }
    if (props1_.size() != props2_.size()) {
        errors->report(props1_.size() != props2_.size(), "props1", "It's necessary select the same number of properties.");
        errors->report(props1_.size() != props2_.size(), "props2", "It's necessary select the same number of properties.");
        return false;
    }
    if (props1_.size() < 1) {
        errors->report(props1_.size() < 1, "props1", "No property selected");
        return false;
    }
    if (output_grid_name_.empty()) {
        errors->report(output_grid_name_.empty(),
                       "varmap_name", "No varmap grid selected");
        return false;
    } else {
        output_grid_ = get_grid_from_manager(output_grid_name_);
        if (!output_grid_) {
            return false;
        }
    }
    if (!input_grid_name_.empty()) {
        input_grid_ = get_grid_from_manager(input_grid_name_);
        if (!input_grid_) {
            return false;
        }
    } else {
        errors->report(input_grid_name_.empty(),
                       "grid", "No input grid selected");
        return false;
    }
    return true;
}


Named_interface* FFTCrossVarmap_declus::create_new_interface(std::string&) {
    return new FFTCrossVarmap_declus;
}


FFTCrossVarmap_declus::FFTCrossVarmap_declus() {
}


FFTCrossVarmap_declus::~FFTCrossVarmap_declus() {
}


