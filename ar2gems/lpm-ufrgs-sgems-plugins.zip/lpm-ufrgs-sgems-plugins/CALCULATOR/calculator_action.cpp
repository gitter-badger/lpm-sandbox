/*
Implementação do plugin que efetua transformações nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/


#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <map>

#include "calculator_action.h"
#include "calculator_algorithms.h"


#include "Expression.h"

#include <utils/string_manipulation.h>
#include <grid/utilities.h>
#include <gui/utils/task_manager.h>


#include <QTextStream>



Named_interface* CalculatorHandling::create_new_interface( std::string& )
{
	return new CalculatorHandling;
}

// MODELVALIDATION gridName::res_prop::prop1::prop2[::prop3::propN]
bool CalculatorHandling::init(std::string& parameters, GsTL_project* proj, Error_messages_handler* errors, Progress_notifier* notifier)
{

    std::vector<std::string> params = String_Op::decompose_string(parameters, "|", Actions::unique);
	
	this->result = params[0];
	this->cmd = params[1];
	this->grid_name = params[2];
	this->props = params[3];

	this->grid = get_grid_from_manager(this->grid_name);

	if (!this->grid) {
		return false;
	}
	
	Grid_continuous_property* p = grid->add_property(this->result);
	if (p == 0) {
		p = grid->property(this->result);
		if(p == 0) {
			errors->report( "Could not create the property " + this->result);
			return false;
		}
	} 
	this->result_prop = p;

	std::vector<std::string> vp = String_Op::decompose_string(props, ";", Actions::unique);

	this->n_props = 0;

	for (int i = 0; i < vp.size(); ++i) {
		Grid_continuous_property* prop = grid->property(vp[i]);
		if (prop == 0) {
			errors->report("The property " + vp[i] + " does not exist" );
			return false;
		}
		this->prop_map[vp[i]] = prop;

		if (prop->size() > this->n_props) {
			this->n_props = prop->size();
		}
	}

	return true;
}


bool CalculatorHandling::exec(Progress_notifier* notifier) 
{
	QString s_r;
	QTextStream out(&s_r, QIODevice::ReadWrite);


	/*Evaluate expression*/
	out << "Evaluation result:\n";
	SExpression *e = NULL;
	char* test = const_cast<char*>(cmd.c_str());
	double result = 0;
 
	e = getAST(test);

	if (e) {
		for (size_t i = 0; i < this->n_props; ++i) {

            for (MapVar::iterator it = prop_map.begin();
                 it != prop_map.end();
                 ++it) {
                std::cout << it->first << "->" << it->second->get_value(i) << endl;
            }

			result = evaluate(e, &(this->prop_map), i, out, this->n_props);

			if (result < INF) {
                this->result_prop->set_value(result, i);
			}
		}
	} else {
		out << "Parser error!\n";
	}

	deleteExpression(e);



	/*Evaluation report*/
	out << "_________________________________________________\n";
	out << "Number of properties = " << prop_map.size() << "\n";
	out << "Result property name = " << this->result.c_str() << "\n";
	out << "Grid name = " << grid_name.c_str() << "\n";
	out << "Props = " << props.c_str() << "\n";

    cout << s_r.toLatin1().data() << endl;

	/*Output result evaluation*/

    calc_report->write(s_r);
    //if (notifier->getParent() != 0) {
        //notifier->write(s_r.toAscii().data(), 0);
    //}
    /*

    calc_report->setReport(s_r);
    */

	return true;
}

