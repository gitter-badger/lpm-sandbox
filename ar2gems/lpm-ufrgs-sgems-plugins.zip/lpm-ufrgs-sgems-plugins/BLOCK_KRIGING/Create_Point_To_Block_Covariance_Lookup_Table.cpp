# include "Covariance_Point_Point.h"
# include "Covariance_Point_Block.h"
# include "Create_Point_To_Block_Covariance_Lookup_Table.h"
# include <vector>

using namespace std;
typedef Geostat_grid::location_type Location;

vector<vector<double> > Create_Point_To_Block_Covariance_Lookup_Table(Geostat_grid *point_i_grid, Geostat_grid *Block_Centroids_Point_Set, Geostat_grid *block_j_grid, const  Two_point_nested_structure &covar_, const std::map<int, Struct_Block> &Map_ID_Blocks){

	vector<vector<double> > Point_To_Block_Covariance_Lookup_Table;
	

	for (size_t i = 0; i < point_i_grid->size(); ++i){
		vector<double> Point_To_Block_Covariance_Lookup_Table_Row;

		for (size_t j = 0; j < Block_Centroids_Point_Set->size(); ++j){
			int Block_ID = Block_Centroids_Point_Set->property("Block_ID")->get_value(j);

			vector<vector<double> > Block_j;

			for (size_t k = 0; k < Map_ID_Blocks.at(Block_ID).X_Locations.size(); ++k){
					vector<double> row;

					row.push_back(Map_ID_Blocks.at(Block_ID).X_Locations[k]);
					row.push_back(Map_ID_Blocks.at(Block_ID).Y_Locations[k]);
					row.push_back(Map_ID_Blocks.at(Block_ID).Z_Locations[k]);
					row.push_back(Map_ID_Blocks.at(Block_ID).Block_Value);
					row.push_back(Map_ID_Blocks.at(Block_ID).node_id[k]);

					Block_j.push_back(row);
			}
						
			double Point_i_To_Block_j_Covariance = Covariance_Point_Block(point_i_grid, i, block_j_grid, Block_j, covar_);
			Point_To_Block_Covariance_Lookup_Table_Row.push_back(Point_i_To_Block_j_Covariance);
		}
		Point_To_Block_Covariance_Lookup_Table.push_back(Point_To_Block_Covariance_Lookup_Table_Row);
		
	}

	return Point_To_Block_Covariance_Lookup_Table;
	

};