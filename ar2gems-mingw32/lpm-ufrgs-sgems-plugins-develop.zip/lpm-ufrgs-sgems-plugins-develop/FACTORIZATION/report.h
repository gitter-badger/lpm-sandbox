/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/


#ifndef FACTORIZATION_REPORT_H_
#define FACTORIZATION_REPORT_H_

#include "common.h"
#include <QDialog>
#include <QMainWindow>
#include <QCloseEvent>
#include <ui_report.h>


class FACTORIZATION_report : public QDialog {
    Q_OBJECT

  public:
    FACTORIZATION_report(QWidget *parent = 0);
    ~FACTORIZATION_report();

    void write(QString msg) {
        emit setText(msg);
    }

  signals:
    void setText(QString text);
  public slots:
    void setReport(QString text) {
        this->ui.report_text->setText(text);
        this->show();
    }


  private:

    Ui::Report ui;
};

#endif /* LPM_REPORT_H_ */
