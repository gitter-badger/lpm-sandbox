/*
Implementação do plugin BLENDSIM.

(c) 2013, LPM/UFRGS, Roberto Menin, Péricles Lopes Machado
*/

#include "common.h"
#include "blendsim_chart_creator.h"
#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>

extern "C" PLUGINS_LPM_UFRGS_DECL
int plugin_init() {
	SmartPtr<Named_interface> ni = Root::instance()->interface( eda_charts_manager );
	Manager* dir = dynamic_cast<Manager*>( ni.raw_ptr() );
	if( !dir ) {
		GsTLlog << "Directory " << eda_charts_manager << " does not exist \n";
		return 1;
	}

	dir->factory( Blendsim_chart_creator_factory().name(), 
				  Blendsim_chart_creator_factory::create_new_interface);

	return 0;
}
