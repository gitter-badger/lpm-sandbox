/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#ifndef PLUGINS_LPM_UFRGS_COMMON_H_
#define PLUGINS_LPM_UFRGS_COMMON_H_

#include <string>

#if defined(_WIN32) || defined(WIN32)
  #ifdef LIB_STATIC
    #define PLUGINS_LPM_UFRGS_DECL
  #else
    #ifdef PLUGINS_LPM_UFRGS_EXPORT
      #define PLUGINS_LPM_UFRGS_DECL __declspec(dllexport)
    #else
      #define PLUGINS_LPM_UFRGS_DECL __declspec(dllimport)
    #endif
  #endif
#else
    #define PLUGINS_LPM_UFRGS_DECL
    using std::size_t;
#endif

#include <cstring>

namespace LPM_UFRGS {
	inline std::string to_string(int i)
	{
		char buffer[100];
		sprintf(buffer, "%02d", i);
		
		return buffer;
	}
}



#endif // PLUGINS_LPM_UFRGS_COMMON_H_
