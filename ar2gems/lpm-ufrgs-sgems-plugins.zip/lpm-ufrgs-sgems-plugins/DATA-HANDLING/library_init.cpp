/*
Implementação do plugin que efetua transformações nos dados.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado & Luiz Gustavo Rasera
*/

#include "common.h"

#include "data_handling_action.h"

#include "data_handling_algorithms.h"

#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>

extern "C" PLUGINS_LPM_UFRGS_DECL
int plugin_init() 
{
	// ACTIONS
	GsTLlog << "\n\n registering action data_handling" << "\n";
	SmartPtr<Named_interface> ni = Root::instance()->interface(actions_manager);
	Manager* dir = dynamic_cast<Manager*>(ni.raw_ptr());
	
	if(!dir) {
		GsTLlog << "Directory " << actions_manager << " does not exist \n";
		return 1;
	}

	dir->factory("LPM_DATA_HANDLING", DataHandling::create_new_interface);
	
	// ALGORITHMS
	GsTLlog << "\n\n registering data_handling Algorithms" << "\n";
	ni = Root::instance()->interface(geostatAlgo_manager);
	dir = dynamic_cast<Manager*>(ni.raw_ptr());
	if( !dir ) {
		GsTLlog << "Directory " << geostatAlgo_manager << " does not exist \n";
		return 1;
	}
	dir->factory(DataHandlingAlgorithms().name(),DataHandlingAlgorithms::create_new_interface);
	

	return 0;
}
