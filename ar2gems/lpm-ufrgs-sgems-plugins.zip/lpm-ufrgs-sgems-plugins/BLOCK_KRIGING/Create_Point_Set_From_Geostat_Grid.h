# ifndef CREATE_POINT_SET_FROM_GEOSTAT_GRID_H
# define CREATE_POINT_SET_FROM_GEOSTAT_GRID_H
# include <grid/point_set.h>
# include <map>
# include <vector>
# include <grid/point_set.h>
# include <math/gstlpoint.h>

bool Create_Point_Set_From_Geostat_Grid(Point_set *&Block_Locations_Point_Set, Geostat_grid * &Block_Locations, Grid_continuous_property *&Block_Sample_Values, Grid_continuous_property *&Block_Sample_ID);

#endif