/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/

#include "factorization_algorithms.h"

#include "pca_transformation.h"
#include "maf_transformation.h"

#include <geostat/utilities.h>
#include <utils/string_manipulation.h>
#include <grid/utilities.h>
#include <grid/neighbors.h>
#include <geostat/utilities.h>

#include <qstring.h>
#include <qmessagebox.h>
#include <cstdio>

FactorizationAlgorithms::FactorizationAlgorithms() 
{
}

FactorizationAlgorithms::~FactorizationAlgorithms() 
{
}

Named_interface* FactorizationAlgorithms::create_new_interface(std::string&) 
{
	return new FactorizationAlgorithms;
}

bool FactorizationAlgorithms::initialize(const Parameters_handler* parameters,
								   Error_messages_handler* errors, Progress_notifier* notifier) 
{
	this->errors_ = errors;

	// Set algorithm type
	bool Ev_option = String_Op::to_number<bool>(parameters->value("Ev_option.value"));
	bool Inverse_option = String_Op::to_number<bool>(parameters->value("Inverse_option.value"));
	
	bool PCA_option = String_Op::to_number<bool>(parameters->value("PCA_option.value"));
	bool MAF_option = String_Op::to_number<bool>(parameters->value("MAF_option.value"));

	this->algorithm_type_ = LPM_UFRGS::Factorization_Algorithm_Type::PCA;
	if (PCA_option) {
		if (Inverse_option) {
			this->algorithm_type_ = LPM_UFRGS::Factorization_Algorithm_Type::INV_PCA;
		} else {
			this->algorithm_type_ = LPM_UFRGS::Factorization_Algorithm_Type::PCA;
		}
	} else if (MAF_option) {
		if (Inverse_option) {
			this->algorithm_type_ = LPM_UFRGS::Factorization_Algorithm_Type::INV_MAF;
		} else {
			this->algorithm_type_ = LPM_UFRGS::Factorization_Algorithm_Type::MAF;
		}
	}

	
	// Set grid and properties to build the transformation
	std::string grid_name = parameters->value("grid_selector.value");
	errors->report(grid_name.empty(), "grid_selector", "No grid selected");
	
	std::string props = parameters->value("factorization_properties.value");
	std::vector<std::string> vprops = String_Op::decompose_string(props, ";");

	if (Inverse_option) {
		std::string grid_input_name = parameters->value("input_grid.value");
		errors->report(grid_input_name.empty(), "input_grid", "No grid selected");

		std::string input_props = parameters->value("input_properties.value");
		std::vector<std::string> vprops = String_Op::decompose_string(input_props, ";");

		this->params_input = grid_input_name;
		for (size_t i = 0; i < vprops.size(); ++i) {
			this->params_input  += "::" + vprops[i];
		}
	}


	this->params = grid_name;
	for (size_t i = 0; i < vprops.size(); ++i) {
		this->params  += "::" + vprops[i];
	}

	switch (this->algorithm_type_) {
		/*PCA and INV_PCA*/
		case LPM_UFRGS::Factorization_Algorithm_Type::PCA :
		case LPM_UFRGS::Factorization_Algorithm_Type::INV_PCA:
			this->action_ = new PCA_Transformation();

			static_cast<PCA_Transformation*>(this->action_)->show_ev(Ev_option);
			return static_cast<PCA_Transformation*>(this->action_)->init(this->params, 0, this->errors_);
		break;
		
		/*MAF and INV_MAF*/
		case LPM_UFRGS::Factorization_Algorithm_Type::MAF :
		case LPM_UFRGS::Factorization_Algorithm_Type::INV_MAF:
			this->action_ = new MAF_Transformation();
			
			this->dmin =  String_Op::to_number<double>(parameters->value("distMin.value"));
			this->dmax =  String_Op::to_number<double>(parameters->value("distMax.value"));

			static_cast<MAF_Transformation*>(this->action_)->show_ev(Ev_option);
			return static_cast<MAF_Transformation*>(this->action_)->init(this->params, 0, this->errors_);
		break;
	}
	
	return true;
}

int FactorizationAlgorithms::execute(GsTL_project* proj, Progress_notifier* notifier)
{	
	switch (this->algorithm_type_) {
		/*PCA*/
		case LPM_UFRGS::Factorization_Algorithm_Type::INV_PCA:
			static_cast<PCA_Transformation*>(this->action_)->set_inv(this->params_input);
		case LPM_UFRGS::Factorization_Algorithm_Type::PCA :
            return static_cast<PCA_Transformation*>(this->action_)->exec(notifier);
		break;	
		
		/*MAF*/
		case LPM_UFRGS::Factorization_Algorithm_Type::INV_MAF:
			static_cast<MAF_Transformation*>(this->action_)->set_inv(this->params_input);
		case LPM_UFRGS::Factorization_Algorithm_Type::MAF :
			static_cast<MAF_Transformation*>(this->action_)->set_dist(this->dmin, this->dmax);
            return static_cast<MAF_Transformation*>(this->action_)->exec(notifier);
		break;	
	}

	return true;
}

