/*
Implementation of the MULTIPLE RANDOM WALK SIMULATION.

(c) 2014, LPM/UFRGS, Rafael Caixeta, Péricles Lopes Machado

BASED ON AR2GEMS KRIGING IMPLEMENTATION
*/

/* -----------------------------------------------------------------------------
** Copyright (c) 2012 Advanced Resources and Risk Technology, LLC
** All rights reserved.
**
** This file is part of Advanced Resources and Risk Technology, LLC (AR2TECH)
** version of the open source software sgems.  It is a derivative work by
** AR2TECH (THE LICENSOR) based on the x-free license granted in the original
** version of the software (see notice below) and now sublicensed such that it
** cannot be distributed or modified without the explicit and written permission
** of AR2TECH.
**
** Only AR2TECH can modify, alter or revoke the licensing terms for this
** file/software.
**
** This file cannot be modified or distributed without the explicit and written
** consent of AR2TECH.
**
** Contact Dr. Alex Boucher (aboucher@ar2tech.com) for any questions regarding
** the licensing of this file/software
**
** The open-source version of sgems can be downloaded at
** sourceforge.net/projects/sgems.
** ----------------------------------------------------------------------------*/


#include <geostat/kriging.h>
#include <geostat/parameters_handler.h>
#include <utils/gstl_messages.h>
#include <utils/string_manipulation.h>
#include <utils/error_messages_handler.h>
#include <grid/geostat_grid.h>
#include <grid/point_set.h>
#include <grid/combined_neighborhood.h>
#include <grid/gval_iterator.h>
#include <utils/manager_repository.h>
#include <grid/cartesian_grid.h>
#include <grid/point_set.h>
#include <grid/grid_region.h>
#include <grid/grid_path.h>
#include <appli/utilities.h>
#include <math/angle_convention.h>

#include <qthread.h>
#include <omp.h>

#include <random>
#include <iostream>
#include <thread>
#include <QTextStream>
#include <fstream>
#include <QTime>

#include <math/continuous_distribution.h>

#include "random_walk.h"

// random generator for 50:50 chance
double random_walk(std::mt19937& gen, double f) {
	std::uniform_real_distribution<> dis(0, 1);
	double r = dis(gen);

	return (r < 0.5) ? (-f) : (f);
}


// function for generation of the random walk paths
void RandomWalkMatrixProcess::execute_random_walk(int id_thread, int nb_of_threads,
	int seed, Vector2D* output, double f, double lag, double dmax, int n_random_walks)
{
	std::mt19937 gen;
	gen.seed(seed);

	int nlags = static_cast<int>(dmax / lag) + 1;

	for (int i = id_thread; i < n_random_walks; i += nb_of_threads) {
		double v = 0;
		double d = 0;

		for (int j = 0; j < nlags; ++j) {
			output->at(i)[j] = v;

			v += random_walk(gen, f);
			d += lag;
		}
	}
}

// multi-thread allocation of the random paths on a vector
void random_walk(std::mt19937& gen, Vector2D& output, double f, double lag, double dmax, int n_random_walks,
	int  nb_of_threads = 1)
{
	if (output.size() != n_random_walks) output.resize(n_random_walks);
	int nlags = static_cast<int>(dmax / lag) + 1;

	for (int i = 0; i < n_random_walks; ++i) {
		if (output[i].size() != nlags) output[i].resize(nlags);
	}

	std::vector<RandomWalkMatrixProcess*> threads(nb_of_threads);

	for (int id_thread = 0; id_thread < nb_of_threads; ++id_thread) {
		threads[id_thread] = new RandomWalkMatrixProcess(
			id_thread, nb_of_threads,
			gen(), &output, f, lag, dmax,
			n_random_walks);
		threads[id_thread]->start();
	}

	for (int id_thread = 0; id_thread < nb_of_threads; ++id_thread) {
		threads[id_thread]->wait();
		delete threads[id_thread];
	}

}

Named_interface* RandomWalk::create_new_interface(std::string&) {
	return new RandomWalk;
}

RandomWalk::RandomWalk()
	: kriging_estimator_(), simul_grid_(0), harddata_grid_(0),
	neighborhood_(), min_neigh_(0), max_neigh_(0), block_covar_() {
	report_ = new RW_report(0);
	report_->setSelf(report_);
}

RandomWalk::~RandomWalk() {
	for (int i = 0; i < kriging_estimator_.size(); ++i) {
		if (kriging_estimator_[i])
			delete kriging_estimator_[i];
	}
	if (harddata_grid_ != 0 && dynamic_cast<Point_set*>(harddata_grid_)) {
		harddata_grid_->set_coordinate_mapper(0);
	}

	for (int i = 0; i < block_covar_.size(); ++i) {
		if (block_covar_[i])
			delete block_covar_[i];
	}
}




// function for simulation of each node
void  RandomWalkProcess::execute_simulation(
	int id_thread,
	int n_threads,
	Progress_notifier* notifier,
	RandomWalk& handler,
	Prop_real& prop,
	const Vector2D& oracle,
	bool& issue_singular_system_warning,
	bool& issue_no_conditioning_data_warning,
	const Vector2D& path_pos,
	Vector1D& VarVector,
	Vector1D& krig_vect) {



	for (int i = id_thread; i < handler.simul_grid_->size(); i += n_threads) {


		if (handler.target_grid_region_ && !handler.target_grid_region_->is_inside_region(i)) continue;

		Geovalue gval = Geovalue(handler.simul_grid_, prop[0], i);

		if (gval.is_informed() && !handler.rw_parameters_.is_cross_validation) continue;
		if (!gval.is_informed() && handler.rw_parameters_.is_cross_validation) continue;

		Neighbors neighbors;
		handler.neighborhood_[id_thread]->find_neighbors(gval, neighbors);

		int number_of_neighbors = neighbors.size();

		if (number_of_neighbors < handler.min_neigh_)  continue;


		//if(!neighborhood_->is_valid()) continue;

		// Kriging system resolution
		Kriging_system::Kriging_solve_result result;
		int status = 0;
		double variance = 0;
		std::vector<double> estimate(handler.rw_parameters_.nb_of_realizations, 0);


		status = handler.kriging_system_[id_thread].solve(gval, neighbors, result);
		variance = handler.kriging_system_[id_thread].compute_kriging_variance(result);


		if (status == 0) {
			// the kriging system could be solved

			
			krig_vect[gval.node_id()] = handler.kriging_estimator_[id_thread]->operator()(result.weights, neighbors);
			
			Neighbors::const_iterator it = neighbors.begin();
			Neighbors::const_iterator end = neighbors.end();
			
			for (int count = 0; it != end && count < result.weights.size(); it++, count++) {

				double h = (handler.two_point_stat_[id_thread].c0() - handler.two_point_stat_[id_thread].operator()(it->location() - gval.location())) * (it->location() - gval.location()).length();

				int ih = static_cast<int>(h / handler.rw_parameters_.lag);
					
				for (int j = 0; j < handler.rw_parameters_.nb_of_realizations; ++j)
				{
					int sample_rw = path_pos[j][it->node_id()];
					if (ih >= oracle[sample_rw].size()) ih = oracle[sample_rw].size() - 1;

					double rw = oracle[sample_rw][ih];
					estimate[j] += rw * result.weights[count];
				}
			}
			
		
			if (handler.output_kriging_) handler.kriging_prop->set_value(krig_vect[gval.node_id()], gval.node_id());
				


			for (int j = 0; j < handler.rw_parameters_.nb_of_realizations; ++j)
			{
				prop[j]->set_value(estimate[j], i);
			}


			if (handler.output_average_distance_ && number_of_neighbors > 0) {
				float average_dist = 0.0;
				for (int i = 0; i < number_of_neighbors; ++i){
					average_dist += (gval.location() - neighbors[i].location()).length();
				}
				handler.aver_dist_prop->set_value(average_dist / (float)(number_of_neighbors), gval.node_id());
			}

			if (handler.output_n_samples_) handler.nsamples_prop->set_value(number_of_neighbors, gval.node_id());

			if (handler.output_sum_positive_weights_) {
				float sum_pos_weight = 0.0;
				for (int i = 0; i<number_of_neighbors; ++i) {
					if (result.weights[i] > 0) sum_pos_weight += result.weights[i];
				}
				handler.sum_pos_prop->set_value(sum_pos_weight, gval.node_id());
			}

			if (handler.output_sum_weights_) {
				float sum_weight = 0.0;
				for (int i = 0; i < number_of_neighbors; ++i) {
					sum_weight += result.weights[i];
				}
				sum_weight = 1 - sum_weight;
				handler.sum_weights_prop->set_value(sum_weight, gval.node_id());
			}

			
		}
		else {
			// the kriging system could not be solved, issue a warning and skip the
			// node
			issue_singular_system_warning = true;
		}

		if (notifier) {
			if (!notifier->notify()) break;
			while (notifier->is_paused()) {
				notifier->write("Paused", 0);
			}
		}
	}
}

void Calib::calibration(
	int id_thread,
	int n_threads,
	const Vector1D& restore_calib,
	const RandomWalk& handler,
	Prop_real& prop,
	const Vector1D& krig_vect,
	const Continuous_distribution& from,
	const Continuous_distribution& to,
	const Vector2D& ngt_effect)
{
	for (int i = id_thread; i < handler.simul_grid_->size(); i += n_threads) {

		if (!prop[0]->is_informed(i)) continue;
		if (!prop[0]->is_harddata(i) || handler.rw_parameters_.is_cross_validation)
		{

			for (int j = 0; j < handler.rw_parameters_.nb_of_realizations; ++j)
			{

				double updated;
				if (!handler.rw_parameters_.rw_manual_calib)
				{
					updated = ((prop[j]->get_value(i)) * (restore_calib[(j+2)] / handler.rw_parameters_.scale_factor)) + krig_vect[i] + ngt_effect[j][i];
				}
				else
				{
					updated = prop[j]->get_value(i) + krig_vect[i] + ngt_effect[j][i];
				}

				if (handler.use_target_hist_)
				{
					double P = from.prob(updated);
					prop[j]->set_value(to.inverse(P), i);
				}
				else
				{
					prop[j]->set_value(updated, i);
				}

			}


		}
	}

}


int RandomWalk::execute(GsTL_project*, Progress_notifier* notifier) {

	if (notifier) notifier->write("Initializing... ", 0);
	QTime clock_;
	clock_.start();
	// those flags will be used to signal if some of the nodes could not be informed
	bool issue_singular_system_warning = false;
	bool issue_no_conditioning_data_warning = false;
	Vector2D oracle(rw_parameters_.nb_of_randomwalks);
	int operations_int = rw_parameters_.nb_of_realizations + 2;
	Vector1D VarVector(operations_int, 0);
	Vector1D krig_vect(simul_grid_->size());
	double operations_dbl = std::sqrt(rw_parameters_.nugget);
	GaussNoise ngt(0, operations_dbl);

	std::mt19937 gen;
	double f_med = 0;

	gen.seed(rw_parameters_.seed);


	random_walk(gen, oracle, rw_parameters_.scale_factor,
		rw_parameters_.lag, rw_parameters_.dmax,
		rw_parameters_.nb_of_randomwalks,
		rw_parameters_.nb_of_threads);


		
	// create the property
	//appli_message("creating new property: " << property_name_ << "...");
		
	Prop_real prop(rw_parameters_.nb_of_realizations);
	for (int i = 0; i < rw_parameters_.nb_of_realizations; ++i)
	{
		prop[i] = multireal_rw_property_->new_realization();
	}

				
	Vector2D path_pos(rw_parameters_.nb_of_realizations, std::vector<double>(harddata_property_->size()));
		
	for (int i = 0; i < path_pos.size(); ++i) {
		for (int j = 0; j < path_pos[0].size(); ++j)
		{
			path_pos[i][j] = gen() % oracle.size();
		}
	}
		
	for (int i = 0; i < rw_parameters_.nb_of_realizations; ++i)
	{
		prop[i]->set_parameters(parameters_);
		simul_grid_->select_property(prop[i]->name());
		prop[i]->swap_to_memory();
	}

	if (rw_parameters_.assign || rw_parameters_.is_cross_validation){
		if (property_copier_) {
			for (int i = 0; i < rw_parameters_.nb_of_realizations; ++i){
				property_copier_->copy(harddata_grid_, harddata_property_, simul_grid_, prop[i]);
			}
		}
	}
	
	this->init_option_properties(prop[0]->name(), var_prop, nsamples_prop, aver_dist_prop, sum_pos_prop, sum_weights_prop, kriging_prop);
	
	if (notifier) notifier->write("Simulating... ", 0);

	std::vector<RandomWalkProcess*> threads(rw_parameters_.nb_of_threads);

	for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
		threads[id_thread] = new RandomWalkProcess(
			id_thread, rw_parameters_.nb_of_threads,
			notifier, this, &prop, &oracle,
			&issue_singular_system_warning,
			&issue_no_conditioning_data_warning, &path_pos, &VarVector, &krig_vect);

		threads[id_thread]->start();
	}

	for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
		threads[id_thread]->wait();
		delete threads[id_thread];
	}

	// resetting the oracle vector to simulate and store ngt effect
	oracle.clear();
	oracle.resize(rw_parameters_.nb_of_realizations, std::vector<double>(simul_grid_->size()));
	
	// resetting seed
	gen.seed(rw_parameters_.seed);

	for (int j = 0; j < rw_parameters_.nb_of_realizations; ++j)
	{
		operations_int = j + 2;
		for (int i = 0; i < simul_grid_->size(); ++i) {
			if (prop[j]->is_informed(i)){
				if (j == 0){
					VarVector[0] += 1; // number of simulated ndoes
					VarVector[1] += (krig_vect[i])*(krig_vect[i]); // partial kriging variance
				}
				oracle[j][i] = ngt(gen);
				VarVector[operations_int] += (prop[j]->get_value(i))*(prop[j]->get_value(i)); // partial noise variance
			}
		}
	
		if (j == 0) VarVector[1] = VarVector[1] / VarVector[0]; // final kriging variance
		VarVector[operations_int] = VarVector[operations_int] / VarVector[0]; // final noise variance
	}
		
		
	if (!rw_parameters_.is_cross_validation)
	{
		operations_dbl = 1 - VarVector[1] - rw_parameters_.nugget;
	}
	else
	{
		operations_dbl = rw_parameters_.ns_var - VarVector[1] - rw_parameters_.nugget;
	}

	for (int k = 2; k < VarVector.size(); ++k)
	{
		double operations_dbl_ = (operations_dbl * rw_parameters_.scale_factor * rw_parameters_.scale_factor) / VarVector[k];
		VarVector[k] = std::sqrt(operations_dbl_);
		f_med += VarVector[k];
	}

	f_med = f_med / rw_parameters_.nb_of_realizations;

	if (notifier) notifier->write("Final transformations and calibrations ...", 0);

	std::vector<Calib*> threads2(rw_parameters_.nb_of_threads);
	SmartPtr<Continuous_distribution> normal(new Gaussian_distribution(0, 1));

	for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
		threads2[id_thread] = new Calib(id_thread, rw_parameters_.nb_of_threads, &VarVector, this, &prop, &krig_vect, normal.raw_ptr(), target_cdf_.raw_ptr(), &oracle);
		threads2[id_thread]->start();
	}

	for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
		threads2[id_thread]->wait();
		delete threads2[id_thread];
	}
		
	for (int i = 0; i < rw_parameters_.nb_of_realizations; ++i)
	{
		prop[i]->swap_to_disk();
	}


	if (use_target_hist_) harddata_grid_->remove_property(harddata_property_name_);

	

	int elapsed_time = clock_.elapsed();


	QString s_r;
	QTextStream out(&s_r);

	out << "The simulations completed in " << elapsed_time << " ms \n";
	out << "Average scale factor (f) for unit Gaussian variance = " << f_med << "\n";
	out << "Variance of the kriged values = " << VarVector[1] << "\n \n";
	
	out << "RW Parameters: \n";
	out << "Lag = " << rw_parameters_.lag << "\n";
	out << "Number of paths = " << rw_parameters_.nb_of_randomwalks << "\n";
		

	report_->write(s_r);

	return 0;
}


void RandomWalk::clean(const std::string& prop) {
	simul_grid_->remove_property(prop);
}


bool RandomWalk::initialize(const Parameters_handler* parameters,
	Error_messages_handler* errors, Progress_notifier* notifier) {

	//-----------------
	// Extract the parameters input by the user from the parameter handler
	// Extract the parameters input by the user from the parameter handler
	std::string simul_grid_name = parameters->value("Grid_Name.value");
	errors->report(simul_grid_name.empty(), "Grid_Name", "No grid selected");
	property_name_ = parameters->value("Property_Name.value");
	errors->report(property_name_.empty(), "Property_Name", "No property name specified");

	// Get the simulation grid from the grid manager
	if (!simul_grid_name.empty()) {
		bool ok = geostat_utils::create(simul_grid_, simul_grid_name, "Grid_Name", errors);
		if (!ok) return false;
	}
	else {
		return false;
	}
	
	multireal_rw_property_ =
		simul_grid_->add_multi_realization_property(property_name_);

	target_grid_region_ = simul_grid_->region(parameters->value("Grid_Name.region"));

	std::string harddata_grid_name = parameters->value("Hard_Data.grid");
	errors->report(harddata_grid_name.empty(), "Hard_Data", "No hard data specified");

	harddata_property_name_ = parameters->value("Hard_Data.property");
	errors->report(harddata_property_name_.empty(), "Hard_Data", "No property name specified");

	// Get the harddata grid from the grid manager
	if (!harddata_grid_name.empty()) {
		bool ok = geostat_utils::create(harddata_grid_, harddata_grid_name, "Hard_Data", errors);
		if (!ok) return false;
	}
	else {
		return false;
	}

	std::string harddata_region_name = parameters->value("Hard_Data.region");
	hd_grid_region_ = harddata_grid_->region(harddata_region_name);

	harddata_property_ = harddata_grid_->property(harddata_property_name_);
	
	
	// Target histogram

	use_target_hist_ = String_Op::to_number<bool>(parameters->value("Use_Target_Histogram.value"));
	if (use_target_hist_) {
		bool ok = distribution_utils::get_continuous_cdf(target_cdf_, parameters, errors, "nonParamCdf");
		if (!ok) return false;

		if (harddata_property_) {
			harddata_property_ = distribution_utils::gaussian_transform_property(harddata_property_, target_cdf_.raw_ptr(), harddata_grid_, hd_grid_region_);
			if (!harddata_property_) return false;
			harddata_property_name_ = harddata_property_->name();
			harddata_grid_->select_property(harddata_property_name_);
		}
	}

	

	//-------------


	max_neigh_ = String_Op::to_number<int>(parameters->value("Max_Conditioning_Data.value"));
	min_neigh_ = String_Op::to_number<int>(parameters->value("Min_Conditioning_Data.value"));
	errors->report(min_neigh_ >= max_neigh_, "Min_Conditioning_Data", "Min must be less than Max");

	//Initialize Random Walk parameters

	GsTLTriplet ellips_ranges2;
	GsTLTriplet ellips_angles2;
	bool extract_ok = geostat_utils::extract_ellipsoid_definition(ellips_ranges2, ellips_angles2, "Search_Ellipsoid.value", parameters, errors);
	if (!extract_ok) return false;




	double rw_dmax = ellips_ranges2[0];

	bool rw_manual_lag = String_Op::to_number<bool>(parameters->value("rw_manual_lag.value"));
	double rw_lag;
	if (rw_manual_lag){
		rw_lag = String_Op::to_number<double>(parameters->value("rw_lag.value"));
	}
	else
	{
		double hor = (simul_grid_->location(0) - simul_grid_->location(1)).length();
		double vol = simul_grid_->get_support(0);
		vol = vol / (hor*hor);
		rw_lag = std::min(hor, vol) / 50; // works properly in 3D if  xsiz = ysiz. In 2D may show problems

	}

	bool rw_manual_nbrw = String_Op::to_number<bool>(parameters->value("rw_manual_nbrw.value"));
	int rw_nb_rw;
	if (rw_manual_nbrw){
		rw_nb_rw = String_Op::to_number<int>(parameters->value("rw_nb_random_walks.value"));
	}
	else
	{
		rw_nb_rw = (harddata_grid_->size()) + 2000;
	}

	int rw_nb_real = String_Op::to_number<int>(parameters->value("rw_nb_realizations.value"));
	int rw_seed = String_Op::to_number<int>(parameters->value("rw_seed.value"));

	bool rw_manual_threads = String_Op::to_number<bool>(parameters->value("rw_manual_threads.value"));
	int rw_nb_of_threads;
	if (rw_manual_threads){
		rw_nb_of_threads = String_Op::to_number<int>(parameters->value("rw_nb_threads.value"));
	}
	else
	{
		rw_nb_of_threads = QThread::idealThreadCount();
		if (rw_nb_of_threads == -1) rw_nb_of_threads = 1;
	}

	int rw_assign = String_Op::to_number<int>(parameters->value("rw_report.value"));
	double rw_nugget = 0;

	// Getting the nugget effect
	int struct_count = String_Op::to_number<int>(parameters->value("Variogram.structures_count"));
	for (int i = 1; i <= struct_count; i++)
	{
		std::string struct_name = "Structure_" + String_Op::to_string(i);
		std::string struct_type = parameters->value("Variogram/" + struct_name + "/Two_point_model.type");

		if (struct_type == "Nugget Covariance")
		{
			double cc = String_Op::to_number<double>(parameters->value("Variogram/" + struct_name + "/Two_point_model.contribution"));
			rw_nugget += cc;
		}
		if (struct_type == "Nugget Local Covariance")
		{
			double cc = String_Op::to_number<double>(parameters->value("Variogram/" + struct_name + "/Two_point_model/contribution.value"));
			rw_nugget += cc;
		}
	}



	bool execute_crossvalidation = String_Op::to_number<bool>(parameters->value("execute_crossvalidation.value"));

	double nscore_var = 1;
	double nscore_mean = 0;

	if (execute_crossvalidation)
	{
		double sum = std::accumulate(harddata_property_->begin(), harddata_property_->end(), 0.0);
		nscore_mean = sum / harddata_property_->size();

		double sq_sum = std::inner_product(harddata_property_->begin(), harddata_property_->end(), harddata_property_->begin(), 0.0);
		nscore_var = sq_sum / harddata_property_->size() - nscore_mean * nscore_mean;
	}

	bool rw_manual_calib = String_Op::to_number<bool>(parameters->value("rw_manual_calib.value"));
	double rw_f;
	if (rw_manual_calib)
	{
		rw_f = String_Op::to_number<double>(parameters->value("rw_f.value"));
	}
	else
	{
		rw_f = 0.5;
	}

	rw_parameters_ = RandomWalkParameters(rw_seed, rw_nb_rw, rw_nb_real, rw_lag, rw_dmax, rw_f, rw_nb_of_threads, nscore_var, rw_assign, rw_nugget, execute_crossvalidation, nscore_mean, rw_manual_calib);

	if (rw_parameters_.assign || rw_parameters_.is_cross_validation){
		property_copier_ = Property_copier_factory::get_copier(harddata_grid_, simul_grid_);
		if (!property_copier_) {
			std::ostringstream message;
			message << "It is currently not possible to copy a property from a "
				<< harddata_grid_->classname() << " to a "
				<< simul_grid_->classname();
			errors->report(!property_copier_, "Assign_Hard_Data", message.str());
			return false;
		}
	}


	// Set up the covariance
	two_point_stat_.resize(rw_nb_of_threads);
	for (int id_thread = 0; id_thread < rw_nb_of_threads; ++id_thread) {
		if (!geostat_utils::initialize_two_point_nested_structure(&two_point_stat_[id_thread], "Variogram", parameters, errors, simul_grid_))
		{
			return false;
		}
	}
	


	Prop_real prop(rw_parameters_.nb_of_realizations);
	prop[0]= harddata_grid_->select_property(harddata_property_name_);
	if (!prop[0]) {
		std::ostringstream error_stream;
		error_stream << harddata_grid_name << " does not have a property called " << harddata_property_name_;
		errors->report("Hard_Data", error_stream.str());
	}
	prop[0]->swap_to_memory(); // this is a MUST to ensure thread safe


	// Set up the search neighborhood
	neighborhood_.resize(rw_nb_of_threads);
	for (int id_thread = 0; id_thread < rw_nb_of_threads; ++id_thread) {
		GsTLTriplet ellips_ranges;
		GsTLTriplet ellips_angles;
		bool extract_ok = geostat_utils::extract_ellipsoid_definition(ellips_ranges, ellips_angles, "Search_Ellipsoid.value", parameters, errors);
		if (!extract_ok) return false;

		harddata_grid_->select_property(harddata_property_name_);
		if (dynamic_cast<Point_set*>(harddata_grid_)) {
			harddata_grid_->set_coordinate_mapper(simul_grid_->coordinate_mapper());
			neighborhood_[id_thread] = SmartPtr<Neighborhood>(
				((Point_set*)harddata_grid_)->neighborhood(ellips_ranges, ellips_angles, &two_point_stat_[id_thread], true, hd_grid_region_));
		}
		else {
			neighborhood_[id_thread] = SmartPtr<Neighborhood>(harddata_grid_->neighborhood(ellips_ranges, ellips_angles,
				&two_point_stat_[id_thread], false, hd_grid_region_));
		}
		neighborhood_[id_thread]->select_property(harddata_property_name_);
		neighborhood_[id_thread]->max_size(max_neigh_);
		if (rw_parameters_.is_cross_validation) neighborhood_[id_thread]->includes_center(false);

		geostat_utils::set_advanced_search(neighborhood_[id_thread].raw_ptr(), "AdvancedSearch", parameters, errors);
	}


	// The kriging constraints and combiner

	geostat_utils::KrigTagMap tags_map;
	tags_map[geostat_utils::SK] = "0.0";
	tags_map[geostat_utils::KT] = "Kriging_Type/parameters.trend";
	tags_map[geostat_utils::LVM] = "Kriging_Type/parameters.property";

	output_n_samples_ = parameters->value("output_n_samples_.value") == "1";
	output_average_distance_ = parameters->value("output_average_distance.value") == "1";
	output_sum_positive_weights_ = parameters->value("output_sum_positive_weights.value") == "1";
	output_sum_weights_ = parameters->value("output_sum_weights.value") == "1";
	output_kriging_ = parameters->value("output_kriging.value") == "1";

	std::string kriging_type = parameters->value("Kriging_Type.type");


	// init kriging system
	kriging_system_.resize(rw_nb_of_threads);
	kriging_estimator_.resize(rw_nb_of_threads);
	for (int id_thread = 0; id_thread < rw_nb_of_threads; ++id_thread) {
		std::string kriging_base_type = "Kriging_Type";
		if (!geostat_utils::initialize_kriging_system_(kriging_base_type, kriging_system_[id_thread], kriging_estimator_[id_thread], parameters, errors, simul_grid_, harddata_grid_))
		{
			return false;
		}
		kriging_system_[id_thread].lhs_covariance_is(two_point_stat_[id_thread]);
		if (block_covar_.size() > 0) {
			kriging_system_[id_thread].rhs_covariance_is(*block_covar_[id_thread]);
		}
		else {
			kriging_system_[id_thread].rhs_covariance_is(two_point_stat_[id_thread]);
		}
	}

	if (!errors->empty()){
		return false;
	}

	this->extract_parameters(parameters);

	if (notifier) {
		int total_steps = target_grid_region_ == 0 ? this->simul_grid_->size() : target_grid_region_->active_size();
		notifier->total_steps(total_steps);
		notifier->frequency(20);
	}

	return true;
}


void  RandomWalk::init_option_properties(std::string base_name,
	Grid_continuous_property*& var_prop, Grid_continuous_property*& nsamples_prop,
	Grid_continuous_property*& aver_dist_prop, Grid_continuous_property*& sum_pos_prop,
	Grid_continuous_property*& sum_weights_prop, Grid_continuous_property*& kriging_prop)
{
	if (output_n_samples_) {
		std::string prop_name = base_name + " n samples";
		nsamples_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		nsamples_prop->set_parameters(parameters_);
	}
	if (output_average_distance_) {
		std::string prop_name = base_name + " average sample distance";
		aver_dist_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		aver_dist_prop->set_parameters(parameters_);
	}
	if (output_sum_positive_weights_) {
		std::string prop_name = base_name + " sum positive weights";
		sum_pos_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		sum_pos_prop->set_parameters(parameters_);
	}
	if (output_sum_weights_) {
		std::string prop_name = base_name + " weights for the mean";
		sum_weights_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		sum_weights_prop->set_parameters(parameters_);
	}

	if (output_kriging_) {
		std::string prop_name = base_name + " kriging";
		kriging_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		kriging_prop->set_parameters(parameters_);
	}

}


