/*
Implementa��o do plugin que realiza o model_validation.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/



#ifndef __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_PROCESS_H___
#define __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_PROCESS_H___

#include "common.h"

#include <qstring.h>
#include <QDialog>
#include <QThread>
#include <QMutex>
#include <vector>

#include "ui_model_validation_progressdialog.h"

class PLUGINS_LPM_UFRGS_DECL ModelValidationProgressDialog : public QDialog {
	Q_OBJECT

public:
    ModelValidationProgressDialog(int number_steps = 100, QWidget *parent = 0);
    ~ModelValidationProgressDialog();

    Ui::ModelValidationProgressDialog& getUi()
	{
		return ui_;
	}

	bool isRunning() {
		mutex_.lock();
		bool is_r = is_running_;
		mutex_.unlock();

		return is_r;
	}

	bool isPaused();

signals:
	void finish(const QString& msg);
	void sendText(const QString& msg);
	void sendTextAppend(const QString& msg);
	void valueChanged(int step);

public slots:
	
	void setPaused();
	void setRunning();
	void setDead();

	void nextStep();
	void reset();
	void setStep(int step);
	void setNumberSteps(int n);
	void setText(const QString& msg);
	void appendText(const QString& msg);
	void lastMsg(const QString& msg);

	void writeMsg(const QString& msg, bool append = false);

	void lock() { mutex_.lock();  }

	void unlock() { mutex_.lock(); }

private:
	int current_step_;
	int number_steps_;
	
	bool is_paused_;
	bool is_running_;
	QMutex mutex_;

    Ui::ModelValidationProgressDialog ui_;
};

class PLUGINS_LPM_UFRGS_DECL ModelValidationProcess;

class PLUGINS_LPM_UFRGS_DECL ModelValidationAction
{
public:
    ModelValidationAction(){}

    virtual void run_master_process(ModelValidationProcess* process_handler, int number_threads, std::vector<ModelValidationProcess*>& slaves) = 0;
    virtual void run_slave_process(ModelValidationProcess* process_handler, int id_thread, int number_threads) = 0;
};

class PLUGINS_LPM_UFRGS_DECL ModelValidationProcess : public QThread
{
	Q_OBJECT

public:
    ModelValidationProcess(
        ModelValidationAction* action,
        ModelValidationProgressDialog* notifier,
		int number_threads = 1,
		int id_thread = 1,
		bool is_master = true);
    ~ModelValidationProcess();

	bool isOk() { return ok_; }
	
	void setOk(bool ok) {
		ok_ = ok;
	}

    ModelValidationProgressDialog* getNotifier() { return notifier_; }
    ModelValidationAction* getAction() { return action_; }
public slots:

	void killProcess();
	void run();
	void lock();
	void unlock();
	void waitProcess();

	void run_master();
	void run_slaves();

private:
	bool is_master_;
	int id_thread_;
	int number_threads_;
    ModelValidationAction* action_;
    ModelValidationProgressDialog* notifier_;
	bool ok_;
    std::vector<ModelValidationProcess*> slaves_;

signals:
	void sendMessage(const QString&);
	void finished();
    void killMe(ModelValidationProcess*);
};


PLUGINS_LPM_UFRGS_DECL void model_validation_progress_sleep(int time = 200);

#endif // __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_PROCESS_H___
