/*
Implementação do RANDOM WALK.

(c) 2014, LPM/UFRGS, Rafael Caixeta, Péricles Lopes Machado

BASED ON AR2GEMS KRIGING IMPLEMENTATION
*/


#ifndef RW_REPORT_H_
#define RW_REPORT_H_

#include "common.h"
#include <QDialog>
#include <QMainWindow>
#include <QCloseEvent>
#include <ui_report.h>


class RW_report : public QDialog
{
	Q_OBJECT

public:
	RW_report(QWidget *parent = 0);
	~RW_report();

    void write(QString msg){
        emit setText(msg);
    }

signals:
    void setText(QString text);
public slots:
    void setReport(QString text) {
        this->ui.report_text->setText(text);
        this->show();
    }

	void setSelf(RW_report* r) {
		self = r;
	}

	void autoDestroy() {
		if (self) delete self;
	}

	void closeEvent(QCloseEvent *event) {
		if (self) delete self;
	}

private:
	RW_report* self;
	Ui::RW_report ui;
};

#endif /* LPM_RW_REPORT_H_ */
