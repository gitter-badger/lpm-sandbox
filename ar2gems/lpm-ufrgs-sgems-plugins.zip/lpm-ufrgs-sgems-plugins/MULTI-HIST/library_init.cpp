/*
Implementa��o do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include <geostat/library_geostat_init.h>
#include <geostat/parameters_handler_impl.h>

#include <utils/manager_repository.h>
#include <utils/gstl_messages.h>
#include <geostat/two_point_statistics_initialization.h>
#include <geostat/two_point_statistics_local_initialization.h>
#include <geostat/two_point_lmc_initialization.h>
#include <math/continuous_distribution.h>
#include <math/non_parametric_distribution.h>

#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>


#include "common.h"

//#include "multi_hist_action.h"

//#include "multi_hist_algorithms.h"


#include "histogram_chart_creator.h"


extern "C" PLUGINS_LPM_UFRGS_DECL
int plugin_init() 
{
	SmartPtr<Named_interface> ni;
	Manager* dir;
	
	
	// CHARTS
	GsTLlog << "\n\n registering Histogram charts" << "\n";
	ni = Root::instance()->interface(eda_charts_manager);
	dir = dynamic_cast<Manager*>(ni.raw_ptr());
	if (!dir) {
		GsTLlog << "Directory " << eda_charts_manager << " does not exist \n";
		return 1;
	}

	dir->factory(Histogram_chart_creator_factory().name(),
		Histogram_chart_creator_factory::create_new_interface);
	return 0;
}

