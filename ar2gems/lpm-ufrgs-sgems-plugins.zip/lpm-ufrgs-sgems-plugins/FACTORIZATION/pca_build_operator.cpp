/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/


#include "pca_build_operator.h"

using namespace std;
using Eigen::MatrixXd;
using namespace Eigen;

void build_operator(Matrix2f& D, const std::vector<std::vector<double> >& data, bool& status, 
										std::vector<std::vector<double> >& varmatriz)
{
	status = true;
	size_t M = data[0].size();
	varmatriz.resize(M);
	
    vector<double> media(M);
	
    for (size_t i = 0; i < M; ++i) {
        double soma = 0;
		
        for(size_t j = 0; j < data.size(); ++j) {
            soma += data[j][i];
        }
     
        media[i] = soma / data.size();
        
		double d;

        for(size_t j = 0;j < data.size(); ++j) {
            d = data[j][i] - media[i];

            varmatriz[i].push_back(d);
        }
    }


    size_t m = data.size();
    double sum, mult, cov;
    vector<vector<double> > matrizcov(M);
    
    for (size_t i = 0; i < M; ++i) {
        for (size_t k = 0; k < M; ++k) {
            sum = 0;
            for (size_t j = 0; j < data.size(); ++j) {
                mult = varmatriz[i][j] * varmatriz[k][j];
                sum += mult;

                cov = sum / (m - 1);
            }
			
            matrizcov[i].push_back(cov);
        }
    }

    Matrix2f A(M,M);

    for(size_t i = 0; i < M; ++i) {
        for(size_t j = 0; j < M; ++j) {
            A(i,j) = matrizcov[i][j];
        }
    }

    SelfAdjointEigenSolver<Matrix2f> eigensolver(A);
    
	if (eigensolver.info() != Success) {
		status = false;
		return;
	}

    D << eigensolver.eigenvectors();
}

