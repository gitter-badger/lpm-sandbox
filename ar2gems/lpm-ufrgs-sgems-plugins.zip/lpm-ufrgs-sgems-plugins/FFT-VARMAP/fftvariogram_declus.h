/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_FFTVARIOGRAM_DECLUS_H___
#define __PLUGINS_LPM_UFRGS_FFTVARIOGRAM_DECLUS_H___

#include "common.h"

#include <QFrame>

#include "ui_fftvariogram_declus.h"

class FFTVariogramDeclus : public QFrame {
    Q_OBJECT

  public:
    FFTVariogramDeclus(QWidget *parent = 0);
    ~FFTVariogramDeclus();

    double getX(int row, bool* ok = 0);
    double getY(int row, bool* ok = 0);
    double getZ(int row, bool* ok = 0);

    double getDx();
    double getDy();
    double getDz();

    int getNumberVariograms();
    int getNumberLags();
    int getNumberThreads();

    QPushButton* getDisplayButton();

    QStringList getProperties();
    Geostat_grid* getGrid();
    QString getWeigth();

  public slots:
    void updateNumberVariograms(int nVariograms);

    void checkCell(int, int);
  signals:

  private:
    Ui::FFTVariogramDeclus ui;
};

#endif

