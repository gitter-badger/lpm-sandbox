/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#include "common.h"

#include "alr_transformation.h"
#include "alr_inv_transformation.h"

#include "clr_transformation.h"
#include "clr_inv_transformation.h"

#include "ilr_transformation.h"
#include "ilr_inv_transformation.h"

#include "coda_algorithms.h"

#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>

extern "C" PLUGINS_LPM_UFRGS_DECL
int plugin_init() 
{
	// ACTIONS
	GsTLlog << "\n\n registering action alr_transformation" << "\n";
	SmartPtr<Named_interface> ni = Root::instance()->interface(actions_manager);
	Manager* dir = dynamic_cast<Manager*>(ni.raw_ptr());
	
	if(!dir) {
		GsTLlog << "Directory " << actions_manager << " does not exist \n";
		return 1;
	}

	dir->factory("LPM_CODA_ALR", ALR_Transformation::create_new_interface);
	dir->factory("LPM_CODA_ALR_INV", ALR_Inv_Transformation::create_new_interface);
	
	dir->factory("LPM_CODA_CLR", CLR_Transformation::create_new_interface);
	dir->factory("LPM_CODA_CLR_INV", CLR_Inv_Transformation::create_new_interface);
	
	dir->factory("LPM_CODA_ILR", ILR_Transformation::create_new_interface);
	dir->factory("LPM_CODA_ILR_INV", ILR_Inv_Transformation::create_new_interface);
	
	// ALGORITHMS
	GsTLlog << "\n\n registering LPM/CODA Algorithms" << "\n";
	ni = Root::instance()->interface(geostatAlgo_manager);
	dir = dynamic_cast<Manager*>(ni.raw_ptr());
	if( !dir ) {
		GsTLlog << "Directory " << geostatAlgo_manager << " does not exist \n";
		return 1;
	}
	dir->factory(CodaAlgorithms().name(), CodaAlgorithms::create_new_interface);
	

	return 0;
}
