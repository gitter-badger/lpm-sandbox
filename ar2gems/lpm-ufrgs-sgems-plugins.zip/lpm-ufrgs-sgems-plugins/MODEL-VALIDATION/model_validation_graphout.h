/*
Implementação do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/



#ifndef __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_GRAPHOUT_H___
#define __PLUGINS_LPM_UFRGS_MODEL_VALIDATION_GRAPHOUT_H___

#include "common.h"

#include <qstring.h>
#include <qstringlist.h>
#include <QFrame>

#include "ui_model_validation_graphout.h"

class ModelValidationGraphOutput : public QFrame {
    Q_OBJECT

  public:
    ModelValidationGraphOutput(QWidget *parent = 0);
    ~ModelValidationGraphOutput();

    Ui::ModelValidationGraphOutput& getUI() {
        return ui;
    }
  private:
    Ui::ModelValidationGraphOutput ui;
};

#endif
