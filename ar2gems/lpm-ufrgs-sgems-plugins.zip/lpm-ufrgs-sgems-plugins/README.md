# lpm-ufrgs-sgems-plugins
A repository with SGEMS plugins.

Building instructions
---------------------

Before compilling the code run:

```
$ git submodule update --init
```

Dependences
-----------

* AR2GEMS (https://github.com/ar2tech/ar2gems)
* VTK (https://github.com/Kitware/VTK)
* QT 5 (http://download.qt.io)
* Flex
* Bison
* Boost
