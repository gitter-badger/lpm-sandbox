/*
Implementa��o do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/


#include "histogram_chart_creator.h"
#include "histogram_chart.h"

Histogram_chart_creator::Histogram_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent)
    : Chart_creator(mdi_area, parent) {
    QTabWidget* Histogram_Widget = new QTabWidget(this);
    my_histogram_ = this->build_histogram_page();
    Histogram_Widget->addTab(my_histogram_, QIcon(), "Histogram");
    Histogram_Widget->show();
    //my_histogram_->show();
    QVBoxLayout* main_layout = new QVBoxLayout(this);
    main_layout->setContentsMargins(0, 0, 0, 0);
    main_layout->addWidget(Histogram_Widget);
    this->setLayout(main_layout);
    bool ok = connect(my_histogram_->getDisplayButton(), SIGNAL(clicked()),
                      this, SLOT(show_chart_histogram()));
}

Histogram_chart_creator::~Histogram_chart_creator() {
}

void Histogram_chart_creator::kill_process(HistogramProcess* process) {
    Histogram_chart* chart = static_cast<Histogram_chart*>(process->getAction());
    if (process->isOk()) {
        chart->build_histogram_chart();
        QMdiSubWindow* sub_window = mdi_area_->addSubWindow(chart);
        sub_window->setAttribute(Qt::WA_DeleteOnClose);
        sub_window->showMaximized();
    } else {
        delete chart;
    }
    if (process) delete process;
}

void Histogram_chart_creator::create_histogram_process(HistogramAction* chart, int n_steps, int n_threads) {
    HistogramProcess* process = new HistogramProcess(
        chart,
        new HistogramProgressDialog(n_steps),
        n_threads);
    QObject::connect(
        process, SIGNAL(killMe(HistogramProcess*)),
        this, SLOT(kill_process(HistogramProcess*)));
    process->getNotifier()->show();
    process->start();
}

void Histogram_chart_creator::show_chart_histogram() {
    int nprops = my_histogram_->getProperties().size();
    if (my_histogram_->getGrid() != 0 &&
            nprops > 0) {
        Histogram_chart* chart = new  Histogram_chart(
            my_histogram_,
            0);
        create_histogram_process(chart, nprops, my_histogram_->getNumberThreads());
    }
}


LPMHistogram* Histogram_chart_creator::build_histogram_page() {
    return new LPMHistogram(0);
}

