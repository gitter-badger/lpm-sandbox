/*
Implementation of the MULTIPLE RANDOM WALK SIMULATION.

(c) 2014, LPM/UFRGS, Rafael Caixeta, Péricles Lopes Machado

*/

/* -----------------------------------------------------------------------------
** Copyright (c) 2012 Advanced Resources and Risk Technology, LLC
** All rights reserved.
**
** This file is part of Advanced Resources and Risk Technology, LLC (AR2TECH)
** version of the open source software sgems.  It is a derivative work by
** AR2TECH (THE LICENSOR) based on the x-free license granted in the original
** version of the software (see notice below) and now sublicensed such that it
** cannot be distributed or modified without the explicit and written permission
** of AR2TECH.
**
** Only AR2TECH can modify, alter or revoke the licensing terms for this
** file/software.
**
** This file cannot be modified or distributed without the explicit and written
** consent of AR2TECH.
**
** Contact Dr. Alex Boucher (aboucher@ar2tech.com) for any questions regarding
** the licensing of this file/software
**
** The open-source version of sgems can be downloaded at
** sourceforge.net/projects/sgems.
** ----------------------------------------------------------------------------*/


#include <geostat/kriging.h>
#include <geostat/parameters_handler.h>
#include <utils/gstl_messages.h>
#include <utils/string_manipulation.h>
#include <utils/error_messages_handler.h>
#include <grid/geostat_grid.h>
#include <grid/point_set.h>
#include <grid/combined_neighborhood.h>
#include <grid/gval_iterator.h>
#include <utils/manager_repository.h>
#include <grid/cartesian_grid.h>
#include <grid/point_set.h>
#include <grid/grid_region.h>
#include <grid/grid_path.h>
#include <appli/utilities.h>
#include <math/angle_convention.h>

#include <qthread.h>
#include <omp.h>

#include <random>
#include <iostream>
#include <thread>
#include <QTextStream>
#include <fstream>
#include <QTime>

#include <math/continuous_distribution.h>
#include <geostat/gaussian_cdf_kestimator.h>
#include <geostat/sequential_simulation.h>


#include "random_walk.h"

// Function to call a positive or negative Random Walk increment
double random_walk(std::mt19937& gen, double f) {
	std::uniform_real_distribution<> dis(0, 1);
	double r = dis(gen);

	return (r < 0.5) ? (-f) : (f);
}


// Function to generate the Random Walk paths (called in multithread)
void RandomWalkMatrixProcess::execute_random_walk(int id_thread, int nb_of_threads,
	int seed, Vector2D* output, double f, double lag, double dmax, int n_random_walks)
{
	std::mt19937 gen;
	gen.seed(seed);

	int nlags = static_cast<int>(dmax / lag) + 1;

	for (int i = id_thread; i < n_random_walks; i += nb_of_threads) {
		double v = 0;
		double d = 0;

		for (int j = 0; j < nlags; ++j) {
			output->at(i)[j] = v;

			v += random_walk(gen, f);
			d += lag;
		}
	}
}

// Function that starts the generation of the Random Walks
void random_walk(std::mt19937& gen, Vector2D& output, double f, double lag, double dmax, int n_random_walks,
	int  nb_of_threads = 1)
{
	if (output.size() != n_random_walks) output.resize(n_random_walks);
	int nlags = static_cast<int>(dmax / lag) + 1;

	for (int i = 0; i < n_random_walks; ++i) {
		if (output[i].size() != nlags) output[i].resize(nlags);
	}

	std::vector<RandomWalkMatrixProcess*> threads(nb_of_threads);

	for (int id_thread = 0; id_thread < nb_of_threads; ++id_thread) {
		threads[id_thread] = new RandomWalkMatrixProcess(
			id_thread, nb_of_threads,
			gen(), &output, f, lag, dmax,
			n_random_walks);
		threads[id_thread]->start();
	}

	for (int id_thread = 0; id_thread < nb_of_threads; ++id_thread) {
		threads[id_thread]->wait();
		delete threads[id_thread];
	}

}

Named_interface* RandomWalk::create_new_interface(std::string&) {
	return new RandomWalk;
}

RandomWalk::RandomWalk()
	: kriging_estimator_(), simul_grid_(), harddata_grid_(0),
	neighborhood_(), min_neigh_(0), max_neigh_(0) {
	report_ = new RW_report(0);
	report_->setSelf(report_);
}

RandomWalk::~RandomWalk() {
	for (int i = 0; i < kriging_estimator_.size(); ++i) {
		if (kriging_estimator_[i])
			delete kriging_estimator_[i];
	}
	if (harddata_grid_ != 0 && dynamic_cast<Point_set*>(harddata_grid_)) {
		harddata_grid_->set_coordinate_mapper(0);
	}

}


// Base function of the MRW simulation (called in multithread)
void  RandomWalkProcess::execute_simulation(
	int id_thread,
	int n_threads,
	Progress_notifier* notifier,
	RandomWalk& handler,
	Prop_real& prop,
	const Vector2D& oracle,
	bool& issue_singular_system_warning,
	bool& issue_no_conditioning_data_warning,
	const Vector2D& path_pos,
	Vector2D& krig_vect,
	const Prop_real& prop_sgs)
{
	for (int i = id_thread; i < handler.simul_grid_->size(); i += n_threads) {

		if (handler.target_grid_region_ && !handler.target_grid_region_->is_inside_region(i)) continue;

		// Initializing geovalue node property
		Geovalue gval = Geovalue(handler.simul_grid_, prop[0], i);
		if (gval.is_informed() && !handler.rw_parameters_.is_cross_validation) continue;

		// Finding neighbors
		Neighbors neighbors;
		handler.neighborhood_[id_thread]->find_neighbors(gval, neighbors);
		int number_of_neighbors = neighbors.size();
		if (number_of_neighbors < handler.min_neigh_)  continue;

		// Kriging system resolution
		Kriging_system::Kriging_solve_result result;
		int status = 0;
		std::vector<double> estimate(handler.rw_parameters_.nb_of_realizations, 0);
		status = handler.kriging_system_[id_thread].solve(gval, neighbors, result);

		if (status == 0) { // The kriging system could be solved
			
			// Kriged value
			if (handler.without_sgs) krig_vect[gval.node_id()][0] = handler.kriging_estimator_[id_thread]->operator()(result.weights, neighbors);

			Neighbors::const_iterator it = neighbors.begin();
			Neighbors::const_iterator end = neighbors.end();

			// Iterating the neighbors to estimate the rw noise (and kriged value in SGS + MRW case)
			for (int count = 0; it != end && count < result.weights.size(); it++, count++) {

				double h = (handler.two_point_stat_[id_thread].c0() - handler.two_point_stat_[id_thread].operator()(it->location() - gval.location())) * (it->location() - gval.location()).length();
				int ih = static_cast<int>(h / handler.rw_parameters_.lag);

				for (int j = 0; j < handler.rw_parameters_.nb_of_realizations; ++j)
				{
					//Kriged value (for MRW + SGS case)
					if (!handler.without_sgs){
						Const_geovalue gval_aux = Const_geovalue(handler.sgs_grid_[0], prop_sgs[j], it->node_id());
						krig_vect[gval.node_id()][j] += result.weights[count] * gval_aux.property_value();
					}
					
					//MRW noise
					int sample_rw = path_pos[j][it->node_id()];
					if (ih >= oracle[sample_rw].size()) ih = oracle[sample_rw].size() - 1;

					double rw = oracle[sample_rw][ih];
					estimate[j] += rw * result.weights[count];
				}
			}

			// Assigning values to each realization property
			for (int j = 0; j < handler.rw_parameters_.nb_of_realizations; ++j)
			{
				prop[j]->set_value(estimate[j], i);
			}

			// Assigning values to the additional properties requested
			if (handler.output_kriging_){
				double krig_value = std::accumulate(krig_vect[gval.node_id()].begin(), krig_vect[gval.node_id()].end(), 0.0);
				krig_value = krig_value / krig_vect[0].size();
				handler.kriging_prop->set_value(krig_value, gval.node_id());
			}

			if (handler.output_average_distance_ && number_of_neighbors > 0) {
				float average_dist = 0.0;
				for (int i = 0; i < number_of_neighbors; ++i){
					average_dist += (gval.location() - neighbors[i].location()).length();
				}
				handler.aver_dist_prop->set_value(average_dist / (float)(number_of_neighbors), gval.node_id());
			}

			if (handler.output_n_samples_) handler.nsamples_prop->set_value(number_of_neighbors, gval.node_id());

			if (handler.output_sum_positive_weights_) {
				float sum_pos_weight = 0.0;
				for (int i = 0; i < number_of_neighbors; ++i) {
					if (result.weights[i] > 0) sum_pos_weight += result.weights[i];
				}
				handler.sum_pos_prop->set_value(sum_pos_weight, gval.node_id());
			}

			if (handler.output_sum_weights_) {
				float sum_weight = 0.0;
				for (int i = 0; i < number_of_neighbors; ++i) {
					sum_weight += result.weights[i];
				}
				sum_weight = 1 - sum_weight;
				handler.sum_weights_prop->set_value(sum_weight, gval.node_id());
			}

		}
		else { // The kriging system could not be solved, issue a warning and skip the node
			issue_singular_system_warning = true;
		}

		if (notifier) {
			if (!notifier->notify()) break;
			while (notifier->is_paused()) {
				notifier->write("Paused", 0);
			}
		}
	}
}

// This function calibrates the result to get unit variance; also back-transform values, if requested
void Calib::calibration(
	int id_thread,
	int n_threads,
	const Vector1D& restore_calib,
	const RandomWalk& handler,
	Prop_real& prop,
	const Vector2D& krig_vect,
	const Continuous_distribution& from,
	const Continuous_distribution& to,
	const Vector2D& ngt_effect)
{
	for (int i = id_thread; i < handler.simul_grid_->size(); i += n_threads) {

		if (!prop[0]->is_informed(i)) continue;
		if (!prop[0]->is_harddata(i) || handler.rw_parameters_.is_cross_validation)
		{

			for (int j = 0; j < handler.rw_parameters_.nb_of_realizations; ++j)
			{
				// Calibrating final value
				int krig_id = 0;
				if (!handler.without_sgs) krig_id = j;
				double updated;
				if (!handler.rw_parameters_.rw_manual_calib)
				{
					updated = ((prop[j]->get_value(i)) * (restore_calib[(j + 2)] / handler.rw_parameters_.scale_factor)) + krig_vect[i][krig_id] + ngt_effect[j][i];
				}
				else
				{
					updated = prop[j]->get_value(i) + krig_vect[i][krig_id] + ngt_effect[j][i];
				}

				// Back-transform normal values, if requested
				if (handler.use_target_hist_)
				{
					double P = from.prob(updated);
					prop[j]->set_value(to.inverse(P), i);
				}
				else
				{
					prop[j]->set_value(updated, i);
				}

			}
		}
	}

}

// For MRW+SGS case; This function look for and establish the places in the grid to be later simulated via SGS
std::vector<int> Locate_Auxiliary_HD(
	SmartPtr<Neighborhood>& aux_neighborhood,
	Grid_path::iterator begin,
	Grid_path::iterator end)
{
	std::vector<int> places;
	for (; begin != end; begin++)
	{

		if (begin->is_harddata()){
			continue;
		}

		Neighbors neighbors;
		aux_neighborhood->find_neighbors(*begin, neighbors);

		if (neighbors.size() < 1){
			places.push_back(begin->node_id());
			begin->set_property_value(999);
			begin->set_harddata(true);
		}
	}
	return places;
}


// For MRW+SGS case; Create a virtual pointset to use as grid in SGS to make it faster
Geostat_grid* Create_pointset(
	const Geostat_grid* simul_grid_,
	const Geostat_grid* harddata_grid_,
	const std::vector<int>& places,
	const std::string& prop_name)
{
	int grid_size = places.size() + harddata_grid_->size();
	std::string name = "Aux_pointset_" + prop_name;
	SmartPtr<Named_interface> ni = Root::instance()->interface(gridModels_manager + "/" + name);

	while (ni.raw_ptr() != 0) {
		name += "_0";
		ni = Root::instance()->interface(gridModels_manager + "/" + name);
	}

	std::string size_str = String_Op::to_string(grid_size);
	ni = Root::instance()->new_interface("point_set://" + name + "::" + size_str, gridModels_manager + "/" + name);
	Point_set* Point_Set_SGS = dynamic_cast<Point_set*>(ni.raw_ptr());
	//Point_set* Point_Set_SGS = new Point_set_property_impl_template<Grid_property_manager, Grid_region_manager>("__SGS_pointset__", grid_size);

	std::vector<GsTLPoint> xyz_location;

	for (int l = 0; l < harddata_grid_->size(); ++l) {
		GsTLPoint xyz = harddata_grid_->xyz_location(l);
		xyz_location.push_back(xyz);
	}

	for (std::vector<int>::const_iterator it = places.begin(); it != places.end(); it++) {
		GsTLPoint xyz = simul_grid_->xyz_location(*it);
		xyz_location.push_back(xyz);
	}

	Point_Set_SGS->point_locations(xyz_location);
	Geostat_grid* return_grid = dynamic_cast<Geostat_grid*>(Point_Set_SGS);
	return return_grid;
}

// For MRW+SGS case; Function to perform SGS simulation of auxiliary data (called in multithread)
void SGS::simul(
	int id_thread,
	int nb_of_realizations,
	int sgs_threads,
	const std::vector<Two_point_nested_structure>& two_point_stat_,
	const std::vector<Kriging_system>& kriging_system_,
	const std::vector<Kriging_estimator*>& kriging_estimator_,
	Prop_real& prop,
	std::vector<Geostat_grid*>& sgs_grid_,
	std::vector<SmartPtr<Neighborhood> >& neighborhood_,
	const std::vector<Geostat_grid*>& hd_grid,
	const std::vector<Grid_continuous_property*>& hd_prop,
 	std::vector<Random_number_seeds*>& seed)
{
	Gaussian_cdf marginal(0.0, 1.0);
	Gaussian_cdf ccdf;
	Gaussian_cdf_kestimator cdf_estimator(&two_point_stat_[id_thread], &kriging_system_[id_thread], kriging_estimator_[id_thread]);
	Mersenne_generator gen_m;
	Grid_path_generator* grid_path_generator_ = new Grid_path_random_generator(seed[id_thread], sgs_grid_[id_thread]);

	for (int count = id_thread; count < nb_of_realizations; count += sgs_threads) {

		std::string property_name_ = "SGS_" + std::to_string(count);
		prop[count] = geostat_utils::add_property_to_grid(sgs_grid_[id_thread], property_name_);

		// Copying harddata values to the new pointset grid
		for (int l = 0; l < hd_grid[id_thread]->size(); ++l) {
			Const_geovalue hd = Const_geovalue(hd_grid[id_thread], hd_prop[id_thread], l);
			Geovalue sgs = Geovalue(sgs_grid_[id_thread], prop[count], l);
			sgs.set_property_value(hd.property_value());
		}

		sgs_grid_[id_thread]->select_property(prop[count]->name());
		neighborhood_[id_thread]->select_property(prop[count]->name());
		//prop[count]->set_parameters(parameters);
		
		gen_m.seed(seed[id_thread]->seed(count));
		Monte_carlo_sampler_t< Mersenne_generator > sampler(gen_m);
		
		auto path = grid_path_generator_->path(count, prop[count]);

		for (Grid_path::iterator gval = path->begin(); gval != path->end(); gval++) {
			
			if (gval->is_informed()) continue;

			Neighbors neighbors;
			neighborhood_[id_thread]->find_neighbors(*gval, neighbors);


			if (neighbors.is_empty()){
				//if we don't have any conditioning data, we simply draw from the marginal
				sampler(*gval, marginal);
			}
			else {
				int status = cdf_estimator(*gval, neighbors, ccdf);
				if (status == 0) {
					sampler(*gval, ccdf);
				}
				else {
					// the ccdf could not be estimated. Draw from the marginal
					sampler(*gval, marginal);
				}
			}
			gval->set_harddata(true);
		}
	}

}



int RandomWalk::execute(GsTL_project*, Progress_notifier* notifier) {

	if (notifier) notifier->write("Initializing... ", 0);
	QTime clock_;
	clock_.start();
	bool issue_singular_system_warning = false;
	bool issue_no_conditioning_data_warning = false;
	Vector2D oracle(rw_parameters_.nb_of_randomwalks);
	int operations_int = rw_parameters_.nb_of_realizations + 2;
	Vector1D VarVector(operations_int, 0);
	Vector2D krig_vect(simul_grid_->size(), std::vector<double>(rw_parameters_.nb_of_realizations, 0));
	if (without_sgs) krig_vect.resize(simul_grid_->size(), std::vector<double>(1));
	double operations_dbl = std::sqrt(rw_parameters_.nugget);
	if (operations_dbl == 0) operations_dbl = 0.0001;
	GaussNoise ngt(0, operations_dbl);
	std::mt19937 gen;
	double f_med = 0;

	gen.seed(rw_parameters_.seed);


	// Creating the properties vectors
	Prop_real prop_sgs(rw_parameters_.nb_of_realizations);
	Prop_real prop(rw_parameters_.nb_of_realizations);
	prop[0] = multireal_rw_property_->new_realization();
	
	// Part executed when the SGS of auxiliary points is requested
	if (!without_sgs){
		// If the minimal sample distance is not informed, it is estimated via gammabar
		if (!sgs_neigh){
			if (notifier) notifier->write("Automatically find the minimal sample distance... ", 0);
			GsTLTriplet gridfill_ranges;
			GsTLTriplet gridfill_angles;

			gridfill_ranges[0] = 3 * gridcell[1];
			gridfill_ranges[1] = 3 * gridcell[0];
			gridfill_ranges[2] = 3 * gridcell[2];

			Regular_block_covariance* cvv = new Regular_block_covariance(&two_point_stat_[0]);
			double gbar, diff, ngt_gbar = rw_parameters_.nugget;
			double factor = 1.5;
			int zdiscr = 4;
			if (!three_dimensions) zdiscr = 1;

			for (int iterations = 0; iterations < 7; ++iterations){
				cvv->set_block_geometry(gridfill_ranges[1], gridfill_ranges[0], gridfill_ranges[2], 5, 5, zdiscr);
				gbar = two_point_stat_[0].c0() - cvv->c0() - ngt_gbar;

				if (iterations == 0){
					diff = gbar;
					if (gbar < 0.02){
						gbar += ngt_gbar;
						ngt_gbar = 0;
					}
				}
				else
				{
					diff -= gbar;
					std::abs(diff);
					if (iterations != 0 && diff < 0.01){
						factor *= 2;
					}
					else if (iterations != 0 && diff > 0.05){
						factor *= 0.5;
					}
				}

				if (gbar <= 0.09 && gbar >= 0.065){
					break;
				}
				else if (gbar > 0.09){
					gridfill_ranges[0] -= factor * gridcell[1];
					gridfill_ranges[1] -= factor * gridcell[0];
					gridfill_ranges[2] -= factor * gridcell[2];
				}
				else if (gbar < 0.065){
					gridfill_ranges[0] += factor * gridcell[1];
					gridfill_ranges[1] += factor * gridcell[0];
					gridfill_ranges[2] += factor * gridcell[2];
				}
			}

			delete cvv;
			for (int i = 0; i < 3; i++) {
				gridfill_angles[i] = 0;
				gridcell[i] = gridfill_ranges[i];
			}	

			// Creating auxiliary neighborhood
			aux_neighborhood = SmartPtr<Neighborhood>(simul_grid_->neighborhood(gridfill_ranges, gridfill_angles));
			aux_neighborhood->max_size(1);
		}

		if (notifier) notifier->write("Defining the aux. pointset to perform SGS... ", 0);

		// Initializing additional properties required and requested	
		this->init_option_properties(prop[0]->name(), nsamples_prop, aver_dist_prop, sum_pos_prop, sum_weights_prop, kriging_prop, prop_lochd);
		
		simul_grid_->select_property(prop_lochd->name());
		if (property_copier_) property_copier_->copy(harddata_grid_, harddata_property_, simul_grid_, prop_lochd);
		prop_lochd->set_parameters(parameters_);

		// Random path to make the search
		Grid_path_generator* grid_path_generator_;
		Random_number_seeds* seed = new Random_number_seeds_increment(rw_parameters_.seed);
		grid_path_generator_ = new Grid_path_random_generator(seed, simul_grid_);
		auto path = grid_path_generator_->path(0, prop_lochd);

		// Finding nodes to use as auxiliary data
		aux_neighborhood->select_property(prop_lochd->name());
		std::vector<int> places = Locate_Auxiliary_HD(aux_neighborhood, path->begin(), path->end());

		if (places.size() > 0){
			// Increasing nb of paths to simulate later
			rw_parameters_.nb_of_randomwalks += places.size();
			
			// Creating the pointset grid and properties where the SGS will be performed
			int sgs_threads = std::min(rw_parameters_.nb_of_threads, rw_parameters_.nb_of_realizations);
			Geostat_grid* sgs_grid = Create_pointset(simul_grid_, harddata_grid_, places, property_name_);
			sgs_grid_.resize(sgs_threads);

			for (int j = 0; j < sgs_threads; ++j) {
				sgs_grid_[j] = sgs_grid;
			}

			std::vector<Geostat_grid*> hd_grid_vect(sgs_threads);
			std::vector<Grid_continuous_property*> hd_prop_vect(sgs_threads);
			std::vector<Random_number_seeds*> seed_vect(sgs_threads);

			// Initializing neighborhood
			for (int j = 0; j < rw_parameters_.nb_of_threads; ++j) {
				if (dynamic_cast<Point_set*>(sgs_grid_[0])){
					neighborhood_[j] = SmartPtr<Neighborhood>((dynamic_cast<Point_set*>(sgs_grid_[0]))->neighborhood(ellips_ranges_saved, ellips_angles_saved));
				}
				else
				{
					neighborhood_[j] = SmartPtr<Neighborhood>(sgs_grid_[0]->neighborhood(ellips_ranges_saved, ellips_angles_saved));
				}
				neighborhood_[j]->max_size(max_neigh_);
				if (j < sgs_threads)
				{
					hd_grid_vect[j] = harddata_grid_;
					hd_prop_vect[j] = harddata_property_;
					seed_vect[j] = seed;
				}
			}


			// Starting SGS in multithread
			if (notifier) notifier->write("Simulating SGS... ", 0);
			std::vector<SGS*> process(sgs_threads);

			for (int id_thread = 0; id_thread < sgs_threads; ++id_thread) {
				process[id_thread] = new SGS(id_thread, rw_parameters_.nb_of_realizations, sgs_threads, &two_point_stat_, &kriging_system_,
					&kriging_estimator_, &prop_sgs, &sgs_grid_, &neighborhood_, &hd_grid_vect, &hd_prop_vect, &seed_vect);
			}

			for (int id_thread = 0; id_thread < sgs_threads; ++id_thread) {
				process[id_thread]->start();
			}

			for (int id_thread = 0; id_thread < sgs_threads; ++id_thread) {
				process[id_thread]->wait();
			}

			for (int id_thread = 0; id_thread < sgs_threads; ++id_thread) {
				delete process[id_thread];
			}
			
			for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
				//if (adv_search) neighborhood_[id_thread]->search_neighborhood_filter(adv_search);
				neighborhood_[id_thread]->select_property(prop_sgs[0]->name());
			}
			
		}
		else
		{
			simul_grid_->remove_property(prop_lochd->name());
			krig_vect.resize(simul_grid_->size(), std::vector<double>(1));
			without_sgs = true;
			for (int j = 0; j < rw_parameters_.nb_of_threads; ++j) {
				if (dynamic_cast<Point_set*>(harddata_grid_)) {
					harddata_grid_->set_coordinate_mapper(simul_grid_->coordinate_mapper());
					neighborhood_[j] = SmartPtr<Neighborhood>(
						(dynamic_cast<Point_set*>(harddata_grid_))->neighborhood(ellips_ranges_saved, ellips_angles_saved, 0, true, hd_grid_region_));
				}
				else {
					neighborhood_[j] = SmartPtr<Neighborhood>(harddata_grid_->neighborhood(ellips_ranges_saved, ellips_angles_saved,
						0, false, hd_grid_region_));
				}
				
				neighborhood_[j]->max_size(max_neigh_);
				//if (adv_search) neighborhood_[j]->search_neighborhood_filter(adv_search);
				neighborhood_[j]->select_property(harddata_property_name_);
			}
		}
	}

	if (notifier) notifier->write("Simulating MRW... ", 0);

	// Initializing Random Walk vector
	random_walk(gen, oracle, rw_parameters_.scale_factor,
		rw_parameters_.lag, rw_parameters_.dmax,
		rw_parameters_.nb_of_randomwalks,
		rw_parameters_.nb_of_threads);

	// Creating the MRW properties
	for (int i = 0; i < rw_parameters_.nb_of_realizations; ++i) {
		if (i != 0) prop[i] = multireal_rw_property_->new_realization();
		simul_grid_->select_property(prop[i]->name());
		if (property_copier_ && rw_parameters_.assign) property_copier_->copy(harddata_grid_, harddata_property_, simul_grid_, prop[i]);
		prop[i]->set_parameters(parameters_);
	}

	// Initializing MRW simulation

	// Associating one Random Walk to each hard data (and auxiliary data, if considered)
	if (!without_sgs)
	{
		operations_int = prop_sgs[0]->size();
	}
	else
	{
		operations_int = harddata_grid_->size();

		// Initializing other output properties requested if not initialized yet
		if (!rw_parameters_.is_cross_validation) this->init_option_properties(prop[0]->name(), nsamples_prop, aver_dist_prop, sum_pos_prop, sum_weights_prop, kriging_prop, prop_lochd);
	}

	Vector2D path_pos(rw_parameters_.nb_of_realizations, std::vector<double>(operations_int));

	for (int i = 0; i < path_pos.size(); ++i) {
		for (int j = 0; j < path_pos[0].size(); ++j)
		{
			path_pos[i][j] = gen() % oracle.size();
		}
		prop[i]->swap_to_memory(); // Using the loop to already swap the propeties to memory
	}

	// Starting MRW simulation in multithread
	std::vector<RandomWalkProcess*> threads(rw_parameters_.nb_of_threads);

	for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
		threads[id_thread] = new RandomWalkProcess(
			id_thread, rw_parameters_.nb_of_threads,
			notifier, this, &prop, &oracle,
			&issue_singular_system_warning,
			&issue_no_conditioning_data_warning, &path_pos, &krig_vect, &prop_sgs);

		threads[id_thread]->start();
	}

	for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
		threads[id_thread]->wait();
		delete threads[id_thread];
	}

	// Resetting the oracle vector to simulate and store ngt effect
	oracle.clear();
	oracle.resize(rw_parameters_.nb_of_realizations, std::vector<double>(simul_grid_->size()));

	// Resetting seed
	gen.seed(rw_parameters_.seed);

	// This loop calculates the variance of MRW noise and Kriged values
	operations_dbl = rw_parameters_.is_cross_validation ? rw_parameters_.ns_mean : 0;
	for (int j = 0; j < rw_parameters_.nb_of_realizations; ++j)
	{
		operations_int = j + 2;
		for (int i = 0; i < prop[0]->size(); ++i) {
			Const_geovalue gval_aux = Const_geovalue(simul_grid_, prop[j], i);
			if (gval_aux.is_informed() && (!gval_aux.is_harddata() || rw_parameters_.is_cross_validation)){
				if (j == 0){
					VarVector[0] += 1; // Number of simulated nodes
					if (without_sgs) VarVector[1] += ((krig_vect[i][j] - operations_dbl)*(krig_vect[i][j] - operations_dbl)); // Partial kriging variance (without SGS)
				}
				oracle[j][i] = ngt(gen);
				double val_from_prop = gval_aux.property_value();
				VarVector[operations_int] += (val_from_prop * val_from_prop); // Partial noise variance
				if (!without_sgs) VarVector[1] += ((krig_vect[i][j])*(krig_vect[i][j])); // Partial kriging variance (with SGS)
			}
		}

		if (j == 0 && without_sgs) VarVector[1] = VarVector[1] / VarVector[0]; // Final kriging variance
		VarVector[operations_int] = VarVector[operations_int] / VarVector[0]; // Final noise variance
	}
	if (!without_sgs) VarVector[1] = VarVector[1] / (VarVector[0] * rw_parameters_.nb_of_realizations);

	// This second part calculates a factor to be used for calibrations
	if (!rw_parameters_.is_cross_validation)
	{
		operations_dbl = 1 - VarVector[1] - rw_parameters_.nugget;
	}
	else
	{
		operations_dbl = rw_parameters_.ns_var - VarVector[1] - rw_parameters_.nugget;
	}

	for (int k = 2; k < VarVector.size(); ++k)
	{
		double operations_dbl_ = (operations_dbl * rw_parameters_.scale_factor * rw_parameters_.scale_factor) / VarVector[k];
		VarVector[k] = std::sqrt(operations_dbl_);
		f_med += VarVector[k];
	}

	f_med = f_med / rw_parameters_.nb_of_realizations;

	if (notifier) notifier->write("Final transformations and calibrations ...", 0);

	// Starting calibration in multithread
	std::vector<Calib*> threads2(rw_parameters_.nb_of_threads);
	SmartPtr<Continuous_distribution> normal(new Gaussian_distribution(0, 1));

	for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
		threads2[id_thread] = new Calib(id_thread, rw_parameters_.nb_of_threads, &VarVector, this, &prop, &krig_vect, normal.raw_ptr(), target_cdf_.raw_ptr(), &oracle);
		threads2[id_thread]->start();
	}

	for (int id_thread = 0; id_thread < rw_parameters_.nb_of_threads; ++id_thread) {
		threads2[id_thread]->wait();
		delete threads2[id_thread];
	}

	// Swapping properties to disk
	for (int i = 0; i < rw_parameters_.nb_of_realizations; ++i)
	{
		prop[i]->swap_to_disk();
		if (!without_sgs && prop_sgs[i]->is_in_memory()) prop_sgs[i]->swap_to_disk();
	}

	// Removing temporary properties
	if (!without_sgs) simul_grid_->remove_property(prop_lochd->name());
	if (use_target_hist_) harddata_grid_->remove_property(harddata_property_name_);


	int elapsed_time = clock_.elapsed();


	QString s_r;
	QTextStream out(&s_r);

	out << "The simulations completed in " << elapsed_time << " ms \n";
	out << "Average scale factor (f) for unit Gaussian variance = " << f_med << "\n";
	out << "Variance of the kriged values = " << VarVector[1] << "\n \n";

	if (!without_sgs && !sgs_neigh) out << "Min. sample distance after aux. data = " << gridcell[0] << "  " << gridcell[1] << "  " << gridcell[2] << "\n \n";

	out << "RW Parameters: \n";
	out << "Lag = " << rw_parameters_.lag << "\n";
	out << "Number of paths = " << rw_parameters_.nb_of_randomwalks << "\n";


	report_->write(s_r);

	return 0;
}


void RandomWalk::clean(const std::string& prop) {
	simul_grid_->remove_property(prop);
}


bool RandomWalk::initialize(const Parameters_handler* parameters,
	Error_messages_handler* errors, Progress_notifier* notifier) {

	// Extract the parameters input by the user
	bool execute_crossvalidation = String_Op::to_number<bool>(parameters->value("execute_crossvalidation.value"));
	std::string simul_grid_name = parameters->value("Grid_Name.value");
	if (execute_crossvalidation) simul_grid_name = parameters->value("Hard_Data.grid");
	errors->report(simul_grid_name.empty(), "Grid_Name", "No grid selected");
	property_name_ = parameters->value("Property_Name.value");
	errors->report(property_name_.empty(), "Property_Name", "No property name specified");

	// Getting nb of threads
	bool rw_manual_threads = String_Op::to_number<bool>(parameters->value("rw_manual_threads.value"));
	int rw_nb_of_threads;
	if (rw_manual_threads){
		rw_nb_of_threads = String_Op::to_number<int>(parameters->value("rw_nb_threads.value"));
	}
	else
	{
		rw_nb_of_threads = QThread::idealThreadCount();
		if (rw_nb_of_threads == -1) rw_nb_of_threads = 1;
	}

	// Getting nb of realizations
	int rw_nb_real = String_Op::to_number<int>(parameters->value("rw_nb_realizations.value"));

	// Get the simulation grid from the grid manager
	if (simul_grid_name.empty()) return false;
	bool ok = geostat_utils::create(simul_grid_, simul_grid_name, "Grid_Name", errors);
	if (!ok) return false;
	std::string resulting_name = execute_crossvalidation ? ("xval_" + property_name_) : property_name_;
	multireal_rw_property_ = simul_grid_->add_multi_realization_property(resulting_name);
	target_grid_region_ = simul_grid_->region(parameters->value("Grid_Name.region"));


	// Getting grid geometry
	GetGridGeom(simul_grid_, gridcell, three_dimensions);

	
	// Get the harddata grid from the grid manager
	std::string harddata_grid_name = parameters->value("Hard_Data.grid");
	errors->report(harddata_grid_name.empty(), "Hard_Data", "No hard data specified");
	harddata_property_name_ = parameters->value("Hard_Data.property");
	errors->report(harddata_property_name_.empty(), "Hard_Data", "No property name specified");
	
	if (!harddata_grid_name.empty()) {
		bool ok = geostat_utils::create(harddata_grid_, harddata_grid_name, "Hard_Data", errors);
		if (!ok) return false;
	}
	else {
		return false;
	}

	std::string harddata_region_name = parameters->value("Hard_Data.region");
	hd_grid_region_ = harddata_grid_->region(harddata_region_name);
	harddata_property_ = harddata_grid_->property(harddata_property_name_);

	// Target histogram

	use_target_hist_ = String_Op::to_number<bool>(parameters->value("Use_Target_Histogram.value"));
	if (use_target_hist_) {
		bool ok = distribution_utils::get_continuous_cdf(target_cdf_, parameters, errors, "nonParamCdf");
		if (!ok) return false;

		if (harddata_property_) {
			harddata_property_ = distribution_utils::gaussian_transform_property(harddata_property_, target_cdf_.raw_ptr(), harddata_grid_, hd_grid_region_);
			if (!harddata_property_) return false;
			harddata_property_name_ = harddata_property_->name();
		}
	}

	harddata_grid_->select_property(harddata_property_name_);
	harddata_property_->swap_to_memory();

	// Getting conditioning data restrictions
	max_neigh_ = String_Op::to_number<int>(parameters->value("Max_Conditioning_Data.value"));
	min_neigh_ = String_Op::to_number<int>(parameters->value("Min_Conditioning_Data.value"));
	errors->report(min_neigh_ >= max_neigh_, "Min_Conditioning_Data", "Min must be less than Max");

	// Set up the covariance
	two_point_stat_.resize(rw_nb_of_threads);
	for (int id_thread = 0; id_thread < rw_nb_of_threads; ++id_thread) {
		if (!geostat_utils::initialize_two_point_nested_structure(&two_point_stat_[id_thread], "Variogram", parameters, errors, simul_grid_))
		{
			return false;
		}
	}

	// Set up the SGS search neighborhood, if informed
	sgs_neigh = String_Op::to_number<bool>(parameters->value("sgs_dist.value"));
	if (sgs_neigh)
	{
		GsTLTriplet ellips_rangesSGS;
		GsTLTriplet ellips_anglesSGS;
		bool extract_ok = geostat_utils::extract_ellipsoid_definition(ellips_rangesSGS, ellips_anglesSGS, "SearchSGS.value", parameters, errors);
		if (!extract_ok) return false;
		aux_neighborhood = SmartPtr<Neighborhood>(simul_grid_->neighborhood(ellips_rangesSGS, ellips_anglesSGS));
		aux_neighborhood->max_size(1);
		without_sgs = false;
	}
	else
	{
		without_sgs = String_Op::to_number<bool>(parameters->value("rw_sgs.value"));
	}

	if (execute_crossvalidation) without_sgs = true;

	// Set up the search neighborhood
	neighborhood_.resize(rw_nb_of_threads);
	for (int id_thread = 0; id_thread < rw_nb_of_threads; ++id_thread) {

		GsTLTriplet ellips_ranges;
		GsTLTriplet ellips_angles;
		bool extract_ok = geostat_utils::extract_ellipsoid_definition(ellips_ranges, ellips_angles, "Search_Ellipsoid.value", parameters, errors);
		if (!extract_ok) return false;

		ellips_ranges_saved = ellips_ranges;
		ellips_angles_saved = ellips_angles;

		if (!without_sgs){
			//adv_search = geostat_utils::set_advanced_search("AdvancedSearch", parameters, errors);
			break;
		}

		if (dynamic_cast<Point_set*>(harddata_grid_)) {
			harddata_grid_->set_coordinate_mapper(simul_grid_->coordinate_mapper());
			neighborhood_[id_thread] = SmartPtr<Neighborhood>(
				(dynamic_cast<Point_set*>(harddata_grid_))->neighborhood(ellips_ranges, ellips_angles, 0, true, hd_grid_region_));
		}
		else {
			neighborhood_[id_thread] = SmartPtr<Neighborhood>(harddata_grid_->neighborhood(ellips_ranges, ellips_angles,
				0, false, hd_grid_region_));
		}
		neighborhood_[id_thread]->max_size(max_neigh_);
		geostat_utils::set_advanced_search(neighborhood_[id_thread].raw_ptr(), "AdvancedSearch", parameters, errors);
		neighborhood_[id_thread]->select_property(harddata_property_name_);
		if (execute_crossvalidation) neighborhood_[id_thread]->includes_center(false);
	}



	//Initializing Random Walk parameters

	double rw_dmax = ellips_ranges_saved[0];

	bool rw_manual_lag = String_Op::to_number<bool>(parameters->value("rw_manual_lag.value"));
	double rw_lag;
	if (rw_manual_lag){
		rw_lag = String_Op::to_number<double>(parameters->value("rw_lag.value"));
	}
	else
	{
		if (three_dimensions)
		{
			rw_lag = std::min({ gridcell[0], gridcell[1], gridcell[2] }) / 50;
		}
		else
		{
			rw_lag = std::min(gridcell[0], gridcell[1]) / 50;
		}

	}

	bool rw_manual_nbrw = String_Op::to_number<bool>(parameters->value("rw_manual_nbrw.value"));
	int rw_nb_rw;
	if (rw_manual_nbrw){
		rw_nb_rw = String_Op::to_number<int>(parameters->value("rw_nb_random_walks.value"));
	}
	else
	{
		rw_nb_rw = (harddata_grid_->size()) + 2000;
	}

	int rw_seed = String_Op::to_number<int>(parameters->value("rw_seed.value"));

	int rw_assign = String_Op::to_number<int>(parameters->value("rw_report.value"));

	double rw_nugget = 0;
	int struct_count = String_Op::to_number<int>(parameters->value("Variogram.structures_count"));
	for (int i = 1; i <= struct_count; i++)
	{
		std::string struct_name = "Structure_" + String_Op::to_string(i);
		std::string struct_type = parameters->value("Variogram/" + struct_name + "/Two_point_model.type");

		if (struct_type == "Nugget Covariance")
		{
			double cc = String_Op::to_number<double>(parameters->value("Variogram/" + struct_name + "/Two_point_model.contribution"));
			rw_nugget += cc;
		}
		if (struct_type == "Nugget Local Covariance")
		{
			double cc = String_Op::to_number<double>(parameters->value("Variogram/" + struct_name + "/Two_point_model/contribution.value"));
			rw_nugget += cc;
		}
	}
	rw_nugget = rw_nugget / two_point_stat_[0].c0();

	double nscore_var = 1;
	double nscore_mean = 0;

	if (execute_crossvalidation)
	{
		double sum = std::accumulate(harddata_property_->begin(), harddata_property_->end(), 0.0);
		nscore_mean = sum / harddata_property_->size();

		double sq_sum = std::inner_product(harddata_property_->begin(), harddata_property_->end(), harddata_property_->begin(), 0.0);
		nscore_var = sq_sum / harddata_property_->size() - nscore_mean * nscore_mean;
	}

	bool rw_manual_calib = String_Op::to_number<bool>(parameters->value("rw_manual_calib.value"));
	double rw_f;
	if (rw_manual_calib)
	{
		rw_f = String_Op::to_number<double>(parameters->value("rw_f.value"));
	}
	else
	{
		rw_f = 0.5;
	}

	rw_parameters_ = RandomWalkParameters(rw_seed, rw_nb_rw, rw_nb_real, rw_lag, rw_dmax, rw_f, rw_nb_of_threads, nscore_var, rw_assign, rw_nugget, execute_crossvalidation, nscore_mean, rw_manual_calib);


	// Initializing property_copier if necessary
	if (rw_parameters_.assign || !without_sgs){
		property_copier_ = Property_copier_factory::get_copier(harddata_grid_, simul_grid_);
		if (!property_copier_) {
			std::ostringstream message;
			message << "It is currently not possible to copy a property from a "
				<< harddata_grid_->classname() << " to a "
				<< simul_grid_->classname();
			errors->report(!property_copier_, "Assign_Hard_Data", message.str());
			return false;
		}
	}


	// Extra outputs requested
	output_n_samples_ = parameters->value("output_n_samples_.value") == "1";
	output_average_distance_ = parameters->value("output_average_distance.value") == "1";
	output_sum_positive_weights_ = parameters->value("output_sum_positive_weights.value") == "1";
	output_sum_weights_ = parameters->value("output_sum_weights.value") == "1";
	output_kriging_ = parameters->value("output_kriging.value") == "1";

	// The kriging constraints and combiner (SK or OK)
	std::string kriging_type = parameters->value("krigingType.value");
	if (kriging_type == "Simple Kriging (SK)") output_sum_positive_weights_ = false;
	if (kriging_type == "Ordinary Kriging (OK)") output_sum_weights_ = false;

	// init kriging system
	kriging_system_.resize(rw_nb_of_threads);
	kriging_estimator_.resize(rw_nb_of_threads);
	for (int id_thread = 0; id_thread < rw_nb_of_threads; ++id_thread) {
		if (kriging_type == "Simple Kriging (SK)"){
			kriging_system_[id_thread].kriging_constraint_is(SK_constraint());
			kriging_system_[id_thread].lhs_covariance_is(two_point_stat_[id_thread]);
			kriging_system_[id_thread].rhs_covariance_is(two_point_stat_[id_thread]);
			kriging_estimator_[id_thread] = new SK_estimator();
			((SK_estimator*)kriging_estimator_[id_thread])->kriging_mean_is(0.0);
		}
		else
		{
			kriging_system_[id_thread].kriging_constraint_is(OK_constraint());
			kriging_system_[id_thread].lhs_covariance_is(two_point_stat_[id_thread]);
			kriging_system_[id_thread].rhs_covariance_is(two_point_stat_[id_thread]);
			kriging_estimator_[id_thread] = new OK_estimator();
			((OK_estimator*)kriging_estimator_[id_thread]);
		}
	}

	if (!errors->empty()){
		return false;
	}

	this->extract_parameters(parameters);

	if (notifier) {
		int total_steps = target_grid_region_ == 0 ? this->simul_grid_->size() : target_grid_region_->active_size();
		notifier->total_steps(total_steps);
		notifier->frequency(20);
	}

	return true;
}

// Initializing auxiliar and extra properties
void  RandomWalk::init_option_properties(std::string base_name,
	Grid_continuous_property*& nsamples_prop,
	Grid_continuous_property*& aver_dist_prop, Grid_continuous_property*& sum_pos_prop,
	Grid_continuous_property*& sum_weights_prop, Grid_continuous_property*& kriging_prop,
	Grid_continuous_property*& prop_lochd)
{
	if (!without_sgs) {
		std::string prop_name = base_name + "_aux_data";
		prop_lochd = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		prop_lochd->set_parameters(parameters_);
	}
	if (output_n_samples_) {
		std::string prop_name = base_name + "_n_samples";
		nsamples_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		nsamples_prop->set_parameters(parameters_);
	}
	if (output_average_distance_) {
		std::string prop_name = base_name + "_average_sample_dist";
		aver_dist_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		aver_dist_prop->set_parameters(parameters_);
	}
	if (output_sum_positive_weights_) {
		std::string prop_name = base_name + "_sum_positive_weights";
		sum_pos_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		sum_pos_prop->set_parameters(parameters_);
	}
	if (output_sum_weights_) {
		std::string prop_name = base_name + "_weights_for_the_mean";
		sum_weights_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		sum_weights_prop->set_parameters(parameters_);
	}

	if (output_kriging_) {
		std::string prop_name = base_name + "_kriging";
		kriging_prop = geostat_utils::add_property_to_grid(simul_grid_, prop_name);
		kriging_prop->set_parameters(parameters_);
	}

}

void RandomWalk::GetGridGeom(
	Geostat_grid* simul_grid_,
	std::vector<double>& gridcell,
	bool& three_dimensions)
{
	gridcell.resize(3);
	if (dynamic_cast<const Cartesian_grid*>(simul_grid_)){
		const RGrid_geometry* src_geom = dynamic_cast<const Cartesian_grid*>(simul_grid_)->geometry();
		gridcell[0] = src_geom->cell_dims().x();
		gridcell[1] = src_geom->cell_dims().y();
		gridcell[2] = src_geom->cell_dims().z();
		if (src_geom->nk() == 1) three_dimensions = false;
	}
	else
	{
		gridcell[0] = 1;
		gridcell[1] = 1;
		gridcell[2] = 1;
	}
}
