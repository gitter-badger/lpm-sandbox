/*
Implementa��o do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/



#ifndef __PLUGINS_LPM_UFRGS_HISTOGRAM_H___ 
#define __PLUGINS_LPM_UFRGS_HISTOGRAM_H___

#include "common.h"

#include <qstring.h>
#include <qstringlist.h>
#include <QFrame>

#include "ui_histogram.h"

class LPMHistogram : public QFrame
{
	Q_OBJECT

public:
    LPMHistogram(QWidget *parent = 0);
    ~LPMHistogram();

	int getNumberBins();
	int getNumberThreads();

	QPushButton* getDisplayButton();

	QStringList getProperties();
	Geostat_grid* getGrid();

    Ui::Histogram& getUi() { return ui; }

private:	
    Ui::Histogram ui;
};

#endif

