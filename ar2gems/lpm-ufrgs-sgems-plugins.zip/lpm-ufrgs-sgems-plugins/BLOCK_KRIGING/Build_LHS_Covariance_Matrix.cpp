# include "Covariance_Point_Point.h"
# include "Covariance_Point_Block.h"
# include "Covariance_Block_Block.h"
# include "Build_LHS_Covariance_Matrix.h"
# include <vector>
# include <map>

# include <iostream>

// the function receives the points and blocks which will be used in the estimates


using namespace std;


vector<vector<double> > Build_LHS_Covariance_Matrix(Geostat_grid *Point_samples_grid, const std::vector<std::vector<double> > &samples, const std::vector<std::vector<double> > &Point_To_Block_Covariance_Lookup_Table, std::vector<std::vector<double> > &Block_To_Block_Covariance_Lookup_Table, const vector<int> &block_ids, const Two_point_nested_structure &covar_, const int &kriging_option) {
    int Number_Of_Samples = samples.size();
    int Number_Of_Blocks = block_ids.size();
    vector<vector<double> > LHS_Covariance_Matrix; // Define the matrix which will receive the covariances
    // Calculate all covariance point-point among the sample points
    for(size_t i = 0; i < (Number_Of_Samples + Number_Of_Blocks) ; ++i)	{
        vector<double> row;
        for(size_t j = 0; j < (Number_Of_Samples + Number_Of_Blocks) ; ++j) {
            if(i < Number_Of_Samples) {
                if(j < Number_Of_Samples) { //Calculate Covariance Point-Point
                    double covariance_sample_point_sample_point = Covariance_Point_Point(Point_samples_grid, samples[i][4], Point_samples_grid, samples[j][4], covar_);
                    row.push_back(covariance_sample_point_sample_point);
                } else { // Calculate Covariance Point-Block
                    int Block_Indice_j = j - Number_Of_Samples;
                    int point_node_id = samples[i][4];
                    int block_node_id = block_ids[Block_Indice_j];
                    double covariance_sample_point_sample_block = Point_To_Block_Covariance_Lookup_Table[point_node_id][block_node_id];
                    row.push_back(covariance_sample_point_sample_block);
                }
            } else {
                if(j < Number_Of_Samples) { //Calculate Covariance Block-Point
                    int Block_Indice_i = i - Number_Of_Samples;
                    int block_node_id = block_ids[Block_Indice_i];
                    int point_node_id = samples[j][4];
                    double covariance_sample_point_sample_block = Point_To_Block_Covariance_Lookup_Table[point_node_id][block_node_id];
                    row.push_back(covariance_sample_point_sample_block);
                } else { // Calculate Covariance Block-Block
                    int Block_Indice_i = i - Number_Of_Samples;
                    int Block_Indice_j = j - Number_Of_Samples;
                    int Block_id_i = block_ids[Block_Indice_i];
                    int Block_id_j = block_ids[Block_Indice_j];
                    double covariance_block_block = Block_To_Block_Covariance_Lookup_Table[Block_id_i][Block_id_j];
                    row.push_back(covariance_block_block);
                }
            }
        }
        LHS_Covariance_Matrix.push_back(row);
    }
    int size = LHS_Covariance_Matrix[0].size();
    // If kriging option = 0; simple kriging
    // If kriging option = 1; ordinary kriging
    if(kriging_option == 1) {
        for (size_t i = 0; i < size; ++i) { // add colum to the lines of the Matrix
            double Um = 1.00;
            LHS_Covariance_Matrix[i].push_back(Um);
        }
        //Complete last row of the LHS_Covariance_Matrix
        vector<double> last_row_LHS_cova_matrix_ordinary_kriging;
        for (size_t j = 0; j < LHS_Covariance_Matrix[0].size(); ++ j) {
            double Zero = 0.00;
            double Um = 1.00;
            if (j < (LHS_Covariance_Matrix[0].size()-1) ) {
                last_row_LHS_cova_matrix_ordinary_kriging.push_back(Um);
            } else {
                last_row_LHS_cova_matrix_ordinary_kriging.push_back(Zero);
            }
        }
        LHS_Covariance_Matrix.push_back(last_row_LHS_cova_matrix_ordinary_kriging);
    }
    return LHS_Covariance_Matrix;
}

