/*
Implementação do RANDOM WALK.

(c) 2014, LPM/UFRGS, Rafael Caixeta, Péricles Lopes Machado

BASED ON AR2GEMS KRIGING IMPLEMENTATION
*/



#include "report.h"

RW_report::RW_report(QWidget *parent):QDialog(parent){
	ui.setupUi(this);
	self = 0;
    QObject::connect(this,
                     SIGNAL(setText(QString)),
                     this,
                     SLOT(setReport(QString)),
                     Qt::QueuedConnection
                     );

}

RW_report::~RW_report(){

}
