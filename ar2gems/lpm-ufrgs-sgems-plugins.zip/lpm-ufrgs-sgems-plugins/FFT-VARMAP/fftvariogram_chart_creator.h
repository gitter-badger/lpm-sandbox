/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/


#ifndef __PLUGINS_LPM_UFRGS_FFTVARIOGRAM_CHART_CREATOR_H___ 
#define __PLUGINS_LPM_UFRGS_FFTVARIOGRAM_CHART_CREATOR_H___

#include "common.h"

#include <charts/chart_widget.h>
#include <charts/chart_creator.h>
#include <charts/chart_mdi_area.h>
#include <qtplugins/selectors.h>
#include <qtplugins/categorical_selectors.h>
#include <grid/grid_filter.h>

#include <QDialog>
#include <QMainWindow>
#include <QItemSelectionModel>
#include <QLineEdit>
#include <QDoubleSpinBox>
#include <QRadioButton>

#include <map>

#include "fftvariogram.h"
#include "fftcrossvariogram.h"
#include "fftvariogram_declus.h"
#include "fftcrossvariogram_declus.h"

#include "fftprocess.h"


class PLUGINS_LPM_UFRGS_DECL FFTVariogram_chart_creator : public Chart_creator
{
	Q_OBJECT

public:
	FFTVariogram_chart_creator(Chart_mdi_area* mdi_area, QWidget *parent = 0);
	~FFTVariogram_chart_creator();

private slots:
	void kill_process(FFTProcess*);

	void show_chart_variogram();
	void show_chart_crossvariogram();
	void show_chart_crossvariogram_declus();
	void show_chart_variogram_declus();

	void create_variogram_process(FFTAction* chart, int n_steps, int n_threads);

	FFTVariogram* getVariogram() { return my_variogram_;  }
	FFTCrossVariogram* getCrossVariogram() { return my_crossvariogram_; }
	FFTCrossVariogramDeclus* getCrossVariogramDeclus() { return my_crossvariogram_declus_; }
	FFTVariogramDeclus* getVariogramDeclus() { return my_variogram_declus_; }

private:

	FFTVariogram* build_variogram_page();
	FFTCrossVariogram* build_crossvariogram_page();
	FFTVariogramDeclus* build_variogram_declus_page();
	FFTCrossVariogramDeclus* build_crossvariogram_declus_page();


	FFTVariogram* my_variogram_;
	FFTCrossVariogram* my_crossvariogram_;
	FFTCrossVariogramDeclus* my_crossvariogram_declus_;
	FFTVariogramDeclus* my_variogram_declus_;
};

class PLUGINS_LPM_UFRGS_DECL FFTVariogram_chart_creator_factory : public Chart_creator_factory
{

public:

	static Named_interface* create_new_interface(std::string&) {
		return new FFTVariogram_chart_creator_factory;
	}

	FFTVariogram_chart_creator_factory(){}
	~FFTVariogram_chart_creator_factory(){}

	virtual QString title_name() const { return "FFT-Variogram"; }
	virtual QString tab_name() const{ return "LPM_UFRGS"; }
	std::string name() const { return "FFT-Variogram"; }

	virtual Chart_creator* get_interface(Chart_mdi_area* mdi_area){ return new FFTVariogram_chart_creator(mdi_area); }

};


#endif
