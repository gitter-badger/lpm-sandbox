
# include "Create_Areal_Dataset.h"
# include <vector>
# include <map>
# include "Struct_Drillhole.h"


std::vector<std::vector<double> > Create_Areal_Dataset(const std::map<int, Struct_Drillhole> &Map_Drillhole) {
    std::vector<std::vector<double> > Areal_Dataset;
    for(std::map<int, Struct_Drillhole>:: const_iterator it = Map_Drillhole.begin(), end = Map_Drillhole.end(); it != end; ++it) {
        std::vector<double> Areal_Dataset_Row;
        Areal_Dataset_Row.push_back(it->second.X_Centroid);
        Areal_Dataset_Row.push_back(it->second.Y_Centroid);
        Areal_Dataset_Row.push_back(0.00); //As the dataset is areal, the Z coordinate receives elevation equals to zero
        Areal_Dataset_Row.push_back(it->second.Average);
        Areal_Dataset_Row.push_back(it->first);
        Areal_Dataset_Row.push_back(it->second.Grades.size());
        Areal_Dataset.push_back(Areal_Dataset_Row);
    }
    return Areal_Dataset;
}