# include "Create_Block_Centroid_Point_Set_From_Block_Map.h"
# include "Struct_Block.h"
# include <string>
# include <map>
# include <vector>
# include <grid/point_set.h>
# include <grid/point_set_impl.h>
# include <math/gstlpoint.h>

using namespace std;

bool Create_Block_Centroid_Point_Set_From_Block_Map(Point_set * &Block_Centroids_Point_Set, const string &Point_Set_Name, const map<int, Struct_Block> &Map_ID_Blocks) {
    Block_Centroids_Point_Set = new Point_set_property_impl_template<Grid_property_manager, Grid_region_manager>("Block_Centroids_Point_Set", Map_ID_Blocks.size());
    //Block_Centroids_Point_Set = new  Point_set("Block_Centroids_Point_Set", Map_ID_Blocks.size());
    //Grid_continuous_property *Copy_Pointer = Block_Locations_Point_set->add_property("Block_ID");
    vector<GsTLPoint> xyz_location;
    vector<int> Block_ID_vector;
    for(std::map<int, Struct_Block>::const_iterator map_it_begin = Map_ID_Blocks.begin(), map_it_end = Map_ID_Blocks.end(); map_it_begin != map_it_end; ++map_it_begin) {
        //Struct_Block *second = &map_it_begin->second;
        GsTLTripletTmpl<GsTLCoord> tripla(map_it_begin->second.X_centroid, map_it_begin->second.Y_centroid, map_it_begin->second.Z_centroid);
        xyz_location.push_back(tripla);
        Block_ID_vector.push_back(map_it_begin->first);
        //Copy_Pointer->set_value(map_it_begin->first, map_it_begin);
    }
    //Add the xyz_location vector of triples
    Block_Centroids_Point_Set->point_locations(xyz_location);
    // add the property Block_ID
    Grid_continuous_property *Property_Pointer = Block_Centroids_Point_Set->add_property("Block_ID");
    //Teste = Copy_Pointer;
    //map<int, Struct_Block>:: const_iterator begin = Map_ID_Blocks.begin();
    //map<int, Struct_Block>:: const_iterator end = Map_ID_Blocks.end();
    for(size_t i = 0; i < Block_Centroids_Point_Set->size() ; ++i) {
        Property_Pointer->set_value(Block_ID_vector[i], i);
        double teste = Property_Pointer->get_value(i);
    }
    return  true;
}
