#ifndef TRANSFORM_NEIGH_TO_VECTOR_OF_VECTORS_H
#define TRANSFORM_NEIGH_TO_VECTOR_OF_VECTORS_H

# include "Transform_Neigh_To_Vector_Of_Vectors.h"
# include <vector>
# include <grid/geovalue.h>

std::vector<std::vector<double> > Transform_Neigh_To_Vector_Of_Vectors(const std::vector<Geovalue> &neigh_);

#endif