/*
Implementação do plugin que realiza o moving window.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/

#include "moving_window_algorithms.h"

#include "moving_window_action.h"

#include <geostat/utilities.h>
#include <utils/string_manipulation.h>
#include <grid/utilities.h>
#include <grid/neighbors.h>
#include <grid/cartesian_grid.h>
#include <geostat/utilities.h>

#include <GsTL/utils/smartptr.h>
#include <utils/gstl_messages.h>
#include <utils/manager_repository.h>

#include <qstring.h>
#include <qmessagebox.h>
#include <cstdio>

MovingWindowAlgorithms::MovingWindowAlgorithms() {
}

MovingWindowAlgorithms::~MovingWindowAlgorithms() {
}

Named_interface* MovingWindowAlgorithms::create_new_interface(std::string&) {
    return new MovingWindowAlgorithms;
}

Named_interface* create_cart_grid( std::string& name) {
    return new Cartesian_grid(name);
}

bool MovingWindowAlgorithms::initialize(const Parameters_handler* parameters,
                                        Error_messages_handler* errors, Progress_notifier* notifier) {
    this->errors_ = errors;
    std::string grid_input_name = parameters->value("grid_input.value");
    if (grid_input_name.size() < 1) {
        errors->report("grid_input", "parameter is missing");
        return false;
    }
    std::string prop_name = parameters->value("prop_input.value");
    if (prop_name.size() < 1) {
        errors->report("prop_input", "parameter is missing");
        return false;
    }
    std::string grid_output_name = parameters->value("output_grid_name.value");
    if (grid_output_name.size() < 1) {
        errors->report("output_grid_name", "parameter is missing");
        return false;
    }
    std::string dx = parameters->value("dx.value");
    std::string dy = parameters->value("dy.value");
    std::string dz = parameters->value("dz.value");
    std::string x_size = parameters->value("x_size.value");
    std::string y_size = parameters->value("y_size.value");
    std::string z_size = parameters->value("z_size.value");
    double dx_ = String_Op::to_number<double>(dx);
    double dy_ = String_Op::to_number<double>(dy);
    double dz_ = String_Op::to_number<double>(dz);
    double x_size_ = String_Op::to_number<double>(x_size);
    double y_size_ = String_Op::to_number<double>(y_size);
    double z_size_ = String_Op::to_number<double>(z_size);
    if (dx_ < 1e-8 || dy_ < 1e-8 || dz_ < 1e-8 ||
            x_size_ < 1e-8 || y_size_ < 1e-8 || z_size_ < 1e-8) {
        errors->report("dx", "parameter is wrong");
        errors->report("dy", "parameter is wrong");
        errors->report("dz", "parameter is wrong");
        errors->report("x_size", "parameter is wrong");
        errors->report("y_size", "parameter is wrong");
        errors->report("z_size", "parameter is wrong");
        return false;
    }
    this->params =
        grid_input_name + "::" +
        prop_name + "::" +
        grid_output_name + "::" +
        dx + "::" +
        dy + "::" +
        dz + "::" +
        x_size + "::" +
        y_size + "::" +
        z_size
        ;
    this->action_ = new MovingWindow();
    return true;
}

int MovingWindowAlgorithms::execute(GsTL_project* proj, Progress_notifier* notifier) {
    if (!static_cast<MovingWindow*>(action_)->init(this->params, proj, errors_)) {
        return false;
    }
    return  static_cast<MovingWindow*>(action_)->exec(notifier);
}

