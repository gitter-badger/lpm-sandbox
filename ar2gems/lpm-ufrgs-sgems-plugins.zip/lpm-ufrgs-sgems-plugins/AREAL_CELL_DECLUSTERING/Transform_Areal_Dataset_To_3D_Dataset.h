#ifndef TRANSFORM_AREAL_DATASET_TO_3D_DATASET_H
#define TRANSFORM_AREAL_DATASET_TO_3D_DATASET_H

# include <vector>
# include <map>
# include "Struct_Drillhole.h"


std::vector<std::vector<double> > Transform_Areal_Dataset_To_3D_Dataset(std::map<int, Struct_Drillhole > &Map_Drillhole, const std::vector<double> &wopt, const std::vector<int> &bhid);

#endif