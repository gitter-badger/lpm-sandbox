#ifndef COVARIANCE_BLOCK_BLOCK_H
#define COVARIANCE_BLOCK_BLOCK_H

# include "Covariance_Point_Point.h"
# include <vector>


double Covariance_Block_Block(Geostat_grid *block_i_grid, const std::vector<std::vector<double> > &block_i, Geostat_grid *block_j_grid, const std::vector<std::vector<double> > &block_j, const  Two_point_nested_structure &covar_);
#endif
