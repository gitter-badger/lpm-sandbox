# ifndef STRUCT_BLOCK_H
# define STRUCT_BLOCK_H
# include <vector>


struct Struct_Block {
    std::vector<double> X_Locations;
    std::vector<double> Y_Locations;
    std::vector<double> Z_Locations;

    std::vector<int> node_id;

    int Block_ID;
    double Block_Value;
    double X_centroid;
    double Y_centroid;
    double Z_centroid;

    Struct_Block() {}
};


#endif