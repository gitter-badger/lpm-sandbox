/*
Implementação do plugin que realiza o model validation.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/


#include "model_validation_graphout.h"


ModelValidationGraphOutput::ModelValidationGraphOutput(QWidget *parent)
: QFrame(parent)
{
	ui.setupUi(this);

}

ModelValidationGraphOutput::~ModelValidationGraphOutput()
{
}
