/*
Implementação do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/


#include "accplotgraphout.h"


AccPlotGraphOutput::AccPlotGraphOutput(QWidget *parent)
    : QFrame(parent) {
    ui.setupUi(this);
}

AccPlotGraphOutput::~AccPlotGraphOutput() {
}
