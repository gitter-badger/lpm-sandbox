#ifndef COVARIANCE_POINT_BLOCK_H
#define COVARIANCE_POINT_BLOCK_H
# include <vector>

double Covariance_Point_Block(Geostat_grid *point_i_grid, const int &node_id_point_i, Geostat_grid *block_j_grid, const std::vector<std::vector<double> > &block_j, const  Two_point_nested_structure &covar_);


#endif
