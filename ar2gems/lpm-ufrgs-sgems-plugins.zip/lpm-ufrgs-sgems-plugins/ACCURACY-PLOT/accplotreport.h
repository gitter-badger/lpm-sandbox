/*
Implementação do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/


#ifndef ACCPLOT_REPORT_H_
#define ACCPLOT_REPORT_H_

#include "common.h"
#include <QDialog>
#include <QMainWindow>
#include <QCloseEvent>
#include <ui_accplotreport.h>


class AccPlotReport : public QDialog
{
	Q_OBJECT

public:
	AccPlotReport(QWidget *parent = 0);
	~AccPlotReport();

    void write(QString msg){
        emit setText(msg);
    }

signals:
    void setText(QString text);
	
public slots:
    void setReport(QString text) {
        this->ui.report_text->setText(text);
        this->show();
    }

	void setSelf(AccPlotReport* r) {
		self = r;
	}

	void autoDestroy() {
		if (self) delete self;
	}


private:
	AccPlotReport* self;
	Ui::AccPlotReport ui;
};

#endif /* ACCPLOT_REPORT_H_ */
