/**
 * Clever programming language
 * Copyright (c) Clever Team
 *
 * This file is distributed under the MIT license. See LICENSE for details.
 */

#ifndef CLEVER_CTHREAD_H
#define CLEVER_CTHREAD_H

#ifndef CLEVER_WIN32
# include <pthread.h>
#else
# include <windows.h>
#endif


namespace clever {

#if defined(_WIN32) || defined(WIN32)
#ifdef LIB_STATIC
#define PLUGINS_LPM_UFRGS_DECL
#else
#ifdef PLUGINS_LPM_UFRGS_EXPORT
#define PLUGINS_LPM_UFRGS_DECL __declspec(dllexport)
#else
#define PLUGINS_LPM_UFRGS_DECL __declspec(dllimport)
#endif
#endif
#else
#define PLUGINS_LPM_UFRGS_DECL
#endif

class PLUGINS_LPM_UFRGS_DECL CMutex {
  public:
    CMutex();

    ~CMutex();

    bool lock();
    bool unlock();

#ifndef CLEVER_WIN32
    pthread_mutex_t m_mut;
#else
    HANDLE m_mut;
#endif

  private:
};

#ifndef CLEVER_WIN32
# define CLEVER_THREAD_FUNC(name) void* name(void *arg)
typedef void* (*ThreadFunc)(void*);
#else
typedef DWORD (*ThreadFunc)(LPVOID);
# define CLEVER_THREAD_FUNC(name) DWORD name(void *arg)
#endif

class PLUGINS_LPM_UFRGS_DECL CThread {
  public:
    CThread()
        : m_is_running(false), t_mutex() {}

    ~CThread() {
        t_mutex.lock();
        bool status = m_is_running;
        t_mutex.unlock();
        if (status) {
            wait();
        }
    }

    void create(ThreadFunc, void*);

    bool isRunning() {
        t_mutex.lock();
        bool status = m_is_running;
        t_mutex.unlock();
        return status;
    }

    int wait();

  private:
    bool m_is_running;
#ifndef CLEVER_WIN32
    pthread_t t_handler;
#else
    HANDLE t_handler;
#endif
    CMutex t_mutex;
};

} // clever

#endif // CLEVER_CTHREAD_H

