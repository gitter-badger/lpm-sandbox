/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftvariogram.h"

FFTVariogram::FFTVariogram(QWidget *parent)
: QFrame(parent) 
{
	ui.setupUi(this);

	QStringList labels;

	labels << "x" << "y" << "z";

	ui.varPropTable->setColumnCount(3);
	ui.varPropTable->setRowCount(1);
	ui.varPropTable->setHorizontalHeaderLabels(labels);

}

void FFTVariogram::updateNumberVariograms(int nVariograms)
{
	ui.varPropTable->setRowCount(nVariograms);
}


double FFTVariogram::getX(int row, bool* ok)
{
	if (ui.varPropTable->item(row, 0) == 0) return 0;
	return ui.varPropTable->item(row, 0)->text().toDouble(ok);
}

double FFTVariogram::getY(int row, bool* ok)
{
	if (ui.varPropTable->item(row, 1) == 0) return 0;
	return ui.varPropTable->item(row, 1)->text().toDouble(ok);
}

double FFTVariogram::getZ(int row, bool* ok)
{
	if (ui.varPropTable->item(row, 2) == 0) return 0;
	return ui.varPropTable->item(row, 2)->text().toDouble(ok);
}

void FFTVariogram::checkCell(int x, int y)
{
	bool ok = true;
	
	if (ui.varPropTable->item(x, y) == 0) {
		ui.varPropTable->item(x, y)->setText("0");
		return;
	}

	double v = ui.varPropTable->item(x, y)->text().toDouble(&ok);

	if (!ok) {
		ui.varPropTable->item(x, y)->setText("0");
	}
}

int FFTVariogram::getNumberVariograms()
{
	return ui.varPropTable->rowCount();
}

int FFTVariogram::getNumberLags()
{
	return ui.nLags->value();
}

int FFTVariogram::getNumberThreads()
{
	return ui.nThreads->value();
}

QStringList FFTVariogram::getProperties()
{
	return ui.props->selected_properties();
}

Geostat_grid* FFTVariogram::getGrid()
{
	return ui.grid->selected_grid_object();
}

FFTVariogram::~FFTVariogram()
{

}

QPushButton* FFTVariogram::getDisplayButton()
{
	return ui.displayButton;
}

double FFTVariogram::getDx()
{
	return ui.dx->value();
}

double FFTVariogram::getDy()
{
	return ui.dy->value();
}

double FFTVariogram::getDz()
{
	return ui.dz->value();
}

bool FFTVariogram::computeCovariance()
{
	return ui.compute_covariance->isChecked();
}

bool FFTVariogram::computeVariogram()
{
	return ui.compute_variogram->isChecked();
}

