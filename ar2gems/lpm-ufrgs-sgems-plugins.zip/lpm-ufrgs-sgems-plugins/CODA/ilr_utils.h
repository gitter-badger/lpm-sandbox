/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#ifndef PLUGINS_LPM_UFRGS_ILR_UTILS_H_
#define PLUGINS_LPM_UFRGS_ILR_UTILS_H_

#include <vector>

using std::size_t;
void build_partition(std::vector<std::vector<double> >& p, size_t dim, size_t ini, size_t l, size_t npl);

#endif // PLUGINS_LPM_UFRGS_ILR_UTILS_H_
