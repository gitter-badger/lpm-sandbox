/* -----------------------------------------------------------------------------
** Copyright (c) 2012 Advanced Resources and Risk Technology, LLC
** All rights reserved.
**
** This file is part of Advanced Resources and Risk Technology, LLC (AR2TECH)
** version of the open source software sgems.  It is a derivative work by
** AR2TECH (THE LICENSOR) based on the x-free license granted in the original
** version of the software (see notice below) and now sublicensed such that it
** cannot be distributed or modified without the explicit and written permission
** of AR2TECH.
**
** Only AR2TECH can modify, alter or revoke the licensing terms for this
** file/software.
**
** This file cannot be modified or distributed without the explicit and written
** consent of AR2TECH.
**
** Contact Dr. Alex Boucher (aboucher@ar2tech.com) for any questions regarding
** the licensing of this file/software
**
** The open-source version of sgems can be downloaded at
** sourceforge.net/projects/sgems.
** ----------------------------------------------------------------------------*/


#include <actions/coord_mapper_actions.h>
#include <grid/coordinate_mapper_from_centroid.h>
#include <appli/action.h>
#include <math/random_numbers.h>
#include <utils/gstl_messages.h>
#include <utils/string_manipulation.h>
#include <utils/error_messages_handler.h>
#include <utils/manager_repository.h>
#include <appli/project.h>
#include <grid/rgrid.h>
#include <grid/grid_path.h>
#include <geostat/utilities.h>
#include <math/angle_convention.h>

#include <limits>

#if defined (RELEASE_PYTHON_IN_DEBUG) && defined (_DEBUG)
  #undef _DEBUG
  #include <Python.h>
  #define _DEBUG
#else
  #include <Python.h>
#endif

#include <GsTL/math/math_functions.h>


Named_interface* 
Coord_mapper_set_uvw::create_new_interface( std::string& ) {
  return new Coord_mapper_set_uvw; 
}


bool Coord_mapper_set_uvw::init( std::string& parameters,
                                GsTL_project* proj,
                                Error_messages_handler* errors,
                                Progress_notifier* notifier )
{
  std::vector< std::string > params = String_Op::decompose_string(parameters,Actions::separator,Actions::unique );

  if( params.size() < 4 ) return false;

  std::string grid_name = params[0];
  SmartPtr<Named_interface> grid_ni = Root::instance()->interface( gridModels_manager + "/" + grid_name );
  grid_ = dynamic_cast<Geostat_grid*>( grid_ni.raw_ptr() );
  if( !grid_ ) {
    std::ostringstream message;
    message << "No grid called \"" << grid_name << "\" was found";
    errors->report( message.str() );
    return false;
  }

  prop_u_ = grid_->property( params[1] );
  if(prop_u_ == 0) {
    errors->report( "No property called "+params[1] );
    return false;
  }

  prop_v_ = grid_->property( params[2] );
  if(prop_v_ == 0) {
    errors->report( "No property called "+params[2] );
    return false;
  }

  prop_w_ = grid_->property( params[3] );
  if(prop_w_ == 0) {
    errors->report( "No property called "+params[3] );
    return false;
  }

  // Check if there are any NaN in the three properties:
  for (int ii=0;ii<grid_->size();++ii){
    if( !prop_u_->is_informed( ii ) ) {
      std::ostringstream message;
      message << "Property "<< params[1] << " contains a NaN property (nodeid=" << ii << ") - action aborted after that";
      errors->report( message.str() );
      return false;
    }
  }
  for (int ii=0;ii<grid_->size();++ii){
    if( !prop_v_->is_informed( ii )  ) {
      std::ostringstream message;
      message << "Property "<< params[2] << " contains a NaN property (nodeid=" << ii << ") - action aborted after that";
      errors->report( message.str() );
      return false;
    }
  }
  for (int ii=0;ii<grid_->size();++ii){
    if( !prop_w_->is_informed( ii )  ) {
      std::ostringstream message;
      message << "Property "<< params[3] << " contains a NaN property (nodeid=" << ii << ") - action aborted after that";
      errors->report( message.str() );
      return false;
    }
  }


  return true;

}

bool Coord_mapper_set_uvw::exec(  Progress_notifier* notifier ) {

  RGrid* rgrid = dynamic_cast<RGrid*>(grid_);
  if (rgrid) {
    RGrid_coordinate_mapper_from_centroid* coord_ = new RGrid_coordinate_mapper_from_centroid(rgrid->cursor(), rgrid->geometry(), prop_u_, prop_v_, prop_w_);
    grid_->set_coordinate_mapper(coord_);
  }
  else {
    Grid_coordinate_mapper_from_centroid* coord_ = new Grid_coordinate_mapper_from_centroid(grid_, prop_u_, prop_v_, prop_w_);
    grid_->set_coordinate_mapper(coord_);
  }
  return true;

}


// -----------------------------------------------------

Named_interface* 
  Coord_mapper_set_to_xyz::create_new_interface( std::string& ) {
  return new Coord_mapper_set_to_xyz; 
};

bool Coord_mapper_set_to_xyz::init( std::string& parameters,
                                GsTL_project* proj,
                                Error_messages_handler* errors,
                                Progress_notifier* notifier )
{
  std::vector< std::string > params = String_Op::decompose_string(parameters,Actions::separator,Actions::unique );
  if( params.size() < 1 ) return false;
  std::string grid_name = params[0];
  SmartPtr<Named_interface> grid_ni = Root::instance()->interface( gridModels_manager + "/" + grid_name );
  grid_ = dynamic_cast<Geostat_grid*>(grid_ni.raw_ptr());
  if( !grid_ ) {
    std::ostringstream message;
    message << "No grid called \"" << grid_name << "\" was found";
    errors->report( message.str() );
    return false;
  }
  return true;
};


bool Coord_mapper_set_to_xyz::exec(  Progress_notifier* notifier ) {
  grid_->set_coordinate_mapper(0);
  return true;
};

