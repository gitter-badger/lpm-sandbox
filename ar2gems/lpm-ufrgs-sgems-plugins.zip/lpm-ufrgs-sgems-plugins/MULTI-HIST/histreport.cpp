/*
Implementação do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/



#include "histreport.h"

HistogramReport::HistogramReport(QWidget *parent):QDialog(parent){
	ui.setupUi(this);
	self = 0;
    QObject::connect(this,
                     SIGNAL(setText(QString)),
                     this,
                     SLOT(setReport(QString)),
                     Qt::QueuedConnection
                     );
}

HistogramReport::~HistogramReport(){

}
