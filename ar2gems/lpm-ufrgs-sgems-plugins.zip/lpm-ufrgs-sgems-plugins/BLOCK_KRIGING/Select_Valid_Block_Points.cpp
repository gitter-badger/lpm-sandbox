# include <vector>

using namespace std;

vector<vector<double> > Select_Valid_Block_Points(const vector<vector<double> > &Block_Points_Inside_Neighborhood){

	vector<vector<double> > Valid_Block_Points; // a Valida block point is a point whose Block_ID is greater than zero

	for( size_t row_index = 0; row_index < Block_Points_Inside_Neighborhood.size(); ++row_index){
		//vector<double> row;
		if(Block_Points_Inside_Neighborhood[row_index][3] > 0){
				
			Valid_Block_Points.push_back(Block_Points_Inside_Neighborhood[row_index]);
	
	    }
	}

	return Valid_Block_Points;
}

