/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftvariogram_declus.h"

FFTVariogramDeclus::FFTVariogramDeclus(QWidget *parent)
    : QFrame(parent) {
    ui.setupUi(this);
    QStringList labels;
    labels << "x" << "y" << "z";
    ui.varPropTable->setColumnCount(3);
    ui.varPropTable->setRowCount(1);
    ui.varPropTable->setHorizontalHeaderLabels(labels);
}

void FFTVariogramDeclus::updateNumberVariograms(int nVariograms) {
    ui.varPropTable->setRowCount(nVariograms);
}


double FFTVariogramDeclus::getX(int row, bool* ok) {
    if (ui.varPropTable->item(row, 0) == 0) return 0;
    return ui.varPropTable->item(row, 0)->text().toDouble(ok);
}

double FFTVariogramDeclus::getY(int row, bool* ok) {
    if (ui.varPropTable->item(row, 1) == 0) return 0;
    return ui.varPropTable->item(row, 1)->text().toDouble(ok);
}

double FFTVariogramDeclus::getZ(int row, bool* ok) {
    if (ui.varPropTable->item(row, 2) == 0) return 0;
    return ui.varPropTable->item(row, 2)->text().toDouble(ok);
}

void FFTVariogramDeclus::checkCell(int x, int y) {
    bool ok = true;
    if (ui.varPropTable->item(x, y) == 0) {
        ui.varPropTable->item(x, y)->setText("0");
        return;
    }
    double v = ui.varPropTable->item(x, y)->text().toDouble(&ok);
    if (!ok) {
        ui.varPropTable->item(x, y)->setText("0");
    }
}

int FFTVariogramDeclus::getNumberVariograms() {
    return ui.varPropTable->rowCount();
}

int FFTVariogramDeclus::getNumberLags() {
    return ui.nLags->value();
}

int FFTVariogramDeclus::getNumberThreads() {
    return ui.nThreads->value();
}

QStringList FFTVariogramDeclus::getProperties() {
    return ui.props->selected_properties();
}

Geostat_grid* FFTVariogramDeclus::getGrid() {
    return ui.grid->selected_grid_object();
}

QString FFTVariogramDeclus::getWeigth() {
    return ui.weigth->currentText();
}

FFTVariogramDeclus::~FFTVariogramDeclus() {
}

QPushButton* FFTVariogramDeclus::getDisplayButton() {
    return ui.displayButton;
}

double FFTVariogramDeclus::getDx() {
    return ui.dx->value();
}

double FFTVariogramDeclus::getDy() {
    return ui.dy->value();
}

double FFTVariogramDeclus::getDz() {
    return ui.dz->value();
}

