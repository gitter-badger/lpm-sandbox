/*
Implementação do plugin que adiciona as transformações de fatorização.

Este plugin adiciona as ações PCA, MAF e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Camila Zacche, Lucas Candido, Péricles Lopes Machado
*/


#ifndef PLUGINS_LPM_UFRGS_FACTORIZATION_ALGORITHMS_H_
#define PLUGINS_LPM_UFRGS_FACTORIZATION_ALGORITHMS_H_

#include "common.h"

#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>
#include <grid/grid_property.h>
#include <grid/grid_region.h>
#include <grid/neighborhood.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>
#include <geostat/parameters_handler.h>

namespace LPM_UFRGS {
	enum Factorization_Algorithm_Type {
		PCA = 0,
		INV_PCA = 1,
		MAF = 2,
		INV_MAF = 3
	};
}


class FactorizationAlgorithms : public Geostat_algo {
	public:
		FactorizationAlgorithms();
		virtual ~FactorizationAlgorithms();

		virtual bool initialize(const Parameters_handler* parameters,
								Error_messages_handler* errors =0, Progress_notifier* notifier = 0 );
		
		virtual int execute(GsTL_project* proj=0, Progress_notifier* notifier = 0);
		
		virtual std::string name() const 
		{ 
			return "factorization_algorithms"; 
		}
		
		static Named_interface* create_new_interface(std::string&);

	private :
		LPM_UFRGS::Factorization_Algorithm_Type algorithm_type_;
		Error_messages_handler* errors_;
		std::string params;
		std::string params_input;
		Named_interface* action_;

		double dmin, dmax;
};



#endif // PLUGINS_LPM_UFRGS_FACTORIZATION_ALGORITHMS_H_
