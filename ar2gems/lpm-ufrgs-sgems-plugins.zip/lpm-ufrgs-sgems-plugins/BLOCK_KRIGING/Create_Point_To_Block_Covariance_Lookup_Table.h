#ifndef CREATE_POINT_TO_BLOCK_COVARIANCE_LOOKUP_TABLE
#define CREATE_POINT_TO_BLOCK_COVARIANCE_LOOKUP_TABLE
# include <vector>
# include <map>
# include "Struct_Block.h"

std::vector<std::vector<double> > Create_Point_To_Block_Covariance_Lookup_Table(Geostat_grid *point_i_grid, Geostat_grid *Block_Centroids_Point_Set, Geostat_grid *block_j_grid, const  Two_point_nested_structure &covar_, const std::map<int, Struct_Block> &Map_ID_Blocks);



#endif