/*
Implementação do plugin que realiza o multi-histograma.

(c) 2013, LPM/UFRGS,  Péricles Lopes Machado
*/

#ifndef HISTOGRAM_REPORT_H_
#define HISTOGRAM_REPORT_H_

#include "common.h"
#include <QDialog>
#include <QMainWindow>
#include <QCloseEvent>
#include <ui_histreport.h>


class HistogramReport : public QDialog {
    Q_OBJECT

  public:
    HistogramReport(QWidget *parent = 0);
    ~HistogramReport();

    void write(QString msg) {
        emit setText(msg);
    }

  signals:
    void setText(QString text);

  public slots:
    void setReport(QString text) {
        this->ui.report_text->setText(text);
        this->show();
    }

    void setSelf(HistogramReport* r) {
        self = r;
    }

    void autoDestroy() {
        if (self) delete self;
    }


  private:
    HistogramReport* self;
    Ui::HistogramReport ui;
};

#endif /* HIST_REPORT_H_ */
