/*
Implementa��o do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/

#ifndef __PLUGINS_LPM_UFRGS_ACCPLOT_CHART_H___
#define __PLUGINS_LPM_UFRGS_ACCPLOT_CHART_H___

#include "common.h"

#include <charts/chart_base.h>
#include <charts/chart_widget.h>
#include <charts/chart_display_control.h>
#include <grid/grid_property.h>
#include <grid/grid_weight_property.h>
#include <grid/grid_filter.h>

#include <vtkQtTableView.h>
#include <vtkSmartPointer.h>
#include <vtkLookupTable.h>
#include <vtkChartPie.h>

#include <QModelIndex>
#include <QLabel>
#include <qtextstream.h>
#include <qfiledialog.h>

#include <vector>
#include <map>

#include "accplot.h"

#include "accplotgraphout.h"
#include "accplotprocess.h"

enum AccPlot_types {
    ACCPLOT              = 0
};

enum AccPlotOperation_type {
    CALC_ACCPLOT = 0
};

static const char* accplot_charts_name = "Accuracy Plot";

struct Point {
    double x, y;
    Point(double x = 0, double y = 0) : x(x), y(y) {}
};

inline bool operator<(const Point& a, const Point& b) {
    if (a.x < b.x) return true;
    return a.y < b.y;
}

typedef std::vector<Point> Points;

class PLUGINS_LPM_UFRGS_DECL AccPlot_chart : public Chart_base, public AccPlotAction {
    Q_OBJECT

  public:
    void set_ok(bool ok) {
        is_ok = ok;
    }

    void run_master_process(AccPlotProcess* process_handler, int number_threads, std::vector<AccPlotProcess*>& slaves);
    void run_slave_process(AccPlotProcess* process_handler, int id_thread, int number_threads);

    explicit AccPlot_chart(
        AccPlot* my_variogram,
        QWidget *parent = 0);


    ~AccPlot_chart() {
    }

  public slots:
    void build_accplot_chart();

    void repaint_chart(const QString& in);
    void clear_chart();

    void save_report();
    void view_report();

    void build_value_table();
    void build_plot();

    void build_accplot(int id, int n_threads);

    void import_graphs();


  private:
    bool ok;

    AccPlotGraphOutput* gout_;

    AccPlot_types chart_type_;

    AccPlot* my_accplot_;

    Chart_widget* chart_accplot_widget_;

    Chart_display_control* chart_accplot_control_;

    vtkSmartPointer<vtkTable> table_accplot_;
    vtkSmartPointer<vtkQtTableView> table_accplot_view_;
    QTableView* qtable_accplot_;

    void write_table_accplot(QTextStream& out);


    Points  accplot_, average_width_;

    bool is_ok;
    double dv_;
    double dp_;
    bool compute_average_width_;

    QStringList props_names_;
    QString reference_prop_;

    Geostat_grid* grid_;

    QString weight_;

    int n_bins_;
    QMutex mutex;
    AccPlotProcess* my_process_handler_;

    double precision_;
};

#endif

