#ifndef CREATE_BLOCK_TO_BLOCK_COVARIANCE_LOOKUP_TABLE
#define CREATE_BLOCK_TO_BLOCK_COVARIANCE_LOOKUP_TABLE
# include <vector>
# include <map>
# include "Struct_Block.h"
# include <grid/geostat_grid.h>

typedef Geostat_grid::location_type Location;

std::vector<std::vector<double> > Create_Block_To_Block_Covariance_Lookup_Table(const std::vector<std::vector<double> > &Point_To_Block_Covariance_Lookup_Table, Geostat_grid *Block_Centroids_Point_Set, const std::map<int, Struct_Block> &Map_ID_Blocks);

#endif