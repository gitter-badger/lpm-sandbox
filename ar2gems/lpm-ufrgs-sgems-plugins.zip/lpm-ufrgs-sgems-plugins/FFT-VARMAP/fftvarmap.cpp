/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftvarmap.h"

#include <array>
#include <cmath>


typedef Const_geovalue::location_type loc_point;

int FFTVarmap::execute( GsTL_project* , Progress_notifier* notifier) {
    double dx = this->lag_x_, dy = this->lag_y_, dz = this->lag_z_;
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    for (size_t i = 0; i < input_grid_->size(); ++i) {
        double x = input_grid_->xyz_location(i).x();
        double y = input_grid_->xyz_location(i).y();
        double z = input_grid_->xyz_location(i).z();
        if (i == 0) {
            xmin = xmax = x;
            ymin = ymax = y;
            zmin = zmax = z;
        } else {
            if (x < xmin) {
                xmin = x;
            } else if (x > xmax) {
                xmax = x;
            }
            if (y < ymin) {
                ymin = y;
            } else if (y > ymax) {
                ymax = y;
            }
            if (z < zmin) {
                zmin = z;
            } else if (z > zmax) {
                zmax = z;
            }
        }
    }
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    for (size_t i = 0; i < props_.size(); ++i) {
        Grid_continuous_property* p = input_grid_->property(props_.at(i));
        Grid_continuous_property* pout = output_grid_->add_property(varmap_name_ + "_" + props_.at(i));
        Grid_continuous_property* pout_np = output_grid_->add_property(varmap_name_ + "_" + props_.at(i) + "_np");
        if (!p || !pout) {
            return 1;
        }
        if(notifier) {
            notifier->write("Working on variogram <" + output_grid_name_ + "_" + props_.at(i) + ">", 0);
            if(!notifier->notify()) {
                return 1;
            }
            while (notifier->is_paused()) {
                notifier->write("Paused", 0);
            }
        }
        if (!compute_varmap(
                    input_grid_, output_grid_, p, pout, pout_np,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax))  return 1;
    }
    return 0;
}


bool FFTVarmap::initialize( const Parameters_handler* parameters,
                            Error_messages_handler* errors, Progress_notifier* notifier ) {
    input_grid_name_ = parameters->value("grid.value");
    output_grid_name_ = parameters->value("varmap_grid.value");
    varmap_name_ = parameters->value("varmap_name.value");
    n_threads_ = String_Op::to_number<int>(parameters->value("nthreads.value"));
    fft_set_num_threads(n_threads_);
    lag_x_ = String_Op::to_number<double>(parameters->value("lag_x.value"));
    lag_y_ = String_Op::to_number<double>(parameters->value("lag_y.value"));
    lag_z_ = String_Op::to_number<double>(parameters->value("lag_z.value"));
    std::string props = parameters->value("props.value");
    props_ = String_Op::decompose_string(props, ";");
    if (notifier) {
        notifier->total_steps(props_.size());
        notifier->frequency(1);
    }
    if (props_.size() < 1) {
        errors->report(props_.size() < 1, "props", "No property selected");
        return false;
    }
    if( output_grid_name_.empty() ) {
        errors->report( output_grid_name_.empty(),
                        "varmap_name", "No varmap grid selected" );
        return false;
    } else {
        output_grid_ = get_grid_from_manager(output_grid_name_);
        if (!output_grid_) {
            return false;
        }
    }
    if (!input_grid_name_.empty()) {
        input_grid_ = get_grid_from_manager(input_grid_name_);
        if (!input_grid_) {
            return false;
        }
    } else {
        errors->report( input_grid_name_.empty(),
                        "grid", "No input grid selected" );
        return false;
    }
    return true;
}


Named_interface* FFTVarmap::create_new_interface( std::string& ) {
    return new FFTVarmap;
}


FFTVarmap::FFTVarmap() {
}


FFTVarmap::~FFTVarmap() {
}

//////////////////////////////////////////////////////////////////////////////

int FFTVarmap_declus::execute(GsTL_project*, Progress_notifier* notifier) {
    double dx = this->lag_x_, dy = this->lag_y_, dz = this->lag_z_;
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    for (size_t i = 0; i < input_grid_->size(); ++i) {
        double x = input_grid_->xyz_location(i).x();
        double y = input_grid_->xyz_location(i).y();
        double z = input_grid_->xyz_location(i).z();
        if (i == 0) {
            xmin = xmax = x;
            ymin = ymax = y;
            zmin = zmax = z;
        } else {
            if (x < xmin) {
                xmin = x;
            } else if (x > xmax) {
                xmax = x;
            }
            if (y < ymin) {
                ymin = y;
            } else if (y > ymax) {
                ymax = y;
            }
            if (z < zmin) {
                zmin = z;
            } else if (z > zmax) {
                zmax = z;
            }
        }
    }
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    Grid_continuous_property* w = input_grid_->property(weigth_name_);
    for (size_t i = 0; i < props_.size(); ++i) {
        Grid_continuous_property* p = input_grid_->property(props_.at(i));
        Grid_continuous_property* pout = output_grid_->add_property(varmap_name_ + "_" + props_.at(i));
        Grid_continuous_property* pout_np = output_grid_->add_property(varmap_name_ + "_" + props_.at(i) + "_np");
        if (!p || !pout) {
            return 1;
        }
        if (notifier) {
            notifier->write("Working on variogram <" + output_grid_name_ + "_" + props_.at(i) + ">", 0);
            if (!notifier->notify()) {
                return 1;
            }
            while (notifier->is_paused()) {
                notifier->write("Paused", 0);
            }
        }
        if (!compute_varmap_declus(
                    input_grid_, output_grid_, p, w, pout, pout_np,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax))  return 1;
    }
    return 0;
}


bool FFTVarmap_declus::initialize(const Parameters_handler* parameters,
                                  Error_messages_handler* errors, Progress_notifier* notifier) {
    input_grid_name_ = parameters->value("grid.value");
    output_grid_name_ = parameters->value("varmap_grid.value");
    varmap_name_ = parameters->value("varmap_name.value");
    weigth_name_ = parameters->value("weigth.value");
    n_threads_ = String_Op::to_number<int>(parameters->value("nthreads.value"));
    fft_set_num_threads(n_threads_);
    lag_x_ = String_Op::to_number<double>(parameters->value("lag_x.value"));
    lag_y_ = String_Op::to_number<double>(parameters->value("lag_y.value"));
    lag_z_ = String_Op::to_number<double>(parameters->value("lag_z.value"));
    std::string props = parameters->value("props.value");
    props_ = String_Op::decompose_string(props, ";");
    if (notifier) {
        notifier->total_steps(props_.size());
        notifier->frequency(1);
    }
    if (props_.size() < 1) {
        errors->report(props_.size() < 1, "props", "No property selected");
        return false;
    }
    if (output_grid_name_.empty()) {
        errors->report(output_grid_name_.empty(),
                       "varmap_name", "No varmap grid selected");
        return false;
    } else {
        output_grid_ = get_grid_from_manager(output_grid_name_);
        if (!output_grid_) {
            return false;
        }
    }
    if (!input_grid_name_.empty()) {
        input_grid_ = get_grid_from_manager(input_grid_name_);
        if (!input_grid_) {
            return false;
        }
    } else {
        errors->report(input_grid_name_.empty(),
                       "grid", "No input grid selected");
        return false;
    }
    return true;
}


Named_interface* FFTVarmap_declus::create_new_interface(std::string&) {
    return new FFTVarmap_declus;
}


FFTVarmap_declus::FFTVarmap_declus() {
}


FFTVarmap_declus::~FFTVarmap_declus() {
}


