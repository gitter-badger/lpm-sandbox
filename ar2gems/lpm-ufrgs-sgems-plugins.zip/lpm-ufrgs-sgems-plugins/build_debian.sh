#!/bin/bash

git submodule update --init

# Update VTK

cd VTK
git stash
git fetch origin
git checkout v6.2.0.rc1
git merge origin/v6.2.0.rc1
cd ..

# Update ar2gems

cd ar2gems
git stash
git fetch origin
git checkout develop
git merge origin/develop
cd ..


AR2GEMS_SRC_PATH=$PWD/ar2gems
QT5_PATH=/usr/lib/x86_64-linux-gnu

# Install dependecies
sudo aptitude update
sudo aptitude install -y \
g++ cmake git make \
libboost-all-dev cmake-gui \
supervisor openssh-server \
gedit wget bash libfftw3-dev \
x11-apps flex bison \
libgl1-mesa-dev libglu1-mesa-dev \
libxt-dev libpulse-dev \
xvfb \
unzip \
qtbase5-dev \
qt5-qmake \
qttools5-dev \
qtbase5-dev-tools \
qttools5-dev-tools \
libqt5widgets5 \
libqt5designer5 \
libqt5designercomponents5 \
libqt5gui5 \
libqt5webkit5-dev \
libqt5svg5 \
libqt5svg5-dev \
qtmultimedia5-dev \
libqt5multimedia5 \
qtcreator

# Create a new build directory

mkdir -p build

cd build

# Create dependencies build directories

mkdir -p vtk-build
mkdir -p ar2gems-build
mkdir -p lpm-ufrgs-sgems-plugins-build

# Build VTK

cd vtk-build
cmake ../../VTK -DCMAKE_BUILD_TYPE:STRING=Release \
-DBUILD_TESTING:BOOL=OFF \
-DVTK_Group_Qt:BOOL=ON \
-DVTK_Group_Imaging:BOOL=ON \
-DVTK_Group_Rendering:BOOL=ON \
-DVTK_Group_StandAlone:BOOL=ON \
-DVTK_Group_Views:BOOL=ON \
-DVTK_QT_VERSION:STRING=5 \
-DVTK_RENDERING_BACKEND:STRING=OpenGL \
-DQT5_PATH:PATH=$QT5_PATH \
-DQt5Core_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Core \
-DQt5Designer_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Designer \
-DQt5Gui_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Gui \
-DQt5Multimedia_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Multimedia \
-DQt5Network_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Network \
-DQt5PrintSupport_DIR:PATH=$QT5_PATH/lib/cmake/Qt5PrintSupport \
-DQt5Svg_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Svg \
-DQt5UiTools_DIR:PATH=$QT5_PATH/lib/cmake/Qt5UiTools \
-DQt5Widgets_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Widgets \
-DQt5Xml_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Xml

make -j $(nproc)

sudo make install

cd ..

# Build ar2gems

cd ar2gems-build
cmake ../../ar2gems -DCMAKE_BUILD_TYPE:STRING=Release \
-DPYTHON_LIBRARY:FILEPATH=/usr/lib/x86_64-linux-gnu/libpython2.7.so \
-DQT5_PATH:PATH=/usr/lib/x86_64-linux-gnu \
-DVTK_DIR:PATH=/usr/local/lib/cmake/vtk-6.2 \
-DQT5_PATH:PATH=$QT5_PATH \
-DQt5Core_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Core \
-DQt5Designer_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Designer \
-DQt5Gui_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Gui \
-DQt5Multimedia_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Multimedia \
-DQt5Network_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Network \
-DQt5PrintSupport_DIR:PATH=$QT5_PATH/lib/cmake/Qt5PrintSupport \
-DQt5Svg_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Svg \
-DQt5UiTools_DIR:PATH=$QT5_PATH/lib/cmake/Qt5UiTools \
-DQt5Widgets_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Widgets \
-DQt5Xml_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Xml

make -j $(nproc)


sudo make install

cd ..

# Build lpm-ufrgs-sgems-plugins

cd lpm-ufrgs-sgems-plugins-build
cmake ../../ -DCMAKE_BUILD_TYPE:STRING=Release \
-DAR2GEMS_BUILD_PATH:PATH=../ar2gems-build \
-DAR2GEMS_PATH:PATH=$AR2GEMS_SRC_PATH \
-DAR2GEMS_SOURCE_PATH:PATH=$AR2GEMS_SRC_PATH \
-DAR2GEMS_INCLUDE_DIR:PATH=$AR2GEMS_SRC_PATH \
-DBISON_EXECUTABLE:FILEPATH=/usr/bin/bison \
-DFLEX_EXECUTABLE:FILEPATH=/usr/bin/flex \
-DFLEX_INCLUDE_DIR:PATH=/usr/include \
-DPYTHON_LIBRARY:FILEPATH=/usr/lib/libpython2.7.so \
-DVTK_DIR:PATH=/usr/local/lib/cmake/vtk-6.2 \
-DQT5_PATH:PATH=$QT5_PATH \
-DQt5Core_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Core \
-DQt5Designer_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Designer \
-DQt5Gui_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Gui \
-DQt5Multimedia_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Multimedia \
-DQt5Network_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Network \
-DQt5PrintSupport_DIR:PATH=$QT5_PATH/lib/cmake/Qt5PrintSupport \
-DQt5Svg_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Svg \
-DQt5UiTools_DIR:PATH=$QT5_PATH/lib/cmake/Qt5UiTools \
-DQt5Widgets_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Widgets \
-DQt5Xml_DIR:PATH=$QT5_PATH/lib/cmake/Qt5Xml

make -j $(nproc)

cd ..

# Install plugins  in the ar2gems directory

cd ar2gems-build

mkdir -p Release/bin/plugins
mkdir -p Release/bin/plugins/designer
mkdir -p Release/bin/plugins/Geostat

cp -rf ../../ar2gems/plugins/* Release/bin/plugins/
cp Release/lib/libar2gems_widgets.so Release/bin/plugins/designer/
cp -rf ../../*/*.ui Release/bin/plugins/Geostat/
cp -rf ../lpm-ufrgs-sgems-plugins-build/*/*.so Release/bin/plugins/Geostat/


cd Release/bin
