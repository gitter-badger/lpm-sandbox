/*
Implementa��o do plugin FFT-Varmap.

Este plugin computa varmaps usando FFT.

(c) 2014, LPM/UFRGS, P�ricles Lopes Machado
*/

#include "fftvarmaputils.h"


inline void calc_geo(GeometryData* geo, bool use_geo,
                     double& xmin, double& xmax,
                     double& ymin, double& ymax,
                     double& zmin, double& zmax,
                     Geostat_grid* input_grid) {
    if (use_geo) {
        xmin = geo->xmin;
        xmax = geo->xmax;
        ymax = geo->ymax;
        ymin = geo->ymin;
        zmin = geo->zmin;
        zmax = geo->zmax;
    } else {
        for (size_t i = 0; i < input_grid->size(); ++i) {
            double x = input_grid->xyz_location(i).x();
            double y = input_grid->xyz_location(i).y();
            double z = input_grid->xyz_location(i).z();
            if (i == 0) {
                xmin = xmax = x;
                ymin = ymax = y;
                zmin = zmax = z;
            } else {
                if (x < xmin) {
                    xmin = x;
                } else if (x > xmax) {
                    xmax = x;
                }
                if (y < ymin) {
                    ymin = y;
                } else if (y > ymax) {
                    ymax = y;
                }
                if (z < zmin) {
                    zmin = z;
                } else if (z > zmax) {
                    zmax = z;
                }
            }
        }
    }
}

bool process_grid(
    std::vector<double>& data,
    std::vector<int>& has_point,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x, bool inv_y, bool inv_z
) {
    int N = nx * ny * nz;
    for (int i = 0; i < N; ++i) {
        data[i] = 0;
        has_point[i] = 0;
    }
    At p(nx, ny, nz);
    for (size_t i = 0; i < input_prop->size(); ++i) {
        double X = input_grid->xyz_location(i).x();
        double Y = input_grid->xyz_location(i).y();
        double Z = input_grid->xyz_location(i).z();
        if (input_prop->is_informed(i)) {
            int ix = static_cast<int>((X - xmin) / dx);
            int iy = static_cast<int>((Y - ymin) / dy);
            int iz = static_cast<int>((Z - zmin) / dz);
            if (inv_x) ix = nx - ix - 1;
            if (inv_y) iy = ny - iy - 1;
            if (inv_z) iz = nz - iz - 1;
            data[p(ix, iy, iz)] = input_prop->get_value(i);
            has_point[p(ix, iy, iz)] = 1;
        }
    }
    return true;
}

//////////////////////////////////////////////////////////////////////////
bool compute_covariogram(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap,
    VarOut* varmap_out,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!varmap) {
        if (!compute_covarmap(
                    Yout,
                    input_grid,
                    input_prop,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    vx < 0, vy < 0, vz < 0)) {
            return false;
        }
    }
    vx = (vx < 0) ? (-vx) : (vx);
    vy = (vy < 0) ? (-vy) : (vy);
    vz = (vz < 0) ? (-vz) : (vz);
    pts.clear();
    int ix = 0, iy = 0, iz = 0;
    double px = vx, py = vy, pz = vz;
    double delta_x = 0, delta_y = 0, delta_z = 0;
    for (int i = 0; i < n_lags; ++i) {
        ix = static_cast<int>(px / dx);
        iy = static_cast<int>(py / dy);
        iz = static_cast<int>(pz / dz);
        if (ix > -1 && iy > -1 && iz > -1 &&
                ix < nx && iy < ny && iz < nz) {
            delta_x = px * px;
            delta_y = py * py;
            delta_z = pz * pz;
            if (varmap) {
                if (varmap->ni[at(ix, iy, iz)] > 0) {
                    double lag = sqrt(delta_x + delta_y + delta_z);
                    double value = varmap->varmap[at(ix, iy, iz)];
                    pts.push_back(Point(lag, value));
                }
            } else if (Yout.ni[at(ix, iy, iz)] > 0) {
                double lag = sqrt(delta_x + delta_y + delta_z);
                double value = Yout.varmap[at(ix, iy, iz)];
                pts.push_back(Point(lag, value));
            }
        }
        px += vx;
        py += vy;
        pz += vz;
    }
    if (varmap_out) {
        varmap_out->ni = Yout.ni;
        varmap_out->varmap = Yout.varmap;
    }
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}

bool compute_covarmap(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!compute_covarmap(
                Yout,
                input_grid,
                input_prop,
                nx, ny, nz,
                dx, dy, dz,
                xmin, ymin, zmin,
                xmax, ymax, zmax,
                inv_x, inv_y, inv_z, geo, use_geo)) {
        return false;
    }
    varmap_out->ni = Yout.ni;
    varmap_out->varmap = Yout.varmap;
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}


bool compute_covarmap(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo
) {
    int N = nx * ny * nz;
    std::vector<double> data((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point((nx + 1) * (ny + 1) * (nz + 1));
    process_grid(
        data, has_point,
        input_grid, input_prop,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    Yout.varmap.clear();
    Yout.varmap.resize(data.size());
    Yout.ni.clear();
    Yout.ni.resize(data.size());
    fft_covarmap_3d(Yout, data, has_point, nx, ny, nz);
    return true;
}

bool compute_covarmap(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo,
    bool use_geo
) {
    int N = nx * ny * nz;
    std::vector<double> data((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point((nx + 1) * (ny + 1) * (nz + 1));
    VarOut  varmap(data.size());
    At p(nx, ny, nz);
    for (int inv_x = 0; inv_x < std::min(nx, 2); ++inv_x) {
        for (int inv_y = 0; inv_y < std::min(ny, 2); ++inv_y) {
            for (int inv_z = 0; inv_z < std::min(nz, 2); ++inv_z) {
                process_grid(
                    data, has_point,
                    input_grid, input_prop,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                fft_covarmap_3d(varmap,
                                data,
                                has_point,
                                nx, ny, nz);
                for (int ix = 0; ix < nx; ++ix) {
                    for (int iy = 0; iy < ny; ++iy) {
                        for (int iz = 0; iz < nz; ++iz) {
                            double x = ((inv_x) ? (-ix) : (ix)) * dx;
                            double y = ((inv_y) ? (-iy) : (iy)) * dy;
                            double z = ((inv_z) ? (-iz) : (iz)) * dz;
                            int node_id = output_grid->closest_node(Geostat_grid::location_type(x, y, z));
                            output_prop->set_value(varmap.varmap[p(ix, iy, iz)], node_id);
                            output_np_prop->set_value(varmap.ni[p(ix, iy, iz)], node_id);
                        }
                    }
                }
            }
        }
    }
    return true;
}




//////////////////////////////////////////////////////////////////////////
bool compute_variogram(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap,
    VarOut* varmap_out,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!varmap) {
        if (!compute_varmap(
                    Yout,
                    input_grid,
                    input_prop,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    vx < 0, vy < 0, vz < 0)) {
            return false;
        }
    }
    vx = (vx < 0) ? (-vx) : (vx);
    vy = (vy < 0) ? (-vy) : (vy);
    vz = (vz < 0) ? (-vz) : (vz);
    pts.clear();
    int ix = 0, iy = 0, iz = 0;
    double px = vx, py = vy, pz = vz;
    double delta_x = 0, delta_y = 0, delta_z = 0;
    for (int i = 0; i < n_lags; ++i) {
        ix = static_cast<int>(px / dx);
        iy = static_cast<int>(py / dy);
        iz = static_cast<int>(pz / dz);
        if (ix > -1 && iy > -1 && iz > -1 &&
                ix < nx && iy < ny && iz < nz) {
            delta_x = px * px;
            delta_y = py * py;
            delta_z = pz * pz;
            if (varmap) {
                if (varmap->ni[at(ix, iy, iz)] > 0) {
                    double lag = sqrt(delta_x + delta_y + delta_z);
                    double value = varmap->varmap[at(ix, iy, iz)];
                    pts.push_back(Point(lag, value));
                }
            } else if (Yout.ni[at(ix, iy, iz)] > 0) {
                double lag = sqrt(delta_x + delta_y + delta_z);
                double value = Yout.varmap[at(ix, iy, iz)];
                pts.push_back(Point(lag, value));
            }
        }
        px += vx;
        py += vy;
        pz += vz;
    }
    if (varmap_out) {
        varmap_out->ni = Yout.ni;
        varmap_out->varmap = Yout.varmap;
    }
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}

bool compute_varmap(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!compute_varmap(
                Yout,
                input_grid,
                input_prop,
                nx, ny, nz,
                dx, dy, dz,
                xmin, ymin, zmin,
                xmax, ymax, zmax,
                inv_x, inv_y, inv_z, geo, use_geo)) {
        return false;
    }
    varmap_out->ni = Yout.ni;
    varmap_out->varmap = Yout.varmap;
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}


bool compute_varmap(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo
) {
    int N = nx * ny * nz;
    std::vector<double> data((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point((nx + 1) * (ny + 1) * (nz + 1));
    process_grid(
        data, has_point,
        input_grid, input_prop,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    Yout.varmap.clear();
    Yout.varmap.resize(data.size());
    Yout.ni.clear();
    Yout.ni.resize(data.size());
    fft_varmap_3d(Yout, data, has_point, nx, ny, nz);
    return true;
}

bool compute_varmap(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo,
    bool use_geo
) {
    int N = nx * ny * nz;
    std::vector<double> data((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point((nx + 1) * (ny + 1) * (nz + 1));
    VarOut  varmap(data.size());
    At p(nx, ny, nz);
    for (int inv_x = 0; inv_x < std::min(nx, 2); ++inv_x) {
        for (int inv_y = 0; inv_y < std::min(ny, 2); ++inv_y) {
            for (int inv_z = 0; inv_z < std::min(nz, 2); ++inv_z) {
                process_grid(
                    data, has_point,
                    input_grid, input_prop,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                fft_varmap_3d(varmap,
                              data,
                              has_point,
                              nx, ny, nz);
                for (int ix = 0; ix < nx; ++ix) {
                    for (int iy = 0; iy < ny; ++iy) {
                        for (int iz = 0; iz < nz; ++iz) {
                            double x = ((inv_x)?(-ix):(ix)) * dx;
                            double y = ((inv_y)?(-iy):(iy)) * dy;
                            double z = ((inv_z)?(-iz):(iz)) * dz;
                            int node_id = output_grid->closest_node(Geostat_grid::location_type(x, y, z));
                            output_prop->set_value(varmap.varmap[p(ix, iy, iz)], node_id);
                            output_np_prop->set_value(varmap.ni[p(ix, iy, iz)], node_id);
                        }
                    }
                }
            }
        }
    }
    return true;
}


//////////////////////////////////////////////////////////////////////////
bool compute_variogram_declus(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* weigth,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap,
    VarOut* varmap_out,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!varmap) {
        if (!compute_varmap_declus(
                    Yout,
                    input_grid,
                    input_prop,
                    weigth,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    vx < 0, vy < 0, vz < 0)) {
            return false;
        }
    }
    vx = (vx < 0) ? (-vx) : (vx);
    vy = (vy < 0) ? (-vy) : (vy);
    vz = (vz < 0) ? (-vz) : (vz);
    pts.clear();
    int ix = 0, iy = 0, iz = 0;
    double px = vx, py = vy, pz = vz;
    double delta_x = 0, delta_y = 0, delta_z = 0;
    for (int i = 0; i < n_lags; ++i) {
        ix = static_cast<int>(px / dx);
        iy = static_cast<int>(py / dy);
        iz = static_cast<int>(pz / dz);
        if (ix > -1 && iy > -1 && iz > -1 &&
                ix < nx && iy < ny && iz < nz) {
            delta_x = px * px;
            delta_y = py * py;
            delta_z = pz * pz;
            if (varmap) {
                if (varmap->ni[at(ix, iy, iz)] > 0) {
                    double lag = sqrt(delta_x + delta_y + delta_z);
                    double value = varmap->varmap[at(ix, iy, iz)];
                    pts.push_back(Point(lag, value));
                }
            } else if (Yout.ni[at(ix, iy, iz)] > 0) {
                double lag = sqrt(delta_x + delta_y + delta_z);
                double value = Yout.varmap[at(ix, iy, iz)];
                pts.push_back(Point(lag, value));
            }
        }
        px += vx;
        py += vy;
        pz += vz;
    }
    if (varmap_out) {
        varmap_out->ni = Yout.ni;
        varmap_out->varmap = Yout.varmap;
    }
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}

bool compute_varmap_declus(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* weigth,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!compute_varmap_declus(
                Yout,
                input_grid,
                input_prop,
                weigth,
                nx, ny, nz,
                dx, dy, dz,
                xmin, ymin, zmin,
                xmax, ymax, zmax,
                inv_x, inv_y, inv_z)) {
        return false;
    }
    if (varmap_out) {
        varmap_out->ni = Yout.ni;
        varmap_out->varmap = Yout.varmap;
    }
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}


bool compute_varmap_declus(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* weigth,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo) {
    int N = nx * ny * nz;
    std::vector<double> data((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> w((nx + 1) * (ny + 1) * (nz + 1));
    process_grid(
        data, has_point,
        input_grid, input_prop,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    process_grid(
        w, has_point,
        input_grid, weigth,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    Yout.varmap.clear();
    Yout.varmap.resize(data.size());
    Yout.ni.clear();
    Yout.ni.resize(data.size());
    fft_varmap_3d_declus(Yout, data, w, has_point, nx, ny, nz);
    return true;
}

bool compute_varmap_declus(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop,
    Grid_continuous_property* weigth,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo,
    bool use_geo) {
    int N = nx * ny * nz;
    std::vector<double> data((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> w((nx + 1) * (ny + 1) * (nz + 1));
    VarOut  varmap(data.size());
    At p(nx, ny, nz);
    for (int inv_x = 0; inv_x < std::min(nx, 2); ++inv_x) {
        for (int inv_y = 0; inv_y < std::min(ny, 2); ++inv_y) {
            for (int inv_z = 0; inv_z < std::min(nz, 2); ++inv_z) {
                process_grid(
                    data, has_point,
                    input_grid, input_prop,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                process_grid(
                    w, has_point,
                    input_grid, weigth,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                fft_varmap_3d_declus(varmap,
                                     data, w, has_point, nx, ny, nz);
                for (int ix = 0; ix < nx; ++ix) {
                    for (int iy = 0; iy < ny; ++iy) {
                        for (int iz = 0; iz < nz; ++iz) {
                            double x = ((inv_x) ? (-ix) : (ix)) * dx;
                            double y = ((inv_y) ? (-iy) : (iy)) * dy;
                            double z = ((inv_z) ? (-iz) : (iz)) * dz;
                            int node_id = output_grid->closest_node(Geostat_grid::location_type(x, y, z));
                            output_prop->set_value(varmap.varmap[p(ix, iy, iz)], node_id);
                            output_np_prop->set_value(varmap.ni[p(ix, iy, iz)], node_id);
                        }
                    }
                }
            }
        }
    }
    return true;
}
//////////////////////////////////////////////////////////////////////////
bool compute_crosscovariogram(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap,
    VarOut* varmap_out,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!varmap) {
        if (!compute_crosscovarmap(
                    Yout,
                    input_grid,
                    input_prop1,
                    input_prop2,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    vx < 0, vy < 0, vz < 0)) {
            return false;
        }
    }
    vx = (vx < 0) ? (-vx) : (vx);
    vy = (vy < 0) ? (-vy) : (vy);
    vz = (vz < 0) ? (-vz) : (vz);
    pts.clear();
    int ix = 0, iy = 0, iz = 0;
    double px = vx, py = vy, pz = vz;
    double delta_x = 0, delta_y = 0, delta_z = 0;
    for (int i = 0; i < n_lags; ++i) {
        ix = static_cast<int>(px / dx);
        iy = static_cast<int>(py / dy);
        iz = static_cast<int>(pz / dz);
        if (ix > -1 && iy > -1 && iz > -1 &&
                ix < nx && iy < ny && iz < nz) {
            delta_x = px * px;
            delta_y = py * py;
            delta_z = pz * pz;
            if (varmap) {
                if (varmap->ni[at(ix, iy, iz)] > 0) {
                    double lag = sqrt(delta_x + delta_y + delta_z);
                    double value = varmap->varmap[at(ix, iy, iz)];
                    pts.push_back(Point(lag, value));
                }
            } else if (Yout.ni[at(ix, iy, iz)] > 0) {
                double lag = sqrt(delta_x + delta_y + delta_z);
                double value = Yout.varmap[at(ix, iy, iz)];
                pts.push_back(Point(lag, value));
            }
        }
        px += vx;
        py += vy;
        pz += vz;
    }
    if (varmap_out) {
        varmap_out->ni = Yout.ni;
        varmap_out->varmap = Yout.varmap;
    }
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}

bool compute_crosscovarmap(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!compute_crosscovarmap(
                Yout,
                input_grid,
                input_prop1,
                input_prop2,
                nx, ny, nz,
                dx, dy, dz,
                xmin, ymin, zmin,
                xmax, ymax, zmax,
                inv_x, inv_y, inv_z)) {
        return false;
    }
    varmap_out->ni = Yout.ni;
    varmap_out->varmap = Yout.varmap;
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}

bool compute_crosscovarmap(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo) {
    int N = nx * ny * nz;
    std::vector<double> data1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> data2((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point2((nx + 1) * (ny + 1) * (nz + 1));
    process_grid(
        data1, has_point1,
        input_grid, input_prop1,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    process_grid(
        data2, has_point2,
        input_grid, input_prop2,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    Yout.varmap.clear();
    Yout.varmap.resize(data1.size());
    Yout.ni.clear();
    Yout.ni.resize(data1.size());
    fft_crosscovarmap_3d(Yout, data1, has_point1, data2, has_point2, nx, ny, nz);
    return true;
}

bool compute_crosscovarmap(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo,
    bool use_geo) {
    int N = nx * ny * nz;
    std::vector<double> data1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> data2((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point2((nx + 1) * (ny + 1) * (nz + 1));
    At p(nx, ny, nz);
    VarOut  varmap(data1.size());
    for (int inv_x = 0; inv_x < std::min(nx, 2); ++inv_x) {
        for (int inv_y = 0; inv_y < std::min(ny, 2); ++inv_y) {
            for (int inv_z = 0; inv_z < std::min(nz, 2); ++inv_z) {
                process_grid(
                    data1, has_point1,
                    input_grid, input_prop1,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                process_grid(
                    data2, has_point2,
                    input_grid, input_prop2,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                fft_crosscovarmap_3d(varmap,
                                     data1, has_point1, data2, has_point2, nx, ny, nz);
                for (int ix = 0; ix < nx; ++ix) {
                    for (int iy = 0; iy < ny; ++iy) {
                        for (int iz = 0; iz < nz; ++iz) {
                            double x = ((inv_x) ? (-ix) : (ix)) * dx;
                            double y = ((inv_y) ? (-iy) : (iy)) * dy;
                            double z = ((inv_z) ? (-iz) : (iz)) * dz;
                            int node_id = output_grid->closest_node(Geostat_grid::location_type(x, y, z));
                            output_prop->set_value(varmap.varmap[p(ix, iy, iz)], node_id);
                            output_np_prop->set_value(varmap.ni[p(ix, iy, iz)], node_id);
                        }
                    }
                }
            }
        }
    }
    return true;
}



//////////////////////////////////////////////////////////////////////////
bool compute_crossvariogram(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap,
    VarOut* varmap_out,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!varmap) {
        if (!compute_crossvarmap(
                    Yout,
                    input_grid,
                    input_prop1,
                    input_prop2,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    vx < 0, vy < 0, vz < 0)) {
            return false;
        }
    }
    vx = (vx < 0) ? (-vx) : (vx);
    vy = (vy < 0) ? (-vy) : (vy);
    vz = (vz < 0) ? (-vz) : (vz);
    pts.clear();
    int ix = 0, iy = 0, iz = 0;
    double px = vx, py = vy, pz = vz;
    double delta_x = 0, delta_y = 0, delta_z = 0;
    for (int i = 0; i < n_lags; ++i) {
        ix = static_cast<int>(px / dx);
        iy = static_cast<int>(py / dy);
        iz = static_cast<int>(pz / dz);
        if (ix > -1 && iy > -1 && iz > -1 &&
                ix < nx && iy < ny && iz < nz) {
            delta_x = px * px;
            delta_y = py * py;
            delta_z = pz * pz;
            if (varmap) {
                if (varmap->ni[at(ix, iy, iz)] > 0) {
                    double lag = sqrt(delta_x + delta_y + delta_z);
                    double value = varmap->varmap[at(ix, iy, iz)];
                    pts.push_back(Point(lag, value));
                }
            } else if (Yout.ni[at(ix, iy, iz)] > 0) {
                double lag = sqrt(delta_x + delta_y + delta_z);
                double value = Yout.varmap[at(ix, iy, iz)];
                pts.push_back(Point(lag, value));
            }
        }
        px += vx;
        py += vy;
        pz += vz;
    }
    if (varmap_out) {
        varmap_out->ni = Yout.ni;
        varmap_out->varmap = Yout.varmap;
    }
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}

bool compute_crossvarmap(
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!compute_crossvarmap(
                Yout,
                input_grid,
                input_prop1,
                input_prop2,
                nx, ny, nz,
                dx, dy, dz,
                xmin, ymin, zmin,
                xmax, ymax, zmax,
                inv_x, inv_y, inv_z)) {
        return false;
    }
    varmap_out->ni = Yout.ni;
    varmap_out->varmap = Yout.varmap;
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}

bool compute_crossvarmap(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo,
    bool use_geo) {
    int N = nx * ny * nz;
    std::vector<double> data1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> data2((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point2((nx + 1) * (ny + 1) * (nz + 1));
    At p(nx, ny, nz);
    VarOut  varmap(data1.size());
    for (int inv_x = 0; inv_x < std::min(nx, 2); ++inv_x) {
        for (int inv_y = 0; inv_y < std::min(ny, 2); ++inv_y) {
            for (int inv_z = 0; inv_z < std::min(nz, 2); ++inv_z) {
                process_grid(
                    data1, has_point1,
                    input_grid, input_prop1,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                process_grid(
                    data2, has_point2,
                    input_grid, input_prop2,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                fft_crossvarmap_3d(varmap,
                                   data1, has_point1, data2, has_point2, nx, ny, nz);
                for (int ix = 0; ix < nx; ++ix) {
                    for (int iy = 0; iy < ny; ++iy) {
                        for (int iz = 0; iz < nz; ++iz) {
                            double x = ((inv_x) ? (-ix) : (ix)) * dx;
                            double y = ((inv_y) ? (-iy) : (iy)) * dy;
                            double z = ((inv_z) ? (-iz) : (iz)) * dz;
                            int node_id = output_grid->closest_node(Geostat_grid::location_type(x, y, z));
                            output_prop->set_value(varmap.varmap[p(ix, iy, iz)], node_id);
                            output_np_prop->set_value(varmap.ni[p(ix, iy, iz)], node_id);
                        }
                    }
                }
            }
        }
    }
    return true;
}


bool compute_crossvarmap(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo) {
    int N = nx * ny * nz;
    std::vector<double> data1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> data2((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point2((nx + 1) * (ny + 1) * (nz + 1));
    process_grid(
        data1, has_point1,
        input_grid, input_prop1,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    process_grid(
        data2, has_point2,
        input_grid, input_prop2,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    Yout.varmap.clear();
    Yout.varmap.resize(data1.size());
    Yout.ni.clear();
    Yout.ni.resize(data1.size());
    fft_crossvarmap_3d(Yout, data1, has_point1, data2, has_point2, nx, ny, nz);
    return true;
}

//////////////////////////////////////////////////////////////////////////
bool compute_crossvariogram_declus(
    Points& pts,
    Geostat_grid* input_grid,
    Grid_continuous_property* weigth1,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    double vx, double vy, double vz,
    int n_lags,
    VarOut* varmap,
    VarOut* varmap_out,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!varmap) {
        if (!compute_crossvarmap_declus(
                    Yout,
                    input_grid,
                    weigth1,
                    input_prop1,
                    input_prop2,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    vx < 0, vy < 0, vz < 0)) {
            return false;
        }
    }
    vx = (vx < 0) ? (-vx) : (vx);
    vy = (vy < 0) ? (-vy) : (vy);
    vz = (vz < 0) ? (-vz) : (vz);
    pts.clear();
    int ix = 0, iy = 0, iz = 0;
    double px = vx, py = vy, pz = vz;
    double delta_x = 0, delta_y = 0, delta_z = 0;
    for (int i = 0; i < n_lags; ++i) {
        ix = static_cast<int>(px / dx);
        iy = static_cast<int>(py / dy);
        iz = static_cast<int>(pz / dz);
        if (ix > -1 && iy > -1 && iz > -1 &&
                ix < nx && iy < ny && iz < nz) {
            delta_x = px * px;
            delta_y = py * py;
            delta_z = pz * pz;
            if (varmap) {
                if (varmap->ni[at(ix, iy, iz)] > 0) {
                    double lag = sqrt(delta_x + delta_y + delta_z);
                    double value = varmap->varmap[at(ix, iy, iz)];
                    pts.push_back(Point(lag, value));
                }
            } else if (Yout.ni[at(ix, iy, iz)] > 0) {
                double lag = sqrt(delta_x + delta_y + delta_z);
                double value = Yout.varmap[at(ix, iy, iz)];
                pts.push_back(Point(lag, value));
            }
        }
        px += vx;
        py += vy;
        pz += vz;
    }
    if (varmap_out) {
        varmap_out->ni = Yout.ni;
        varmap_out->varmap = Yout.varmap;
    }
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}


bool compute_crossvarmap_declus(
    Geostat_grid* input_grid,
    Grid_continuous_property* weigth1,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    double dx, double dy, double dz,
    VarOut* varmap_out,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo
) {
    double xmin, ymin, zmin;
    double xmax, ymax, zmax;
    calc_geo(
        geo, use_geo,
        xmin, xmax,
        ymin, ymax,
        zmin, zmax,
        input_grid);
    int nx, ny, nz;
    nx = static_cast<int>(ceil((xmax - xmin) / dx)) + 1;
    ny = static_cast<int>(ceil((ymax - ymin) / dy)) + 1;
    nz = static_cast<int>(ceil((zmax - zmin) / dz)) + 1;
    VarOut Yout;
    At at(nx, ny, nz);
    if (!compute_crossvarmap_declus(
                Yout,
                input_grid,
                weigth1,
                input_prop1,
                input_prop2,
                nx, ny, nz,
                dx, dy, dz,
                xmin, ymin, zmin,
                xmax, ymax, zmax,
                inv_x, inv_y, inv_z)) {
        return false;
    }
    varmap_out->ni = Yout.ni;
    varmap_out->varmap = Yout.varmap;
    fft_lock();
    if (geo) {
        geo->xmin = xmin;
        geo->ymin = ymin;
        geo->zmin = zmin;
        geo->xmax = xmax;
        geo->ymax = ymax;
        geo->zmax = zmax;
        geo->nx = nx;
        geo->ny = ny;
        geo->nz = nz;
        geo->dx = dx;
        geo->dy = dy;
        geo->dz = dz;
    }
    fft_unlock();
    return true;
}

bool compute_crossvarmap_declus(
    VarOut& Yout,
    Geostat_grid* input_grid,
    Grid_continuous_property* weigth1,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    bool inv_x, bool inv_y, bool inv_z,
    GeometryData* geo,
    bool use_geo) {
    int N = nx * ny * nz;
    std::vector<double> w1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> data1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> data2((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point2((nx + 1) * (ny + 1) * (nz + 1));
    process_grid(
        data1, has_point1,
        input_grid, input_prop1,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    process_grid(
        w1, has_point1,
        input_grid, weigth1,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    process_grid(
        data2, has_point2,
        input_grid, input_prop2,
        nx, ny, nz,
        dx, dy, dz,
        xmin, ymin, zmin,
        xmax, ymax, zmax,
        inv_x, inv_y, inv_z);
    Yout.varmap.clear();
    Yout.varmap.resize(data1.size());
    Yout.ni.clear();
    Yout.ni.resize(data1.size());
    fft_crossvarmap_3d_declus(Yout, w1,  data1, has_point1, data2, has_point2, nx, ny, nz);
    return true;
}

bool compute_crossvarmap_declus(
    Geostat_grid* input_grid,
    Geostat_grid* output_grid,
    Grid_continuous_property* weigth1,
    Grid_continuous_property* input_prop1,
    Grid_continuous_property* input_prop2,
    Grid_continuous_property* output_prop,
    Grid_continuous_property* output_np_prop,
    int nx, int ny, int nz,
    double dx, double dy, double dz,
    double xmin, double ymin, double zmin,
    double xmax, double ymax, double zmax,
    GeometryData* geo,
    bool use_geo) {
    int N = nx * ny * nz;
    std::vector<double> w1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> data1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point1((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<double> data2((nx + 1) * (ny + 1) * (nz + 1));
    std::vector<int> has_point2((nx + 1) * (ny + 1) * (nz + 1));
    VarOut  varmap(data1.size());
    At p(nx, ny, nz);
    for (int inv_x = 0; inv_x < std::min(nx, 2); ++inv_x) {
        for (int inv_y = 0; inv_y < std::min(ny, 2); ++inv_y) {
            for (int inv_z = 0; inv_z < std::min(nz, 2); ++inv_z) {
                process_grid(
                    data1, has_point1,
                    input_grid, input_prop1,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                process_grid(
                    w1, has_point1,
                    input_grid, weigth1,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                process_grid(
                    data2, has_point2,
                    input_grid, input_prop2,
                    nx, ny, nz,
                    dx, dy, dz,
                    xmin, ymin, zmin,
                    xmax, ymax, zmax,
                    inv_x, inv_y, inv_z);
                fft_crossvarmap_3d_declus(varmap,
                                          w1, data1, has_point1, data2, has_point2, nx, ny, nz);
                for (int ix = 0; ix < nx; ++ix) {
                    for (int iy = 0; iy < ny; ++iy) {
                        for (int iz = 0; iz < nz; ++iz) {
                            double x = ((inv_x) ? (-ix) : (ix)) * dx;
                            double y = ((inv_y) ? (-iy) : (iy)) * dy;
                            double z = ((inv_z) ? (-iz) : (iz)) * dz;
                            int node_id = output_grid->closest_node(Geostat_grid::location_type(x, y, z));
                            output_prop->set_value(varmap.varmap[p(ix, iy, iz)], node_id);
                            output_np_prop->set_value(varmap.ni[p(ix, iy, iz)], node_id);
                        }
                    }
                }
            }
        }
    }
    return true;
}
