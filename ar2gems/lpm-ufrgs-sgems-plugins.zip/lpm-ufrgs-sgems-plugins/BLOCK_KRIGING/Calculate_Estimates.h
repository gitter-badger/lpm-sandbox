#ifndef CALCULATE_ESTIMATES_H
#define CALCULATE_ESTIMATES_H
# include <vector>
typedef std::vector<std::vector<std::vector<double> > > block;

double Calculate_Estimates(const std::vector<double> &point_values, const std::vector<double> &block_values, const std::vector<double> &Kriging_Weights, const int &kriging_option, const double SK_mean);
#endif