#ifndef COVARIANCE_POINT_POINT_H
#define COVARIANCE_POINT_POINT_H

#include <grid/geostat_grid.h>
#include <GsTL/geometry/covariance.h>
#include <geostat/kriging.h>
# include "LPM_UFRGS_Block_Kriging.h"

typedef Geostat_grid::location_type Location;


double Covariance_Point_Point(Geostat_grid *point_i_grid, const int &node_id_point_i, Geostat_grid *point_j_grid, const int &node_id_point_j, const  Two_point_nested_structure &covar_);

#endif
