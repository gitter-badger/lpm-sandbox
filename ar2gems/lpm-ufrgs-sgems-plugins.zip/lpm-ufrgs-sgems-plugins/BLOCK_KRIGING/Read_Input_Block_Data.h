#ifndef READ_INPUT_BLOCK_DATA_H
#define READ_INPUT_BLOCK_DATA_H

# include <vector>
# include <map>
# include "Struct_Block.h"


bool Read_Input_Block_Data(std::map<int, Struct_Block> &Map_ID_Blocks, const std::vector<std::vector<double> > &Block_Locations);

#endif