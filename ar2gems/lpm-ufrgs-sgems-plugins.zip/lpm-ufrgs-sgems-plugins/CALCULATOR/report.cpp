/*
Implementação do plugin que efetua transformações nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/


#include "report.h"

Calculator_report::Calculator_report(QWidget *parent):QDialog(parent){
	ui.setupUi(this);
    QObject::connect(this,
                     SIGNAL(setText(QString)),
                     this,
                     SLOT(setReport(QString)),
                     Qt::QueuedConnection
                     );
}

Calculator_report::~Calculator_report(){

}
