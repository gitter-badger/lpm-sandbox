/*
Implementação do plugin que adiciona as transformações ALR, CLR e ILR no SGEMS.

Este plugin adiciona as ações ALR, CLR e ILR no SGEMS e também adiciona 
dialogos com essas transformações na interface gráfica do SGEMS.

(c) 2013, LPM/UFRGS, Péricles Lopes Machado
*/

#include "coda_algorithms.h"

#include "alr_transformation.h"
#include "alr_inv_transformation.h"

#include "clr_transformation.h"
#include "clr_inv_transformation.h"

#include "ilr_transformation.h"
#include "ilr_inv_transformation.h"

#include <geostat/utilities.h>
#include <utils/string_manipulation.h>
#include <grid/utilities.h>
#include <grid/neighbors.h>
#include <geostat/utilities.h>

#include <qstring.h>
#include <qmessagebox.h>
#include <cstdio>

CodaAlgorithms::CodaAlgorithms() 
{
}

CodaAlgorithms::~CodaAlgorithms() 
{
}

Named_interface* CodaAlgorithms::create_new_interface(std::string&) 
{
	return new CodaAlgorithms;
}

bool CodaAlgorithms::initialize(const Parameters_handler* parameters,
								   Error_messages_handler* errors, Progress_notifier* notifier) 
{
	this->errors_ = errors;

	// Set algorithm type
	bool Inverse_option = String_Op::to_number<bool>(parameters->value("Inverse_option.value"));
	
	bool ALR_option = String_Op::to_number<bool>(parameters->value("ALR_option.value"));
	bool CLR_option = String_Op::to_number<bool>(parameters->value("CLR_option.value"));
	bool ILR_option = String_Op::to_number<bool>(parameters->value("ILR_option.value"));

	if (ALR_option) {
		if (Inverse_option) {
			this->algorithm_type_ = LPM_UFRGS::Coda_Algorithm_Type::ALR_INV;
		} else {
			this->algorithm_type_ = LPM_UFRGS::Coda_Algorithm_Type::ALR;
		}
	} else if (CLR_option) {
		if (Inverse_option) {
			this->algorithm_type_ = LPM_UFRGS::Coda_Algorithm_Type::CLR_INV;
		} else {
			this->algorithm_type_ = LPM_UFRGS::Coda_Algorithm_Type::CLR;
		}
	} else if (ILR_option) {
		if (Inverse_option) {
			this->algorithm_type_ = LPM_UFRGS::Coda_Algorithm_Type::ILR_INV;
		} else {
			this->algorithm_type_ = LPM_UFRGS::Coda_Algorithm_Type::ILR;
		}
	}
	// Get pivot
	std::string pivot_name;
	std::string prop_name = parameters->value("prop_name.value");
	// Set grid
	std::string grid_name = parameters->value("grid_selector.value");
	errors->report(grid_name.empty(), "grid_selector", "No grid selected");
	std::string props = parameters->value("CODA_properties.value");
	std::vector<std::string> vprops = String_Op::decompose_string(props, ";");

	this->params = grid_name;
	for (size_t i = 0; i < vprops.size(); ++i) {
		this->params  += "::" + vprops[i];
	}

	std::string closure_value = parameters->value("constant.value");

	switch (this->algorithm_type_) {
		/*ALR*/
		case LPM_UFRGS::Coda_Algorithm_Type::ALR :
			this->action_ = new ALR_Transformation();
			
			pivot_name = parameters->value("pivot_property.value");
			static_cast<ALR_Transformation*>(this->action_)->set_prop_name(prop_name);
			static_cast<ALR_Transformation*>(this->action_)->set_pivot(pivot_name);
			static_cast<ALR_Transformation*>(this->action_)->set_constant(String_Op::to_number<double>(closure_value));

			return static_cast<ALR_Transformation*>(this->action_)->init(this->params, 0, this->errors_);
		break;

		case LPM_UFRGS::Coda_Algorithm_Type::ALR_INV :
			this->action_ = new ALR_Inv_Transformation();

			pivot_name = parameters->value("pivotIndex.value");
			static_cast<ALR_Inv_Transformation*>(this->action_)->set_prop_name(prop_name);
			static_cast<ALR_Inv_Transformation*>(this->action_)->set_pivot(pivot_name);
			static_cast<ALR_Inv_Transformation*>(this->action_)->set_constant(String_Op::to_number<double>(closure_value));

			return static_cast<ALR_Inv_Transformation*>(this->action_)->init(this->params, 0, this->errors_);
		break;
		
		/*CLR*/
		case LPM_UFRGS::Coda_Algorithm_Type::CLR :
			this->action_ = new CLR_Transformation();

			static_cast<CLR_Transformation*>(this->action_)->set_prop_name(prop_name);
			static_cast<CLR_Transformation*>(this->action_)->set_constant(String_Op::to_number<double>(closure_value));

			return static_cast<CLR_Transformation*>(this->action_)->init(this->params, 0, this->errors_);
		break;

		case LPM_UFRGS::Coda_Algorithm_Type::CLR_INV :
			this->action_ = new CLR_Inv_Transformation();
			static_cast<CLR_Inv_Transformation*>(this->action_)->set_prop_name(prop_name);
			static_cast<CLR_Inv_Transformation*>(this->action_)->set_constant(String_Op::to_number<double>(closure_value));
			return static_cast<CLR_Inv_Transformation*>(this->action_)->init(this->params, 0, this->errors_);
		break;

		/*ILR*/
		case LPM_UFRGS::Coda_Algorithm_Type::ILR :
			this->action_ = new ILR_Transformation();
			static_cast<ILR_Transformation*>(this->action_)->set_prop_name(prop_name);
			static_cast<ILR_Transformation*>(this->action_)->set_constant(String_Op::to_number<double>(closure_value));
			return static_cast<ILR_Transformation*>(this->action_)->init(this->params, 0, this->errors_);
		break;

		case LPM_UFRGS::Coda_Algorithm_Type::ILR_INV :
			this->action_ = new ILR_Inv_Transformation();
			static_cast<ILR_Inv_Transformation*>(this->action_)->set_prop_name(prop_name);
			static_cast<ILR_Inv_Transformation*>(this->action_)->set_constant(String_Op::to_number<double>(closure_value));
			return static_cast<ILR_Inv_Transformation*>(this->action_)->init(this->params, 0, this->errors_);
		break;
	}
	
	return true;
}

int CodaAlgorithms::execute(GsTL_project* proj, Progress_notifier* notifier)
{	
	switch (this->algorithm_type_) {
		/*ALR*/
		case LPM_UFRGS::Coda_Algorithm_Type::ALR :
            return static_cast<ALR_Transformation*>(this->action_)->exec(notifier);
		break;

		case LPM_UFRGS::Coda_Algorithm_Type::ALR_INV :
            return static_cast<ALR_Inv_Transformation*>(this->action_)->exec(notifier);
		break;

		/*CLR*/
		case LPM_UFRGS::Coda_Algorithm_Type::CLR :
            return static_cast<CLR_Transformation*>(this->action_)->exec(notifier);
		break;

		case LPM_UFRGS::Coda_Algorithm_Type::CLR_INV :
            return static_cast<CLR_Inv_Transformation*>(this->action_)->exec(notifier);
		break;

		/*ILR*/
		case LPM_UFRGS::Coda_Algorithm_Type::ILR :
            return static_cast<ILR_Transformation*>(this->action_)->exec(notifier);
		break;

		case LPM_UFRGS::Coda_Algorithm_Type::ILR_INV :
            return static_cast<ILR_Inv_Transformation*>(this->action_)->exec(notifier);
		break;
	}

	return true;
}

