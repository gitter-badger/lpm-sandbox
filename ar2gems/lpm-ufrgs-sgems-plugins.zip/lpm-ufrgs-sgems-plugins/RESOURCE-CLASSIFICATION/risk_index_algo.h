#ifndef __RISK_INDEX_ALGO_H__
#define __RISK_INDEX_ALGO_H__


#include "common.h"
#include <geostat/geostat_algo.h>
#include <grid/geostat_grid.h>
#include <grid/grid_property.h>
#include <grid/grid_region.h>
#include <grid/neighborhood.h>
#include <utils/error_messages_handler.h>
#include <appli/project.h>
#include <geostat/parameters_handler.h>

class Risk_index : public Geostat_algo {
public:
	Risk_index();
	virtual ~Risk_index();

    virtual bool initialize( const Parameters_handler* parameters,
                                 Error_messages_handler* errors,
                             Progress_notifier* notifier = 0 );
    virtual int execute( GsTL_project* proj=0, Progress_notifier* notifier = 0  );

	  virtual std::string name() const { return "risk_index"; }

	 public:
	  static Named_interface* create_new_interface( std::string& );

private :
    
  //float threshold_;
  Grid_continuous_property* prop_;
  Geostat_grid* est_grid_;
  Geostat_grid* data_grid_;
 // Grid_region* region_;
  GsTLVector<double> p_val_;
  std::string out_name_;
  double medido_value_; 
  double indicado_value_;
  double inferido_value_;

  Neighborhood* neigh_;

};

#endif /* GEOBODY_H_ */
