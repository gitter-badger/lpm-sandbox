/*
Implementa��o do plugin que realiza o accuracy plot.

(c) 2013, LPM/UFRGS,  P�ricles Lopes Machado
*/

#include "accplot_chart_creator.h"
#include "accplot_chart.h"
#include "accplotgraphout.h"
#include "accplotreport.h"

#include <qfiledialog.h>

#include <cmath>

#include <utils/string_manipulation.h>

#include <vtkAxis.h>
#include <vtkPlotLine.h>
#include <vtkPlotPoints.h>
#include <vtkPlotPie.h>
#include <vtkPlotBar.h>
#include <vtkIntArray.h>
#include <vtkFloatArray.h>
#include <vtkDoubleArray.h>
#include <vtkColorSeries.h>
#include <vtkTextProperty.h>

#define INF 1e9

AccPlot_chart::AccPlot_chart(
    AccPlot* my_accplot,
	QWidget *parent)
	: 
	AccPlotAction(),
	Chart_base(parent), 
	my_accplot_(my_accplot)
{
	AccPlotGraphOutput* gout = new AccPlotGraphOutput(this);
	
	n_bins_ = my_accplot_->getNumberBins();
	precision_ = my_accplot_->getPrecision();
	gout_ = gout;
	my_process_handler_ = 0;
	dv_ = INF;
	dp_ = 1.0 / n_bins_;
	table_accplot_ = 0;
	is_ok = false;
	
	compute_average_width_ = my_accplot_->computeAverageWidth();
	
	grid_ = my_accplot_->getGrid();
	props_names_ = my_accplot_->getProperties();

	reference_prop_ = my_accplot_->getReferenceProperty();
	
	accplot_.resize(n_bins_);

	if (compute_average_width_) {
		average_width_.resize(n_bins_);
	}


	this->hide();
}

void AccPlot_chart::run_master_process(AccPlotProcess* process_handler, int number_threads, std::vector<AccPlotProcess*>& slaves)
{
	if (process_handler->isOk()) {
		process_handler->getNotifier()->appendText("Creating Accuracy Plots...\n");
		this->my_process_handler_ = process_handler;
	}
}

void AccPlot_chart::run_slave_process(AccPlotProcess* process_handler, int id_thread, int number_threads)
{
	if (process_handler->isOk()) {
		build_accplot(id_thread, number_threads);
	}
}


void AccPlot_chart::repaint_chart(const QString& in)
{
	if (is_ok) {
		this->build_value_table();
		this->build_plot();
	}
}


void AccPlot_chart::build_value_table()
{	
	Points& pts = accplot_;

	table_accplot_ = vtkSmartPointer<vtkTable>::New();

	vtkSmartPointer<vtkFloatArray> index_accplot = vtkSmartPointer<vtkFloatArray>::New();
	vtkSmartPointer<vtkFloatArray> values = vtkSmartPointer<vtkFloatArray>::New();
	vtkSmartPointer<vtkFloatArray> values_aw;
	
	if (compute_average_width_) {
		values_aw = vtkSmartPointer<vtkFloatArray>::New();
		values_aw->SetName("PI - width plot");
		values_aw->SetNumberOfValues(pts.size());
	}
	

	index_accplot->SetName("p-PI");
	index_accplot->SetNumberOfValues(pts.size());

	values->SetName("Accuracy plot");
	values->SetNumberOfValues(pts.size());

	double goodness = 0;
	
	for (size_t i = 0; i < pts.size(); ++i) {
		index_accplot->SetValue(i, pts[i].x);
		values->SetValue(i, pts[i].y);

		if (compute_average_width_)
			values_aw->SetValue(i, average_width_[i].y / pts[i].y);

		if (pts[i].y >= pts[i].x) {
			goodness += (pts[i].y - pts[i].x) * dp_;
		}
		else {
			goodness -= 2 * (pts[i].y - pts[i].x) * dp_;
		}
	}

	goodness = 1 - goodness;
	
	QString buffer;
	QTextStream in_log(&buffer);

	in_log << "[\"Goodness\" statistic ] G = " << goodness << "\n";
	gout_->getUI().infoAccPlot->setText(buffer);

	table_accplot_->AddColumn(index_accplot);
	table_accplot_->AddColumn(values);

	if (compute_average_width_) {
		table_accplot_->AddColumn(values_aw);
	}

	this->table_accplot_view_->SetRepresentationFromInput(table_accplot_);
	this->table_accplot_view_->Update();
}


void AccPlot_chart::build_accplot(int id, int n_threads)
{
	Grid_continuous_property* prop = grid_->property(reference_prop_.toStdString());
	double N = prop->size();

	for (int i = id; i < prop->size(); i += n_threads) {

		if (this->my_process_handler_) {
			if (!this->my_process_handler_->isOk()){
				return;
			}

			if (this->my_process_handler_->getNotifier()->isPaused()) {
				my_process_handler_->getNotifier()->appendText("Paused...");
				while (this->my_process_handler_->getNotifier()->isPaused()) {
				}
			}
		}

		if (my_process_handler_) my_process_handler_
			->getNotifier()
			->appendText(QString("Computing property <") + QString(prop->name().c_str()) + ">");

		mutex.lock();
		double ref_value = prop->get_value(i);
		if (!prop->is_informed(i)) {
			mutex.unlock();
			continue;
		}
		mutex.unlock();

		

		/*Build local ccdf*/
		std::map<int, double> local_ccdf;
		double vmin = 0, vmax = 0;
		double dv = 0;

		for (int p = 0; p < props_names_.size(); ++p) {
			Grid_continuous_property* prop_ref = grid_->property(props_names_[p].toStdString());
			
			mutex.lock();
			if (!prop_ref->is_informed(i)) {
				mutex.unlock();
				continue;
			}
			double value = prop_ref->get_value(i);
			mutex.unlock();
			if (p == 0) {
				vmin = vmax = value;
			}
			else {
				if (value < vmin) vmin = value;
				if (value > vmax) vmax = value;
			}
		}

		//dv = (vmax - vmin) / n_bins_;
		dv = precision_;
		int iref_value = static_cast<int>(round((ref_value - vmin) / dv));

		for (int p = 0; p < props_names_.size(); ++p) {
			Grid_continuous_property* prop_ref = grid_->property(props_names_[p].toStdString());
			
			mutex.lock();
			if (!prop_ref->is_informed(i)) {
				mutex.unlock();
				continue;
			}
			double value = prop_ref->get_value(i) - vmin;
			mutex.unlock();

			++local_ccdf[static_cast<int>(round(value / dv))];
		}

		double acc = 0;
		for (std::map<int, double>::iterator it = local_ccdf.begin(); it != local_ccdf.end(); ++it) {
			acc += it->second;
			it->second = acc;
		}

		for (std::map<int, double>::iterator it = local_ccdf.begin(); it != local_ccdf.end(); ++it) {
			it->second /= acc;
		}

		//Inverse local_ccdf
		std::map<int, int> inverse_local_ccdf;
		for (std::map<int, double>::iterator it = local_ccdf.begin(); it != local_ccdf.end(); ++it) {
			int ip = static_cast<int>(round(it->second / dp_));
			int iv = it->first;
			
			if (inverse_local_ccdf.find(ip) == inverse_local_ccdf.end()) {
				inverse_local_ccdf[ip] = iv;
			}
		}

		for (int ip = 0; ip < n_bins_; ++ip) {
			double p = ip * dp_;
			double p1 = (1 - p) * 0.5;
			double p2 = (1 + p) * 0.5;

			double v1 = 0; 
			double v2 = 0;

			if (inverse_local_ccdf.lower_bound(static_cast<int>(round(p1 / dp_))) == inverse_local_ccdf.end()) {
				v1 = vmax;
			}
			else {
				v1 = inverse_local_ccdf.lower_bound(static_cast<int>(round(p1 / dp_)))->second * dv + vmin;
			}

			if (inverse_local_ccdf.lower_bound(static_cast<int>(round(p2 / dp_))) == inverse_local_ccdf.end()) {
				v2 = vmax;
			}
			else {
				v2 = inverse_local_ccdf.lower_bound(static_cast<int>(round(p2 / dp_)))->second * dv + vmin;
			}

			mutex.lock();
			accplot_[ip].x = p;
			if (ref_value > v1 && ref_value <= v2) {
				accplot_[ip].y += 1.0 / N;

				if (compute_average_width_) {
					average_width_[ip].y += 1.0 / N * (v2 - v1);
				}
			}
			mutex.unlock();
		}

		if (my_process_handler_) my_process_handler_->getNotifier()->nextStep();
	}
}


void AccPlot_chart::clear_chart()
{
	chart_accplot_widget_->chart()->ClearPlots();
}

void AccPlot_chart::build_plot()
{
	vtkSmartPointer<vtkTable> table_ref_ = vtkSmartPointer<vtkTable>::New();

	vtkSmartPointer<vtkFloatArray> indexes = vtkSmartPointer<vtkFloatArray>::New();
	vtkSmartPointer<vtkFloatArray>  values = vtkSmartPointer<vtkFloatArray>::New();

	indexes->SetName("PI");
	values->SetName("Reference");

	indexes->SetNumberOfValues(2);
	values->SetNumberOfValues(2);

	indexes->SetValue(0, 0);
	values->SetValue(0, 0);

	indexes->SetValue(1, 1);
	values->SetValue(1, 1);

	table_ref_->AddColumn(indexes);
	table_ref_->AddColumn(values);
	vtkPlotLine* plot_ref = vtkPlotLine::SafeDownCast(chart_accplot_widget_->chart()->AddPlot(vtkChart::LINE));
	plot_ref->SetInputData(table_ref_, 0, 1);
	plot_ref->SetColor(0.0, 0.0, 1.0);

	for (int i = 1; i < table_accplot_->GetNumberOfColumns(); ++i) {

		if (gout_->getUI().line->isChecked()) {
			vtkPlotLine* plot_accplot = vtkPlotLine::SafeDownCast(chart_accplot_widget_->chart()->AddPlot(vtkChart::LINE));

			plot_accplot->SetInputData(table_accplot_, 0, i);

			if (i == 1) {
				plot_accplot->SetColor(1.0, 0.0, 0.0);
			}
			else {
				plot_accplot->SetColor(0.0, 1.0, 0.0);
			}
		}

		if (gout_->getUI().point->isChecked()) {
			vtkPlotPoints* plot_accplot = vtkPlotPoints::SafeDownCast(chart_accplot_widget_->chart()->AddPlot(vtkChart::POINTS));

			plot_accplot->SetInputData(table_accplot_, 0, i);
			if (i == 1) {
				plot_accplot->SetColor(1.0, 0.0, 0.0);
			}
			else {
				plot_accplot->SetColor(0.0, 1.0, 0.0);
			}
		}	
	}

	chart_accplot_widget_->chart()->GetAxis(vtkAxis::LEFT)->SetTitle("Accuracy Plot");
	chart_accplot_widget_->chart()->GetAxis(vtkAxis::BOTTOM)->SetTitle("Probability interval - p");

	//chart_accplot_widget_->chart()->SetAutoAxes(true);
	chart_accplot_widget_->chart()->SetVisible(true);
	chart_accplot_widget_->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));
	chart_accplot_widget_->chart()->Update();

	chart_accplot_widget_->update();
}

void AccPlot_chart::build_accplot_chart()
{
	if (grid_ == 0) return;
	if (props_names_.size() == 0) return;

	QString title = QString(accplot_charts_name).arg(grid_->name().c_str());

	this->setWindowTitle(title);
	this->setWindowIcon(QPixmap(":/icons/appli/Pixmaps/ar2gems-icon-256x256.png"));

	chart_accplot_widget_ = new Chart_widget(this);
    chart_accplot_control_ = new Chart_display_control( chart_accplot_widget_ );
    chart_accplot_widget_->set_controler(chart_accplot_control_);

	table_accplot_view_ = vtkSmartPointer<vtkQtTableView>::New();

	QVBoxLayout* accplot_layout = new QVBoxLayout(this);

	accplot_layout->addWidget(gout_); 
	this->setLayout(accplot_layout);
	
	ok = connect(gout_->getUI().line, SIGNAL(clicked()), this, SLOT(build_plot()));
	ok = connect(gout_->getUI().point, SIGNAL(clicked()), this, SLOT(build_plot()));

	this->build_value_table();
	this->build_plot();

	QTableView* table_accplot = dynamic_cast<QTableView*>(table_accplot_view_->GetWidget());
	qtable_accplot_ = table_accplot;

	ok = connect(
		table_accplot, SIGNAL(clicked(const QModelIndex &)), 
		this, SLOT(cutoff_selected(const QModelIndex &)));

	gout_->getUI().graphViewer->addWidget(chart_accplot_widget_);
	gout_->getUI().graphControl->addWidget(chart_accplot_control_);
	gout_->getUI().tabWidget->addTab(table_accplot, "Data");

	ok = connect(gout_->getUI().saveFigureButton, SIGNAL(clicked()), chart_accplot_widget_, SLOT(save_figure()));
	ok = connect(gout_->getUI().saveReportButton, SIGNAL(clicked()), this, SLOT(save_report()));
	ok = connect(gout_->getUI().viewReportButton, SIGNAL(clicked()), this, SLOT(view_report()));
	ok = connect(gout_->getUI().clear, SIGNAL(clicked()), this, SLOT(clear_chart()));
	ok = connect(gout_->getUI().importGraphsButton, SIGNAL(clicked()), this, SLOT(import_graphs()));

	is_ok = true;
	this->show();
	
}

void AccPlot_chart::save_report()
{
	QString fileName = QFileDialog::getSaveFileName(this, tr("Save File"),
		"report.csv",
		tr("CSV Files (*.csv)"));

	if (fileName.size() > 0) {
		QString msg;
		QTextStream output(&msg);

		write_table_accplot(output);

		FILE* fout = fopen(fileName.toStdString().c_str(), "w+");
		fprintf(fout, "%s\n", msg.toStdString().c_str());
		fclose(fout);
	}
}

void AccPlot_chart::view_report()
{
	AccPlotReport* report = new AccPlotReport(0);
	QString msg;
	QTextStream output(&msg, QIODevice::WriteOnly);

	write_table_accplot(output);

	report->setText(msg);
	report->show();
}

void AccPlot_chart::write_table_accplot(QTextStream& out)
{
	int nr = this->table_accplot_->GetNumberOfRows();
	int nc = this->table_accplot_->GetNumberOfColumns();

	for (int i = 0; i < nc; ++i) {
		if (i > 0) out << ", ";

		out << "\"" << QString(this->table_accplot_->GetColumnName(i)) << "\"";
	}
	out << "\n";

	for (int j = 0; j < nr; ++j) {
		for (int k = 0; k < nc; ++k) {
			if (k > 0) out << ", ";

			out << this->table_accplot_->GetValue(j, k).ToDouble();
		}
		out << "\n";
	}
}


void AccPlot_chart::import_graphs()
{
	QString file_name = QFileDialog::getOpenFileName(this, "Import graphs", "", tr("CSV Files (*.csv)"));

	if (file_name == "") return;

	std::ifstream fin(file_name.toStdString().c_str());

	if (fin.fail()) return;

	bool is_first = true;

	std::vector<std::string> titles;
	std::vector<std::vector<double> > data;

	size_t min_size = 0;
	while (!fin.eof()) {

		std::string line;
		std::getline(fin, line);

		std::vector<std::string> values = String_Op::decompose_string(line, ",");

		if (is_first) {
			is_first = false;
			titles = values;
			data.resize(values.size());
		}
		else {
			for (int i = 0; i < std::min(values.size(), data.size()); ++i) {
				double v = String_Op::to_number<double>(values[i]);
				data[i].push_back(v);
			}
		}
	}

	for (int i = 0; i < data.size(); ++i) {
		if (i == 0) {
			min_size = data[i].size();
		}
		else {
			min_size = std::min(min_size, data[i].size());
		}
	}

	std::vector<vtkSmartPointer<vtkFloatArray> > values(titles.size());
	vtkSmartPointer<vtkTable> table_values = vtkSmartPointer<vtkTable>::New();

	for (int i = 0; i < titles.size(); ++i) {
		values[i] = vtkSmartPointer<vtkFloatArray>::New();
		values[i]->SetName(titles[i].c_str());
		values[i]->SetNumberOfValues(min_size);
		for (int j = 0; j < min_size; ++j) {
			values[i]->SetValue(j, data[i][j]);
		}
		table_values->AddColumn(values[i]);
	}


	for (int i = 1; i < table_values->GetNumberOfColumns(); ++i) {

		if (gout_->getUI().line->isChecked()) {
			vtkPlotLine* plot_variog = vtkPlotLine::SafeDownCast(chart_accplot_widget_->chart()->AddPlot(vtkChart::LINE));

			plot_variog->SetInputData(table_values, 0, i);
			plot_variog->SetColor(0.0, 0.0, 1.0);
		}

		if (gout_->getUI().point->isChecked()) {
			vtkPlotPoints* plot_variog = vtkPlotPoints::SafeDownCast(chart_accplot_widget_->chart()->AddPlot(vtkChart::POINTS));

			plot_variog->SetInputData(table_values, 0, i);
			plot_variog->SetColor(0.0, 0.0, 1.0);
		}
	}

	fin.close();
	chart_accplot_widget_->update();
}

