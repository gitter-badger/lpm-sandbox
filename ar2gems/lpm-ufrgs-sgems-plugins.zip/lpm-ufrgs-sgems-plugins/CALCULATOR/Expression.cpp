/*
Implementa��o do plugin que efetua transforma��es nos dados utilizando uma linguagem script.

(c) 2013, LPM/UFRGS, P�ricles Lopes Machado
*/


/*
 * Expression.cpp
 * Implementation of functions used to build the syntax tree.
 */
#include "Expression.h"
 
#include "Parser.h"
#include "Lexer.h"

#include "calculator_action.h"

#include <stdlib.h>
 
int yyparse(SExpression **expression, yyscan_t scanner);

/**
 * @brief Allocates space for expression
 * @return The expression or NULL if not enough memory
 */
static SExpression *allocateExpression()
{
    SExpression *b = (SExpression *)malloc(sizeof *b);
 
    if (b == NULL)
        return NULL;
 
    b->type = eVALUE;
    b->value = 0;
 
    b->left = NULL;
    b->right = NULL;
	b->cond = NULL;
 
    return b;
}
 
SExpression *createNumber(double value)
{
    SExpression *b = allocateExpression();
 
    if (b == NULL)
        return NULL;
 
    b->type = eVALUE;
    b->value = value;
 
    return b;
}

SExpression *createString(char* str)
{
    SExpression *b = allocateExpression();
 
    if (b == NULL)
        return NULL;
 
    b->type = eSTRING;

	size_t l = strlen(str);

	b->str = (char*) malloc(l);
	strncpy(b->str, str + 1, l - 2);
	b->str[l - 2] = '\0';

    return b;
}

SExpression *createConditional(EOperationType type, SExpression *cond, SExpression *left, SExpression *right)
{
	SExpression *b = allocateExpression();
 
    if (b == NULL)
        return NULL;
 
    b->type = type;
	b->cond = cond;
    b->left = left;
    b->right = right;
 
    return b;
}
 
SExpression *createOperation(EOperationType type, SExpression *left, SExpression *right)
{
    SExpression *b = allocateExpression();
 
    if (b == NULL)
        return NULL;
 
    b->type = type;
    b->left = left;
    b->right = right;
	b->cond = NULL;
 
    return b;
}
 
void deleteExpression(SExpression *b)
{
    if (b == NULL)
        return;

	if (b->type == eSTRING) {
		free(b->str);
	}
 
	if (b->type == eFUNCTION) {
		delete b->func;
	}

	deleteExpression(b->cond);
    deleteExpression(b->left);
    deleteExpression(b->right);
 
    free(b);
}

SExpression* createFunction(EOperationType type, const char* fname, FuncArgs* func_args) 
{
    SExpression *b = allocateExpression();
 
    if (b == NULL) return NULL;
 
    b->type = type;
    b->func = new FExpression(fname, func_args);
    b->left = NULL;
    b->right = NULL;
    b->cond = NULL;
 
    return b;
}


SExpression *getAST(char *expr)
{
	init_library();
    SExpression *expression;
    yyscan_t scanner;
    YY_BUFFER_STATE state;
 
    if (yylex_init(&scanner)) {
        // couldn't initialize
        return NULL;
    }
 
    state = yy_scan_string(expr, scanner);
 
    if (yyparse(&expression, scanner)) {
        // error parsing
        return NULL;
    }
 
    yy_delete_buffer(state, scanner);
 
    yylex_destroy(scanner);
 
    return expression;
}
 
double evaluate(SExpression *e, MapVar* m, int i, QTextStream& out, int n_props)
{
    switch (e->type) {
        case eVALUE:
            //out << " VALUE " << e->value << endl;
            return e->value;
        case eMULTIPLY:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return a * b;
				} else {
					return INF;
				}
			}
		case eSTRING:
			//out << "STR = <" << e->str << ">\n"; 
			if (m->find(e->str) != m->end()) {
				if (m->at(e->str)->is_informed(i)) {
					return m->at(e->str)->get_value(i);
				} else {
					return INF;
				}
			} else {
				return INF;
			}
        case ePLUS:
            {
                double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

                //out << " PLUS " << a << " + " << b << endl;

				if (a < INF && b < INF) {
                    //out << " PLUS = " << a + b << endl;
					return a + b;
				} else {
                    //out << " PLUS = INF \n";
					return INF;
				}
			}

		case eDIV:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return a / b;
				} else {
					return INF;
				}
			}
		case eSUB:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return a - b;
				} else {
					return INF;
				}
			}
		case eMOD:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return fmod(a, b);
				} else {
					return INF;
				}
			}
		case ePOW:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return pow(a, b);
				} else {
					return INF;
				}
			}
		case eNEG:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				
				if (a < INF) {
					return -a;
				} else {
					return INF;
				}
			}

		
		case eAND:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return int(a) && int(b);
				} else {
					return INF;
				}
			}
		case eOR:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return int(a) || int(b);
				} else {
					return INF;
				}
			}
		case eNOT:
			{
				double a = evaluate(e->left, m, i, out, n_props);
			
				if (a < INF) {
					return !int(a);
				} else {
					return INF;
				}
			}
		case eLE:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return a < b;
				} else {
					return INF;
				}
			}
		case eGE:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return a > b;
				} else {
					return INF;
				}
			}
		case eLEQ:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return a <= b;
				} else {
					return INF;
				}
			}
		case eGEQ:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return a >= b;
				} else {
					return INF;
				}
			}
		case eEQ:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return fabs(a-b) < 1e-9;
				} else {
					return INF;
				}
			}
		case eDIFF:
			{
				double a = evaluate(e->left, m, i, out, n_props);
				double b = evaluate(e->right, m, i, out, n_props);

				if (a < INF && b < INF) {
					return !(fabs(a-b) < 1e-9);
				} else {
					return INF;
				}
			}
		case eIF:
			{
				double c = evaluate(e->cond, m, i, out, n_props);
				
				if (c < INF) {
					if (int(c)) {
						double a = evaluate(e->left, m, i, out, n_props);
						return a;
					} else {
						double b = evaluate(e->right, m, i, out, n_props);
						return b;
					}
				} else {
					return INF;
				}
			}
		case eFUNCTION:
			{
				return e->func->evaluate(m, i, out, n_props);
			}
        default:
            // shouldn't be here
            return 0;
    }
}


