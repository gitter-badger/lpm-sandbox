#ifndef DRILLHOLE_H
#define DRILLHOLE_H

#include <vector>

struct Struct_Drillhole {

	int BHID;

	double X_Centroid;
	double Y_Centroid;
	double Z_Centroid;

	std::vector<double> X_Locations;
	std::vector<double> Y_Locations;
	std::vector<double> Z_Locations;
	std::vector<double> Grades;
	std::vector<int> Node_ID;



	

	double Average;
	
}
;

#endif