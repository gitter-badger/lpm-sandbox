
# include <vector>
# include <map>
# include "Create_Block_To_Block_Covariance_Lookup_Table.h"
# include <grid/geostat_grid.h>

using namespace std;

typedef Geostat_grid::location_type Location;

vector<vector<double> > Create_Block_To_Block_Covariance_Lookup_Table(const vector<vector<double> > &Point_To_Block_Covariance_Lookup_Table, Geostat_grid *Block_Centroids_Point_Set, const std::map<int, Struct_Block> &Map_ID_Blocks){

	vector<vector<double> > Block_To_Block_Covariance_Lookup_Table;
	//get node_id of the First block
	for (size_t i = 0; i < Block_Centroids_Point_Set->size(); ++i){

		int node_id_Block_i = i;
		vector<double> Block_To_Block_Covariance_Lookup_Table_Row;

		for (size_t j = 0; j < Block_Centroids_Point_Set->size(); ++j){
			//get node_ids of all the points the make the block_j
			int Block_ID = Block_Centroids_Point_Set->property("Block_ID")->get_value(j);
			
			vector<int> node_ids;
			for (size_t k = 0; k < Map_ID_Blocks.at(Block_ID).X_Locations.size(); ++k){
				node_ids.push_back(Map_ID_Blocks.at(Block_ID).node_id[k]);
			}

			//Average the point-to-block covariance lookup table
			double sum_block_to_block_covariance = 0;
			double block_to_block_covariance;
			int ncov = 0;
			int point_of_block_j_node_id = 0;
			for (size_t l = 0; l < node_ids.size(); ++l){
				point_of_block_j_node_id = node_ids[l];
				sum_block_to_block_covariance = sum_block_to_block_covariance + Point_To_Block_Covariance_Lookup_Table[point_of_block_j_node_id][i];
				ncov = ncov + 1;
			}
			block_to_block_covariance = sum_block_to_block_covariance / ncov;

			Block_To_Block_Covariance_Lookup_Table_Row.push_back(block_to_block_covariance);
		}

		Block_To_Block_Covariance_Lookup_Table.push_back(Block_To_Block_Covariance_Lookup_Table_Row);
	}
	return Block_To_Block_Covariance_Lookup_Table;
};